//
// File: USV.cpp
//
// Code generated for Simulink model 'USV'.
//
// Model version                  : 10.49
// Simulink Coder version         : 9.7 (R2022a) 13-Nov-2021
// C/C++ source code generated on : Thu Sep 22 23:56:13 2022
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#include "USV.h"
#include "rtwtypes.h"
#include <cmath>
#include <cstring>
#include <cfloat>
#include <stddef.h>
#define NumBitsPerChar                 8U

// Private macros used by the generated code to access rtModel
#ifndef rtmSetFirstInitCond
#define rtmSetFirstInitCond(rtm, val)  ((rtm)->Timing.firstInitCondFlag = (val))
#endif

#ifndef rtmIsFirstInitCond
#define rtmIsFirstInitCond(rtm)        ((rtm)->Timing.firstInitCondFlag)
#endif

#ifndef rtmIsMajorTimeStep
#define rtmIsMajorTimeStep(rtm)        (((rtm)->Timing.simTimeStep) == MAJOR_TIME_STEP)
#endif

#ifndef rtmIsMinorTimeStep
#define rtmIsMinorTimeStep(rtm)        (((rtm)->Timing.simTimeStep) == MINOR_TIME_STEP)
#endif

#ifndef rtmSetTPtr
#define rtmSetTPtr(rtm, val)           ((rtm)->Timing.t = (val))
#endif

#ifndef GRAVITY2_TYPEDEF

typedef enum { WGS84TAYLORSERIES = 1, WGS84CLOSEAPPROX,
  WGS84EXACT } GravityTypeIdx;

typedef enum { METRIC = 1, ENGLISH } UnitIdx;

typedef enum { JANUARY = 1, FEBRUARY, MARCH, APRIL, MAY, JUNE, JULY,
  AUGUST, SEPTEMBER, OCTOBER, NOVEMBER, DECEMBER } MonthIdx;

#define GRAVITY2_TYPEDEF
#endif                                 // GRAVITY2_TYPEDEF

#ifndef WGS84_DEFINE
#define WGS84_A                        6378137.0                 // Semi-major Axis (m) 
#define WGS84_INV_F                    298.257223563             // Reciprocal of Flattening 
#define WGS84_W_DEF                    7292115.0e-11             // WGS 84 Angular Velocity of Earth (rad/sec)
#define WGS84_GM_DEF                   3986004.418e+8            // Earth's Gravitational Const. (m^3/sec^2) 
#define WGS84_GM_PRM                   3986000.9e+8              // Earth's Grav. Const. (m^3/sec^2) [no atmos]
#define WGS84_W_PRM                    7292115.1467e-11          // IAU Angular Velocity of Earth (rad/sec) 
#define WGS84_G_E                      9.7803253359              // Theoretical (Normal) Gravity at the Equator
                                                                 // (on the Ellipsoid) (m/s^2) 
#define WGS84_K                        0.00193185265241          // Theoretical (Normal) Gravity Formula Const.
#define WGS84_E_2                      6.69437999014e-3          // First Eccentricity Squared 
#define WGS84_EL                       5.2185400842339e+5        // Linear Eccentricity 
#define WGS84_B                        6356752.3142              // Semi-minor Axis (m) 
#define WGS84_B_A                      0.996647189335            // Axis Ratio
#define M2FT                           1.0/0.3048
#define AERO_PI                        3.14159265358979323846
#define DEG2RAD                        AERO_PI/180.0
#define YEAR2000                       2000
#define WGS84_DEFINE
#endif                                 // WGS84_DEFINE

// Block parameters (default storage)
P_USV_T MulticopterModelClass::USV_P = {
  // Variable: USVPara
  //  Referenced by: '<S192>/USVPara_Dmat'

  {
    { -0.4, 1.03, 0.2 },

    { -0.4, -1.03, 0.2 },
    562.1,
    0.213,
    0.2,
    4.9,
    2.4,
    1.0,
    997.8,

    { 5.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 5.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.1,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.1, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.1, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0, 1.0 },

    { 30.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 300.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      300.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 600.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      600.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 300.0 }
  },

  // Variable: FaultParamAPI
  //  Referenced by:
  //    '<S50>/Constant'
  //    '<S50>/Gain'
  //    '<S54>/Gust start time'
  //    '<S100>/Wind direction'
  //    '<S100>/Windspeed at 20ft (6m)'
  //    '<S101>/Wind direction'
  //    '<S101>/Windspeed at 20ft (6m)'
  //    '<S110>/Wind Direction'
  //    '<S110>/Wind speed at reference height'
  //    '<S432>/2*zeta * wn'
  //    '<S443>/2*zeta * wn'

  {
    { 1.0, 2.0, 2.0, 3.0, 1.0, 3.0, 1.0, 2.0, 1.0, 0.707, 0.0, 0.0, 0.0, 0.707,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0 }
  },

  // Variable: ESCFault
  //  Referenced by: '<S50>/MotorNum'

  {
    123451.0,
    4
  },

  // Variable: BoatParam_cf
  //  Referenced by: '<S194>/BoatParam_cf'

  0.1,

  // Variable: BoatParam_cg
  //  Referenced by: '<S4>/Constant1'

  0.1,

  // Variable: BoatParam_len
  //  Referenced by: '<S194>/BoatParam_len'

  1.5,

  // Variable: BoatParam_lenSlope
  //  Referenced by: '<S194>/BoatParam_lenSlope'

  0.52359877559829882,

  // Variable: BoatParam_waterDensity
  //  Referenced by: '<S194>/BoatParam_waterDensity'

  1000.0,

  // Variable: BoatParam_widSlope
  //  Referenced by: '<S194>/BoatParam_widSlope'

  0.78539816339744828,

  // Variable: BoatParam_width
  //  Referenced by: '<S194>/BoatParam_width'

  0.8,

  // Variable: ModelInit_AngEuler
  //  Referenced by: '<S10>/Initial Euler Angles'

  { 0.0, 0.0, 0.0 },

  // Variable: ModelInit_PosE
  //  Referenced by: '<S9>/xe,ye,ze'

  { 0.0, 0.0, 0.0 },

  // Variable: ModelInit_RateB
  //  Referenced by: '<S9>/p,q,r '

  { 0.0, 0.0, 0.0 },

  // Variable: ModelInit_VelB
  //  Referenced by: '<S9>/ub,vb,wb'

  { 0.0, 0.0, 0.0 },

  // Variable: ModelParam_GPSEphFinal
  //  Referenced by: '<S331>/ModelParam.GPSEphFinal'

  0.3,

  // Variable: ModelParam_GPSEpvFinal
  //  Referenced by: '<S331>/ModelParam.GPSEpvFinal'

  0.4,

  // Variable: ModelParam_GPSLatLong
  //  Referenced by:
  //    '<S69>/ref_position'
  //    '<S378>/ref_position'

  { 40.1540302, 116.2593683 },

  // Variable: ModelParam_envAltitude
  //  Referenced by:
  //    '<S3>/ModelParam.envAltitude'
  //    '<S373>/ModelParam.envAltitude'

  -600.0,

  // Variable: ModelParam_noisePowerOffGainAccel
  //  Referenced by: '<S402>/AccelNoiseGainFunction'

  0.04,

  // Variable: ModelParam_noisePowerOffGainAccelZ
  //  Referenced by: '<S402>/AccelNoiseGainFunction'

  0.03,

  // Variable: ModelParam_noisePowerOffGainGyro
  //  Referenced by: '<S402>/GyroNoiseGainFunction'

  0.02,

  // Variable: ModelParam_noisePowerOffGainGyroZ
  //  Referenced by: '<S402>/GyroNoiseGainFunction'

  0.025,

  // Variable: ModelParam_noisePowerOffGainMag
  //  Referenced by: '<S402>/MagNoiseGainFunction'

  0.02,

  // Variable: ModelParam_noisePowerOffGainMagZ
  //  Referenced by: '<S402>/MagNoiseGainFunction'

  0.035,

  // Variable: ModelParam_noisePowerOnGainAccel
  //  Referenced by: '<S402>/AccelNoiseGainFunction'

  0.8,

  // Variable: ModelParam_noisePowerOnGainAccelZ
  //  Referenced by: '<S402>/AccelNoiseGainFunction'

  4.5,

  // Variable: ModelParam_noisePowerOnGainGyro
  //  Referenced by: '<S402>/GyroNoiseGainFunction'

  2.0,

  // Variable: ModelParam_noisePowerOnGainGyroZ
  //  Referenced by: '<S402>/GyroNoiseGainFunction'

  1.0,

  // Variable: ModelParam_noisePowerOnGainMag
  //  Referenced by: '<S402>/MagNoiseGainFunction'

  0.025,

  // Variable: ModelParam_noisePowerOnGainMagZ
  //  Referenced by: '<S402>/MagNoiseGainFunction'

  0.05,

  // Variable: ModelParam_uavCCm
  //  Referenced by: '<S192>/ModelParam.uavCCm'

  { 200.0, 200.0, 200.0 },

  // Variable: ModelParam_uavCd
  //  Referenced by: '<S192>/ModelParam.uavCd'

  { 2.0, 200.0, 200.0 },

  // Variable: ModelParam_uavJ
  //  Referenced by: '<S12>/Constant1'

  { 181.42, 0.0, 0.0, 0.0, 408.203, 0.0, 0.0, 0.0, 495.037 },

  // Variable: ModelParam_uavMass
  //  Referenced by:
  //    '<S4>/ModelParam.uavMass'
  //    '<S8>/ModelParam.uavMass'
  //    '<S194>/ModelParam.uavMass'
  //    '<S12>/Constant'

  227.0,

  // Variable: ModelParam_uavType
  //  Referenced by: '<S8>/UAVType'

  608,

  // Mask Parameter: Motor1_MotorPara
  //  Referenced by:
  //    '<S198>/isEnable'
  //    '<S198>/maxRotVelocity'
  //    '<S198>/momentConstant'
  //    '<S198>/motorConstant'
  //    '<S198>/pose'
  //    '<S198>/pose: 1 * 6'
  //    '<S198>/reversible'
  //    '<S198>/rollingMomentCoefficient'
  //    '<S198>/rotorDragCoefficient'
  //    '<S198>/rotorVelocitySlowdownSim'
  //    '<S198>/rotorVelocitySlowdownSim1'
  //    '<S198>/timeConstantDown'
  //    '<S198>/timeConstantUp'
  //    '<S198>/turningDirection'
  //    '<S198>/turningDirection1'

  {
    true,
    1.0,

    { -2.65193, 1.02713, -0.06, 0.0, 1.57079, 0.0 },
    1.0,
    1.0,
    0.0125,
    0.025,
    1100.0,
    0.0454858,
    0.01,
    0.000806428,
    1.0e-6,
    10.0
  },

  // Mask Parameter: Motor2_MotorPara
  //  Referenced by:
  //    '<S199>/isEnable'
  //    '<S199>/maxRotVelocity'
  //    '<S199>/momentConstant'
  //    '<S199>/motorConstant'
  //    '<S199>/pose'
  //    '<S199>/pose: 1 * 6'
  //    '<S199>/reversible'
  //    '<S199>/rollingMomentCoefficient'
  //    '<S199>/rotorDragCoefficient'
  //    '<S199>/rotorVelocitySlowdownSim'
  //    '<S199>/rotorVelocitySlowdownSim1'
  //    '<S199>/timeConstantDown'
  //    '<S199>/timeConstantUp'
  //    '<S199>/turningDirection'
  //    '<S199>/turningDirection1'

  {
    true,
    1.0,

    { -2.65193, -1.02713, -0.06, 0.0, 1.57079, 0.0 },
    1.0,
    1.0,
    0.0125,
    0.025,
    1100.0,
    0.0454858,
    0.01,
    0.000806428,
    1.0e-6,
    10.0
  },

  // Mask Parameter: Motor3_MotorPara
  //  Referenced by:
  //    '<S200>/isEnable'
  //    '<S200>/maxRotVelocity'
  //    '<S200>/momentConstant'
  //    '<S200>/motorConstant'
  //    '<S200>/pose'
  //    '<S200>/pose: 1 * 6'
  //    '<S200>/reversible'
  //    '<S200>/rollingMomentCoefficient'
  //    '<S200>/rotorDragCoefficient'
  //    '<S200>/rotorVelocitySlowdownSim'
  //    '<S200>/rotorVelocitySlowdownSim1'
  //    '<S200>/timeConstantDown'
  //    '<S200>/timeConstantUp'
  //    '<S200>/turningDirection'
  //    '<S200>/turningDirection1'

  {
    false,
    1.0,

    { -2.65193, 1.02713, 0.0, 0.0, 1.57079, 0.0 },
    0.0,
    -1.0,
    0.0125,
    0.025,
    1100.0,
    0.0454858,
    0.01,
    0.000806428,
    1.0e-6,
    10.0
  },

  // Mask Parameter: Motor4_MotorPara
  //  Referenced by:
  //    '<S201>/isEnable'
  //    '<S201>/maxRotVelocity'
  //    '<S201>/momentConstant'
  //    '<S201>/motorConstant'
  //    '<S201>/pose'
  //    '<S201>/pose: 1 * 6'
  //    '<S201>/reversible'
  //    '<S201>/rollingMomentCoefficient'
  //    '<S201>/rotorDragCoefficient'
  //    '<S201>/rotorVelocitySlowdownSim'
  //    '<S201>/rotorVelocitySlowdownSim1'
  //    '<S201>/timeConstantDown'
  //    '<S201>/timeConstantUp'
  //    '<S201>/turningDirection'
  //    '<S201>/turningDirection1'

  {
    false,
    1.0,

    { -2.65193, 1.02713, 0.0, 0.0, 1.57079, 0.0 },
    0.0,
    -1.0,
    0.0125,
    0.025,
    1100.0,
    0.0454858,
    0.01,
    0.000806428,
    1.0e-6,
    10.0
  },

  // Mask Parameter: Motor5_MotorPara
  //  Referenced by:
  //    '<S202>/isEnable'
  //    '<S202>/maxRotVelocity'
  //    '<S202>/momentConstant'
  //    '<S202>/motorConstant'
  //    '<S202>/pose'
  //    '<S202>/pose: 1 * 6'
  //    '<S202>/reversible'
  //    '<S202>/rollingMomentCoefficient'
  //    '<S202>/rotorDragCoefficient'
  //    '<S202>/rotorVelocitySlowdownSim'
  //    '<S202>/rotorVelocitySlowdownSim1'
  //    '<S202>/timeConstantDown'
  //    '<S202>/timeConstantUp'
  //    '<S202>/turningDirection'
  //    '<S202>/turningDirection1'

  {
    false,
    1.0,

    { -2.65193, 1.02713, 0.0, 0.0, 1.57079, 0.0 },
    0.0,
    -1.0,
    0.0125,
    0.025,
    1100.0,
    0.0454858,
    0.01,
    0.000806428,
    1.0e-6,
    10.0
  },

  // Mask Parameter: Motor6_MotorPara
  //  Referenced by:
  //    '<S203>/isEnable'
  //    '<S203>/maxRotVelocity'
  //    '<S203>/momentConstant'
  //    '<S203>/motorConstant'
  //    '<S203>/pose'
  //    '<S203>/pose: 1 * 6'
  //    '<S203>/reversible'
  //    '<S203>/rollingMomentCoefficient'
  //    '<S203>/rotorDragCoefficient'
  //    '<S203>/rotorVelocitySlowdownSim'
  //    '<S203>/rotorVelocitySlowdownSim1'
  //    '<S203>/timeConstantDown'
  //    '<S203>/timeConstantUp'
  //    '<S203>/turningDirection'
  //    '<S203>/turningDirection1'

  {
    false,
    1.0,

    { -2.65193, 1.02713, 0.0, 0.0, 1.57079, 0.0 },
    0.0,
    -1.0,
    0.0125,
    0.025,
    1100.0,
    0.0454858,
    0.01,
    0.000806428,
    1.0e-6,
    10.0
  },

  // Mask Parameter: Motor7_MotorPara
  //  Referenced by:
  //    '<S204>/isEnable'
  //    '<S204>/maxRotVelocity'
  //    '<S204>/momentConstant'
  //    '<S204>/motorConstant'
  //    '<S204>/pose'
  //    '<S204>/pose: 1 * 6'
  //    '<S204>/reversible'
  //    '<S204>/rollingMomentCoefficient'
  //    '<S204>/rotorDragCoefficient'
  //    '<S204>/rotorVelocitySlowdownSim'
  //    '<S204>/rotorVelocitySlowdownSim1'
  //    '<S204>/timeConstantDown'
  //    '<S204>/timeConstantUp'
  //    '<S204>/turningDirection'
  //    '<S204>/turningDirection1'

  {
    false,
    1.0,

    { -2.65193, 1.02713, 0.0, 0.0, 1.57079, 0.0 },
    0.0,
    -1.0,
    0.0125,
    0.025,
    1100.0,
    0.0454858,
    0.01,
    0.000806428,
    1.0e-6,
    10.0
  },

  // Mask Parameter: Motor8_MotorPara
  //  Referenced by:
  //    '<S205>/isEnable'
  //    '<S205>/maxRotVelocity'
  //    '<S205>/momentConstant'
  //    '<S205>/motorConstant'
  //    '<S205>/pose'
  //    '<S205>/pose: 1 * 6'
  //    '<S205>/reversible'
  //    '<S205>/rollingMomentCoefficient'
  //    '<S205>/rotorDragCoefficient'
  //    '<S205>/rotorVelocitySlowdownSim'
  //    '<S205>/rotorVelocitySlowdownSim1'
  //    '<S205>/timeConstantDown'
  //    '<S205>/timeConstantUp'
  //    '<S205>/turningDirection'
  //    '<S205>/turningDirection1'

  {
    false,
    1.0,

    { -2.65193, 1.02713, 0.0, 0.0, 1.57079, 0.0 },
    0.0,
    -1.0,
    0.0125,
    0.025,
    1100.0,
    0.0454858,
    0.01,
    0.000806428,
    1.0e-6,
    10.0
  },

  // Mask Parameter: ESC1_MotorPara
  //  Referenced by:
  //    '<S61>/input_offset'
  //    '<S61>/input_scaling'
  //    '<S61>/isEnable'
  //    '<S61>/zero_position_armed'
  //    '<S61>/zero_position_disarmed'

  {
    true,
    0.0,
    100.0,
    0.0,
    0.0,
    0.0
  },

  // Mask Parameter: ESC2_MotorPara
  //  Referenced by:
  //    '<S62>/input_offset'
  //    '<S62>/input_scaling'
  //    '<S62>/isEnable'
  //    '<S62>/zero_position_armed'
  //    '<S62>/zero_position_disarmed'

  {
    true,
    0.0,
    100.0,
    0.0,
    0.0,
    0.0
  },

  // Mask Parameter: ESC3_MotorPara
  //  Referenced by:
  //    '<S63>/input_offset'
  //    '<S63>/input_scaling'
  //    '<S63>/isEnable'
  //    '<S63>/zero_position_armed'
  //    '<S63>/zero_position_disarmed'

  {
    false,
    0.0,
    100.0,
    0.0,
    0.0,
    0.0
  },

  // Mask Parameter: ESC4_MotorPara
  //  Referenced by:
  //    '<S64>/input_offset'
  //    '<S64>/input_scaling'
  //    '<S64>/isEnable'
  //    '<S64>/zero_position_armed'
  //    '<S64>/zero_position_disarmed'

  {
    false,
    0.0,
    100.0,
    0.0,
    0.0,
    0.0
  },

  // Mask Parameter: ESC5_MotorPara
  //  Referenced by:
  //    '<S65>/input_offset'
  //    '<S65>/input_scaling'
  //    '<S65>/isEnable'
  //    '<S65>/zero_position_armed'
  //    '<S65>/zero_position_disarmed'

  {
    false,
    0.0,
    100.0,
    0.0,
    0.0,
    0.0
  },

  // Mask Parameter: ESC6_MotorPara
  //  Referenced by:
  //    '<S66>/input_offset'
  //    '<S66>/input_scaling'
  //    '<S66>/isEnable'
  //    '<S66>/zero_position_armed'
  //    '<S66>/zero_position_disarmed'

  {
    false,
    0.0,
    100.0,
    0.0,
    0.0,
    0.0
  },

  // Mask Parameter: ESC7_MotorPara
  //  Referenced by:
  //    '<S67>/input_offset'
  //    '<S67>/input_scaling'
  //    '<S67>/isEnable'
  //    '<S67>/zero_position_armed'
  //    '<S67>/zero_position_disarmed'

  {
    false,
    0.0,
    100.0,
    0.0,
    0.0,
    0.0
  },

  // Mask Parameter: ESC8_MotorPara
  //  Referenced by:
  //    '<S68>/input_offset'
  //    '<S68>/input_scaling'
  //    '<S68>/isEnable'
  //    '<S68>/zero_position_armed'
  //    '<S68>/zero_position_disarmed'

  {
    false,
    0.0,
    100.0,
    0.0,
    0.0,
    0.0
  },

  // Mask Parameter: BandLimitedWhiteNoise_Cov
  //  Referenced by: '<S53>/Output'

  1.0,

  // Mask Parameter: DrydenWindTurbulenceModelDiscre
  //  Referenced by: '<S187>/Medium//High Altitude'

  533.4,

  // Mask Parameter: DrydenWindTurbulenceModelDisc_i
  //  Referenced by: '<S148>/Medium//High Altitude'

  533.4,

  // Mask Parameter: DrydenWindTurbulenceModelDisc_g
  //  Referenced by: '<S161>/White Noise'

  { 23301.0, 23542.0, 82443.0, 33344.0 },

  // Mask Parameter: DrydenWindTurbulenceModelDisc_m
  //  Referenced by: '<S122>/White Noise'

  { 23341.0, 23342.0, 23343.0, 23344.0 },

  // Mask Parameter: DrydenWindTurbulenceModelDisc_f
  //  Referenced by:
  //    '<S151>/Constant1'
  //    '<S151>/Constant2'
  //    '<S151>/Constant3'
  //    '<S152>/Constant3'

  1.0,

  // Mask Parameter: DrydenWindTurbulenceModelDisc_a
  //  Referenced by:
  //    '<S112>/Constant1'
  //    '<S112>/Constant2'
  //    '<S112>/Constant3'
  //    '<S113>/Constant3'

  1.0,

  // Mask Parameter: WhiteNoise_Ts
  //  Referenced by: '<S161>/Constant1'

  0.01,

  // Mask Parameter: WhiteNoise_Ts_b
  //  Referenced by: '<S122>/Constant1'

  0.01,

  // Mask Parameter: DrydenWindTurbulenceModelDisc_n
  //  Referenced by: '<S168>/Probability of  Exceedance'

  3.0,

  // Mask Parameter: DrydenWindTurbulenceModelDisc_d
  //  Referenced by: '<S129>/Probability of  Exceedance'

  4.0,

  // Mask Parameter: DrydenWindTurbulenceModelDisc_l
  //  Referenced by: '<S100>/Wingspan'

  1.0,

  // Mask Parameter: DrydenWindTurbulenceModelDis_dk
  //  Referenced by: '<S101>/Wingspan'

  1.0,

  // Mask Parameter: ThreeaxisInertialMeasurementUni
  //  Referenced by: '<S426>/Measurement bias'

  { 0.0, 0.0, 0.0 },

  // Mask Parameter: ThreeaxisInertialMeasurementU_n
  //  Referenced by: '<S426>/Scale factors & Cross-coupling  errors'

  { 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0 },

  // Mask Parameter: DirectionCosineMatrixtoQuaterni
  //  Referenced by:
  //    '<S337>/Constant'
  //    '<S362>/Constant'
  //    '<S363>/Constant'

  1.0,

  // Mask Parameter: CompareToConstant_const
  //  Referenced by: '<S88>/Constant'

  180.0,

  // Mask Parameter: CompareToConstant_const_j
  //  Referenced by: '<S86>/Constant'

  90.0,

  // Mask Parameter: CompareToConstant_const_b
  //  Referenced by: '<S89>/Constant'

  180.0,

  // Mask Parameter: CompareToConstant_const_n
  //  Referenced by: '<S82>/Constant'

  180.0,

  // Mask Parameter: CompareToConstant_const_i
  //  Referenced by: '<S80>/Constant'

  90.0,

  // Mask Parameter: CompareToConstant_const_e
  //  Referenced by: '<S83>/Constant'

  180.0,

  // Mask Parameter: CompareToConstant_const_h
  //  Referenced by: '<S459>/Constant'

  180.0,

  // Mask Parameter: CompareToConstant_const_k
  //  Referenced by: '<S457>/Constant'

  90.0,

  // Mask Parameter: CompareToConstant_const_ee
  //  Referenced by: '<S460>/Constant'

  180.0,

  // Mask Parameter: CompareToConstant_const_a
  //  Referenced by: '<S394>/Constant'

  180.0,

  // Mask Parameter: CompareToConstant_const_a2
  //  Referenced by: '<S392>/Constant'

  90.0,

  // Mask Parameter: CompareToConstant_const_d
  //  Referenced by: '<S395>/Constant'

  180.0,

  // Mask Parameter: CompareToConstant_const_ew
  //  Referenced by: '<S388>/Constant'

  180.0,

  // Mask Parameter: CompareToConstant_const_l
  //  Referenced by: '<S386>/Constant'

  90.0,

  // Mask Parameter: CompareToConstant_const_an
  //  Referenced by: '<S389>/Constant'

  180.0,

  // Mask Parameter: Distanceintogustx_d_m
  //  Referenced by: '<S57>/Distance into Gust (x) (Limited to gust length d)'

  120.0,

  // Mask Parameter: Distanceintogusty_d_m
  //  Referenced by: '<S54>/Distance into gust (y)'

  120.0,

  // Mask Parameter: Distanceintogustz_d_m
  //  Referenced by: '<S54>/Distance into gust (z)'

  80.0,

  // Mask Parameter: DiscreteWindGustModel_d_m
  //  Referenced by: '<S54>/pi//Gust length'

  { 120.0, 120.0, 80.0 },

  // Mask Parameter: ThreeaxisInertialMeasurementU_b
  //  Referenced by: '<S427>/Measurement bias'

  { 0.0, 0.0, 0.0 },

  // Mask Parameter: ThreeaxisInertialMeasurementU_o
  //  Referenced by: '<S427>/g-sensitive bias'

  { 0.0, 0.0, 0.0 },

  // Mask Parameter: ThreeaxisInertialMeasurementU_f
  //  Referenced by: '<S427>/Scale factors & Cross-coupling  errors '

  { 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0 },

  // Mask Parameter: ThreeaxisInertialMeasurementU_j
  //  Referenced by: '<S426>/wl_ins'

  { 0.0, 0.0, 0.0 },

  // Mask Parameter: CustomVariableMass6DOFQuaternio
  //  Referenced by: '<S21>/High Gain Quaternion Normalization'

  1.0,

  // Mask Parameter: CheckAltitude_max
  //  Referenced by: '<S444>/max_val'

  850000.0,

  // Mask Parameter: CheckLatitude_max
  //  Referenced by: '<S445>/max_val'

  90.0,

  // Mask Parameter: CheckLongitude_max
  //  Referenced by: '<S446>/max_val'

  180.0,

  // Mask Parameter: Istimewithinmodellimits_max
  //  Referenced by: '<S448>/max_val'

  5.0,

  // Mask Parameter: CheckAltitude_min
  //  Referenced by: '<S444>/min_val'

  -1000.0,

  // Mask Parameter: CheckLatitude_min
  //  Referenced by: '<S445>/min_val'

  -90.0,

  // Mask Parameter: CheckLongitude_min
  //  Referenced by: '<S446>/min_val'

  -180.0,

  // Mask Parameter: Istimewithinmodellimits_min
  //  Referenced by: '<S448>/min_val'

  0.0,

  // Mask Parameter: FlatEarthtoLLA_psi
  //  Referenced by: '<S69>/ref_rotation'

  0.0,

  // Mask Parameter: FlatEarthtoLLA_psi_h
  //  Referenced by: '<S378>/ref_rotation'

  0.0,

  // Mask Parameter: WhiteNoise_pwr
  //  Referenced by: '<S161>/Constant'

  { 0.01, 0.01, 0.01, 0.01 },

  // Mask Parameter: WhiteNoise_pwr_m
  //  Referenced by: '<S122>/Constant'

  { 0.01, 0.01, 0.01, 0.01 },

  // Mask Parameter: BandLimitedWhiteNoise_seed
  //  Referenced by: '<S53>/White Noise'

  23341.0,

  // Mask Parameter: DirectionCosineMatrixtoQuater_d
  //  Referenced by:
  //    '<S370>/Constant'
  //    '<S372>/Constant'

  4.4408920985006262E-16,

  // Mask Parameter: DiscreteWindGustModel_v_m
  //  Referenced by: '<S54>/Gust magnitude//2.0'

  { 3.5, 3.5, 3.0 },

  // Mask Parameter: ThreeaxisInertialMeasurementU_a
  //  Referenced by:
  //    '<S432>/2*zeta * wn'
  //    '<S432>/wn^2'

  190.0,

  // Mask Parameter: ThreeaxisInertialMeasurement_jf
  //  Referenced by:
  //    '<S443>/2*zeta * wn'
  //    '<S443>/wn^2'

  190.0,

  // Mask Parameter: DiscreteWindGustModel_Gx
  //  Referenced by: '<S54>/Constant'

  true,

  // Mask Parameter: DiscreteWindGustModel_Gy
  //  Referenced by: '<S54>/Constant1'

  true,

  // Mask Parameter: DiscreteWindGustModel_Gz
  //  Referenced by: '<S54>/Constant2'

  true,

  // Expression: 1
  //  Referenced by: '<S38>/Constant'

  1.0,

  // Expression: 1
  //  Referenced by: '<S39>/Constant'

  1.0,

  // Expression: [0]
  //  Referenced by: '<S57>/x'

  0.0,

  // Expression: 0
  //  Referenced by: '<S57>/Distance into Gust (x) (Limited to gust length d)'

  0.0,

  // Expression: 0
  //  Referenced by: '<S57>/Distance into Gust (x) (Limited to gust length d)'

  0.0,

  // Expression: 0
  //  Referenced by: '<S61>/Constant'

  0.0,

  // Expression: 0
  //  Referenced by: '<S61>/Switch2'

  0.0,

  // Expression: 0
  //  Referenced by: '<S61>/Constant1'

  0.0,

  // Expression: 0
  //  Referenced by: '<S62>/Constant'

  0.0,

  // Expression: 0
  //  Referenced by: '<S62>/Switch2'

  0.0,

  // Expression: 0
  //  Referenced by: '<S62>/Constant1'

  0.0,

  // Expression: 0
  //  Referenced by: '<S63>/Constant'

  0.0,

  // Expression: 0
  //  Referenced by: '<S63>/Switch2'

  0.0,

  // Expression: 0
  //  Referenced by: '<S63>/Constant1'

  0.0,

  // Expression: 0
  //  Referenced by: '<S64>/Constant'

  0.0,

  // Expression: 0
  //  Referenced by: '<S64>/Switch2'

  0.0,

  // Expression: 0
  //  Referenced by: '<S64>/Constant1'

  0.0,

  // Expression: 0
  //  Referenced by: '<S65>/Constant'

  0.0,

  // Expression: 0
  //  Referenced by: '<S65>/Switch2'

  0.0,

  // Expression: 0
  //  Referenced by: '<S65>/Constant1'

  0.0,

  // Expression: 0
  //  Referenced by: '<S66>/Constant'

  0.0,

  // Expression: 0
  //  Referenced by: '<S66>/Switch2'

  0.0,

  // Expression: 0
  //  Referenced by: '<S66>/Constant1'

  0.0,

  // Expression: 0
  //  Referenced by: '<S67>/Constant'

  0.0,

  // Expression: 0
  //  Referenced by: '<S67>/Switch2'

  0.0,

  // Expression: 0
  //  Referenced by: '<S67>/Constant1'

  0.0,

  // Expression: 0
  //  Referenced by: '<S68>/Constant'

  0.0,

  // Expression: 0
  //  Referenced by: '<S68>/Switch2'

  0.0,

  // Expression: 0
  //  Referenced by: '<S68>/Constant1'

  0.0,

  // Expression: -90
  //  Referenced by: '<S78>/Bias'

  -90.0,

  // Expression: -1
  //  Referenced by: '<S78>/Gain'

  -1.0,

  // Expression: +90
  //  Referenced by: '<S78>/Bias1'

  90.0,

  // Expression: 180
  //  Referenced by: '<S81>/Bias'

  180.0,

  // Expression: -180
  //  Referenced by: '<S81>/Bias1'

  -180.0,

  // Expression: 180
  //  Referenced by: '<S79>/Bias'

  180.0,

  // Expression: -180
  //  Referenced by: '<S79>/Bias1'

  -180.0,

  // Expression: -90
  //  Referenced by: '<S84>/Bias'

  -90.0,

  // Expression: -1
  //  Referenced by: '<S84>/Gain'

  -1.0,

  // Expression: +90
  //  Referenced by: '<S84>/Bias1'

  90.0,

  // Expression: 360
  //  Referenced by: '<S87>/Constant2'

  360.0,

  // Expression: 180
  //  Referenced by: '<S87>/Bias'

  180.0,

  // Expression: -180
  //  Referenced by: '<S87>/Bias1'

  -180.0,

  // Expression: 180
  //  Referenced by: '<S75>/Constant'

  180.0,

  // Expression: 0
  //  Referenced by: '<S75>/Constant1'

  0.0,

  // Expression: 360
  //  Referenced by: '<S85>/Constant2'

  360.0,

  // Expression: 180
  //  Referenced by: '<S85>/Bias'

  180.0,

  // Expression: -180
  //  Referenced by: '<S85>/Bias1'

  -180.0,

  // Expression: 1
  //  Referenced by: '<S133>/Gain'

  1.0,

  // Expression: 1
  //  Referenced by: '<S141>/Gain'

  1.0,

  // Expression: 1
  //  Referenced by: '<S172>/Gain'

  1.0,

  // Expression: 1
  //  Referenced by: '<S180>/Gain'

  1.0,

  // Expression: 0
  //  Referenced by: '<S198>/Constant'

  0.0,

  // Expression: 0
  //  Referenced by: '<S199>/Constant'

  0.0,

  // Expression: 0
  //  Referenced by: '<S200>/Constant'

  0.0,

  // Expression: 0
  //  Referenced by: '<S201>/Constant'

  0.0,

  // Expression: 0
  //  Referenced by: '<S202>/Constant'

  0.0,

  // Expression: 0
  //  Referenced by: '<S203>/Constant'

  0.0,

  // Expression: 0
  //  Referenced by: '<S204>/Constant'

  0.0,

  // Expression: 0
  //  Referenced by: '<S205>/Constant'

  0.0,

  // Expression: 1
  //  Referenced by: '<S336>/Constant'

  1.0,

  // Expression: 0.5
  //  Referenced by: '<S336>/Gain'

  0.5,

  // Expression: 2
  //  Referenced by: '<S336>/Gain1'

  2.0,

  // Expression: 1
  //  Referenced by: '<S352>/Constant'

  1.0,

  // Expression: 0.5
  //  Referenced by: '<S340>/Gain'

  0.5,

  // Expression: 0.5
  //  Referenced by: '<S351>/Constant1'

  0.5,

  // Expression: [0 1]
  //  Referenced by: '<S351>/Constant2'

  { 0.0, 1.0 },

  // Expression: 1
  //  Referenced by: '<S340>/Gain1'

  1.0,

  // Expression: 1
  //  Referenced by: '<S340>/Gain3'

  1.0,

  // Expression: 1
  //  Referenced by: '<S340>/Gain4'

  1.0,

  // Expression: 1
  //  Referenced by: '<S357>/Constant'

  1.0,

  // Expression: 0.5
  //  Referenced by: '<S341>/Gain'

  0.5,

  // Expression: 0.5
  //  Referenced by: '<S356>/Constant1'

  0.5,

  // Expression: [0 1]
  //  Referenced by: '<S356>/Constant2'

  { 0.0, 1.0 },

  // Expression: 1
  //  Referenced by: '<S341>/Gain1'

  1.0,

  // Expression: 1
  //  Referenced by: '<S341>/Gain2'

  1.0,

  // Expression: 1
  //  Referenced by: '<S341>/Gain3'

  1.0,

  // Expression: 1
  //  Referenced by: '<S347>/Constant'

  1.0,

  // Expression: 0.5
  //  Referenced by: '<S339>/Gain'

  0.5,

  // Expression: 0.5
  //  Referenced by: '<S346>/Constant1'

  0.5,

  // Expression: [0 1]
  //  Referenced by: '<S346>/Constant2'

  { 0.0, 1.0 },

  // Expression: 1
  //  Referenced by: '<S339>/Gain1'

  1.0,

  // Expression: 1
  //  Referenced by: '<S339>/Gain2'

  1.0,

  // Expression: 1
  //  Referenced by: '<S339>/Gain3'

  1.0,

  // Expression: 0
  //  Referenced by: '<S363>/Constant1'

  0.0,

  // Expression: 0
  //  Referenced by: '<S362>/Constant1'

  0.0,

  // Expression: -1
  //  Referenced by: '<S365>/Bias'

  -1.0,

  // Expression: -eye(3)
  //  Referenced by: '<S364>/Bias1'

  { -1.0, -0.0, -0.0, -0.0, -1.0, -0.0, -0.0, -0.0, -1.0 },

  // Expression: -90
  //  Referenced by: '<S384>/Bias'

  -90.0,

  // Expression: -1
  //  Referenced by: '<S384>/Gain'

  -1.0,

  // Expression: +90
  //  Referenced by: '<S384>/Bias1'

  90.0,

  // Expression: 180
  //  Referenced by: '<S387>/Bias'

  180.0,

  // Expression: -180
  //  Referenced by: '<S387>/Bias1'

  -180.0,

  // Expression: 180
  //  Referenced by: '<S385>/Bias'

  180.0,

  // Expression: -180
  //  Referenced by: '<S385>/Bias1'

  -180.0,

  // Expression: -90
  //  Referenced by: '<S390>/Bias'

  -90.0,

  // Expression: -1
  //  Referenced by: '<S390>/Gain'

  -1.0,

  // Expression: +90
  //  Referenced by: '<S390>/Bias1'

  90.0,

  // Expression: 360
  //  Referenced by: '<S393>/Constant2'

  360.0,

  // Expression: 180
  //  Referenced by: '<S393>/Bias'

  180.0,

  // Expression: -180
  //  Referenced by: '<S393>/Bias1'

  -180.0,

  // Expression: 180
  //  Referenced by: '<S381>/Constant'

  180.0,

  // Expression: 0
  //  Referenced by: '<S381>/Constant1'

  0.0,

  // Expression: 360
  //  Referenced by: '<S391>/Constant2'

  360.0,

  // Expression: 180
  //  Referenced by: '<S391>/Bias'

  180.0,

  // Expression: -180
  //  Referenced by: '<S391>/Bias1'

  -180.0,

  // Expression: -90
  //  Referenced by: '<S455>/Bias'

  -90.0,

  // Expression: -1
  //  Referenced by: '<S455>/Gain'

  -1.0,

  // Expression: +90
  //  Referenced by: '<S455>/Bias1'

  90.0,

  // Expression: 180
  //  Referenced by: '<S458>/Bias'

  180.0,

  // Expression: -180
  //  Referenced by: '<S458>/Bias1'

  -180.0,

  // Expression: 180
  //  Referenced by: '<S456>/Bias'

  180.0,

  // Expression: -180
  //  Referenced by: '<S456>/Bias1'

  -180.0,

  // Expression: ones(1,maxdef+1)
  //  Referenced by: '<S477>/pp[13]'

  { 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0 },

  // Expression: 1
  //  Referenced by: '<S477>/Constant'

  1.0,

  // Expression: ones(1,maxdef+1)
  //  Referenced by: '<S478>/pp[13]'

  { 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0 },

  // Expression: k
  //  Referenced by: '<S478>/k[13][13]'

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.33333333333333331,
    0.0, -1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.26666666666666666, 0.2, 0.0, -0.33333333333333331, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.25714285714285712, 0.22857142857142856,
    0.14285714285714285, 0.0, -0.2, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.25396825396825395, 0.23809523809523808, 0.19047619047619047,
    0.1111111111111111, 0.0, -0.14285714285714285, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.25252525252525254, 0.24242424242424243, 0.21212121212121213,
    0.16161616161616163, 0.090909090909090912, 0.0, -0.1111111111111111, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.25174825174825177, 0.24475524475524477,
    0.22377622377622378, 0.1888111888111888, 0.13986013986013987,
    0.076923076923076927, 0.0, -0.090909090909090912, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.25128205128205128, 0.24615384615384617, 0.23076923076923078,
    0.20512820512820512, 0.16923076923076924, 0.12307692307692308,
    0.066666666666666666, 0.0, -0.076923076923076927, 0.0, 0.0, 0.0, 0.0,
    0.25098039215686274, 0.24705882352941178, 0.23529411764705882,
    0.21568627450980393, 0.18823529411764706, 0.15294117647058825,
    0.10980392156862745, 0.058823529411764705, 0.0, -0.066666666666666666, 0.0,
    0.0, 0.0, 0.25077399380804954, 0.24767801857585139, 0.23839009287925697,
    0.22291021671826625, 0.20123839009287925, 0.17337461300309598,
    0.13931888544891641, 0.099071207430340563, 0.052631578947368418, 0.0,
    -0.058823529411764705, 0.0, 0.0, 0.25062656641604009, 0.24812030075187969,
    0.24060150375939848, 0.22807017543859648, 0.21052631578947367,
    0.18796992481203006, 0.16040100250626566, 0.12781954887218044,
    0.090225563909774431, 0.047619047619047616, 0.0, -0.052631578947368418, 0.0,
    0.25051759834368531, 0.2484472049689441, 0.24223602484472051,
    0.2318840579710145, 0.21739130434782608, 0.19875776397515527,
    0.17598343685300208, 0.14906832298136646, 0.11801242236024845,
    0.082815734989648032, 0.043478260869565216, 0.0, -0.047619047619047616 },

  // Expression: 0
  //  Referenced by: '<S473>/bpp'

  0.0,

  // Expression: fm(2)
  //  Referenced by: '<S473>/Constant'

  1.0,

  // Expression: 1
  //  Referenced by: '<S473>/Constant1'

  1.0,

  // Expression: ones(1,maxdef+1)
  //  Referenced by: '<S473>/Unit Delay1'

  { 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0 },

  // Expression: 1
  //  Referenced by: '<S481>/Constant'

  1.0,

  // Expression: 1
  //  Referenced by: '<S481>/Gain1'

  1.0,

  // Expression: 1
  //  Referenced by: '<S481>/Gain2'

  1.0,

  // Expression: 1
  //  Referenced by: '<S483>/Constant'

  1.0,

  // Expression: 1
  //  Referenced by: '<S484>/Constant'

  1.0,

  // Expression: 0
  //  Referenced by: '<S487>/Constant1'

  0.0,

  // Expression: 0
  //  Referenced by: '<S487>/Constant'

  0.0,

  // Expression: k
  //  Referenced by: '<S487>/k[13][13]'

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.33333333333333331,
    0.0, -1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.26666666666666666, 0.2, 0.0, -0.33333333333333331, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.25714285714285712, 0.22857142857142856,
    0.14285714285714285, 0.0, -0.2, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.25396825396825395, 0.23809523809523808, 0.19047619047619047,
    0.1111111111111111, 0.0, -0.14285714285714285, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.25252525252525254, 0.24242424242424243, 0.21212121212121213,
    0.16161616161616163, 0.090909090909090912, 0.0, -0.1111111111111111, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.25174825174825177, 0.24475524475524477,
    0.22377622377622378, 0.1888111888111888, 0.13986013986013987,
    0.076923076923076927, 0.0, -0.090909090909090912, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.25128205128205128, 0.24615384615384617, 0.23076923076923078,
    0.20512820512820512, 0.16923076923076924, 0.12307692307692308,
    0.066666666666666666, 0.0, -0.076923076923076927, 0.0, 0.0, 0.0, 0.0,
    0.25098039215686274, 0.24705882352941178, 0.23529411764705882,
    0.21568627450980393, 0.18823529411764706, 0.15294117647058825,
    0.10980392156862745, 0.058823529411764705, 0.0, -0.066666666666666666, 0.0,
    0.0, 0.0, 0.25077399380804954, 0.24767801857585139, 0.23839009287925697,
    0.22291021671826625, 0.20123839009287925, 0.17337461300309598,
    0.13931888544891641, 0.099071207430340563, 0.052631578947368418, 0.0,
    -0.058823529411764705, 0.0, 0.0, 0.25062656641604009, 0.24812030075187969,
    0.24060150375939848, 0.22807017543859648, 0.21052631578947367,
    0.18796992481203006, 0.16040100250626566, 0.12781954887218044,
    0.090225563909774431, 0.047619047619047616, 0.0, -0.052631578947368418, 0.0,
    0.25051759834368531, 0.2484472049689441, 0.24223602484472051,
    0.2318840579710145, 0.21739130434782608, 0.19875776397515527,
    0.17598343685300208, 0.14906832298136646, 0.11801242236024845,
    0.082815734989648032, 0.043478260869565216, 0.0, -0.047619047619047616 },

  // Expression: zeros(maxdef+1,maxdef+1)
  //  Referenced by: '<S471>/dp[13][13]'

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0 },

  // Expression: snorm
  //  Referenced by: '<S471>/snorm[169]'

  { 1.0, 1.0, 1.5, 2.5, 4.375, 7.875, 14.4375, 26.8125, 50.2734375, 94.9609375,
    180.42578125, 344.44921875, 660.1943359375, 0.0, 1.0, 1.7320508075688772,
    3.0618621784789726, 5.5339859052946636, 10.16658128379447,
    18.903124741692839, 35.469603513959669, 67.03125, 127.40346687426536,
    243.28607380714598, 466.38644692864216, 897.027461585248, 0.0, 0.0,
    0.8660254037844386, 1.9364916731037085, 3.9131189606246322,
    7.685213074469698, 14.944232269507859, 28.960809996010127,
    56.082367403612253, 108.65004161512664, 210.69192030396434,
    409.04797337487776, 795.12986069746626, 0.0, 0.0, 0.0, 0.79056941504209488,
    2.0916500663351889, 4.7062126492541738, 9.9628215130052382,
    20.478385136833914, 41.41957332816817, 82.982839993569982,
    165.28034045942309, 327.9680080977904, 649.22081265302029, 0.0, 0.0, 0.0,
    0.0, 0.739509972887452, 2.2185299186623553, 5.4568620790707172,
    12.348930874776167, 26.736219617835371, 56.375738371688975,
    116.87084953567937, 239.5139682335957, 486.91560948976519, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.7015607600201138, 2.3268138086232852, 6.1744654373880836,
    14.830586268334102, 33.69094768709671, 73.915615322315773,
    158.42359886807964, 334.02135244518831, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.671693289381396, 2.4218245962496963, 6.8652274293172546, 17.39793057467611,
    41.320085114855779, 94.117642301250768, 208.29891011946015, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.6472598492877496, 2.5068266169601756,
    7.5335249254737544, 20.043185339772048, 49.604352946160631,
    117.05388227149012, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.6267066542400439, 2.5839777317091466, 8.1825961504123, 22.760038068635609,
    58.526941135745062, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.60904939217552367, 2.65478475211798, 8.8149248398872544,
    25.543251233216804, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.59362791713657326, 2.72034486491732, 9.4324706362690076, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.579979473934679,
    2.7814838439702596, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.56776801212685635 },

  // Expression: zeros(maxdef+1,maxdef+1)
  //  Referenced by: '<S471>/Unit Delay'

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0 },

  // Expression: snorm
  //  Referenced by: '<S471>/Unit Delay1'

  { 1.0, 1.0, 1.5, 2.5, 4.375, 7.875, 14.4375, 26.8125, 50.2734375, 94.9609375,
    180.42578125, 344.44921875, 660.1943359375, 0.0, 1.0, 1.7320508075688772,
    3.0618621784789726, 5.5339859052946636, 10.16658128379447,
    18.903124741692839, 35.469603513959669, 67.03125, 127.40346687426536,
    243.28607380714598, 466.38644692864216, 897.027461585248, 0.0, 0.0,
    0.8660254037844386, 1.9364916731037085, 3.9131189606246322,
    7.685213074469698, 14.944232269507859, 28.960809996010127,
    56.082367403612253, 108.65004161512664, 210.69192030396434,
    409.04797337487776, 795.12986069746626, 0.0, 0.0, 0.0, 0.79056941504209488,
    2.0916500663351889, 4.7062126492541738, 9.9628215130052382,
    20.478385136833914, 41.41957332816817, 82.982839993569982,
    165.28034045942309, 327.9680080977904, 649.22081265302029, 0.0, 0.0, 0.0,
    0.0, 0.739509972887452, 2.2185299186623553, 5.4568620790707172,
    12.348930874776167, 26.736219617835371, 56.375738371688975,
    116.87084953567937, 239.5139682335957, 486.91560948976519, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.7015607600201138, 2.3268138086232852, 6.1744654373880836,
    14.830586268334102, 33.69094768709671, 73.915615322315773,
    158.42359886807964, 334.02135244518831, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.671693289381396, 2.4218245962496963, 6.8652274293172546, 17.39793057467611,
    41.320085114855779, 94.117642301250768, 208.29891011946015, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.6472598492877496, 2.5068266169601756,
    7.5335249254737544, 20.043185339772048, 49.604352946160631,
    117.05388227149012, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.6267066542400439, 2.5839777317091466, 8.1825961504123, 22.760038068635609,
    58.526941135745062, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.60904939217552367, 2.65478475211798, 8.8149248398872544,
    25.543251233216804, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.59362791713657326, 2.72034486491732, 9.4324706362690076, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.579979473934679,
    2.7814838439702596, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.56776801212685635 },

  // Expression: 0
  //  Referenced by: '<S471>/Merge1'

  0.0,

  // Expression: 0
  //  Referenced by: '<S471>/Merge'

  0.0,

  // Expression: 1
  //  Referenced by: '<S500>/Gain'

  1.0,

  // Expression: zeros(maxdef+1,maxdef+1)
  //  Referenced by: '<S499>/zeros(maxdef+1,maxdef+1)'

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0 },

  // Expression: zeros(maxdef+1,maxdef+1)
  //  Referenced by: '<S472>/tc[13][13]'

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0 },

  // Expression: zeros(maxdef+1,maxdef+1)
  //  Referenced by: '<S472>/Unit Delay'

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0 },

  // Expression: c
  //  Referenced by: '<S472>/c[maxdef][maxdef]'

  { 0.0, 4796.3, -4923.1812154337767, -348.13372969305919, 1567.7782069699783,
    476.81266220996059, -379.95280730802608, -1925.9994708080098, 677.015625,
    -2777.3955778589848, 802.84404356358175, -0.0, -897.027461585248, -29438.2,
    -1493.5, -553.21702793749932, 477.34519742006415, -738.01423597380563,
    1510.1443691332956, 490.17081843985773, -564.73579492219744,
    -1026.3073234861042, 1162.5554452818549, -84.276768121585746,
    859.00074408724333, 238.53895820923987, -3666.75, 5221.6135695778939,
    1454.0566529540724, -424.8520036436218, 377.9611669867686,
    -564.2748966455755, 588.80275141860955, 122.87031082100349,
    550.88032526463667, 979.19751192412582, 760.28956611334615,
    -196.78080485867423, 1168.5974627754365, 3379.5, -7200.2750989111519,
    2369.4912112096977, 460.34857037901179, -244.03829105285917,
    35.496478698597684, -366.1554455056451, 302.54880643201608,
    -387.67518445861288, -383.35502092748504, 514.23173795698926,
    -263.46536505695531, -1071.2143408774834, 3970.3125, 4509.091715634092,
    460.96541356158167, -701.95776226208943, 51.543845110255411,
    70.577012458023447, 18.84719184984861, 21.610629030858291,
    240.25549754701245, -232.4675390409673, -583.93336104629464,
    110.89651920765574, 100.20640573355649, -1834.0875, 3660.9859202943885,
    1473.2553463758411, -664.98784733961486, -348.75290321372222,
    5.4020178521548763, 41.577814612708416, -67.084541316116585,
    41.191364575903528, 137.44365153994127, -24.792051068913466,
    -18.823528460250156, 145.80923708362209, 1001.9625000000001,
    1279.7415450126052, 1080.4679930854181, -1286.2002573289762,
    -154.97488304560835, 31.644667797276679, -47.220038243512143,
    -1.8770535629344738, -23.062804876033614, 7.5335249254737544,
    -84.1813784270426, -104.16914118693732, -11.705388227149014, 2190.58125,
    -2692.1429067095391, -205.6217509716719, 1068.9717041427305,
    185.23396312164252, 56.187635480231556, -7.2654737887490892,
    3.8188331107977227, 1.5040959701761054, -10.077513153665672,
    -23.729528836195669, -34.140057102953413, 17.558082340723519, 1216.6171875,
    596.578125, -947.792009121047, -128.40067731732134, -553.43974608919211,
    197.24679736884357, 79.636638180080155, -40.861273856450865,
    -1.3160839739040922, 5.1769198334919508, -2.9202632273297784,
    -22.918804583706862, 5.1086502466433608, 522.28515625, 1121.1505084935352,
    325.95012484537995, -265.54508797942395, 33.825443023013385,
    -444.72050946967653, -1.739793057467611, 65.541666851621656,
    -23.514197358553233, -6.3341136786254468, -5.2239256708018447,
    -5.44068972983464, -8.489223572642107, -360.8515625, -1484.0450502235904,
    42.138384060792873, 99.168204275653849, -58.435424767839685,
    133.04810758016839, -28.924059580399042, 44.095007747498506,
    19.638230760989519, -4.7786125538123647, -2.1370605016916637,
    -1.3339527900497614, -0.556296768794052, 1033.34765625, -652.941025700099,
    -940.81033876221875, 688.73281700535983, -191.61117458687659,
    95.054159320847774, -65.882349610875536, 4.9604352946160635,
    38.692064716680534, -1.762984967977451, 1.088137945966928,
    2.0299281587713764, 0.45421440970148508, -1320.388671875, -89.7027461585248,
    397.56493034873313, 779.06497518362437, -438.22404854078866,
    300.61921720066948, 20.829891011946017, 70.232329362894077,
    -23.410776454298027, -12.771625616608402, 1.8864941272538016,
    -2.5033354595732336, -0.0 },

  // Expression: cd
  //  Referenced by: '<S472>/cd[maxdef][maxdef]'

  { 0.0, -30.2, -51.268703904038766, 19.902104160113321, -2.2135943621178655,
    2.0333162567588938, 5.6709374225078513, 21.2817621083758, -26.8125,
    -38.221040062279606, 0.0, 0.0, -0.0, 7.0, 9.0, -14.982239485470789,
    -1.5491933384829668, 22.696089971622865, 17.675990071280303,
    -22.41634840426179, 14.480404998005064, 33.649420442167347,
    10.865004161512665, 21.069192030396437, 40.904797337487778, 0.0, -16.5,
    -10.738715006927039, 0.25980762113533157, -1.5811388300841898,
    7.9482702520737174, -0.0, -11.955385815606286, -16.382708109467131,
    -4.1419573328168173, -33.193135997427994, -33.056068091884619, 0.0,
    -64.922081265302026, 6.0, -17.452614417330143, 3.872983346207417,
    -8.6962635654630436, -2.5882849051060819, 7.3211487315857724,
    2.1827448316282871, -2.4697861749552334, 16.041731770701222,
    16.912721511506692, 11.687084953567938, 23.951396823359573,
    48.691560948976523, -3.5, -4.9805873147651978, -25.435273244060109,
    10.876580344942983, -2.9580398915498081, -0.42093645601206825,
    0.46536276172465707, -6.7919119811268924, -2.9661172536668206,
    3.3690947687096711, -7.3915615322315773, -0.0, -0.0, -2.3625,
    6.0999487702766819, -6.1481704595757591, 0.47062126492541739,
    2.6622359023948263, 0.9821850640281593, 0.87320127619581489,
    0.24218245962496965, -3.4326137146586273, -0.0, 4.1320085114855782, -0.0,
    0.0, -11.55, -9.45156237084642, -1.494423226950786, 15.940514420808382,
    -8.7309793265131486, 0.0, 0.80603194725767524, 0.12945196985754992,
    1.2534133084800878, -0.75335249254737546, -0.0, 4.9604352946160635, -0.0,
    -8.04375, -7.0939207027919338, -8.6882429988030374, 18.430546623150523,
    1.2348930874776167, -3.70467926243285, -2.1796421366247265,
    0.45308189450142466, 0.062670665424004388, 1.2919888658545733,
    -0.81825961504123, -0.0, 0.0, -5.02734375, 13.40625, -11.216473480722451,
    20.709786664084085, -2.6736219617835371, 5.9322345073336411,
    2.7460909717269022, -0.25068266169601755, 0.25068266169601755,
    0.12180987843510474, 0.530956950423596, -0.88149248398872548, 0.0,
    -9.49609375, -12.740346687426538, -0.0, 33.193135997427994,
    -22.55029534867559, 0.0, 5.2193791724028324, 0.0, -0.0, -0.1827148176526571,
    -0.0, -0.0, -0.0, 0.0, -0.0, -21.069192030396437, 33.056068091884619,
    -11.687084953567938, -14.783123064463155, -0.0, -2.0043185339772047,
    -1.63651923008246, -0.265478475211798, -0.0, -0.0579979473934679, 0.0, -0.0,
    0.0, -0.0, 0.0, -0.0, -15.842359886807964, 0.0, -0.0, -0.0,
    -0.88149248398872548, -0.0, -0.0579979473934679, -0.056776801212685635, 0.0,
    0.0, -0.0, 0.0, -48.691560948976523, -0.0, 0.0, -0.0, 0.0, -0.0, -0.0, -0.0,
    -0.056776801212685635 },

  // Expression: zeros(maxdef+1,maxdef+1)
  //  Referenced by: '<S499>/Unit Delay'

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0 },

  // Expression: 0
  //  Referenced by: '<S469>/bt'

  0.0,

  // Expression: 0
  //  Referenced by: '<S469>/bp'

  0.0,

  // Expression: 0
  //  Referenced by: '<S469>/br'

  0.0,

  // Expression: 0
  //  Referenced by: '<S469>/bpp'

  0.0,

  // Expression: 1
  //  Referenced by: '<S475>/Constant1'

  1.0,

  // Expression: 0
  //  Referenced by: '<S475>/Merge'

  0.0,

  // Expression: fm
  //  Referenced by: '<S470>/fm'

  { 0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0 },

  // Expression: 0
  //  Referenced by: '<S475>/Merge1'

  0.0,

  // Expression: fn
  //  Referenced by: '<S470>/fn'

  { 0.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0, 13.0 },

  // Expression: 0
  //  Referenced by: '<S476>/Constant1'

  0.0,

  // Expression: 0
  //  Referenced by: '<S470>/Unit Delay1'

  0.0,

  // Expression: 0
  //  Referenced by: '<S470>/Unit Delay3'

  0.0,

  // Expression: 0
  //  Referenced by: '<S470>/Unit Delay2'

  0.0,

  // Expression: 0
  //  Referenced by: '<S470>/Unit Delay4'

  0.0,

  // Expression: [0 0 0 0]
  //  Referenced by: '<S461>/bt,bp,br,bpp'

  { 0.0, 0.0, 0.0, 0.0 },

  // Expression: 0
  //  Referenced by: '<S461>/Unit Delay'

  0.0,

  // Expression: [0 0 0 0]
  //  Referenced by: '<S461>/Unit Delay2'

  { 0.0, 0.0, 0.0, 0.0 },

  // Expression: 6378.137
  //  Referenced by: '<S462>/r'

  6378.137,

  // Expression: 1
  //  Referenced by: '<S462>/ct'

  1.0,

  // Expression: 0
  //  Referenced by: '<S462>/st'

  0.0,

  // Expression: 0
  //  Referenced by: '<S462>/sa'

  0.0,

  // Expression: 0
  //  Referenced by: '<S462>/ca'

  0.0,

  // Expression: 6356.7523142
  //  Referenced by: '<S462>/b'

  6356.7523142,

  // Expression: 6378.137
  //  Referenced by: '<S462>/a'

  6378.137,

  // Expression: 2
  //  Referenced by: '<S507>/Gain'

  2.0,

  // Expression: 1
  //  Referenced by: '<S509>/Constant'

  1.0,

  // Expression: (1:(maxdef-1))
  //  Referenced by: '<S510>/sp[11]'

  { 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0 },

  // Expression: (1:(maxdef-1))
  //  Referenced by: '<S510>/cp[11]'

  { 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0 },

  // Expression: maxdef-1
  //  Referenced by: '<S510>/For Iterator'

  11.0,

  // Expression: [1:maxdef-1]
  //  Referenced by: '<S510>/Constant'

  { 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0 },

  // Expression: 0
  //  Referenced by: '<S510>/Unit Delay1'

  0.0,

  // Expression: 1
  //  Referenced by: '<S510>/cp[m-1] sp[m-1]'

  1.0,

  // Expression: [1:maxdef-1]
  //  Referenced by: '<S510>/Constant1'

  { 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0 },

  // Expression: [0 0 (1:(maxdef-1))]
  //  Referenced by: '<S463>/sp[13]'

  { 0.0, 0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0 },

  // Expression: [1 1 (1:(maxdef-1))]
  //  Referenced by: '<S463>/cp[13]'

  { 1.0, 1.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0 },

  // Expression: 1
  //  Referenced by: '<S463>/Gain'

  1.0,

  // Expression: 1
  //  Referenced by: '<S463>/Gain1'

  1.0,

  // Expression: 1
  //  Referenced by: '<S463>/cp[1]'

  1.0,

  // Expression: 0
  //  Referenced by: '<S463>/sp[1]'

  0.0,

  // Expression: 1E6
  //  Referenced by: '<S8>/Gain_clock'

  1.0E+6,

  // Expression: 0
  //  Referenced by: '<S432>/Integrator, Second-Order Limited'

  0.0,

  // Expression: 0
  //  Referenced by: '<S432>/Integrator, Second-Order Limited'

  0.0,

  // Expression: dtype_a
  //  Referenced by: '<S428>/Constant'

  1.0,

  // Expression: 0.5
  //  Referenced by: '<S20>/1//2'

  0.5,

  // Expression: 2
  //  Referenced by: '<S25>/Gain'

  2.0,

  // Expression: 2
  //  Referenced by: '<S28>/Gain'

  2.0,

  // Expression: 2
  //  Referenced by: '<S23>/Gain'

  2.0,

  // Expression: 2
  //  Referenced by: '<S29>/Gain'

  2.0,

  // Expression: 2
  //  Referenced by: '<S24>/Gain'

  2.0,

  // Expression: 2
  //  Referenced by: '<S27>/Gain'

  2.0,

  // Expression: 1
  //  Referenced by: '<S90>/Constant2'

  1.0,

  // Expression: R
  //  Referenced by: '<S90>/Constant1'

  6.378137E+6,

  // Expression: 1
  //  Referenced by: '<S93>/Constant'

  1.0,

  // Expression: 1
  //  Referenced by: '<S95>/Constant'

  1.0,

  // Expression: F
  //  Referenced by: '<S94>/Constant'

  0.0033528106647474805,

  // Expression: 1
  //  Referenced by: '<S94>/f'

  1.0,

  // Expression: 1
  //  Referenced by: '<S90>/Constant'

  1.0,

  // Expression: 1
  //  Referenced by: '<S90>/Constant3'

  1.0,

  // Expression: 360
  //  Referenced by: '<S81>/Constant2'

  360.0,

  // Expression: 180
  //  Referenced by: '<S74>/Constant'

  180.0,

  // Expression: 0
  //  Referenced by: '<S74>/Constant1'

  0.0,

  // Expression: 360
  //  Referenced by: '<S79>/Constant2'

  360.0,

  // Expression: 100000
  //  Referenced by: '<S3>/Saturation_1'

  100000.0,

  // Expression: 0
  //  Referenced by: '<S3>/Saturation_1'

  0.0,

  // Expression: juliandate(year,month,day)
  //  Referenced by: '<S72>/Julian Date'

  2.4532885E+6,

  // Expression: -1
  //  Referenced by: '<S194>/Gain'

  -1.0,

  // Expression: -1
  //  Referenced by: '<S194>/Gain1'

  -1.0,

  // Expression: 1
  //  Referenced by: '<Root>/armState'

  1.0,

  // Expression: 0
  //  Referenced by: '<S53>/White Noise'

  0.0,

  // Computed Parameter: WhiteNoise_StdDev
  //  Referenced by: '<S53>/White Noise'

  1.0,

  // Expression: 1.0
  //  Referenced by: '<S54>/2'

  1.0,

  // Expression: 0
  //  Referenced by: '<S50>/Gain1'

  0.0,

  // Expression: [1 -1 -1]
  //  Referenced by: '<S198>/Constant3'

  { 1.0, -1.0, -1.0 },

  // Expression: -1
  //  Referenced by: '<S73>/Gain_-1'

  -1.0,

  // Expression: 10000
  //  Referenced by: '<S73>/Saturation_2'

  10000.0,

  // Expression: 0
  //  Referenced by: '<S73>/Saturation_2'

  0.0,

  // Expression: 5
  //  Referenced by: '<S73>/Constant_V'

  5.0,

  // Expression: max_height_low
  //  Referenced by: '<S186>/Limit Function 10ft to 1000ft'

  1000.0,

  // Expression: 10
  //  Referenced by: '<S186>/Limit Function 10ft to 1000ft'

  10.0,

  // Expression: max_height_low
  //  Referenced by: '<S169>/Limit Height h<1000ft'

  1000.0,

  // Expression: 0
  //  Referenced by: '<S169>/Limit Height h<1000ft'

  0.0,

  // Expression: 0.1
  //  Referenced by: '<S169>/sigma_wg '

  0.1,

  // Expression: h_vec
  //  Referenced by: '<S168>/PreLook-Up Index Search  (altitude)'

  { 500.0, 1750.0, 3750.0, 7500.0, 15000.0, 25000.0, 35000.0, 45000.0, 55000.0,
    65000.0, 75000.0, 80000.0 },

  // Expression: [1:7]
  //  Referenced by: '<S168>/PreLook-Up Index Search  (prob of exceed)'

  { 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0 },

  // Expression: sigma_vec'
  //  Referenced by: '<S168>/Medium//High Altitude Intensity'

  { 3.2, 2.2, 1.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 4.2, 3.6, 3.3,
    1.6, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 6.6, 6.9, 7.4, 6.7, 4.6, 2.7,
    0.4, 0.0, 0.0, 0.0, 0.0, 0.0, 8.6, 9.6, 10.6, 10.1, 8.0, 6.6, 5.0, 4.2, 2.7,
    0.0, 0.0, 0.0, 11.8, 13.0, 16.0, 15.1, 11.6, 9.7, 8.1, 8.2, 7.9, 4.9, 3.2,
    2.1, 15.6, 17.6, 23.0, 23.6, 22.1, 20.0, 16.0, 15.1, 12.1, 7.9, 6.2, 5.1,
    18.7, 21.5, 28.4, 30.2, 30.7, 31.0, 25.2, 23.1, 17.5, 10.7, 8.4, 7.2 },

  // Expression: 0
  //  Referenced by: '<S161>/White Noise'

  0.0,

  // Computed Parameter: WhiteNoise_StdDev_e
  //  Referenced by: '<S161>/White Noise'

  1.0,

  // Expression: 1
  //  Referenced by: '<S158>/Lv'

  1.0,

  // Expression: 1
  //  Referenced by: '<S158>/Lw'

  1.0,

  // Expression: eye(3)
  //  Referenced by: '<S73>/Constant_DCM'

  { 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0 },

  // Expression: max_height_low
  //  Referenced by: '<S147>/Limit Function 10ft to 1000ft'

  1000.0,

  // Expression: 10
  //  Referenced by: '<S147>/Limit Function 10ft to 1000ft'

  10.0,

  // Expression: max_height_low
  //  Referenced by: '<S130>/Limit Height h<1000ft'

  1000.0,

  // Expression: 0
  //  Referenced by: '<S130>/Limit Height h<1000ft'

  0.0,

  // Expression: 0.1
  //  Referenced by: '<S130>/sigma_wg '

  0.1,

  // Expression: h_vec
  //  Referenced by: '<S129>/PreLook-Up Index Search  (altitude)'

  { 500.0, 1750.0, 3750.0, 7500.0, 15000.0, 25000.0, 35000.0, 45000.0, 55000.0,
    65000.0, 75000.0, 80000.0 },

  // Expression: [1:7]
  //  Referenced by: '<S129>/PreLook-Up Index Search  (prob of exceed)'

  { 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0 },

  // Expression: sigma_vec'
  //  Referenced by: '<S129>/Medium//High Altitude Intensity'

  { 3.2, 2.2, 1.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 4.2, 3.6, 3.3,
    1.6, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 6.6, 6.9, 7.4, 6.7, 4.6, 2.7,
    0.4, 0.0, 0.0, 0.0, 0.0, 0.0, 8.6, 9.6, 10.6, 10.1, 8.0, 6.6, 5.0, 4.2, 2.7,
    0.0, 0.0, 0.0, 11.8, 13.0, 16.0, 15.1, 11.6, 9.7, 8.1, 8.2, 7.9, 4.9, 3.2,
    2.1, 15.6, 17.6, 23.0, 23.6, 22.1, 20.0, 16.0, 15.1, 12.1, 7.9, 6.2, 5.1,
    18.7, 21.5, 28.4, 30.2, 30.7, 31.0, 25.2, 23.1, 17.5, 10.7, 8.4, 7.2 },

  // Expression: 0
  //  Referenced by: '<S122>/White Noise'

  0.0,

  // Computed Parameter: WhiteNoise_StdDev_k
  //  Referenced by: '<S122>/White Noise'

  1.0,

  // Expression: 1
  //  Referenced by: '<S119>/Lv'

  1.0,

  // Expression: 1
  //  Referenced by: '<S119>/Lw'

  1.0,

  // Expression: inf
  //  Referenced by: '<S110>/3ft-->inf'

  0.0,

  // Expression: 3
  //  Referenced by: '<S110>/3ft-->inf'

  3.0,

  // Expression: 1/z0
  //  Referenced by: '<S110>/h//z0'

  6.666666666666667,

  // Expression: 20/z0
  //  Referenced by: '<S110>/ref_height//z0'

  133.33333333333334,

  // Expression: 0
  //  Referenced by: '<S110>/Wdeg1'

  0.0,

  // Expression: [1 -1 -1]
  //  Referenced by: '<S198>/Constant2'

  { 1.0, -1.0, -1.0 },

  // Expression: [0;0;0;0;0;0]
  //  Referenced by: '<S198>/Constant1'

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

  // Expression: [1 -1 -1]
  //  Referenced by: '<S199>/Constant3'

  { 1.0, -1.0, -1.0 },

  // Expression: [1 -1 -1]
  //  Referenced by: '<S199>/Constant2'

  { 1.0, -1.0, -1.0 },

  // Expression: [0;0;0;0;0;0]
  //  Referenced by: '<S199>/Constant1'

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

  // Expression: [1 -1 -1]
  //  Referenced by: '<S200>/Constant3'

  { 1.0, -1.0, -1.0 },

  // Expression: [1 -1 -1]
  //  Referenced by: '<S200>/Constant2'

  { 1.0, -1.0, -1.0 },

  // Expression: [0;0;0;0;0;0]
  //  Referenced by: '<S200>/Constant1'

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

  // Expression: [1 -1 -1]
  //  Referenced by: '<S201>/Constant3'

  { 1.0, -1.0, -1.0 },

  // Expression: [1 -1 -1]
  //  Referenced by: '<S201>/Constant2'

  { 1.0, -1.0, -1.0 },

  // Expression: [0;0;0;0;0;0]
  //  Referenced by: '<S201>/Constant1'

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

  // Expression: [1 -1 -1]
  //  Referenced by: '<S202>/Constant3'

  { 1.0, -1.0, -1.0 },

  // Expression: [1 -1 -1]
  //  Referenced by: '<S202>/Constant2'

  { 1.0, -1.0, -1.0 },

  // Expression: [0;0;0;0;0;0]
  //  Referenced by: '<S202>/Constant1'

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

  // Expression: [1 -1 -1]
  //  Referenced by: '<S203>/Constant3'

  { 1.0, -1.0, -1.0 },

  // Expression: [1 -1 -1]
  //  Referenced by: '<S203>/Constant2'

  { 1.0, -1.0, -1.0 },

  // Expression: [0;0;0;0;0;0]
  //  Referenced by: '<S203>/Constant1'

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

  // Expression: [1 -1 -1]
  //  Referenced by: '<S204>/Constant3'

  { 1.0, -1.0, -1.0 },

  // Expression: [1 -1 -1]
  //  Referenced by: '<S204>/Constant2'

  { 1.0, -1.0, -1.0 },

  // Expression: [0;0;0;0;0;0]
  //  Referenced by: '<S204>/Constant1'

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

  // Expression: [1 -1 -1]
  //  Referenced by: '<S205>/Constant3'

  { 1.0, -1.0, -1.0 },

  // Expression: [1 -1 -1]
  //  Referenced by: '<S205>/Constant2'

  { 1.0, -1.0, -1.0 },

  // Expression: [0;0;0;0;0;0]
  //  Referenced by: '<S205>/Constant1'

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

  // Expression: 1
  //  Referenced by: '<S426>/Zero-Order Hold1'

  1.0,

  // Expression: 1
  //  Referenced by: '<S426>/Zero-Order Hold2'

  1.0,

  // Expression: 1
  //  Referenced by: '<S426>/Zero-Order Hold'

  1.0,

  // Expression: [0 0 0]
  //  Referenced by: '<S406>/center of gravity'

  { 0.0, 0.0, 0.0 },

  // Expression: 1
  //  Referenced by: '<S426>/Zero-Order Hold4'

  1.0,

  // Expression: [1 -1 1]
  //  Referenced by: '<S426>/Gain'

  { 1.0, -1.0, 1.0 },

  // Expression: [0,0]
  //  Referenced by: '<S4>/Constant'

  { 0.0, 0.0 },

  // Expression: zeros(3)
  //  Referenced by: '<S12>/Constant2'

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

  // Expression: 1
  //  Referenced by: '<S426>/Zero-Order Hold3'

  1.0,

  // Expression: 0.5
  //  Referenced by: '<S428>/Switch'

  0.5,

  // Expression: a_sath
  //  Referenced by: '<S426>/Saturation'

  { 160.0, 160.0, 160.0 },

  // Expression: a_satl
  //  Referenced by: '<S426>/Saturation'

  { -160.0, -160.0, -160.0 },

  // Expression: -[0.1,0.1,0.2]
  //  Referenced by: '<S406>/Uniform Random Number5'

  { -0.1, -0.1, -0.2 },

  // Expression: [0.1,0.1,0.2]
  //  Referenced by: '<S406>/Uniform Random Number5'

  { 0.1, 0.1, 0.2 },

  // Expression: [12233,645554,678766]
  //  Referenced by: '<S406>/Uniform Random Number5'

  { 12233.0, 645554.0, 678766.0 },

  // Expression: 5
  //  Referenced by: '<S406>/Gain10'

  5.0,

  // Expression: 0
  //  Referenced by: '<S443>/Integrator, Second-Order Limited'

  0.0,

  // Expression: 0
  //  Referenced by: '<S443>/Integrator, Second-Order Limited'

  0.0,

  // Expression: dtype_g
  //  Referenced by: '<S441>/Constant'

  1.0,

  // Expression: 1
  //  Referenced by: '<S427>/Zero-Order Hold'

  1.0,

  // Expression: 1
  //  Referenced by: '<S427>/Zero-Order Hold1'

  1.0,

  // Expression: 0.5
  //  Referenced by: '<S441>/Switch'

  0.5,

  // Expression: g_sath
  //  Referenced by: '<S427>/Saturation'

  { 4.36, 4.36, 4.36 },

  // Expression: g_satl
  //  Referenced by: '<S427>/Saturation'

  { -4.36, -4.36, -4.36 },

  // Expression: -[0.01,0.01,0.01]
  //  Referenced by: '<S406>/Uniform Random Number1'

  { -0.01, -0.01, -0.01 },

  // Expression: [0.01,0.01,0.01]
  //  Referenced by: '<S406>/Uniform Random Number1'

  { 0.01, 0.01, 0.01 },

  // Expression: [3243,44556,2334343]
  //  Referenced by: '<S406>/Uniform Random Number1'

  { 3243.0, 44556.0, 2.334343E+6 },

  // Expression: 5
  //  Referenced by: '<S406>/Gain6'

  5.0,

  // Expression: epoch
  //  Referenced by: '<S453>/epoch'

  2015.0,

  // Expression: dyear
  //  Referenced by: '<S419>/Decimal Year'

  2017.8383561643836,

  // Expression: -1000
  //  Referenced by: '<S467>/otime'

  -1000.0,

  // Expression: 180
  //  Referenced by: '<S449>/Constant'

  180.0,

  // Expression: 100000
  //  Referenced by: '<S406>/Saturation2'

  100000.0,

  // Expression: 0
  //  Referenced by: '<S406>/Saturation2'

  0.0,

  // Expression: 360
  //  Referenced by: '<S458>/Constant2'

  360.0,

  // Expression: 0
  //  Referenced by: '<S449>/Constant1'

  0.0,

  // Expression: 360
  //  Referenced by: '<S456>/Constant2'

  360.0,

  // Expression: -1000
  //  Referenced by: '<S466>/olon'

  -1000.0,

  // Expression: -1000
  //  Referenced by: '<S465>/olat'

  -1000.0,

  // Expression: 0.001
  //  Referenced by: '<S419>/Gain'

  0.001,

  // Expression: -1000
  //  Referenced by: '<S465>/oalt'

  -1000.0,

  // Expression: 6371.2
  //  Referenced by: '<S453>/re'

  6371.2,

  // Expression: 1
  //  Referenced by: '<S406>/Gain_Mag'

  1.0,

  // Expression: 1E-5
  //  Referenced by: '<S406>/nT2Gauss'

  1.0E-5,

  // Expression: -[0.01,0.01,0.01]
  //  Referenced by: '<S406>/Uniform Random Number7'

  { -0.01, -0.01, -0.01 },

  // Expression: [0.01,0.01,0.01]
  //  Referenced by: '<S406>/Uniform Random Number7'

  { 0.01, 0.01, 0.01 },

  // Expression: [45465,454534,1234232]
  //  Referenced by: '<S406>/Uniform Random Number7'

  { 45465.0, 454534.0, 1.234232E+6 },

  // Expression: 2
  //  Referenced by: '<S406>/Gain11'

  2.0,

  // Expression: T0
  //  Referenced by: '<S416>/Sea Level  Temperature'

  288.15,

  // Expression: T0
  //  Referenced by: '<S70>/Sea Level  Temperature'

  288.15,

  // Expression: h_trop
  //  Referenced by: '<S70>/Limit  altitude  to troposhere'

  11000.0,

  // Expression: h0
  //  Referenced by: '<S70>/Limit  altitude  to troposhere'

  0.0,

  // Expression: L
  //  Referenced by: '<S70>/Lapse Rate'

  0.0065,

  // Expression: 1/T0
  //  Referenced by: '<S70>/1//T0'

  0.00347041471455839,

  // Expression: g/(L*R)
  //  Referenced by: '<S70>/Constant'

  5.2558756014667134,

  // Expression: rho0
  //  Referenced by: '<S70>/rho0'

  1.225,

  // Expression: h_trop
  //  Referenced by: '<S70>/Altitude of Troposphere'

  11000.0,

  // Expression: 0
  //  Referenced by: '<S70>/Limit  altitude  to Stratosphere'

  0.0,

  // Expression: h_trop-h_strat
  //  Referenced by: '<S70>/Limit  altitude  to Stratosphere'

  -9000.0,

  // Expression: g/R
  //  Referenced by: '<S70>/g//R'

  0.034163191409533639,

  // Expression: 1/2
  //  Referenced by: '<S408>/1//2rhoV^2'

  0.5,

  // Expression: -2
  //  Referenced by: '<S406>/Uniform Random Number'

  -2.0,

  // Expression: 2
  //  Referenced by: '<S406>/Uniform Random Number'

  2.0,

  // Expression: 15634
  //  Referenced by: '<S406>/Uniform Random Number'

  15634.0,

  // Expression: 0.2
  //  Referenced by: '<S406>/Gain5'

  0.2,

  // Expression: 0.3
  //  Referenced by: '<S414>/Constant2'

  0.3,

  // Expression: 100000
  //  Referenced by: '<S406>/Saturation1'

  100000.0,

  // Expression: 0
  //  Referenced by: '<S406>/Saturation1'

  0.0,

  // Expression: h_trop
  //  Referenced by: '<S416>/Limit  altitude  to troposhere'

  11000.0,

  // Expression: h0
  //  Referenced by: '<S416>/Limit  altitude  to troposhere'

  0.0,

  // Expression: L
  //  Referenced by: '<S416>/Lapse Rate'

  0.0065,

  // Expression: 1/T0
  //  Referenced by: '<S416>/1//T0'

  0.00347041471455839,

  // Expression: g/(L*R)
  //  Referenced by: '<S416>/Constant'

  5.2558756014667134,

  // Expression: P0
  //  Referenced by: '<S416>/P0'

  101325.0,

  // Expression: h_trop
  //  Referenced by: '<S416>/Altitude of Troposphere'

  11000.0,

  // Expression: 0
  //  Referenced by: '<S416>/Limit  altitude  to Stratosphere'

  0.0,

  // Expression: h_trop-h_strat
  //  Referenced by: '<S416>/Limit  altitude  to Stratosphere'

  -9000.0,

  // Expression: g/R
  //  Referenced by: '<S416>/g//R'

  0.034163191409533639,

  // Expression: 0.01
  //  Referenced by: '<S406>/Gain'

  0.01,

  // Expression: -1
  //  Referenced by: '<S406>/Uniform Random Number4'

  -1.0,

  // Expression: 1
  //  Referenced by: '<S406>/Uniform Random Number4'

  1.0,

  // Expression: 25634
  //  Referenced by: '<S406>/Uniform Random Number4'

  25634.0,

  // Expression: 0.0005
  //  Referenced by: '<S406>/Gain9'

  0.0005,

  // Expression: 0.5
  //  Referenced by: '<S415>/Constant'

  0.5,

  // Expression: 0.7
  //  Referenced by: '<S415>/Gain2'

  0.7,

  // Expression: 0.3
  //  Referenced by: '<S415>/Constant2'

  0.3,

  // Expression: 0.01
  //  Referenced by: '<S406>/Gain1'

  0.01,

  // Expression: 25
  //  Referenced by: '<S3>/TemperatureConstant'

  25.0,

  // Expression: 8191
  //  Referenced by: '<S402>/Constant'

  8191.0,

  // Expression: [-1,-1,-2]
  //  Referenced by: '<S373>/Uniform Random Number5'

  { -1.0, -1.0, -2.0 },

  // Expression: [1,1,2]
  //  Referenced by: '<S373>/Uniform Random Number5'

  { 1.0, 1.0, 2.0 },

  // Expression: [1452,787,69]
  //  Referenced by: '<S373>/Uniform Random Number5'

  { 1452.0, 787.0, 69.0 },

  // Expression: 0.5
  //  Referenced by: '<S373>/BiasGain2'

  0.5,

  // Expression: 1
  //  Referenced by: '<S396>/Constant2'

  1.0,

  // Expression: R
  //  Referenced by: '<S396>/Constant1'

  6.378137E+6,

  // Expression: 1
  //  Referenced by: '<S399>/Constant'

  1.0,

  // Expression: 1
  //  Referenced by: '<S401>/Constant'

  1.0,

  // Expression: F
  //  Referenced by: '<S400>/Constant'

  0.0033528106647474805,

  // Expression: 1
  //  Referenced by: '<S400>/f'

  1.0,

  // Expression: 1
  //  Referenced by: '<S396>/Constant'

  1.0,

  // Expression: 1
  //  Referenced by: '<S396>/Constant3'

  1.0,

  // Expression: 360
  //  Referenced by: '<S387>/Constant2'

  360.0,

  // Expression: 1E7
  //  Referenced by: '<S331>/latScale'

  1.0E+7,

  // Expression: 180
  //  Referenced by: '<S380>/Constant'

  180.0,

  // Expression: 0
  //  Referenced by: '<S380>/Constant1'

  0.0,

  // Expression: 360
  //  Referenced by: '<S385>/Constant2'

  360.0,

  // Expression: 1E7
  //  Referenced by: '<S331>/lonScale'

  1.0E+7,

  // Expression: 100000
  //  Referenced by: '<S373>/Saturation'

  100000.0,

  // Expression: 0
  //  Referenced by: '<S373>/Saturation'

  0.0,

  // Expression: 1E3
  //  Referenced by: '<S331>/altScale'

  1000.0,

  // Expression: 100
  //  Referenced by: '<S331>/Gain6'

  100.0,

  // Expression: 100
  //  Referenced by: '<S331>/Gain8'

  100.0,

  // Computed Parameter: TransferFcn4_A
  //  Referenced by: '<S375>/Transfer Fcn4'

  -20.0,

  // Computed Parameter: TransferFcn4_C
  //  Referenced by: '<S375>/Transfer Fcn4'

  20.0,

  // Computed Parameter: TransferFcn1_A
  //  Referenced by: '<S375>/Transfer Fcn1'

  -20.0,

  // Computed Parameter: TransferFcn1_C
  //  Referenced by: '<S375>/Transfer Fcn1'

  20.0,

  // Computed Parameter: TransferFcn2_A
  //  Referenced by: '<S375>/Transfer Fcn2'

  -20.0,

  // Computed Parameter: TransferFcn2_C
  //  Referenced by: '<S375>/Transfer Fcn2'

  20.0,

  // Expression: 1E2
  //  Referenced by: '<S331>/VelScale'

  100.0,

  // Expression: 1E2
  //  Referenced by: '<S331>/VeScale'

  100.0,

  // Expression: 1E2
  //  Referenced by: '<S331>/AngleScale'

  100.0,

  // Expression: 1
  //  Referenced by: '<S8>/CopterID'

  1.0,

  // Expression: [1 0 0 0]
  //  Referenced by: '<S330>/Merge'

  { 1.0, 0.0, 0.0, 0.0 },

  // Expression: 0
  //  Referenced by: '<S52>/Constant1'

  0.0,

  // Expression: 60/2/pi
  //  Referenced by: '<S8>/Gain'

  9.5492965855137211,

  // Computed Parameter: TransferFcn2_A_e
  //  Referenced by: '<S52>/Transfer Fcn2'

  -10.0,

  // Computed Parameter: TransferFcn2_C_e
  //  Referenced by: '<S52>/Transfer Fcn2'

  10.0,

  // Expression: 180/pi
  //  Referenced by: '<S52>/Gain1'

  57.295779513082323,

  // Computed Parameter: TransferFcn1_A_n
  //  Referenced by: '<S52>/Transfer Fcn1'

  -10.0,

  // Computed Parameter: TransferFcn1_C_c
  //  Referenced by: '<S52>/Transfer Fcn1'

  10.0,

  // Expression: 180/pi
  //  Referenced by: '<S52>/Gain2'

  57.295779513082323,

  // Computed Parameter: TransferFcn3_A
  //  Referenced by: '<S52>/Transfer Fcn3'

  -10.0,

  // Computed Parameter: TransferFcn3_C
  //  Referenced by: '<S52>/Transfer Fcn3'

  10.0,

  // Expression: 180/pi
  //  Referenced by: '<S52>/Gain3'

  57.295779513082323,

  // Expression: zeros(12,1)
  //  Referenced by: '<S52>/Constant2'

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

  // Expression: 17:32
  //  Referenced by: '<Root>/ExtToPX4'

  { 17.0, 18.0, 19.0, 20.0, 21.0, 22.0, 23.0, 24.0, 25.0, 26.0, 27.0, 28.0, 29.0,
    30.0, 31.0, 32.0 },

  // Expression: [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
  //  Referenced by: '<S5>/Constant'

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

  // Expression: 1
  //  Referenced by: '<S21>/Constant'

  1.0,

  // Expression: [-1,-1,-2]
  //  Referenced by: '<S331>/Uniform Random Number4'

  { -1.0, -1.0, -2.0 },

  // Expression: [1,1,2]
  //  Referenced by: '<S331>/Uniform Random Number4'

  { 1.0, 1.0, 2.0 },

  // Expression: [5445,45433,33433]
  //  Referenced by: '<S331>/Uniform Random Number4'

  { 5445.0, 45433.0, 33433.0 },

  // Expression: 0.1
  //  Referenced by: '<S331>/BiasGain1'

  0.1,

  // Computed Parameter: Constant1_Value_h3
  //  Referenced by: '<S479>/Constant1'

  1,

  // Computed Parameter: Constant_Value_pi
  //  Referenced by: '<S480>/Constant'

  1,

  // Computed Parameter: Constant_Value_b
  //  Referenced by: '<S478>/Constant'

  1,

  // Computed Parameter: Constant_Value_jv
  //  Referenced by: '<S489>/Constant'

  1,

  // Computed Parameter: Gain_Gain_aq
  //  Referenced by: '<S489>/Gain'

  13,

  // Computed Parameter: Constant_Value_ld
  //  Referenced by: '<S492>/Constant'

  1,

  // Computed Parameter: Gain_Gain_l
  //  Referenced by: '<S491>/Gain'

  13,

  // Computed Parameter: Constant_Value_al
  //  Referenced by: '<S495>/Constant'

  1,

  // Computed Parameter: Constant1_Value_dk
  //  Referenced by: '<S495>/Constant1'

  1,

  // Computed Parameter: Constant1_Value_b
  //  Referenced by: '<S496>/Constant1'

  2,

  // Computed Parameter: Constant_Value_cw
  //  Referenced by: '<S494>/Constant'

  1,

  // Computed Parameter: Constant1_Value_js
  //  Referenced by: '<S493>/Constant1'

  1,

  // Computed Parameter: Gain_Gain_cl
  //  Referenced by: '<S493>/Gain'

  13,

  // Computed Parameter: Constant1_Value_iz
  //  Referenced by: '<S497>/Constant1'

  2,

  // Computed Parameter: Constant_Value_ds
  //  Referenced by: '<S471>/Constant'

  1,

  // Computed Parameter: Constant_Value_hb
  //  Referenced by: '<S488>/Constant'

  1,

  // Computed Parameter: Gain_Gain_cx
  //  Referenced by: '<S488>/Gain'

  13,

  // Computed Parameter: Constant_Value_bl
  //  Referenced by: '<S498>/Constant'

  1,

  // Computed Parameter: Constant1_Value_me
  //  Referenced by: '<S498>/Constant1'

  1,

  // Computed Parameter: Constant_Value_op
  //  Referenced by: '<S500>/Constant'

  1,

  // Computed Parameter: tc_old_Threshold
  //  Referenced by: '<S499>/tc_old'

  1,

  // Computed Parameter: Constant_Value_d3e
  //  Referenced by: '<S470>/Constant'

  1,

  // Computed Parameter: Constant1_Value_lk
  //  Referenced by: '<S470>/Constant1'

  1,

  // Computed Parameter: Constant_Value_gj
  //  Referenced by: '<S469>/Constant'

  1,

  // Computed Parameter: Constant_Value_mg
  //  Referenced by: '<S474>/Constant'

  1,

  // Computed Parameter: Gain_Gain_kp
  //  Referenced by: '<S474>/Gain'

  13,

  // Computed Parameter: Constant_Value_jq
  //  Referenced by: '<S476>/Constant'

  1,

  // Computed Parameter: ForIterator_IterationLimit_f
  //  Referenced by: '<S461>/For Iterator'

  12,

  // Computed Parameter: Constant_Value_mk
  //  Referenced by: '<S461>/Constant'

  1,

  // Computed Parameter: arn_Threshold
  //  Referenced by: '<S461>/ar(n)'

  1,

  // Expression: FaultParamStruct.FaultID
  //  Referenced by: '<S50>/FaultID'

  123451,

  // Expression: FaultParamStruct.ConstWindFaultID
  //  Referenced by: '<S73>/FaultID'

  123459,

  // Expression: FaultParamStruct.GustWindFaultID
  //  Referenced by: '<S73>/FaultID1'

  123540,

  // Expression: FaultParamStruct.TurbWindFaultID
  //  Referenced by: '<S73>/FaultID2'

  123541,

  // Expression: FaultParamStruct.SheerWindFaultID
  //  Referenced by: '<S73>/FaultID3'

  123542,

  // Computed Parameter: FaultID_Value_e
  //  Referenced by: '<S406>/FaultID'

  123544,

  // Computed Parameter: FaultID1_Value_a
  //  Referenced by: '<S406>/FaultID1'

  123545,

  // Computed Parameter: FaultID2_Value_l
  //  Referenced by: '<S406>/FaultID2'

  123546,

  // Computed Parameter: FaultID3_Value_n
  //  Referenced by: '<S406>/FaultID3'

  123547,

  // Expression: FaultParamStruct.GPSNoiseFaultID
  //  Referenced by: '<S373>/FaultID'

  123548,

  // Computed Parameter: MediumHighAltitudeIntensity_max
  //  Referenced by: '<S168>/Medium//High Altitude Intensity'

  { 11U, 6U },

  // Computed Parameter: MediumHighAltitudeIntensity_m_g
  //  Referenced by: '<S129>/Medium//High Altitude Intensity'

  { 11U, 6U },

  // Start of '<S157>/Interpolate  velocities'
  {
    // Expression: max_height_low
    //  Referenced by: '<S178>/max_height_low'

    1000.0,

    // Expression: min_height_high
    //  Referenced by: '<S178>/min_height_high'

    2000.0
  }
  ,

  // End of '<S157>/Interpolate  velocities'

  // Start of '<S156>/Interpolate  rates'
  {
    // Expression: max_height_low
    //  Referenced by: '<S170>/max_height_low'

    1000.0,

    // Expression: min_height_high
    //  Referenced by: '<S170>/min_height_high'

    2000.0
  }
  ,

  // End of '<S156>/Interpolate  rates'

  // Start of '<S152>/Hwgw(z)'
  {
    // Expression: 0
    //  Referenced by: '<S167>/wgw'

    0.0,

    // Expression: 2*dt
    //  Referenced by: '<S167>/2'

    0.02,

    // Expression: 1
    //  Referenced by: '<S167>/Constant'

    1.0,

    // Expression: dt
    //  Referenced by: '<S167>/dt'

    0.01,

    // Expression: 0
    //  Referenced by: '<S167>/Unit Delay'

    0.0
  }
  ,

  // End of '<S152>/Hwgw(z)'

  // Start of '<S152>/Hvgw(z)'
  {
    // Expression: 0
    //  Referenced by: '<S166>/vgw'

    0.0,

    // Expression: 2*dt
    //  Referenced by: '<S166>/2'

    0.02,

    // Expression: 1
    //  Referenced by: '<S166>/Constant'

    1.0,

    // Expression: dt
    //  Referenced by: '<S166>/dt'

    0.01,

    // Expression: 0
    //  Referenced by: '<S166>/Unit Delay'

    0.0
  }
  ,

  // End of '<S152>/Hvgw(z)'

  // Start of '<S152>/Hugw(z)'
  {
    // Expression: 0
    //  Referenced by: '<S165>/ugw'

    0.0,

    // Expression: 2*dt
    //  Referenced by: '<S165>/2'

    0.02,

    // Expression: 1
    //  Referenced by: '<S165>/Constant'

    1.0,

    // Expression: dt
    //  Referenced by: '<S165>/dt'

    0.01,

    // Expression: 0
    //  Referenced by: '<S165>/Unit Delay'

    0.0
  }
  ,

  // End of '<S152>/Hugw(z)'

  // Start of '<S151>/Hrgw'
  {
    // Expression: 0
    //  Referenced by: '<S164>/rgw'

    0.0,

    // Expression: 1
    //  Referenced by: '<S164>/Constant'

    1.0,

    // Expression: 3/pi
    //  Referenced by: '<S164>/dt1'

    0.954929658551372,

    // Expression: dt
    //  Referenced by: '<S164>/dt'

    0.01,

    // Expression: 0
    //  Referenced by: '<S164>/Unit Delay'

    0.0,

    // Expression: 0
    //  Referenced by: '<S164>/Unit Delay1'

    0.0
  }
  ,

  // End of '<S151>/Hrgw'

  // Start of '<S151>/Hqgw'
  {
    // Expression: 0
    //  Referenced by: '<S163>/qgw'

    0.0,

    // Expression: 1
    //  Referenced by: '<S163>/Constant'

    1.0,

    // Expression: 4/pi
    //  Referenced by: '<S163>/dt1'

    1.2732395447351628,

    // Expression: dt
    //  Referenced by: '<S163>/dt'

    0.01,

    // Expression: 0
    //  Referenced by: '<S163>/Unit Delay'

    0.0,

    // Expression: 0
    //  Referenced by: '<S163>/Unit Delay1'

    0.0
  }
  ,

  // End of '<S151>/Hqgw'

  // Start of '<S151>/Hpgw'
  {
    // Expression: 0
    //  Referenced by: '<S162>/pgw'

    0.0,

    // Expression: 2.6
    //  Referenced by: '<S162>/Constant2'

    2.6,

    // Expression: 2*dt
    //  Referenced by: '<S162>/2'

    0.02,

    // Expression: 1
    //  Referenced by: '<S162>/Constant'

    1.0,

    // Expression: 0.95
    //  Referenced by: '<S162>/Constant1'

    0.95,

    // Expression: 1/3
    //  Referenced by: '<S162>/Constant3'

    0.33333333333333331,

    // Expression: dt
    //  Referenced by: '<S162>/dt'

    0.01,

    // Expression: 0
    //  Referenced by: '<S162>/Unit Delay'

    0.0
  }
  ,

  // End of '<S151>/Hpgw'

  // Start of '<S118>/Interpolate  velocities'
  {
    // Expression: max_height_low
    //  Referenced by: '<S139>/max_height_low'

    1000.0,

    // Expression: min_height_high
    //  Referenced by: '<S139>/min_height_high'

    2000.0
  }
  ,

  // End of '<S118>/Interpolate  velocities'

  // Start of '<S117>/Interpolate  rates'
  {
    // Expression: max_height_low
    //  Referenced by: '<S131>/max_height_low'

    1000.0,

    // Expression: min_height_high
    //  Referenced by: '<S131>/min_height_high'

    2000.0
  }
  ,

  // End of '<S117>/Interpolate  rates'

  // Start of '<S113>/Hwgw(z)'
  {
    // Expression: 0
    //  Referenced by: '<S128>/wgw'

    0.0,

    // Expression: 2*dt
    //  Referenced by: '<S128>/2'

    0.02,

    // Expression: 1
    //  Referenced by: '<S128>/Constant'

    1.0,

    // Expression: dt
    //  Referenced by: '<S128>/dt'

    0.01,

    // Expression: 0
    //  Referenced by: '<S128>/Unit Delay'

    0.0
  }
  ,

  // End of '<S113>/Hwgw(z)'

  // Start of '<S113>/Hvgw(z)'
  {
    // Expression: 0
    //  Referenced by: '<S127>/vgw'

    0.0,

    // Expression: 2*dt
    //  Referenced by: '<S127>/2'

    0.02,

    // Expression: 1
    //  Referenced by: '<S127>/Constant'

    1.0,

    // Expression: dt
    //  Referenced by: '<S127>/dt'

    0.01,

    // Expression: 0
    //  Referenced by: '<S127>/Unit Delay'

    0.0
  }
  ,

  // End of '<S113>/Hvgw(z)'

  // Start of '<S113>/Hugw(z)'
  {
    // Expression: 0
    //  Referenced by: '<S126>/ugw'

    0.0,

    // Expression: 2*dt
    //  Referenced by: '<S126>/2'

    0.02,

    // Expression: 1
    //  Referenced by: '<S126>/Constant'

    1.0,

    // Expression: dt
    //  Referenced by: '<S126>/dt'

    0.01,

    // Expression: 0
    //  Referenced by: '<S126>/Unit Delay'

    0.0
  }
  ,

  // End of '<S113>/Hugw(z)'

  // Start of '<S112>/Hrgw'
  {
    // Expression: 0
    //  Referenced by: '<S125>/rgw'

    0.0,

    // Expression: 1
    //  Referenced by: '<S125>/Constant'

    1.0,

    // Expression: 3/pi
    //  Referenced by: '<S125>/dt1'

    0.954929658551372,

    // Expression: dt
    //  Referenced by: '<S125>/dt'

    0.01,

    // Expression: 0
    //  Referenced by: '<S125>/Unit Delay'

    0.0,

    // Expression: 0
    //  Referenced by: '<S125>/Unit Delay1'

    0.0
  }
  ,

  // End of '<S112>/Hrgw'

  // Start of '<S112>/Hqgw'
  {
    // Expression: 0
    //  Referenced by: '<S124>/qgw'

    0.0,

    // Expression: 1
    //  Referenced by: '<S124>/Constant'

    1.0,

    // Expression: 4/pi
    //  Referenced by: '<S124>/dt1'

    1.2732395447351628,

    // Expression: dt
    //  Referenced by: '<S124>/dt'

    0.01,

    // Expression: 0
    //  Referenced by: '<S124>/Unit Delay'

    0.0,

    // Expression: 0
    //  Referenced by: '<S124>/Unit Delay1'

    0.0
  }
  ,

  // End of '<S112>/Hqgw'

  // Start of '<S112>/Hpgw'
  {
    // Expression: 0
    //  Referenced by: '<S123>/pgw'

    0.0,

    // Expression: 2.6
    //  Referenced by: '<S123>/Constant2'

    2.6,

    // Expression: 2*dt
    //  Referenced by: '<S123>/2'

    0.02,

    // Expression: 1
    //  Referenced by: '<S123>/Constant'

    1.0,

    // Expression: 0.95
    //  Referenced by: '<S123>/Constant1'

    0.95,

    // Expression: 1/3
    //  Referenced by: '<S123>/Constant3'

    0.33333333333333331,

    // Expression: dt
    //  Referenced by: '<S123>/dt'

    0.01,

    // Expression: 0
    //  Referenced by: '<S123>/Unit Delay'

    0.0
  }
  ,

  // End of '<S112>/Hpgw'

  // Start of '<S54>/Distance into gust (z)'
  {
    // Expression: [0]
    //  Referenced by: '<S59>/x'

    0.0,

    // Expression: 0
    //  Referenced by: '<S59>/Distance into Gust (x) (Limited to gust length d) '

    0.0,

    // Expression: 0
    //  Referenced by: '<S59>/Distance into Gust (x) (Limited to gust length d) '

    0.0
  }
  ,

  // End of '<S54>/Distance into gust (z)'

  // Start of '<S54>/Distance into gust (y)'
  {
    // Expression: [0]
    //  Referenced by: '<S58>/x'

    0.0,

    // Expression: 0
    //  Referenced by: '<S58>/Distance into Gust (x) (Limited to gust length d) '

    0.0,

    // Expression: 0
    //  Referenced by: '<S58>/Distance into Gust (x) (Limited to gust length d) '

    0.0
  }
  // End of '<S54>/Distance into gust (y)'
};

extern real_T rt_powd_snf(real_T u0, real_T u1);
extern real_T rt_modd_snf(real_T u0, real_T u1);
extern real_T rt_atan2d_snf(real_T u0, real_T u1);
extern void rt_mrdivide_U1d1x3_U2d_9vOrDY9Z(const real_T u0[3], const real_T u1
  [9], real_T y[3]);
extern real_T rt_roundd_snf(real_T u);
extern real_T rt_urand_Upu32_Yd_f_pw_snf(uint32_T *u);
extern real_T rt_nrand_Upu32_Yd_f_pw_snf(uint32_T *u);
void wgs84_taylor_series(real_T *h, real_T *phi, real_T opt_m2ft, real_T *y,
  int_T k);
static uint32_T plook_bincpa(real_T u, const real_T bp[], uint32_T maxIndex,
  real_T *fraction, uint32_T *prevIndex);
static real_T intrp2d_la_pw(const uint32_T bpIndex[], const real_T frac[], const
  real_T table[], const uint32_T stride, const uint32_T maxIndex[]);
static uint32_T binsearch_u32d_prevIdx(real_T u, const real_T bp[], uint32_T
  startIndex, uint32_T maxIndex);
static void mul_wide_s32(int32_T in0, int32_T in1, uint32_T *ptrOutBitsHi,
  uint32_T *ptrOutBitsLo);
static int32_T mul_s32_sat(int32_T a, int32_T b);

// private model entry point functions
extern void USV_derivatives();
static void rate_scheduler(RT_MODEL_USV_T *const USV_M);

//===========*
//  Constants *
// ===========
#define RT_PI                          3.14159265358979323846
#define RT_PIF                         3.1415927F
#define RT_LN_10                       2.30258509299404568402
#define RT_LN_10F                      2.3025851F
#define RT_LOG10E                      0.43429448190325182765
#define RT_LOG10EF                     0.43429449F
#define RT_E                           2.7182818284590452354
#define RT_EF                          2.7182817F

//
//  UNUSED_PARAMETER(x)
//    Used to specify that a function parameter (argument) is required but not
//    accessed by the function body.

#ifndef UNUSED_PARAMETER
#if defined(__LCC__)
#define UNUSED_PARAMETER(x)                                      // do nothing
#else

//
//  This is the semi-ANSI standard way of indicating that an
//  unused function parameter is required.

#define UNUSED_PARAMETER(x)            (void) (x)
#endif
#endif

extern "C" {
  real_T rtInf;
  real_T rtMinusInf;
  real_T rtNaN;
  real32_T rtInfF;
  real32_T rtMinusInfF;
  real32_T rtNaNF;
}
//=========*
//  Asserts *
// =========
#ifndef utAssert
#if defined(DOASSERTS)
#if !defined(PRINT_ASSERTS)
#include <assert.h>
#define utAssert(exp)                  assert(exp)
#else
#include <stdio.h>

static void _assert(char *statement, char *file, int line)
{
  printf("%s in %s on line %d\n", statement, file, line);
}

#define utAssert(_EX)                  ((_EX) ? (void)0 : _assert(#_EX, __FILE__, __LINE__))
#endif

#else
#define utAssert(exp)                                            // do nothing
#endif
#endif

extern "C" {
  //
  // Initialize rtInf needed by the generated code.
  // Inf is initialized as non-signaling. Assumes IEEE.
  //
  static real_T rtGetInf(void)
  {
    size_t bitsPerReal = sizeof(real_T) * (NumBitsPerChar);
    real_T inf = 0.0;
    if (bitsPerReal == 32U) {
      inf = rtGetInfF();
    } else {
      union {
        LittleEndianIEEEDouble bitVal;
        real_T fltVal;
      } tmpVal;

      tmpVal.bitVal.words.wordH = 0x7FF00000U;
      tmpVal.bitVal.words.wordL = 0x00000000U;
      inf = tmpVal.fltVal;
    }

    return inf;
  }

  //
  // Initialize rtInfF needed by the generated code.
  // Inf is initialized as non-signaling. Assumes IEEE.
  //
  static real32_T rtGetInfF(void)
  {
    IEEESingle infF;
    infF.wordL.wordLuint = 0x7F800000U;
    return infF.wordL.wordLreal;
  }

  //
  // Initialize rtMinusInf needed by the generated code.
  // Inf is initialized as non-signaling. Assumes IEEE.
  //
  static real_T rtGetMinusInf(void)
  {
    size_t bitsPerReal = sizeof(real_T) * (NumBitsPerChar);
    real_T minf = 0.0;
    if (bitsPerReal == 32U) {
      minf = rtGetMinusInfF();
    } else {
      union {
        LittleEndianIEEEDouble bitVal;
        real_T fltVal;
      } tmpVal;

      tmpVal.bitVal.words.wordH = 0xFFF00000U;
      tmpVal.bitVal.words.wordL = 0x00000000U;
      minf = tmpVal.fltVal;
    }

    return minf;
  }

  //
  // Initialize rtMinusInfF needed by the generated code.
  // Inf is initialized as non-signaling. Assumes IEEE.
  //
  static real32_T rtGetMinusInfF(void)
  {
    IEEESingle minfF;
    minfF.wordL.wordLuint = 0xFF800000U;
    return minfF.wordL.wordLreal;
  }
}
  extern "C"
{
  //
  // Initialize rtNaN needed by the generated code.
  // NaN is initialized as non-signaling. Assumes IEEE.
  //
  static real_T rtGetNaN(void)
  {
    size_t bitsPerReal = sizeof(real_T) * (NumBitsPerChar);
    real_T nan = 0.0;
    if (bitsPerReal == 32U) {
      nan = rtGetNaNF();
    } else {
      union {
        LittleEndianIEEEDouble bitVal;
        real_T fltVal;
      } tmpVal;

      tmpVal.bitVal.words.wordH = 0xFFF80000U;
      tmpVal.bitVal.words.wordL = 0x00000000U;
      nan = tmpVal.fltVal;
    }

    return nan;
  }

  //
  // Initialize rtNaNF needed by the generated code.
  // NaN is initialized as non-signaling. Assumes IEEE.
  //
  static real32_T rtGetNaNF(void)
  {
    IEEESingle nanF = { { 0.0F } };

    nanF.wordL.wordLuint = 0xFFC00000U;
    return nanF.wordL.wordLreal;
  }
}

extern "C" {
  //
  // Initialize the rtInf, rtMinusInf, and rtNaN needed by the
  // generated code. NaN is initialized as non-signaling. Assumes IEEE.
  //
  static void rt_InitInfAndNaN(size_t realSize)
  {
    (void) (realSize);
    rtNaN = rtGetNaN();
    rtNaNF = rtGetNaNF();
    rtInf = rtGetInf();
    rtInfF = rtGetInfF();
    rtMinusInf = rtGetMinusInf();
    rtMinusInfF = rtGetMinusInfF();
  }

  // Test if value is infinite
  static boolean_T rtIsInf(real_T value)
  {
    return (boolean_T)((value==rtInf || value==rtMinusInf) ? 1U : 0U);
  }

  // Test if single-precision value is infinite
  static boolean_T rtIsInfF(real32_T value)
  {
    return (boolean_T)(((value)==rtInfF || (value)==rtMinusInfF) ? 1U : 0U);
  }

  // Test if value is not a number
  static boolean_T rtIsNaN(real_T value)
  {
    boolean_T result = (boolean_T) 0;
    size_t bitsPerReal = sizeof(real_T) * (NumBitsPerChar);
    if (bitsPerReal == 32U) {
      result = rtIsNaNF((real32_T)value);
    } else {
      union {
        LittleEndianIEEEDouble bitVal;
        real_T fltVal;
      } tmpVal;

      tmpVal.fltVal = value;
      result = (boolean_T)((tmpVal.bitVal.words.wordH & 0x7FF00000) ==
                           0x7FF00000 &&
                           ( (tmpVal.bitVal.words.wordH & 0x000FFFFF) != 0 ||
                            (tmpVal.bitVal.words.wordL != 0) ));
    }

    return result;
  }

  // Test if single-precision value is not a number
  static boolean_T rtIsNaNF(real32_T value)
  {
    IEEESingle tmp;
    tmp.wordL.wordLreal = value;
    return (boolean_T)( (tmp.wordL.wordLuint & 0x7F800000) == 0x7F800000 &&
                       (tmp.wordL.wordLuint & 0x007FFFFF) != 0 );
  }
}
//
//         Taylor Series expansion approximation of WGS84 model of
//         ellipsoid normal gravity
//
  void wgs84_taylor_series(real_T *h, real_T *phi, real_T opt_m2ft, real_T *y,
  int_T k)
{
  real_T gamma_ts, m, sinphi, sin2phi;
  int_T i;
  for (i = 0; i < k; i++ ) {
    sinphi = std::sin(phi[i]);
    sin2phi = sinphi*sinphi;

    // Calculate theoretical normal gravity (gamma) /eq. 4-1/
    gamma_ts = (WGS84_G_E)*( 1.0 + (WGS84_K)*sin2phi )/( std::sqrt(1.0 -
      (WGS84_E_2)*sin2phi) );
    m = (WGS84_A)*(WGS84_A)*(WGS84_B)*(WGS84_W_DEF)*(WGS84_W_DEF)/
      (WGS84_GM_DEF);

    // Return normal gravity as the output /eq. 4-3/
    y[i] = opt_m2ft*gamma_ts*( 1.0 - 2.0*( 1.0 + 1.0/(WGS84_INV_F) + m -
      2.0*sin2phi/(WGS84_INV_F) )*h[i]/(WGS84_A) + 3.0*h[i]*h[i]/(
      (WGS84_A)*(WGS84_A)) );
  }
}

static uint32_T plook_bincpa(real_T u, const real_T bp[], uint32_T maxIndex,
  real_T *fraction, uint32_T *prevIndex)
{
  uint32_T bpIndex;

  // Prelookup - Index and Fraction
  // Index Search method: 'binary'
  // Extrapolation method: 'Clip'
  // Use previous index: 'on'
  // Use last breakpoint for index at or above upper limit: 'on'
  // Remove protection against out-of-range input in generated code: 'off'

  if (u <= bp[0U]) {
    bpIndex = 0U;
    *fraction = 0.0;
  } else if (u < bp[maxIndex]) {
    bpIndex = binsearch_u32d_prevIdx(u, bp, *prevIndex, maxIndex);
    *fraction = (u - bp[bpIndex]) / (bp[bpIndex + 1U] - bp[bpIndex]);
  } else {
    bpIndex = maxIndex;
    *fraction = 0.0;
  }

  *prevIndex = bpIndex;
  return bpIndex;
}

static real_T intrp2d_la_pw(const uint32_T bpIndex[], const real_T frac[], const
  real_T table[], const uint32_T stride, const uint32_T maxIndex[])
{
  real_T y;
  real_T yL_0d0;
  uint32_T offset_1d;

  // Column-major Interpolation 2-D
  // Interpolation method: 'Linear point-slope'
  // Use last breakpoint for index at or above upper limit: 'on'
  // Overflow mode: 'portable wrapping'

  offset_1d = bpIndex[1U] * stride + bpIndex[0U];
  if (bpIndex[0U] == maxIndex[0U]) {
    y = table[offset_1d];
  } else {
    yL_0d0 = table[offset_1d];
    y = (table[offset_1d + 1U] - yL_0d0) * frac[0U] + yL_0d0;
  }

  if (bpIndex[1U] == maxIndex[1U]) {
  } else {
    offset_1d += stride;
    if (bpIndex[0U] == maxIndex[0U]) {
      yL_0d0 = table[offset_1d];
    } else {
      yL_0d0 = table[offset_1d];
      yL_0d0 += (table[offset_1d + 1U] - yL_0d0) * frac[0U];
    }

    y += (yL_0d0 - y) * frac[1U];
  }

  return y;
}

static uint32_T binsearch_u32d_prevIdx(real_T u, const real_T bp[], uint32_T
  startIndex, uint32_T maxIndex)
{
  uint32_T bpIndex;
  uint32_T found;
  uint32_T iLeft;
  uint32_T iRght;

  // Binary Search using Previous Index
  bpIndex = startIndex;
  iLeft = 0U;
  iRght = maxIndex;
  found = 0U;
  while (found == 0U) {
    if (u < bp[bpIndex]) {
      iRght = bpIndex - 1U;
      bpIndex = ((bpIndex + iLeft) - 1U) >> 1U;
    } else if (u < bp[bpIndex + 1U]) {
      found = 1U;
    } else {
      iLeft = bpIndex + 1U;
      bpIndex = ((bpIndex + iRght) + 1U) >> 1U;
    }
  }

  return bpIndex;
}

static void mul_wide_s32(int32_T in0, int32_T in1, uint32_T *ptrOutBitsHi,
  uint32_T *ptrOutBitsLo)
{
  uint32_T absIn0;
  uint32_T absIn1;
  uint32_T in0Hi;
  uint32_T in0Lo;
  uint32_T in1Hi;
  uint32_T productHiLo;
  uint32_T productLoHi;
  absIn0 = in0 < 0 ? ~static_cast<uint32_T>(in0) + 1U : static_cast<uint32_T>
    (in0);
  absIn1 = in1 < 0 ? ~static_cast<uint32_T>(in1) + 1U : static_cast<uint32_T>
    (in1);
  in0Hi = absIn0 >> 16U;
  in0Lo = absIn0 & 65535U;
  in1Hi = absIn1 >> 16U;
  absIn0 = absIn1 & 65535U;
  productHiLo = in0Hi * absIn0;
  productLoHi = in0Lo * in1Hi;
  absIn0 *= in0Lo;
  absIn1 = 0U;
  in0Lo = (productLoHi << /*MW:OvBitwiseOk*/ 16U) + /*MW:OvCarryOk*/ absIn0;
  if (in0Lo < absIn0) {
    absIn1 = 1U;
  }

  absIn0 = in0Lo;
  in0Lo += /*MW:OvCarryOk*/ productHiLo << /*MW:OvBitwiseOk*/ 16U;
  if (in0Lo < absIn0) {
    absIn1++;
  }

  absIn0 = (((productLoHi >> 16U) + (productHiLo >> 16U)) + in0Hi * in1Hi) +
    absIn1;
  if (static_cast<int32_T>((in0 != 0) && ((in1 != 0) && ((in0 > 0) != (in1 > 0)))))
  {
    absIn0 = ~absIn0;
    in0Lo = ~in0Lo;
    in0Lo++;
    if (in0Lo == 0U) {
      absIn0++;
    }
  }

  *ptrOutBitsHi = absIn0;
  *ptrOutBitsLo = in0Lo;
}

static int32_T mul_s32_sat(int32_T a, int32_T b)
{
  int32_T result;
  uint32_T u32_chi;
  uint32_T u32_clo;
  mul_wide_s32(a, b, &u32_chi, &u32_clo);
  if ((static_cast<int32_T>(u32_chi) > 0) || ((u32_chi == 0U) && (u32_clo >=
        2147483648U))) {
    result = MAX_int32_T;
  } else if ((static_cast<int32_T>(u32_chi) < -1) || ((static_cast<int32_T>
               (u32_chi) == -1) && (u32_clo < 2147483648U))) {
    result = MIN_int32_T;
  } else {
    result = static_cast<int32_T>(u32_clo);
  }

  return result;
}

//
//         This function updates active task flag for each subrate.
//         The function is called at model base rate, hence the
//         generated code self-manages all its subrates.
//
static void rate_scheduler(RT_MODEL_USV_T *const USV_M)
{
  // Compute which subrates run during the next base time step.  Subrates
  //  are an integer multiple of the base rate counter.  Therefore, the subtask
  //  counter is reset when it reaches its limit (zero means run).

  (USV_M->Timing.TaskCounters.TID[2])++;
  if ((USV_M->Timing.TaskCounters.TID[2]) > 2) {// Sample time: [0.003s, 0.0s]
    USV_M->Timing.TaskCounters.TID[2] = 0;
  }

  (USV_M->Timing.TaskCounters.TID[3])++;
  if ((USV_M->Timing.TaskCounters.TID[3]) > 9) {// Sample time: [0.01s, 0.0s]
    USV_M->Timing.TaskCounters.TID[3] = 0;
  }

  (USV_M->Timing.TaskCounters.TID[4])++;
  if ((USV_M->Timing.TaskCounters.TID[4]) > 19) {// Sample time: [0.02s, 0.0s]
    USV_M->Timing.TaskCounters.TID[4] = 0;
  }

  (USV_M->Timing.TaskCounters.TID[5])++;
  if ((USV_M->Timing.TaskCounters.TID[5]) > 99) {// Sample time: [0.1s, 0.0s]
    USV_M->Timing.TaskCounters.TID[5] = 0;
  }

  (USV_M->Timing.TaskCounters.TID[6])++;
  if ((USV_M->Timing.TaskCounters.TID[6]) > 199) {// Sample time: [0.2s, 0.0s]
    USV_M->Timing.TaskCounters.TID[6] = 0;
  }
}

//
// This function updates continuous states using the ODE4 fixed-step
// solver algorithm
//
void MulticopterModelClass::rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE4_IntgData *id = static_cast<ODE4_IntgData *>(rtsiGetSolverData(si));
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T *f3 = id->f[3];
  real_T temp;
  int_T i;
  int_T nXc = 34;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  // Save the state values at time t in y, we'll use x as ynew.
  (void) std::memcpy(y, x,
                     static_cast<uint_T>(nXc)*sizeof(real_T));

  // Assumes that rtsiSetT and ModelOutputs are up-to-date
  // f0 = f(t,y)
  rtsiSetdX(si, f0);
  USV_derivatives();

  // f1 = f(t + (h/2), y + (h/2)*f0)
  temp = 0.5 * h;
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (temp*f0[i]);
  }

  rtsiSetT(si, t + temp);
  rtsiSetdX(si, f1);
  this->step();
  USV_derivatives();

  // f2 = f(t + (h/2), y + (h/2)*f1)
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (temp*f1[i]);
  }

  rtsiSetdX(si, f2);
  this->step();
  USV_derivatives();

  // f3 = f(t + h, y + h*f2)
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (h*f2[i]);
  }

  rtsiSetT(si, tnew);
  rtsiSetdX(si, f3);
  this->step();
  USV_derivatives();

  // tnew = t + h
  // ynew = y + (h/6)*(f0 + 2*f1 + 2*f2 + 2*f3)
  temp = h / 6.0;
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + temp*(f0[i] + 2.0*f1[i] + 2.0*f2[i] + f3[i]);
  }

  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

//
// System initialize for enable system:
//    '<S54>/Distance into gust (y)'
//    '<S54>/Distance into gust (z)'
//
void MulticopterModelClass::USV_Distanceintogusty_Init(B_Distanceintogusty_USV_T
  *localB, P_Distanceintogusty_USV_T *localP, X_Distanceintogusty_USV_T *localX)
{
  // InitializeConditions for Integrator: '<S58>/Distance into Gust (x) (Limited to gust length d) ' 
  localX->DistanceintoGustxLimitedtogustl =
    localP->DistanceintoGustxLimitedtogustl;

  // SystemInitialize for Integrator: '<S58>/Distance into Gust (x) (Limited to gust length d) ' incorporates:
  //   Outport: '<S58>/x'

  localB->DistanceintoGustxLimitedtogustl = localP->x_Y0;
}

//
// System reset for enable system:
//    '<S54>/Distance into gust (y)'
//    '<S54>/Distance into gust (z)'
//
void MulticopterModelClass::USV_Distanceintogusty_Reset
  (P_Distanceintogusty_USV_T *localP, X_Distanceintogusty_USV_T *localX)
{
  // InitializeConditions for Integrator: '<S58>/Distance into Gust (x) (Limited to gust length d) ' 
  localX->DistanceintoGustxLimitedtogustl =
    localP->DistanceintoGustxLimitedtogustl;
}

//
// Disable for enable system:
//    '<S54>/Distance into gust (y)'
//    '<S54>/Distance into gust (z)'
//
void MulticopterModelClass::USV_Distanceintogusty_Disable
  (DW_Distanceintogusty_USV_T *localDW)
{
  localDW->Distanceintogusty_MODE = false;
}

//
// Outputs for enable system:
//    '<S54>/Distance into gust (y)'
//    '<S54>/Distance into gust (z)'
//
void MulticopterModelClass::USV_Distanceintogusty(boolean_T rtu_Enable, real_T
  rtp_d_m, B_Distanceintogusty_USV_T *localB, DW_Distanceintogusty_USV_T
  *localDW, P_Distanceintogusty_USV_T *localP, X_Distanceintogusty_USV_T *localX)
{
  // Outputs for Enabled SubSystem: '<S54>/Distance into gust (y)' incorporates:
  //   EnablePort: '<S58>/Enable'

  if ((rtmIsMajorTimeStep((&USV_M)) &&
       (&USV_M)->Timing.TaskCounters.TID[1] == 0) && rtsiIsModeUpdateTimeStep(&(
        &USV_M)->solverInfo)) {
    if (rtu_Enable) {
      if (!localDW->Distanceintogusty_MODE) {
        USV_Distanceintogusty_Reset(localP, localX);
        localDW->Distanceintogusty_MODE = true;
      }
    } else if (localDW->Distanceintogusty_MODE) {
      USV_Distanceintogusty_Disable(localDW);
    }
  }

  if (localDW->Distanceintogusty_MODE) {
    // Integrator: '<S58>/Distance into Gust (x) (Limited to gust length d) '
    // Limited  Integrator
    if (localX->DistanceintoGustxLimitedtogustl >= rtp_d_m) {
      localX->DistanceintoGustxLimitedtogustl = rtp_d_m;
    } else if (localX->DistanceintoGustxLimitedtogustl <=
               localP->DistanceintoGustxLimitedtogus_b) {
      localX->DistanceintoGustxLimitedtogustl =
        localP->DistanceintoGustxLimitedtogus_b;
    }

    // Integrator: '<S58>/Distance into Gust (x) (Limited to gust length d) '
    localB->DistanceintoGustxLimitedtogustl =
      localX->DistanceintoGustxLimitedtogustl;
  }

  // End of Outputs for SubSystem: '<S54>/Distance into gust (y)'
}

//
// Derivatives for enable system:
//    '<S54>/Distance into gust (y)'
//    '<S54>/Distance into gust (z)'
//
void MulticopterModelClass::USV_Distanceintogusty_Deriv(real_T rtu_V, real_T
  rtp_d_m, DW_Distanceintogusty_USV_T *localDW, P_Distanceintogusty_USV_T
  *localP, X_Distanceintogusty_USV_T *localX, XDot_Distanceintogusty_USV_T
  *localXdot)
{
  if (localDW->Distanceintogusty_MODE) {
    boolean_T lsat;
    boolean_T usat;

    // Derivatives for Integrator: '<S58>/Distance into Gust (x) (Limited to gust length d) ' 
    lsat = (localX->DistanceintoGustxLimitedtogustl <=
            localP->DistanceintoGustxLimitedtogus_b);
    usat = (localX->DistanceintoGustxLimitedtogustl >= rtp_d_m);
    if (((!lsat) && (!usat)) || (lsat && (rtu_V > 0.0)) || (usat && (rtu_V < 0.0)))
    {
      localXdot->DistanceintoGustxLimitedtogustl = rtu_V;
    } else {
      // in saturation
      localXdot->DistanceintoGustxLimitedtogustl = 0.0;
    }

    // End of Derivatives for Integrator: '<S58>/Distance into Gust (x) (Limited to gust length d) ' 
  } else {
    localXdot->DistanceintoGustxLimitedtogustl = 0.0;
  }
}

real_T rt_powd_snf(real_T u0, real_T u1)
{
  real_T y;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = (rtNaN);
  } else {
    real_T tmp;
    real_T tmp_0;
    tmp = std::abs(u0);
    tmp_0 = std::abs(u1);
    if (rtIsInf(u1)) {
      if (tmp == 1.0) {
        y = 1.0;
      } else if (tmp > 1.0) {
        if (u1 > 0.0) {
          y = (rtInf);
        } else {
          y = 0.0;
        }
      } else if (u1 > 0.0) {
        y = 0.0;
      } else {
        y = (rtInf);
      }
    } else if (tmp_0 == 0.0) {
      y = 1.0;
    } else if (tmp_0 == 1.0) {
      if (u1 > 0.0) {
        y = u0;
      } else {
        y = 1.0 / u0;
      }
    } else if (u1 == 2.0) {
      y = u0 * u0;
    } else if ((u1 == 0.5) && (u0 >= 0.0)) {
      y = std::sqrt(u0);
    } else if ((u0 < 0.0) && (u1 > std::floor(u1))) {
      y = (rtNaN);
    } else {
      y = std::pow(u0, u1);
    }
  }

  return y;
}

//
// System initialize for enable system:
//    '<S112>/Hpgw'
//    '<S151>/Hpgw'
//
void MulticopterModelClass::USV_Hpgw_Init(B_Hpgw_USV_T *localB, DW_Hpgw_USV_T
  *localDW, P_Hpgw_USV_T *localP)
{
  // InitializeConditions for UnitDelay: '<S123>/Unit Delay'
  localDW->UnitDelay_DSTATE[0] = localP->UnitDelay_InitialCondition;

  // SystemInitialize for Sum: '<S123>/Sum' incorporates:
  //   Outport: '<S123>/pgw'

  localB->Sum[0] = localP->pgw_Y0;

  // InitializeConditions for UnitDelay: '<S123>/Unit Delay'
  localDW->UnitDelay_DSTATE[1] = localP->UnitDelay_InitialCondition;

  // SystemInitialize for Sum: '<S123>/Sum' incorporates:
  //   Outport: '<S123>/pgw'

  localB->Sum[1] = localP->pgw_Y0;
}

//
// System reset for enable system:
//    '<S112>/Hpgw'
//    '<S151>/Hpgw'
//
void MulticopterModelClass::USV_Hpgw_Reset(DW_Hpgw_USV_T *localDW, P_Hpgw_USV_T *
  localP)
{
  // InitializeConditions for UnitDelay: '<S123>/Unit Delay'
  localDW->UnitDelay_DSTATE[0] = localP->UnitDelay_InitialCondition;
  localDW->UnitDelay_DSTATE[1] = localP->UnitDelay_InitialCondition;
}

//
// Disable for enable system:
//    '<S112>/Hpgw'
//    '<S151>/Hpgw'
//
void MulticopterModelClass::USV_Hpgw_Disable(B_Hpgw_USV_T *localB, DW_Hpgw_USV_T
  *localDW, P_Hpgw_USV_T *localP)
{
  // Disable for Sum: '<S123>/Sum' incorporates:
  //   Outport: '<S123>/pgw'

  localB->Sum[0] = localP->pgw_Y0;
  localB->Sum[1] = localP->pgw_Y0;
  localDW->Hpgw_MODE = false;
}

//
// Outputs for enable system:
//    '<S112>/Hpgw'
//    '<S151>/Hpgw'
//
void MulticopterModelClass::USV_Hpgw(real_T rtu_Enable, const real_T rtu_L_wg[2],
  real_T rtu_sigma_wg, real_T rtu_sigma_wg_e, real_T rtu_Noise, real_T
  rtu_wingspan, B_Hpgw_USV_T *localB, DW_Hpgw_USV_T *localDW, P_Hpgw_USV_T
  *localP)
{
  // Outputs for Enabled SubSystem: '<S112>/Hpgw' incorporates:
  //   EnablePort: '<S123>/Enable'

  if ((rtmIsMajorTimeStep((&USV_M)) &&
       (&USV_M)->Timing.TaskCounters.TID[1] == 0) && rtsiIsModeUpdateTimeStep(&(
        &USV_M)->solverInfo)) {
    if (rtu_Enable > 0.0) {
      if (!localDW->Hpgw_MODE) {
        USV_Hpgw_Reset(localDW, localP);
        localDW->Hpgw_MODE = true;
      }
    } else if (localDW->Hpgw_MODE) {
      USV_Hpgw_Disable(localB, localDW, localP);
    }
  }

  if (localDW->Hpgw_MODE) {
    real_T rtb_ap_idx_0;
    real_T rtb_ap_idx_1;
    real_T rtb_sp;
    real_T rtb_sp_idx_0;
    real_T tmp;

    // Product: '<S123>/w2'
    rtb_sp = rtu_L_wg[0] * rtu_wingspan;

    // Product: '<S123>/w1' incorporates:
    //   Constant: '<S123>/Constant2'
    //   Sqrt: '<S123>/sqrt'

    rtb_ap_idx_0 = localP->Constant2_Value / std::sqrt(rtb_sp);

    // Product: '<S123>/w2'
    rtb_sp_idx_0 = rtb_sp;
    rtb_sp = rtu_L_wg[1] * rtu_wingspan;

    // Product: '<S123>/w1' incorporates:
    //   Constant: '<S123>/Constant2'
    //   Sqrt: '<S123>/sqrt'

    rtb_ap_idx_1 = localP->Constant2_Value / std::sqrt(rtb_sp);
    if (rtmIsMajorTimeStep((&USV_M)) &&
        (&USV_M)->Timing.TaskCounters.TID[3] == 0) {
      // UnitDelay: '<S123>/Unit Delay'
      localB->UnitDelay[0] = localDW->UnitDelay_DSTATE[0];
      localB->UnitDelay[1] = localDW->UnitDelay_DSTATE[1];
    }

    // Product: '<S123>/w4'
    rtb_sp_idx_0 *= rtu_wingspan;

    // Math: '<S123>/Math Function' incorporates:
    //   Constant: '<S123>/Constant3'

    tmp = std::floor(localP->Constant3_Value);
    if ((rtb_sp_idx_0 < 0.0) && (localP->Constant3_Value > tmp)) {
      rtb_sp_idx_0 = -rt_powd_snf(-rtb_sp_idx_0, localP->Constant3_Value);
    } else {
      rtb_sp_idx_0 = rt_powd_snf(rtb_sp_idx_0, localP->Constant3_Value);
    }

    // Sum: '<S123>/Sum' incorporates:
    //   Constant: '<S123>/Constant'
    //   Constant: '<S123>/Constant1'
    //   Gain: '<S123>/2'
    //   Gain: '<S123>/dt'
    //   Product: '<S123>/Lug//V1'
    //   Product: '<S123>/Lug//V2'
    //   Product: '<S123>/w3'
    //   Sqrt: '<S123>/sqrt1'
    //   Sum: '<S123>/Sum1'

    localB->Sum[0] = localP->Constant1_Value / rtb_sp_idx_0 * rtu_sigma_wg * std::
      sqrt(localP->u_Gain * rtb_ap_idx_0) * rtu_Noise + (localP->Constant_Value
      - localP->dt_Gain * rtb_ap_idx_0) * localB->UnitDelay[0];

    // Product: '<S123>/w4'
    rtb_sp_idx_0 = rtb_sp * rtu_wingspan;

    // Math: '<S123>/Math Function' incorporates:
    //   Constant: '<S123>/Constant3'

    if ((rtb_sp_idx_0 < 0.0) && (localP->Constant3_Value > tmp)) {
      rtb_sp_idx_0 = -rt_powd_snf(-rtb_sp_idx_0, localP->Constant3_Value);
    } else {
      rtb_sp_idx_0 = rt_powd_snf(rtb_sp_idx_0, localP->Constant3_Value);
    }

    // Sum: '<S123>/Sum' incorporates:
    //   Constant: '<S123>/Constant'
    //   Constant: '<S123>/Constant1'
    //   Gain: '<S123>/2'
    //   Gain: '<S123>/dt'
    //   Product: '<S123>/Lug//V1'
    //   Product: '<S123>/Lug//V2'
    //   Product: '<S123>/w3'
    //   Sqrt: '<S123>/sqrt1'
    //   Sum: '<S123>/Sum1'

    localB->Sum[1] = localP->Constant1_Value / rtb_sp_idx_0 * rtu_sigma_wg_e *
      std::sqrt(localP->u_Gain * rtb_ap_idx_1) * rtu_Noise +
      (localP->Constant_Value - localP->dt_Gain * rtb_ap_idx_1) *
      localB->UnitDelay[1];
  }

  // End of Outputs for SubSystem: '<S112>/Hpgw'
}

//
// Update for enable system:
//    '<S112>/Hpgw'
//    '<S151>/Hpgw'
//
void MulticopterModelClass::USV_Hpgw_Update(B_Hpgw_USV_T *localB, DW_Hpgw_USV_T *
  localDW)
{
  // Update for Enabled SubSystem: '<S112>/Hpgw' incorporates:
  //   EnablePort: '<S123>/Enable'

  if (localDW->Hpgw_MODE && (rtmIsMajorTimeStep((&USV_M)) &&
       (&USV_M)->Timing.TaskCounters.TID[3] == 0)) {
    // Update for UnitDelay: '<S123>/Unit Delay'
    localDW->UnitDelay_DSTATE[0] = localB->Sum[0];
    localDW->UnitDelay_DSTATE[1] = localB->Sum[1];
  }

  // End of Update for SubSystem: '<S112>/Hpgw'
}

//
// System initialize for enable system:
//    '<S112>/Hqgw'
//    '<S151>/Hqgw'
//
void MulticopterModelClass::USV_Hqgw_Init(B_Hqgw_USV_T *localB, DW_Hqgw_USV_T
  *localDW, P_Hqgw_USV_T *localP)
{
  // InitializeConditions for UnitDelay: '<S124>/Unit Delay'
  localDW->UnitDelay_DSTATE[0] = localP->UnitDelay_InitialCondition;

  // InitializeConditions for UnitDelay: '<S124>/Unit Delay1'
  localDW->UnitDelay1_DSTATE[0] = localP->UnitDelay1_InitialCondition;

  // SystemInitialize for Sum: '<S124>/Sum1' incorporates:
  //   Outport: '<S124>/qgw'

  localB->Sum1[0] = localP->qgw_Y0;

  // InitializeConditions for UnitDelay: '<S124>/Unit Delay'
  localDW->UnitDelay_DSTATE[1] = localP->UnitDelay_InitialCondition;

  // InitializeConditions for UnitDelay: '<S124>/Unit Delay1'
  localDW->UnitDelay1_DSTATE[1] = localP->UnitDelay1_InitialCondition;

  // SystemInitialize for Sum: '<S124>/Sum1' incorporates:
  //   Outport: '<S124>/qgw'

  localB->Sum1[1] = localP->qgw_Y0;
}

//
// System reset for enable system:
//    '<S112>/Hqgw'
//    '<S151>/Hqgw'
//
void MulticopterModelClass::USV_Hqgw_Reset(DW_Hqgw_USV_T *localDW, P_Hqgw_USV_T *
  localP)
{
  // InitializeConditions for UnitDelay: '<S124>/Unit Delay'
  localDW->UnitDelay_DSTATE[0] = localP->UnitDelay_InitialCondition;

  // InitializeConditions for UnitDelay: '<S124>/Unit Delay1'
  localDW->UnitDelay1_DSTATE[0] = localP->UnitDelay1_InitialCondition;

  // InitializeConditions for UnitDelay: '<S124>/Unit Delay'
  localDW->UnitDelay_DSTATE[1] = localP->UnitDelay_InitialCondition;

  // InitializeConditions for UnitDelay: '<S124>/Unit Delay1'
  localDW->UnitDelay1_DSTATE[1] = localP->UnitDelay1_InitialCondition;
}

//
// Disable for enable system:
//    '<S112>/Hqgw'
//    '<S151>/Hqgw'
//
void MulticopterModelClass::USV_Hqgw_Disable(B_Hqgw_USV_T *localB, DW_Hqgw_USV_T
  *localDW, P_Hqgw_USV_T *localP)
{
  // Disable for Sum: '<S124>/Sum1' incorporates:
  //   Outport: '<S124>/qgw'

  localB->Sum1[0] = localP->qgw_Y0;
  localB->Sum1[1] = localP->qgw_Y0;
  localDW->Hqgw_MODE = false;
}

//
// Outputs for enable system:
//    '<S112>/Hqgw'
//    '<S151>/Hqgw'
//
void MulticopterModelClass::USV_Hqgw(real_T rtu_Enable, real_T rtu_V, const
  real_T rtu_wg[2], real_T rtu_wingspan, B_Hqgw_USV_T *localB, DW_Hqgw_USV_T
  *localDW, P_Hqgw_USV_T *localP)
{
  // Outputs for Enabled SubSystem: '<S112>/Hqgw' incorporates:
  //   EnablePort: '<S124>/Enable'

  if ((rtmIsMajorTimeStep((&USV_M)) &&
       (&USV_M)->Timing.TaskCounters.TID[1] == 0) && rtsiIsModeUpdateTimeStep(&(
        &USV_M)->solverInfo)) {
    if (rtu_Enable > 0.0) {
      if (!localDW->Hqgw_MODE) {
        USV_Hqgw_Reset(localDW, localP);
        localDW->Hqgw_MODE = true;
      }
    } else if (localDW->Hqgw_MODE) {
      USV_Hqgw_Disable(localB, localDW, localP);
    }
  }

  if (localDW->Hqgw_MODE) {
    if (rtmIsMajorTimeStep((&USV_M)) &&
        (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
      // Gain: '<S124>/dt1'
      localB->dt1 = localP->dt1_Gain * rtu_wingspan;

      // Sum: '<S124>/Sum2' incorporates:
      //   Constant: '<S124>/Constant'
      //   Gain: '<S124>/dt'
      //   Product: '<S124>/w1'

      localB->Sum2 = localP->Constant_Value - rtu_V / localB->dt1 *
        localP->dt_Gain;
    }

    if (rtmIsMajorTimeStep((&USV_M)) &&
        (&USV_M)->Timing.TaskCounters.TID[3] == 0) {
      // Product: '<S124>/Lug//V2' incorporates:
      //   UnitDelay: '<S124>/Unit Delay'

      localB->LugV2[0] = localB->Sum2 * localDW->UnitDelay_DSTATE[0];

      // UnitDelay: '<S124>/Unit Delay1'
      localB->UnitDelay1[0] = localDW->UnitDelay1_DSTATE[0];

      // Product: '<S124>/Lug//V2' incorporates:
      //   UnitDelay: '<S124>/Unit Delay'

      localB->LugV2[1] = localB->Sum2 * localDW->UnitDelay_DSTATE[1];

      // UnitDelay: '<S124>/Unit Delay1'
      localB->UnitDelay1[1] = localDW->UnitDelay1_DSTATE[1];
    }

    // Sum: '<S124>/Sum1' incorporates:
    //   Product: '<S124>/w2'
    //   Sum: '<S124>/Sum3'

    localB->Sum1[0] = localB->LugV2[0] - (rtu_wg[0] - localB->UnitDelay1[0]) /
      localB->dt1;
    localB->Sum1[1] = localB->LugV2[1] - (rtu_wg[1] - localB->UnitDelay1[1]) /
      localB->dt1;
  }

  // End of Outputs for SubSystem: '<S112>/Hqgw'
}

//
// Update for enable system:
//    '<S112>/Hqgw'
//    '<S151>/Hqgw'
//
void MulticopterModelClass::USV_Hqgw_Update(const real_T rtu_wg[2], B_Hqgw_USV_T
  *localB, DW_Hqgw_USV_T *localDW)
{
  // Update for Enabled SubSystem: '<S112>/Hqgw' incorporates:
  //   EnablePort: '<S124>/Enable'

  if (localDW->Hqgw_MODE && (rtmIsMajorTimeStep((&USV_M)) &&
       (&USV_M)->Timing.TaskCounters.TID[3] == 0)) {
    // Update for UnitDelay: '<S124>/Unit Delay'
    localDW->UnitDelay_DSTATE[0] = localB->Sum1[0];

    // Update for UnitDelay: '<S124>/Unit Delay1'
    localDW->UnitDelay1_DSTATE[0] = rtu_wg[0];

    // Update for UnitDelay: '<S124>/Unit Delay'
    localDW->UnitDelay_DSTATE[1] = localB->Sum1[1];

    // Update for UnitDelay: '<S124>/Unit Delay1'
    localDW->UnitDelay1_DSTATE[1] = rtu_wg[1];
  }

  // End of Update for SubSystem: '<S112>/Hqgw'
}

//
// System initialize for enable system:
//    '<S112>/Hrgw'
//    '<S151>/Hrgw'
//
void MulticopterModelClass::USV_Hrgw_Init(B_Hrgw_USV_T *localB, DW_Hrgw_USV_T
  *localDW, P_Hrgw_USV_T *localP)
{
  // InitializeConditions for UnitDelay: '<S125>/Unit Delay'
  localDW->UnitDelay_DSTATE[0] = localP->UnitDelay_InitialCondition;

  // InitializeConditions for UnitDelay: '<S125>/Unit Delay1'
  localDW->UnitDelay1_DSTATE[0] = localP->UnitDelay1_InitialCondition;

  // SystemInitialize for Sum: '<S125>/Sum1' incorporates:
  //   Outport: '<S125>/rgw'

  localB->Sum1[0] = localP->rgw_Y0;

  // InitializeConditions for UnitDelay: '<S125>/Unit Delay'
  localDW->UnitDelay_DSTATE[1] = localP->UnitDelay_InitialCondition;

  // InitializeConditions for UnitDelay: '<S125>/Unit Delay1'
  localDW->UnitDelay1_DSTATE[1] = localP->UnitDelay1_InitialCondition;

  // SystemInitialize for Sum: '<S125>/Sum1' incorporates:
  //   Outport: '<S125>/rgw'

  localB->Sum1[1] = localP->rgw_Y0;
}

//
// System reset for enable system:
//    '<S112>/Hrgw'
//    '<S151>/Hrgw'
//
void MulticopterModelClass::USV_Hrgw_Reset(DW_Hrgw_USV_T *localDW, P_Hrgw_USV_T *
  localP)
{
  // InitializeConditions for UnitDelay: '<S125>/Unit Delay'
  localDW->UnitDelay_DSTATE[0] = localP->UnitDelay_InitialCondition;

  // InitializeConditions for UnitDelay: '<S125>/Unit Delay1'
  localDW->UnitDelay1_DSTATE[0] = localP->UnitDelay1_InitialCondition;

  // InitializeConditions for UnitDelay: '<S125>/Unit Delay'
  localDW->UnitDelay_DSTATE[1] = localP->UnitDelay_InitialCondition;

  // InitializeConditions for UnitDelay: '<S125>/Unit Delay1'
  localDW->UnitDelay1_DSTATE[1] = localP->UnitDelay1_InitialCondition;
}

//
// Disable for enable system:
//    '<S112>/Hrgw'
//    '<S151>/Hrgw'
//
void MulticopterModelClass::USV_Hrgw_Disable(B_Hrgw_USV_T *localB, DW_Hrgw_USV_T
  *localDW, P_Hrgw_USV_T *localP)
{
  // Disable for Sum: '<S125>/Sum1' incorporates:
  //   Outport: '<S125>/rgw'

  localB->Sum1[0] = localP->rgw_Y0;
  localB->Sum1[1] = localP->rgw_Y0;
  localDW->Hrgw_MODE = false;
}

//
// Outputs for enable system:
//    '<S112>/Hrgw'
//    '<S151>/Hrgw'
//
void MulticopterModelClass::USV_Hrgw(real_T rtu_Enable, real_T rtu_V, const
  real_T rtu_vg[2], real_T rtu_wingspan, B_Hrgw_USV_T *localB, DW_Hrgw_USV_T
  *localDW, P_Hrgw_USV_T *localP)
{
  // Outputs for Enabled SubSystem: '<S112>/Hrgw' incorporates:
  //   EnablePort: '<S125>/Enable'

  if ((rtmIsMajorTimeStep((&USV_M)) &&
       (&USV_M)->Timing.TaskCounters.TID[1] == 0) && rtsiIsModeUpdateTimeStep(&(
        &USV_M)->solverInfo)) {
    if (rtu_Enable > 0.0) {
      if (!localDW->Hrgw_MODE) {
        USV_Hrgw_Reset(localDW, localP);
        localDW->Hrgw_MODE = true;
      }
    } else if (localDW->Hrgw_MODE) {
      USV_Hrgw_Disable(localB, localDW, localP);
    }
  }

  if (localDW->Hrgw_MODE) {
    if (rtmIsMajorTimeStep((&USV_M)) &&
        (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
      // Gain: '<S125>/dt1'
      localB->dt1 = localP->dt1_Gain * rtu_wingspan;

      // Sum: '<S125>/Sum2' incorporates:
      //   Constant: '<S125>/Constant'
      //   Gain: '<S125>/dt'
      //   Product: '<S125>/w1'

      localB->Sum2 = localP->Constant_Value - rtu_V / localB->dt1 *
        localP->dt_Gain;
    }

    if (rtmIsMajorTimeStep((&USV_M)) &&
        (&USV_M)->Timing.TaskCounters.TID[3] == 0) {
      // Product: '<S125>/Lug//V2' incorporates:
      //   UnitDelay: '<S125>/Unit Delay'

      localB->LugV2[0] = localB->Sum2 * localDW->UnitDelay_DSTATE[0];

      // UnitDelay: '<S125>/Unit Delay1'
      localB->UnitDelay1[0] = localDW->UnitDelay1_DSTATE[0];

      // Product: '<S125>/Lug//V2' incorporates:
      //   UnitDelay: '<S125>/Unit Delay'

      localB->LugV2[1] = localB->Sum2 * localDW->UnitDelay_DSTATE[1];

      // UnitDelay: '<S125>/Unit Delay1'
      localB->UnitDelay1[1] = localDW->UnitDelay1_DSTATE[1];
    }

    // Sum: '<S125>/Sum1' incorporates:
    //   Product: '<S125>/w2'
    //   Sum: '<S125>/Sum3'

    localB->Sum1[0] = (rtu_vg[0] - localB->UnitDelay1[0]) / localB->dt1 +
      localB->LugV2[0];
    localB->Sum1[1] = (rtu_vg[1] - localB->UnitDelay1[1]) / localB->dt1 +
      localB->LugV2[1];
  }

  // End of Outputs for SubSystem: '<S112>/Hrgw'
}

//
// Update for enable system:
//    '<S112>/Hrgw'
//    '<S151>/Hrgw'
//
void MulticopterModelClass::USV_Hrgw_Update(const real_T rtu_vg[2], B_Hrgw_USV_T
  *localB, DW_Hrgw_USV_T *localDW)
{
  // Update for Enabled SubSystem: '<S112>/Hrgw' incorporates:
  //   EnablePort: '<S125>/Enable'

  if (localDW->Hrgw_MODE && (rtmIsMajorTimeStep((&USV_M)) &&
       (&USV_M)->Timing.TaskCounters.TID[3] == 0)) {
    // Update for UnitDelay: '<S125>/Unit Delay'
    localDW->UnitDelay_DSTATE[0] = localB->Sum1[0];

    // Update for UnitDelay: '<S125>/Unit Delay1'
    localDW->UnitDelay1_DSTATE[0] = rtu_vg[0];

    // Update for UnitDelay: '<S125>/Unit Delay'
    localDW->UnitDelay_DSTATE[1] = localB->Sum1[1];

    // Update for UnitDelay: '<S125>/Unit Delay1'
    localDW->UnitDelay1_DSTATE[1] = rtu_vg[1];
  }

  // End of Update for SubSystem: '<S112>/Hrgw'
}

//
// System initialize for enable system:
//    '<S113>/Hugw(z)'
//    '<S152>/Hugw(z)'
//
void MulticopterModelClass::USV_Hugwz_Init(B_Hugwz_USV_T *localB, DW_Hugwz_USV_T
  *localDW, P_Hugwz_USV_T *localP)
{
  // InitializeConditions for UnitDelay: '<S126>/Unit Delay'
  localDW->UnitDelay_DSTATE[0] = localP->UnitDelay_InitialCondition;

  // SystemInitialize for Sum: '<S126>/Sum' incorporates:
  //   Outport: '<S126>/ugw'

  localB->Sum[0] = localP->ugw_Y0;

  // InitializeConditions for UnitDelay: '<S126>/Unit Delay'
  localDW->UnitDelay_DSTATE[1] = localP->UnitDelay_InitialCondition;

  // SystemInitialize for Sum: '<S126>/Sum' incorporates:
  //   Outport: '<S126>/ugw'

  localB->Sum[1] = localP->ugw_Y0;
}

//
// System reset for enable system:
//    '<S113>/Hugw(z)'
//    '<S152>/Hugw(z)'
//
void MulticopterModelClass::USV_Hugwz_Reset(DW_Hugwz_USV_T *localDW,
  P_Hugwz_USV_T *localP)
{
  // InitializeConditions for UnitDelay: '<S126>/Unit Delay'
  localDW->UnitDelay_DSTATE[0] = localP->UnitDelay_InitialCondition;
  localDW->UnitDelay_DSTATE[1] = localP->UnitDelay_InitialCondition;
}

//
// Disable for enable system:
//    '<S113>/Hugw(z)'
//    '<S152>/Hugw(z)'
//
void MulticopterModelClass::USV_Hugwz_Disable(B_Hugwz_USV_T *localB,
  DW_Hugwz_USV_T *localDW, P_Hugwz_USV_T *localP)
{
  // Disable for Sum: '<S126>/Sum' incorporates:
  //   Outport: '<S126>/ugw'

  localB->Sum[0] = localP->ugw_Y0;
  localB->Sum[1] = localP->ugw_Y0;
  localDW->Hugwz_MODE = false;
}

//
// Outputs for enable system:
//    '<S113>/Hugw(z)'
//    '<S152>/Hugw(z)'
//
void MulticopterModelClass::USV_Hugwz(real_T rtu_Enable, real_T rtu_V, real_T
  rtu_L_ug, real_T rtu_L_ug_n, real_T rtu_sigma_ug, real_T rtu_sigma_ug_f,
  real_T rtu_Noise, B_Hugwz_USV_T *localB, DW_Hugwz_USV_T *localDW,
  P_Hugwz_USV_T *localP)
{
  // Outputs for Enabled SubSystem: '<S113>/Hugw(z)' incorporates:
  //   EnablePort: '<S126>/Enable'

  if ((rtmIsMajorTimeStep((&USV_M)) &&
       (&USV_M)->Timing.TaskCounters.TID[1] == 0) && rtsiIsModeUpdateTimeStep(&(
        &USV_M)->solverInfo)) {
    if (rtu_Enable > 0.0) {
      if (!localDW->Hugwz_MODE) {
        USV_Hugwz_Reset(localDW, localP);
        localDW->Hugwz_MODE = true;
      }
    } else if (localDW->Hugwz_MODE) {
      USV_Hugwz_Disable(localB, localDW, localP);
    }
  }

  if (localDW->Hugwz_MODE) {
    real_T rtb_VLug_idx_0;
    real_T rtb_VLug_idx_1;

    // Product: '<S126>/V//Lug'
    rtb_VLug_idx_0 = rtu_V / rtu_L_ug;
    rtb_VLug_idx_1 = rtu_V / rtu_L_ug_n;
    if (rtmIsMajorTimeStep((&USV_M)) &&
        (&USV_M)->Timing.TaskCounters.TID[3] == 0) {
      // UnitDelay: '<S126>/Unit Delay'
      localB->UnitDelay[0] = localDW->UnitDelay_DSTATE[0];
      localB->UnitDelay[1] = localDW->UnitDelay_DSTATE[1];
    }

    // Sum: '<S126>/Sum' incorporates:
    //   Constant: '<S126>/Constant'
    //   Gain: '<S126>/2'
    //   Gain: '<S126>/dt'
    //   Product: '<S126>/Lug//V1'
    //   Product: '<S126>/Lug//V2'
    //   Sqrt: '<S126>/sqrt'
    //   Sum: '<S126>/Sum1'

    localB->Sum[0] = (localP->Constant_Value - localP->dt_Gain * rtb_VLug_idx_0)
      * localB->UnitDelay[0] + std::sqrt(localP->u_Gain * rtb_VLug_idx_0) *
      rtu_Noise * rtu_sigma_ug;
    localB->Sum[1] = (localP->Constant_Value - localP->dt_Gain * rtb_VLug_idx_1)
      * localB->UnitDelay[1] + std::sqrt(localP->u_Gain * rtb_VLug_idx_1) *
      rtu_Noise * rtu_sigma_ug_f;
  }

  // End of Outputs for SubSystem: '<S113>/Hugw(z)'
}

//
// Update for enable system:
//    '<S113>/Hugw(z)'
//    '<S152>/Hugw(z)'
//
void MulticopterModelClass::USV_Hugwz_Update(B_Hugwz_USV_T *localB,
  DW_Hugwz_USV_T *localDW)
{
  // Update for Enabled SubSystem: '<S113>/Hugw(z)' incorporates:
  //   EnablePort: '<S126>/Enable'

  if (localDW->Hugwz_MODE && (rtmIsMajorTimeStep((&USV_M)) &&
       (&USV_M)->Timing.TaskCounters.TID[3] == 0)) {
    // Update for UnitDelay: '<S126>/Unit Delay'
    localDW->UnitDelay_DSTATE[0] = localB->Sum[0];
    localDW->UnitDelay_DSTATE[1] = localB->Sum[1];
  }

  // End of Update for SubSystem: '<S113>/Hugw(z)'
}

//
// System initialize for enable system:
//    '<S113>/Hvgw(z)'
//    '<S152>/Hvgw(z)'
//
void MulticopterModelClass::USV_Hvgwz_Init(B_Hvgwz_USV_T *localB, DW_Hvgwz_USV_T
  *localDW, P_Hvgwz_USV_T *localP)
{
  // InitializeConditions for UnitDelay: '<S127>/Unit Delay'
  localDW->UnitDelay_DSTATE[0] = localP->UnitDelay_InitialCondition;

  // SystemInitialize for Sum: '<S127>/Sum' incorporates:
  //   Outport: '<S127>/vgw'

  localB->Sum[0] = localP->vgw_Y0;

  // InitializeConditions for UnitDelay: '<S127>/Unit Delay'
  localDW->UnitDelay_DSTATE[1] = localP->UnitDelay_InitialCondition;

  // SystemInitialize for Sum: '<S127>/Sum' incorporates:
  //   Outport: '<S127>/vgw'

  localB->Sum[1] = localP->vgw_Y0;
}

//
// System reset for enable system:
//    '<S113>/Hvgw(z)'
//    '<S152>/Hvgw(z)'
//
void MulticopterModelClass::USV_Hvgwz_Reset(DW_Hvgwz_USV_T *localDW,
  P_Hvgwz_USV_T *localP)
{
  // InitializeConditions for UnitDelay: '<S127>/Unit Delay'
  localDW->UnitDelay_DSTATE[0] = localP->UnitDelay_InitialCondition;
  localDW->UnitDelay_DSTATE[1] = localP->UnitDelay_InitialCondition;
}

//
// Disable for enable system:
//    '<S113>/Hvgw(z)'
//    '<S152>/Hvgw(z)'
//
void MulticopterModelClass::USV_Hvgwz_Disable(B_Hvgwz_USV_T *localB,
  DW_Hvgwz_USV_T *localDW, P_Hvgwz_USV_T *localP)
{
  // Disable for Sum: '<S127>/Sum' incorporates:
  //   Outport: '<S127>/vgw'

  localB->Sum[0] = localP->vgw_Y0;
  localB->Sum[1] = localP->vgw_Y0;
  localDW->Hvgwz_MODE = false;
}

//
// Outputs for enable system:
//    '<S113>/Hvgw(z)'
//    '<S152>/Hvgw(z)'
//
void MulticopterModelClass::USV_Hvgwz(real_T rtu_Enable, real_T rtu_sigma_vg,
  real_T rtu_sigma_vg_j, const real_T rtu_L_vg[2], real_T rtu_V, real_T
  rtu_Noise, B_Hvgwz_USV_T *localB, DW_Hvgwz_USV_T *localDW, P_Hvgwz_USV_T
  *localP)
{
  // Outputs for Enabled SubSystem: '<S113>/Hvgw(z)' incorporates:
  //   EnablePort: '<S127>/Enable'

  if ((rtmIsMajorTimeStep((&USV_M)) &&
       (&USV_M)->Timing.TaskCounters.TID[1] == 0) && rtsiIsModeUpdateTimeStep(&(
        &USV_M)->solverInfo)) {
    if (rtu_Enable > 0.0) {
      if (!localDW->Hvgwz_MODE) {
        USV_Hvgwz_Reset(localDW, localP);
        localDW->Hvgwz_MODE = true;
      }
    } else if (localDW->Hvgwz_MODE) {
      USV_Hvgwz_Disable(localB, localDW, localP);
    }
  }

  if (localDW->Hvgwz_MODE) {
    real_T rtb_VLvg_idx_0;
    real_T rtb_VLvg_idx_1;

    // Product: '<S127>/V//Lvg'
    rtb_VLvg_idx_0 = rtu_V / rtu_L_vg[0];
    rtb_VLvg_idx_1 = rtu_V / rtu_L_vg[1];
    if (rtmIsMajorTimeStep((&USV_M)) &&
        (&USV_M)->Timing.TaskCounters.TID[3] == 0) {
      // UnitDelay: '<S127>/Unit Delay'
      localB->UnitDelay[0] = localDW->UnitDelay_DSTATE[0];
      localB->UnitDelay[1] = localDW->UnitDelay_DSTATE[1];
    }

    // Sum: '<S127>/Sum' incorporates:
    //   Constant: '<S127>/Constant'
    //   Gain: '<S127>/2'
    //   Gain: '<S127>/dt'
    //   Product: '<S127>/Lug//V1'
    //   Product: '<S127>/Lug//V2'
    //   Sqrt: '<S127>/sqrt'
    //   Sum: '<S127>/Sum1'

    localB->Sum[0] = (localP->Constant_Value - localP->dt_Gain * rtb_VLvg_idx_0)
      * localB->UnitDelay[0] + std::sqrt(localP->u_Gain * rtb_VLvg_idx_0) *
      rtu_Noise * rtu_sigma_vg;
    localB->Sum[1] = (localP->Constant_Value - localP->dt_Gain * rtb_VLvg_idx_1)
      * localB->UnitDelay[1] + std::sqrt(localP->u_Gain * rtb_VLvg_idx_1) *
      rtu_Noise * rtu_sigma_vg_j;
  }

  // End of Outputs for SubSystem: '<S113>/Hvgw(z)'
}

//
// Update for enable system:
//    '<S113>/Hvgw(z)'
//    '<S152>/Hvgw(z)'
//
void MulticopterModelClass::USV_Hvgwz_Update(B_Hvgwz_USV_T *localB,
  DW_Hvgwz_USV_T *localDW)
{
  // Update for Enabled SubSystem: '<S113>/Hvgw(z)' incorporates:
  //   EnablePort: '<S127>/Enable'

  if (localDW->Hvgwz_MODE && (rtmIsMajorTimeStep((&USV_M)) &&
       (&USV_M)->Timing.TaskCounters.TID[3] == 0)) {
    // Update for UnitDelay: '<S127>/Unit Delay'
    localDW->UnitDelay_DSTATE[0] = localB->Sum[0];
    localDW->UnitDelay_DSTATE[1] = localB->Sum[1];
  }

  // End of Update for SubSystem: '<S113>/Hvgw(z)'
}

//
// System initialize for enable system:
//    '<S113>/Hwgw(z)'
//    '<S152>/Hwgw(z)'
//
void MulticopterModelClass::USV_Hwgwz_Init(B_Hwgwz_USV_T *localB, DW_Hwgwz_USV_T
  *localDW, P_Hwgwz_USV_T *localP)
{
  // InitializeConditions for UnitDelay: '<S128>/Unit Delay'
  localDW->UnitDelay_DSTATE[0] = localP->UnitDelay_InitialCondition;

  // SystemInitialize for Sum: '<S128>/Sum' incorporates:
  //   Outport: '<S128>/wgw'

  localB->Sum[0] = localP->wgw_Y0;

  // InitializeConditions for UnitDelay: '<S128>/Unit Delay'
  localDW->UnitDelay_DSTATE[1] = localP->UnitDelay_InitialCondition;

  // SystemInitialize for Sum: '<S128>/Sum' incorporates:
  //   Outport: '<S128>/wgw'

  localB->Sum[1] = localP->wgw_Y0;
}

//
// System reset for enable system:
//    '<S113>/Hwgw(z)'
//    '<S152>/Hwgw(z)'
//
void MulticopterModelClass::USV_Hwgwz_Reset(DW_Hwgwz_USV_T *localDW,
  P_Hwgwz_USV_T *localP)
{
  // InitializeConditions for UnitDelay: '<S128>/Unit Delay'
  localDW->UnitDelay_DSTATE[0] = localP->UnitDelay_InitialCondition;
  localDW->UnitDelay_DSTATE[1] = localP->UnitDelay_InitialCondition;
}

//
// Disable for enable system:
//    '<S113>/Hwgw(z)'
//    '<S152>/Hwgw(z)'
//
void MulticopterModelClass::USV_Hwgwz_Disable(B_Hwgwz_USV_T *localB,
  DW_Hwgwz_USV_T *localDW, P_Hwgwz_USV_T *localP)
{
  // Disable for Sum: '<S128>/Sum' incorporates:
  //   Outport: '<S128>/wgw'

  localB->Sum[0] = localP->wgw_Y0;
  localB->Sum[1] = localP->wgw_Y0;
  localDW->Hwgwz_MODE = false;
}

//
// Outputs for enable system:
//    '<S113>/Hwgw(z)'
//    '<S152>/Hwgw(z)'
//
void MulticopterModelClass::USV_Hwgwz(real_T rtu_Enable, real_T rtu_V, const
  real_T rtu_L_wg[2], real_T rtu_sigma_wg, real_T rtu_sigma_wg_j, real_T
  rtu_Noise, B_Hwgwz_USV_T *localB, DW_Hwgwz_USV_T *localDW, P_Hwgwz_USV_T
  *localP)
{
  // Outputs for Enabled SubSystem: '<S113>/Hwgw(z)' incorporates:
  //   EnablePort: '<S128>/Enable'

  if ((rtmIsMajorTimeStep((&USV_M)) &&
       (&USV_M)->Timing.TaskCounters.TID[1] == 0) && rtsiIsModeUpdateTimeStep(&(
        &USV_M)->solverInfo)) {
    if (rtu_Enable > 0.0) {
      if (!localDW->Hwgwz_MODE) {
        USV_Hwgwz_Reset(localDW, localP);
        localDW->Hwgwz_MODE = true;
      }
    } else if (localDW->Hwgwz_MODE) {
      USV_Hwgwz_Disable(localB, localDW, localP);
    }
  }

  if (localDW->Hwgwz_MODE) {
    real_T rtb_VLwg_idx_0;
    real_T rtb_VLwg_idx_1;

    // Product: '<S128>/V//Lwg'
    rtb_VLwg_idx_0 = rtu_V / rtu_L_wg[0];
    rtb_VLwg_idx_1 = rtu_V / rtu_L_wg[1];
    if (rtmIsMajorTimeStep((&USV_M)) &&
        (&USV_M)->Timing.TaskCounters.TID[3] == 0) {
      // UnitDelay: '<S128>/Unit Delay'
      localB->UnitDelay[0] = localDW->UnitDelay_DSTATE[0];
      localB->UnitDelay[1] = localDW->UnitDelay_DSTATE[1];
    }

    // Sum: '<S128>/Sum' incorporates:
    //   Constant: '<S128>/Constant'
    //   Gain: '<S128>/2'
    //   Gain: '<S128>/dt'
    //   Product: '<S128>/Lug//V1'
    //   Product: '<S128>/Lug//V2'
    //   Sqrt: '<S128>/sqrt'
    //   Sum: '<S128>/Sum1'

    localB->Sum[0] = (localP->Constant_Value - localP->dt_Gain * rtb_VLwg_idx_0)
      * localB->UnitDelay[0] + std::sqrt(localP->u_Gain * rtb_VLwg_idx_0) *
      rtu_Noise * rtu_sigma_wg;
    localB->Sum[1] = (localP->Constant_Value - localP->dt_Gain * rtb_VLwg_idx_1)
      * localB->UnitDelay[1] + std::sqrt(localP->u_Gain * rtb_VLwg_idx_1) *
      rtu_Noise * rtu_sigma_wg_j;
  }

  // End of Outputs for SubSystem: '<S113>/Hwgw(z)'
}

//
// Update for enable system:
//    '<S113>/Hwgw(z)'
//    '<S152>/Hwgw(z)'
//
void MulticopterModelClass::USV_Hwgwz_Update(B_Hwgwz_USV_T *localB,
  DW_Hwgwz_USV_T *localDW)
{
  // Update for Enabled SubSystem: '<S113>/Hwgw(z)' incorporates:
  //   EnablePort: '<S128>/Enable'

  if (localDW->Hwgwz_MODE && (rtmIsMajorTimeStep((&USV_M)) &&
       (&USV_M)->Timing.TaskCounters.TID[3] == 0)) {
    // Update for UnitDelay: '<S128>/Unit Delay'
    localDW->UnitDelay_DSTATE[0] = localB->Sum[0];
    localDW->UnitDelay_DSTATE[1] = localB->Sum[1];
  }

  // End of Update for SubSystem: '<S113>/Hwgw(z)'
}

//
// Output and update for action system:
//    '<S117>/Low altitude  rates'
//    '<S156>/Low altitude  rates'
//
void MulticopterModelClass::USV_Lowaltituderates(const real_T rtu_DCM[9], const
  real_T rtu_pgw_hl[2], const real_T rtu_qgw_hl[2], const real_T rtu_rgw_hl[2],
  real_T rtu_Winddirection, real_T rty_pgwqgwrgw[3])
{
  real_T rtb_TrigonometricFunction1_o1;
  real_T rtb_TrigonometricFunction1_o2;
  real_T rtb_VectorConcatenate_o_idx_0;
  real_T rtb_VectorConcatenate_o_idx_2;

  // SignalConversion generated from: '<S137>/Vector Concatenate'
  rtb_VectorConcatenate_o_idx_2 = rtu_rgw_hl[0];

  // Trigonometry: '<S138>/Trigonometric Function1'
  rtb_TrigonometricFunction1_o1 = std::sin(rtu_Winddirection);
  rtb_TrigonometricFunction1_o2 = std::cos(rtu_Winddirection);

  // Sum: '<S138>/Sum' incorporates:
  //   Product: '<S138>/Product1'
  //   Product: '<S138>/Product2'

  rtb_VectorConcatenate_o_idx_0 = rtu_pgw_hl[0] * rtb_TrigonometricFunction1_o2
    - rtb_TrigonometricFunction1_o1 * rtu_qgw_hl[0];

  // Sum: '<S138>/Sum1' incorporates:
  //   Product: '<S138>/Product1'
  //   Product: '<S138>/Product2'

  rtb_TrigonometricFunction1_o1 = rtb_TrigonometricFunction1_o1 * rtu_pgw_hl[0]
    + rtu_qgw_hl[0] * rtb_TrigonometricFunction1_o2;

  // Reshape: '<S137>/Reshape1' incorporates:
  //   Concatenate: '<S137>/Vector Concatenate'
  //   Product: '<S137>/Product'

  for (int32_T i = 0; i < 3; i++) {
    rty_pgwqgwrgw[i] = 0.0;
    rty_pgwqgwrgw[i] += rtu_DCM[i] * rtb_VectorConcatenate_o_idx_0;
    rty_pgwqgwrgw[i] += rtu_DCM[i + 3] * rtb_TrigonometricFunction1_o1;
    rty_pgwqgwrgw[i] += rtu_DCM[i + 6] * rtb_VectorConcatenate_o_idx_2;
  }

  // End of Reshape: '<S137>/Reshape1'
}

//
// Output and update for action system:
//    '<S117>/Interpolate  rates'
//    '<S156>/Interpolate  rates'
//
void MulticopterModelClass::USV_Interpolaterates(const real_T rtu_pgw_hl[2],
  const real_T rtu_qgw_hl[2], const real_T rtu_rgw_hl[2], const real_T rtu_DCM[9],
  real_T rtu_Winddirection, real_T rtu_Altitude, real_T rty_pgwqgwrgw[3],
  P_Interpolaterates_USV_T *localP)
{
  real_T rtb_Product_iy[3];
  real_T rtb_TrigonometricFunction_o1;
  real_T rtb_TrigonometricFunction_o2;
  real_T rtb_VectorConcatenate_h_idx_0;

  // Trigonometry: '<S136>/Trigonometric Function'
  rtb_TrigonometricFunction_o1 = std::sin(rtu_Winddirection);
  rtb_TrigonometricFunction_o2 = std::cos(rtu_Winddirection);

  // Sum: '<S136>/Sum' incorporates:
  //   Product: '<S136>/Product1'
  //   Product: '<S136>/Product2'

  rtb_VectorConcatenate_h_idx_0 = rtu_pgw_hl[0] * rtb_TrigonometricFunction_o2 -
    rtb_TrigonometricFunction_o1 * rtu_qgw_hl[0];

  // Sum: '<S136>/Sum1' incorporates:
  //   Product: '<S136>/Product1'
  //   Product: '<S136>/Product2'

  rtb_TrigonometricFunction_o1 = rtb_TrigonometricFunction_o1 * rtu_pgw_hl[0] +
    rtu_qgw_hl[0] * rtb_TrigonometricFunction_o2;

  // SignalConversion generated from: '<S135>/Vector Concatenate'
  rtb_TrigonometricFunction_o2 = rtu_rgw_hl[0];

  // Product: '<S135>/Product' incorporates:
  //   Concatenate: '<S135>/Vector Concatenate'

  for (int32_T i = 0; i < 3; i++) {
    rtb_Product_iy[i] = (rtu_DCM[i + 3] * rtb_TrigonometricFunction_o1 +
                         rtu_DCM[i] * rtb_VectorConcatenate_h_idx_0) + rtu_DCM[i
      + 6] * rtb_TrigonometricFunction_o2;
  }

  // End of Product: '<S135>/Product'

  // Sum: '<S131>/Sum1' incorporates:
  //   Constant: '<S131>/max_height_low'

  rtb_TrigonometricFunction_o1 = rtu_Altitude - localP->max_height_low_Value;

  // Sum: '<S131>/Sum' incorporates:
  //   Constant: '<S131>/max_height_low'
  //   Constant: '<S131>/min_height_high'

  rtb_TrigonometricFunction_o2 = localP->min_height_high_Value -
    localP->max_height_low_Value;

  // Sum: '<S131>/Sum3' incorporates:
  //   Product: '<S131>/Product1'
  //   Sum: '<S131>/Sum2'

  rty_pgwqgwrgw[0] = (rtu_pgw_hl[1] - rtb_Product_iy[0]) *
    rtb_TrigonometricFunction_o1 / rtb_TrigonometricFunction_o2 +
    rtb_Product_iy[0];
  rty_pgwqgwrgw[1] = (rtu_qgw_hl[1] - rtb_Product_iy[1]) *
    rtb_TrigonometricFunction_o1 / rtb_TrigonometricFunction_o2 +
    rtb_Product_iy[1];
  rty_pgwqgwrgw[2] = (rtu_rgw_hl[1] - rtb_Product_iy[2]) *
    rtb_TrigonometricFunction_o1 / rtb_TrigonometricFunction_o2 +
    rtb_Product_iy[2];
}

//
// Output and update for action system:
//    '<S118>/Low altitude  velocities'
//    '<S157>/Low altitude  velocities'
//
void MulticopterModelClass::USV_Lowaltitudevelocities(const real_T rtu_DCM[9],
  const real_T rtu_ugw_hl[2], const real_T rtu_vgw_hl[2], const real_T
  rtu_wgw_hl[2], real_T rtu_Winddirection, real_T rty_ugwvgwwgw[3])
{
  real_T rtb_TrigonometricFunction_o1;
  real_T rtb_TrigonometricFunction_o2;
  real_T rtb_VectorConcatenate_d_idx_0;
  real_T rtb_VectorConcatenate_d_idx_2;

  // SignalConversion generated from: '<S145>/Vector Concatenate'
  rtb_VectorConcatenate_d_idx_2 = rtu_wgw_hl[0];

  // Trigonometry: '<S146>/Trigonometric Function'
  rtb_TrigonometricFunction_o1 = std::sin(rtu_Winddirection);
  rtb_TrigonometricFunction_o2 = std::cos(rtu_Winddirection);

  // Sum: '<S146>/Sum' incorporates:
  //   Product: '<S146>/Product1'
  //   Product: '<S146>/Product2'

  rtb_VectorConcatenate_d_idx_0 = rtu_ugw_hl[0] * rtb_TrigonometricFunction_o2 -
    rtb_TrigonometricFunction_o1 * rtu_vgw_hl[0];

  // Sum: '<S146>/Sum1' incorporates:
  //   Product: '<S146>/Product1'
  //   Product: '<S146>/Product2'

  rtb_TrigonometricFunction_o1 = rtb_TrigonometricFunction_o1 * rtu_ugw_hl[0] +
    rtu_vgw_hl[0] * rtb_TrigonometricFunction_o2;

  // Reshape: '<S145>/Reshape1' incorporates:
  //   Concatenate: '<S145>/Vector Concatenate'
  //   Product: '<S145>/Product'

  for (int32_T i = 0; i < 3; i++) {
    rty_ugwvgwwgw[i] = 0.0;
    rty_ugwvgwwgw[i] += rtu_DCM[i] * rtb_VectorConcatenate_d_idx_0;
    rty_ugwvgwwgw[i] += rtu_DCM[i + 3] * rtb_TrigonometricFunction_o1;
    rty_ugwvgwwgw[i] += rtu_DCM[i + 6] * rtb_VectorConcatenate_d_idx_2;
  }

  // End of Reshape: '<S145>/Reshape1'
}

//
// Output and update for action system:
//    '<S118>/Interpolate  velocities'
//    '<S157>/Interpolate  velocities'
//
void MulticopterModelClass::USV_Interpolatevelocities(const real_T rtu_ugw_hl[2],
  const real_T rtu_vgw_hl[2], const real_T rtu_wgw_hl[2], const real_T rtu_DCM[9],
  real_T rtu_Winddirection, real_T rtu_Altitude, real_T rty_ugwvgwwgw[3],
  P_Interpolatevelocities_USV_T *localP)
{
  real_T rtb_Product_cb[3];
  real_T rtb_TrigonometricFunction_o1;
  real_T rtb_TrigonometricFunction_o2;
  real_T rtb_VectorConcatenate_i_idx_0;

  // Trigonometry: '<S144>/Trigonometric Function'
  rtb_TrigonometricFunction_o1 = std::sin(rtu_Winddirection);
  rtb_TrigonometricFunction_o2 = std::cos(rtu_Winddirection);

  // Sum: '<S144>/Sum' incorporates:
  //   Product: '<S144>/Product1'
  //   Product: '<S144>/Product2'

  rtb_VectorConcatenate_i_idx_0 = rtu_ugw_hl[0] * rtb_TrigonometricFunction_o2 -
    rtb_TrigonometricFunction_o1 * rtu_vgw_hl[0];

  // Sum: '<S144>/Sum1' incorporates:
  //   Product: '<S144>/Product1'
  //   Product: '<S144>/Product2'

  rtb_TrigonometricFunction_o1 = rtb_TrigonometricFunction_o1 * rtu_ugw_hl[0] +
    rtu_vgw_hl[0] * rtb_TrigonometricFunction_o2;

  // SignalConversion generated from: '<S143>/Vector Concatenate'
  rtb_TrigonometricFunction_o2 = rtu_wgw_hl[0];

  // Product: '<S143>/Product' incorporates:
  //   Concatenate: '<S143>/Vector Concatenate'

  for (int32_T i = 0; i < 3; i++) {
    rtb_Product_cb[i] = (rtu_DCM[i + 3] * rtb_TrigonometricFunction_o1 +
                         rtu_DCM[i] * rtb_VectorConcatenate_i_idx_0) + rtu_DCM[i
      + 6] * rtb_TrigonometricFunction_o2;
  }

  // End of Product: '<S143>/Product'

  // Sum: '<S139>/Sum1' incorporates:
  //   Constant: '<S139>/max_height_low'

  rtb_TrigonometricFunction_o1 = rtu_Altitude - localP->max_height_low_Value;

  // Sum: '<S139>/Sum' incorporates:
  //   Constant: '<S139>/max_height_low'
  //   Constant: '<S139>/min_height_high'

  rtb_TrigonometricFunction_o2 = localP->min_height_high_Value -
    localP->max_height_low_Value;

  // Sum: '<S139>/Sum3' incorporates:
  //   Product: '<S139>/Product1'
  //   Sum: '<S139>/Sum2'

  rty_ugwvgwwgw[0] = (rtu_ugw_hl[1] - rtb_Product_cb[0]) *
    rtb_TrigonometricFunction_o1 / rtb_TrigonometricFunction_o2 +
    rtb_Product_cb[0];
  rty_ugwvgwwgw[1] = (rtu_vgw_hl[1] - rtb_Product_cb[1]) *
    rtb_TrigonometricFunction_o1 / rtb_TrigonometricFunction_o2 +
    rtb_Product_cb[1];
  rty_ugwvgwwgw[2] = (rtu_wgw_hl[1] - rtb_Product_cb[2]) *
    rtb_TrigonometricFunction_o1 / rtb_TrigonometricFunction_o2 +
    rtb_Product_cb[2];
}

//
// Output and update for atomic system:
//    '<S198>/MATLAB Function1'
//    '<S199>/MATLAB Function1'
//    '<S200>/MATLAB Function1'
//    '<S201>/MATLAB Function1'
//    '<S202>/MATLAB Function1'
//    '<S203>/MATLAB Function1'
//    '<S204>/MATLAB Function1'
//    '<S205>/MATLAB Function1'
//
void MulticopterModelClass::USV_MATLABFunction1(real_T rtu_timeConstantUp,
  real_T rtu_timeConstantDown, real_T rtu_inputState, real_T rtu_time,
  B_MATLABFunction1_USV_T *localB, DW_MATLABFunction1_USV_T *localDW)
{
  real_T samplingTime;

  // MATLAB Function 'Motor/MATLAB Function1': '<S209>:1'
  // '<S209>:1:3' if isempty(previousState)
  // '<S209>:1:8' if isempty(lastTime)
  // '<S209>:1:12' samplingTime=time-lastTime;
  samplingTime = rtu_time - localDW->lastTime;

  // '<S209>:1:13' if samplingTime<=0
  if (samplingTime <= 0.0) {
    // '<S209>:1:14' samplingTime=0.01;
    samplingTime = 0.01;
  }

  // '<S209>:1:17' if inputState > previousState
  if (rtu_inputState > localDW->previousState) {
    // '<S209>:1:18' alphaUp = exp(-samplingTime/timeConstantUp);
    samplingTime = std::exp(-samplingTime / rtu_timeConstantUp);

    // '<S209>:1:19' outputState = alphaUp*previousState + (1-alphaUp)*inputState; 
    localB->outputState = (1.0 - samplingTime) * rtu_inputState + samplingTime *
      localDW->previousState;
  } else {
    // '<S209>:1:20' else
    // '<S209>:1:21' alphaDown = exp(- samplingTime / timeConstantDown);
    samplingTime = std::exp(-samplingTime / rtu_timeConstantDown);

    // '<S209>:1:22' outputState = alphaDown*previousState + (1-alphaDown)*inputState; 
    localB->outputState = (1.0 - samplingTime) * rtu_inputState + samplingTime *
      localDW->previousState;
  }

  // '<S209>:1:25' previousState=inputState;
  localDW->previousState = rtu_inputState;

  // '<S209>:1:26' lastTime=time;
  localDW->lastTime = rtu_time;
}

//
// Output and update for atomic system:
//    '<S198>/���ģ��'
//    '<S199>/���ģ��'
//    '<S200>/���ģ��'
//    '<S201>/���ģ��'
//    '<S202>/���ģ��'
//    '<S203>/���ģ��'
//    '<S204>/���ģ��'
//    '<S205>/���ģ��'
//
void MulticopterModelClass::USV_u(real_T rtu_motor_rot_vel_, const real_T
  rtu_relative_wind_velocity[3], real_T rtu_MotorDir, real_T
  rtu_rotorVelocitySlowdownSim, real_T rtu_motorConstant, real_T
  rtu_momentConstant, real_T rtu_rotorDragCoefficient, real_T
  rtu_rollingMomentCoefficient, real_T rtu_reversible, B_u_USV_T *localB)
{
  real_T force;
  real_T force_tmp;
  real_T real_motor_velocity;
  real_T scalar;

  //  This is control effectiveness model, where Fb is the force produced by motors, Mb is 
  //  the moment produced by motors, and Fd is the resistance produced by the air. 
  //  The gyroscopic torque is not considered here.
  // MATLAB Function 'Motor/���ģ��': '<S210>:1'
  //  -1: anticlockwise, 1: clockwise
  // '<S210>:1:10' Mb = [0;0;0];
  // '<S210>:1:11' Fb = [0;0;0];
  // '<S210>:1:13' propdir = MotorDir;
  // '<S210>:1:14' real_motor_velocity = motor_rot_vel_ * rotorVelocitySlowdownSim; 
  real_motor_velocity = rtu_motor_rot_vel_ * rtu_rotorVelocitySlowdownSim;

  //  ��Է��ٷ���
  // '<S210>:1:17' velocity_perpendicular_to_rotor_axis = [relative_wind_velocity(1);relative_wind_velocity(2);0]; 
  // '<S210>:1:18' velocity_parallel_to_rotor_axis = [0;0;relative_wind_velocity(3)]; 
  // '<S210>:1:19' vel = abs(relative_wind_velocity(3));
  // '<S210>:1:20' scalar = 1 - vel/25.0;
  scalar = 1.0 - std::abs(rtu_relative_wind_velocity[2]) / 25.0;

  // '<S210>:1:21' if scalar<0
  if (scalar < 0.0) {
    // '<S210>:1:22' scalar = 0;
    scalar = 0.0;
  }

  //  ���� % FmӦ�õ�ģ����֮ǰ����Ҫ������ˮ��/���ٵ�����ٶȽ������ţ�scale��0-1 
  // '<S210>:1:27' force = real_motor_velocity * abs(real_motor_velocity) * motorConstant; 
  force_tmp = std::abs(real_motor_velocity);
  force = real_motor_velocity * force_tmp * rtu_motorConstant;

  // '<S210>:1:28' if reversible==0
  if (rtu_reversible == 0.0) {
    //  ��ʾ��������и�����
    // '<S210>:1:29' force = abs(force);
    force = std::abs(force);
  }

  // '<S210>:1:31' Fm1 = [0;0;force * scalar];
  //   ��������������
  //  relative_wind_velocity = body_velocity - wind_vel_;
  //  velocity_perpendicular_to_rotor_axis = relative_wind_velocity - (relative_wind_velocity.*(joint_axis)) .* joint_axis; 
  // '<S210>:1:35' Fm2 = -abs(real_motor_velocity) * rotorDragCoefficient * velocity_perpendicular_to_rotor_axis; 
  force_tmp = -force_tmp * rtu_rotorDragCoefficient;

  // '<S210>:1:36' Fb = Fm1 + Fm2;
  localB->Fb[0] = force_tmp * rtu_relative_wind_velocity[0];
  localB->Fb[1] = force_tmp * rtu_relative_wind_velocity[1];
  localB->Fb[2] = force * scalar + force_tmp * 0.0;

  //  ����ƫ���Ŀ���������  Mt1
  // '<S210>:1:39' Mt1 = [0;0;-propdir*force*momentConstant];
  //  gazebo��ccw��Ӧ1���������Ӧ-1������propdirǰû����
  //  ��������Mt2
  // '<S210>:1:41' Mt2 = -abs(real_motor_velocity) * rollingMomentCoefficient * velocity_perpendicular_to_rotor_axis; 
  real_motor_velocity = -std::abs(real_motor_velocity) *
    rtu_rollingMomentCoefficient;

  // '<S210>:1:42' Mb = Mt1 + Mt2;
  localB->Mb[0] = real_motor_velocity * rtu_relative_wind_velocity[0];
  localB->Mb[1] = real_motor_velocity * rtu_relative_wind_velocity[1];
  localB->Mb[2] = -rtu_MotorDir * force * rtu_momentConstant +
    real_motor_velocity * 0.0;
}

//
// Output and update for atomic system:
//    '<S407>/Acc NoiseFun'
//    '<S413>/Acc NoiseFun'
//    '<S417>/Acc NoiseFun'
//
void MulticopterModelClass::USV_AccNoiseFun(const real_T rtu_u[3], boolean_T
  rtu_isAccFault, const real_T rtu_AccFaultParams[20], B_AccNoiseFun_USV_T
  *localB)
{
  // MATLAB Function 'SensorFault/AccNoiseSwitch1/Acc NoiseFun': '<S421>:1'
  // '<S421>:1:3' y = 0.2*u;
  localB->y[0] = 0.2 * rtu_u[0];
  localB->y[1] = 0.2 * rtu_u[1];
  localB->y[2] = 0.2 * rtu_u[2];

  // '<S421>:1:5' if isAccFault
  if (rtu_isAccFault) {
    real_T a;

    // '<S421>:1:6' y = (0.2+0.8*AccFaultParams(1))*u;
    a = 0.8 * rtu_AccFaultParams[0] + 0.2;
    localB->y[0] = a * rtu_u[0];
    localB->y[1] = a * rtu_u[1];
    localB->y[2] = a * rtu_u[2];
  }
}

real_T rt_modd_snf(real_T u0, real_T u1)
{
  real_T y;
  y = u0;
  if (u1 == 0.0) {
    if (u0 == 0.0) {
      y = u1;
    }
  } else if (rtIsNaN(u0) || rtIsNaN(u1) || rtIsInf(u0)) {
    y = (rtNaN);
  } else if (u0 == 0.0) {
    y = 0.0 / u1;
  } else if (rtIsInf(u1)) {
    if ((u1 < 0.0) != (u0 < 0.0)) {
      y = u1;
    }
  } else {
    boolean_T yEq;
    y = std::fmod(u0, u1);
    yEq = (y == 0.0);
    if ((!yEq) && (u1 > std::floor(u1))) {
      real_T q;
      q = std::abs(u0 / u1);
      yEq = !(std::abs(q - std::floor(q + 0.5)) > DBL_EPSILON * q);
    }

    if (yEq) {
      y = u1 * 0.0;
    } else if ((u0 < 0.0) != (u1 < 0.0)) {
      y += u1;
    }
  }

  return y;
}

real_T rt_atan2d_snf(real_T u0, real_T u1)
{
  real_T y;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = (rtNaN);
  } else if (rtIsInf(u0) && rtIsInf(u1)) {
    int32_T u0_0;
    int32_T u1_0;
    if (u0 > 0.0) {
      u0_0 = 1;
    } else {
      u0_0 = -1;
    }

    if (u1 > 0.0) {
      u1_0 = 1;
    } else {
      u1_0 = -1;
    }

    y = std::atan2(static_cast<real_T>(u0_0), static_cast<real_T>(u1_0));
  } else if (u1 == 0.0) {
    if (u0 > 0.0) {
      y = RT_PI / 2.0;
    } else if (u0 < 0.0) {
      y = -(RT_PI / 2.0);
    } else {
      y = 0.0;
    }
  } else {
    y = std::atan2(u0, u1);
  }

  return y;
}

// Function for MATLAB Function: '<S73>/MATLAB Function'
real_T MulticopterModelClass::USV_rand(void)
{
  real_T r;
  uint32_T u[2];
  switch (USV_DW.method) {
   case 4U:
    {
      int32_T k;
      uint32_T mti;
      uint32_T y;
      k = static_cast<int32_T>(USV_DW.state / 127773U);
      mti = (USV_DW.state - k * 127773U) * 16807U;
      y = 2836U * k;
      if (mti < y) {
        mti = ~(y - mti) & 2147483647U;
      } else {
        mti -= y;
      }

      r = static_cast<real_T>(mti) * 4.6566128752457969E-10;
      USV_DW.state = mti;
    }
    break;

   case 5U:
    {
      uint32_T mti;
      uint32_T y;
      mti = 69069U * USV_DW.state_i[0] + 1234567U;
      y = USV_DW.state_i[1] << 13 ^ USV_DW.state_i[1];
      y ^= y >> 17;
      y ^= y << 5;
      USV_DW.state_i[0] = mti;
      USV_DW.state_i[1] = y;
      r = static_cast<real_T>(mti + y) * 2.328306436538696E-10;
    }
    break;

   default:
    {
      // ========================= COPYRIGHT NOTICE ============================ 
      //  This is a uniform (0,1) pseudorandom number generator based on:        
      //                                                                         
      //  A C-program for MT19937, with initialization improved 2002/1/26.       
      //  Coded by Takuji Nishimura and Makoto Matsumoto.                        
      //                                                                         
      //  Copyright (C) 1997 - 2002, Makoto Matsumoto and Takuji Nishimura,      
      //  All rights reserved.                                                   
      //                                                                         
      //  Redistribution and use in source and binary forms, with or without     
      //  modification, are permitted provided that the following conditions     
      //  are met:                                                               
      //                                                                         
      //    1. Redistributions of source code must retain the above copyright    
      //       notice, this list of conditions and the following disclaimer.     
      //                                                                         
      //    2. Redistributions in binary form must reproduce the above copyright 
      //       notice, this list of conditions and the following disclaimer      
      //       in the documentation and/or other materials provided with the     
      //       distribution.                                                     
      //                                                                         
      //    3. The names of its contributors may not be used to endorse or       
      //       promote products derived from this software without specific      
      //       prior written permission.                                         
      //                                                                         
      //  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS    
      //  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT      
      //  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR  
      //  A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT  
      //  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,  
      //  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT       
      //  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,  
      //  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY  
      //  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT    
      //  (INCLUDING  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
      //  OF THIS  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.  
      //                                                                         
      // =============================   END   ================================= 
      int32_T exitg1;
      do {
        int32_T k;
        uint32_T mti;
        exitg1 = 0;
        for (k = 0; k < 2; k++) {
          uint32_T y;
          mti = USV_DW.state_is[624] + 1U;
          if (USV_DW.state_is[624] + 1U >= 625U) {
            for (int32_T kk = 0; kk < 227; kk++) {
              mti = (USV_DW.state_is[kk + 1] & 2147483647U) |
                (USV_DW.state_is[kk] & 2147483648U);
              if ((mti & 1U) == 0U) {
                mti >>= 1U;
              } else {
                mti = mti >> 1U ^ 2567483615U;
              }

              USV_DW.state_is[kk] = USV_DW.state_is[kk + 397] ^ mti;
            }

            for (int32_T kk = 0; kk < 396; kk++) {
              mti = (USV_DW.state_is[kk + 227] & 2147483648U) |
                (USV_DW.state_is[kk + 228] & 2147483647U);
              if ((mti & 1U) == 0U) {
                mti >>= 1U;
              } else {
                mti = mti >> 1U ^ 2567483615U;
              }

              USV_DW.state_is[kk + 227] = USV_DW.state_is[kk] ^ mti;
            }

            mti = (USV_DW.state_is[623] & 2147483648U) | (USV_DW.state_is[0] &
              2147483647U);
            if ((mti & 1U) == 0U) {
              mti >>= 1U;
            } else {
              mti = mti >> 1U ^ 2567483615U;
            }

            USV_DW.state_is[623] = USV_DW.state_is[396] ^ mti;
            mti = 1U;
          }

          y = USV_DW.state_is[static_cast<int32_T>(mti) - 1];
          USV_DW.state_is[624] = mti;
          y ^= y >> 11U;
          y ^= y << 7U & 2636928640U;
          y ^= y << 15U & 4022730752U;
          u[k] = y >> 18U ^ y;
        }

        r = (static_cast<real_T>(u[0] >> 5U) * 6.7108864E+7 + static_cast<real_T>
             (u[1] >> 6U)) * 1.1102230246251565E-16;
        if (r == 0.0) {
          boolean_T b_isvalid;
          b_isvalid = ((USV_DW.state_is[624] >= 1U) && (USV_DW.state_is[624] <
            625U));
          if (b_isvalid) {
            boolean_T exitg2;
            b_isvalid = false;
            k = 1;
            exitg2 = false;
            while ((!exitg2) && (k < 625)) {
              if (USV_DW.state_is[k - 1] == 0U) {
                k++;
              } else {
                b_isvalid = true;
                exitg2 = true;
              }
            }
          }

          if (!b_isvalid) {
            mti = 5489U;
            USV_DW.state_is[0] = 5489U;
            for (k = 0; k < 623; k++) {
              mti = ((mti >> 30U ^ mti) * 1812433253U + k) + 1U;
              USV_DW.state_is[k + 1] = mti;
            }

            USV_DW.state_is[624] = 624U;
          }
        } else {
          exitg1 = 1;
        }
      } while (exitg1 == 0);
    }
    break;
  }

  return r;
}

void rt_mrdivide_U1d1x3_U2d_9vOrDY9Z(const real_T u0[3], const real_T u1[9],
  real_T y[3])
{
  real_T A[9];
  real_T a21;
  real_T maxval;
  int32_T r1;
  int32_T r2;
  int32_T r3;
  std::memcpy(&A[0], &u1[0], 9U * sizeof(real_T));
  r1 = 0;
  r2 = 1;
  r3 = 2;
  maxval = std::abs(u1[0]);
  a21 = std::abs(u1[1]);
  if (a21 > maxval) {
    maxval = a21;
    r1 = 1;
    r2 = 0;
  }

  if (std::abs(u1[2]) > maxval) {
    r1 = 2;
    r2 = 1;
    r3 = 0;
  }

  A[r2] = u1[r2] / u1[r1];
  A[r3] /= A[r1];
  A[r2 + 3] -= A[r1 + 3] * A[r2];
  A[r3 + 3] -= A[r1 + 3] * A[r3];
  A[r2 + 6] -= A[r1 + 6] * A[r2];
  A[r3 + 6] -= A[r1 + 6] * A[r3];
  if (std::abs(A[r3 + 3]) > std::abs(A[r2 + 3])) {
    int32_T rtemp;
    rtemp = r2 + 1;
    r2 = r3;
    r3 = rtemp - 1;
  }

  A[r3 + 3] /= A[r2 + 3];
  A[r3 + 6] -= A[r3 + 3] * A[r2 + 6];
  y[r1] = u0[0] / A[r1];
  y[r2] = u0[1] - A[r1 + 3] * y[r1];
  y[r3] = u0[2] - A[r1 + 6] * y[r1];
  y[r2] /= A[r2 + 3];
  y[r3] -= A[r2 + 6] * y[r2];
  y[r3] /= A[r3 + 6];
  y[r2] -= A[r3 + 3] * y[r3];
  y[r1] -= y[r3] * A[r3];
  y[r1] -= y[r2] * A[r2];
}

real_T rt_roundd_snf(real_T u)
{
  real_T y;
  if (std::abs(u) < 4.503599627370496E+15) {
    if (u >= 0.5) {
      y = std::floor(u + 0.5);
    } else if (u > -0.5) {
      y = u * 0.0;
    } else {
      y = std::ceil(u - 0.5);
    }
  } else {
    y = u;
  }

  return y;
}

real_T rt_urand_Upu32_Yd_f_pw_snf(uint32_T *u)
{
  uint32_T hi;
  uint32_T lo;

  // Uniform random number generator (random number between 0 and 1)

  // #define IA      16807                      magic multiplier = 7^5
  // #define IM      2147483647                 modulus = 2^31-1
  // #define IQ      127773                     IM div IA
  // #define IR      2836                       IM modulo IA
  // #define S       4.656612875245797e-10      reciprocal of 2^31-1
  // test = IA * (seed % IQ) - IR * (seed/IQ)
  // seed = test < 0 ? (test + IM) : test
  // return (seed*S)

  lo = *u % 127773U * 16807U;
  hi = *u / 127773U * 2836U;
  if (lo < hi) {
    *u = 2147483647U - (hi - lo);
  } else {
    *u = lo - hi;
  }

  return static_cast<real_T>(*u) * 4.6566128752457969E-10;
}

real_T rt_nrand_Upu32_Yd_f_pw_snf(uint32_T *u)
{
  real_T si;
  real_T sr;
  real_T y;

  // Normal (Gaussian) random number generator
  do {
    sr = 2.0 * rt_urand_Upu32_Yd_f_pw_snf(u) - 1.0;
    si = 2.0 * rt_urand_Upu32_Yd_f_pw_snf(u) - 1.0;
    si = sr * sr + si * si;
  } while (si > 1.0);

  y = std::sqrt(-2.0 * std::log(si) / si) * sr;
  return y;
}

// Model step function
void MulticopterModelClass::step()
{
  // local block i/o variables
  real_T rtb_DataTypeConversion[3];
  real_T rtb_tc_old[169];
  real_T fParamTmp[20];
  real_T inSILFloats[20];
  real_T rtb_VectorConcatenate_n[18];
  real_T rtb_TmpSignalConversionAtppnInp[13];
  real_T rtb_Assignment[11];
  real_T rtb_Assignment1[11];
  real_T Product_f_tmp[9];
  real_T Product_f_tmp_0[9];
  real_T VectorConcatenate[9];
  real_T rtb_Gain_nr[8];
  real_T rtb_Add_l[6];
  real_T rtb_Elementproduct[6];
  real_T rtb_Elementproduct_cd[6];
  real_T rtb_Elementproduct_cn[6];
  real_T rtb_Elementproduct_d[6];
  real_T rtb_Elementproduct_fe[6];
  real_T rtb_Elementproduct_j[6];
  real_T rtb_Elementproduct_l[6];
  real_T rtb_Elementproduct_o[6];
  real_T UnitConversion_i[3];
  real_T rtb_Add_kk[3];
  real_T rtb_DataTypeConversion2[3];
  real_T rtb_IntegratorSecondOrderLimi_e[3];
  real_T rtb_MatrixMultiply2[3];
  real_T rtb_VectorConcatenate[3];
  real_T rtb_fuPos[3];
  real_T rtb_q2dot_0[3];
  real_T rtb_sincos_o1_h[3];
  real_T rtb_sincos_o2_k[3];
  real_T frac[2];
  real_T frac_0[2];
  real_T rtb_Sum_f4[2];
  real_T S_db;
  real_T S_df;
  real_T VectorConcatenate_tmp;
  real_T VectorConcatenate_tmp_0;
  real_T dw_e;
  real_T dw_l_e;
  real_T j;
  real_T lw_b_e;
  real_T lw_f_e;
  real_T rtb_Abs1;
  real_T rtb_Clock1_tmp;
  real_T rtb_Product1_i5;
  real_T rtb_Product_gy;
  real_T rtb_Saturation_1;
  real_T rtb_Sum1_dx;
  real_T rtb_Sum_hp;
  real_T rtb_Switch1;
  real_T rtb_Switch1_a;
  real_T rtb_Switch1_bi;
  real_T rtb_Switch1_h;
  real_T rtb_Switch1_i;
  real_T rtb_Switch1_k;
  real_T rtb_Switch1_m2;
  real_T rtb_Switch_bvp;
  real_T rtb_WhiteNoise_b_idx_0;
  real_T rtb_fcn3;
  real_T rtb_fuPos_tmp;
  real_T rtb_fuPos_tmp_0;
  real_T rtb_q2dot;
  real_T rtb_q3dot;
  real_T rtb_sincos_o1_idx_0;
  real_T rtb_y3DFix;
  real_T rtb_ySats;
  int32_T Product_f_tmp_tmp;
  int32_T i;
  int32_T pitch_sign;
  int32_T qY;
  int32_T roll_sign;
  int32_T roll_sign_0;
  real32_T rtb_AngEuler[3];
  uint32_T bpIndex[2];
  uint32_T bpIndex_0[2];
  uint32_T rtb_time_usec;
  int8_T rtAction;
  uint8_T ForIterator_IterationMarker[6];
  boolean_T rtb_Compare_af[9];
  boolean_T rtb_Compare_f;
  boolean_T rtb_Compare_o;
  boolean_T rtb_RelationalOperator;
  if (rtmIsMajorTimeStep((&USV_M))) {
    // set solver stop time
    rtsiSetSolverStopTime(&(&USV_M)->solverInfo,(((&USV_M)->Timing.clockTick0+1)*
      (&USV_M)->Timing.stepSize0));
  }                                    // end MajorTimeStep

  // Update absolute time of base rate at minor time step
  if (rtmIsMinorTimeStep((&USV_M))) {
    (&USV_M)->Timing.t[0] = rtsiGetT(&(&USV_M)->solverInfo);
  }

  // Clock: '<S8>/Clock1' incorporates:
  //   Clock: '<S54>/Time'
  //   Clock: '<S73>/Clock1'

  rtb_Clock1_tmp = (&USV_M)->Timing.t[0];

  // DataTypeConversion: '<S8>/Data Type Conversion1' incorporates:
  //   Clock: '<S8>/Clock1'
  //   Gain: '<S8>/Gain_clock'

  rtb_fcn3 = std::floor(USV_P.Gain_clock_Gain * rtb_Clock1_tmp);
  if (rtIsNaN(rtb_fcn3) || rtIsInf(rtb_fcn3)) {
    rtb_fcn3 = 0.0;
  } else {
    rtb_fcn3 = std::fmod(rtb_fcn3, 4.294967296E+9);
  }

  rtb_time_usec = rtb_fcn3 < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(
    static_cast<uint32_T>(-rtb_fcn3))) : static_cast<uint32_T>(rtb_fcn3);

  // End of DataTypeConversion: '<S8>/Data Type Conversion1'
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // Gain: '<S20>/1//2' incorporates:
    //   Constant: '<S10>/Initial Euler Angles'

    rtb_sincos_o2_k[0] = USV_P.u2_Gain * USV_P.ModelInit_AngEuler[2];
    rtb_sincos_o2_k[1] = USV_P.u2_Gain * USV_P.ModelInit_AngEuler[1];
    rtb_sincos_o2_k[2] = USV_P.u2_Gain * USV_P.ModelInit_AngEuler[0];

    // Trigonometry: '<S20>/sincos'
    rtb_sincos_o1_h[0] = std::cos(rtb_sincos_o2_k[0]);
    rtb_sincos_o1_idx_0 = std::sin(rtb_sincos_o2_k[0]);
    rtb_sincos_o1_h[1] = std::cos(rtb_sincos_o2_k[1]);
    rtb_Sum1_dx = std::sin(rtb_sincos_o2_k[1]);
    rtb_sincos_o1_h[2] = std::cos(rtb_sincos_o2_k[2]);
    rtb_fcn3 = std::sin(rtb_sincos_o2_k[2]);

    // Fcn: '<S20>/q0' incorporates:
    //   Fcn: '<S20>/q1'

    rtb_Switch_bvp = rtb_sincos_o1_h[0] * rtb_sincos_o1_h[1];
    rtb_Abs1 = rtb_sincos_o1_idx_0 * rtb_Sum1_dx;

    // Fcn: '<S20>/q0'
    USV_B.q0 = rtb_Switch_bvp * rtb_sincos_o1_h[2] + rtb_Abs1 * rtb_fcn3;

    // Fcn: '<S20>/q1'
    USV_B.q1 = rtb_Switch_bvp * rtb_fcn3 - rtb_Abs1 * rtb_sincos_o1_h[2];

    // Fcn: '<S20>/q2' incorporates:
    //   Fcn: '<S20>/q3'

    rtb_Switch_bvp = rtb_sincos_o1_idx_0 * rtb_sincos_o1_h[1];
    rtb_Abs1 = rtb_sincos_o1_h[0] * rtb_Sum1_dx;

    // Fcn: '<S20>/q2'
    USV_B.q2 = rtb_Abs1 * rtb_sincos_o1_h[2] + rtb_Switch_bvp * rtb_fcn3;

    // Fcn: '<S20>/q3'
    USV_B.q3 = rtb_Switch_bvp * rtb_sincos_o1_h[2] - rtb_Abs1 * rtb_fcn3;
  }

  // Integrator: '<S10>/q0 q1 q2 q3' incorporates:
  //   SignalConversion generated from: '<S10>/q0 q1 q2 q3'

  if (USV_DW.q0q1q2q3_IWORK != 0) {
    USV_X.q0q1q2q3_CSTATE[0] = USV_B.q0;
    USV_X.q0q1q2q3_CSTATE[1] = USV_B.q1;
    USV_X.q0q1q2q3_CSTATE[2] = USV_B.q2;
    USV_X.q0q1q2q3_CSTATE[3] = USV_B.q3;
  }

  // Sqrt: '<S33>/sqrt' incorporates:
  //   Integrator: '<S10>/q0 q1 q2 q3'
  //   Product: '<S34>/Product'
  //   Product: '<S34>/Product1'
  //   Product: '<S34>/Product2'
  //   Product: '<S34>/Product3'
  //   Sum: '<S34>/Sum'

  rtb_sincos_o1_idx_0 = std::sqrt(((USV_X.q0q1q2q3_CSTATE[0] *
    USV_X.q0q1q2q3_CSTATE[0] + USV_X.q0q1q2q3_CSTATE[1] * USV_X.q0q1q2q3_CSTATE
    [1]) + USV_X.q0q1q2q3_CSTATE[2] * USV_X.q0q1q2q3_CSTATE[2]) +
    USV_X.q0q1q2q3_CSTATE[3] * USV_X.q0q1q2q3_CSTATE[3]);

  // Product: '<S32>/Product' incorporates:
  //   Integrator: '<S10>/q0 q1 q2 q3'

  rtb_Switch_bvp = USV_X.q0q1q2q3_CSTATE[0] / rtb_sincos_o1_idx_0;

  // Product: '<S32>/Product1' incorporates:
  //   Integrator: '<S10>/q0 q1 q2 q3'

  rtb_Abs1 = USV_X.q0q1q2q3_CSTATE[1] / rtb_sincos_o1_idx_0;

  // Product: '<S32>/Product2' incorporates:
  //   Integrator: '<S10>/q0 q1 q2 q3'

  rtb_Saturation_1 = USV_X.q0q1q2q3_CSTATE[2] / rtb_sincos_o1_idx_0;

  // Product: '<S32>/Product3' incorporates:
  //   Integrator: '<S10>/q0 q1 q2 q3'

  rtb_sincos_o1_idx_0 = USV_X.q0q1q2q3_CSTATE[3] / rtb_sincos_o1_idx_0;

  // Product: '<S22>/Product3' incorporates:
  //   Product: '<S26>/Product3'

  rtb_q2dot = rtb_Switch_bvp * rtb_Switch_bvp;

  // Product: '<S22>/Product2' incorporates:
  //   Product: '<S26>/Product2'

  rtb_Sum1_dx = rtb_Abs1 * rtb_Abs1;

  // Product: '<S22>/Product1' incorporates:
  //   Product: '<S26>/Product1'
  //   Product: '<S30>/Product1'

  rtb_fcn3 = rtb_Saturation_1 * rtb_Saturation_1;

  // Product: '<S22>/Product' incorporates:
  //   Product: '<S26>/Product'
  //   Product: '<S30>/Product'

  rtb_q3dot = rtb_sincos_o1_idx_0 * rtb_sincos_o1_idx_0;

  // Sum: '<S22>/Sum' incorporates:
  //   Concatenate: '<S31>/Vector Concatenate'
  //   Product: '<S22>/Product'
  //   Product: '<S22>/Product1'
  //   Product: '<S22>/Product2'
  //   Product: '<S22>/Product3'

  VectorConcatenate[0] = ((rtb_q2dot + rtb_Sum1_dx) - rtb_fcn3) - rtb_q3dot;

  // Product: '<S25>/Product3' incorporates:
  //   Product: '<S23>/Product3'

  VectorConcatenate_tmp = rtb_sincos_o1_idx_0 * rtb_Switch_bvp;

  // Product: '<S25>/Product2' incorporates:
  //   Product: '<S23>/Product2'

  VectorConcatenate_tmp_0 = rtb_Abs1 * rtb_Saturation_1;

  // Gain: '<S25>/Gain' incorporates:
  //   Concatenate: '<S31>/Vector Concatenate'
  //   Product: '<S25>/Product2'
  //   Product: '<S25>/Product3'
  //   Sum: '<S25>/Sum'

  VectorConcatenate[1] = (VectorConcatenate_tmp_0 - VectorConcatenate_tmp) *
    USV_P.Gain_Gain_kj;

  // Product: '<S28>/Product2' incorporates:
  //   Product: '<S24>/Product2'

  rtb_Product1_i5 = rtb_Abs1 * rtb_sincos_o1_idx_0;

  // Product: '<S28>/Product1' incorporates:
  //   Product: '<S24>/Product1'

  rtb_Product_gy = rtb_Switch_bvp * rtb_Saturation_1;

  // Gain: '<S28>/Gain' incorporates:
  //   Concatenate: '<S31>/Vector Concatenate'
  //   Product: '<S28>/Product1'
  //   Product: '<S28>/Product2'
  //   Sum: '<S28>/Sum'

  VectorConcatenate[2] = (rtb_Product_gy + rtb_Product1_i5) * USV_P.Gain_Gain_nt;

  // Gain: '<S23>/Gain' incorporates:
  //   Concatenate: '<S31>/Vector Concatenate'
  //   Sum: '<S23>/Sum'

  VectorConcatenate[3] = (VectorConcatenate_tmp + VectorConcatenate_tmp_0) *
    USV_P.Gain_Gain_b3;

  // Sum: '<S26>/Sum' incorporates:
  //   Concatenate: '<S31>/Vector Concatenate'
  //   Sum: '<S30>/Sum'

  rtb_q2dot -= rtb_Sum1_dx;
  VectorConcatenate[4] = (rtb_q2dot + rtb_fcn3) - rtb_q3dot;

  // Product: '<S29>/Product1' incorporates:
  //   Product: '<S27>/Product1'

  rtb_Sum1_dx = rtb_Switch_bvp * rtb_Abs1;

  // Product: '<S29>/Product2' incorporates:
  //   Product: '<S27>/Product2'

  VectorConcatenate_tmp = rtb_Saturation_1 * rtb_sincos_o1_idx_0;

  // Gain: '<S29>/Gain' incorporates:
  //   Concatenate: '<S31>/Vector Concatenate'
  //   Product: '<S29>/Product1'
  //   Product: '<S29>/Product2'
  //   Sum: '<S29>/Sum'

  VectorConcatenate[5] = (VectorConcatenate_tmp - rtb_Sum1_dx) *
    USV_P.Gain_Gain_ky;

  // Gain: '<S24>/Gain' incorporates:
  //   Concatenate: '<S31>/Vector Concatenate'
  //   Sum: '<S24>/Sum'

  VectorConcatenate[6] = (rtb_Product1_i5 - rtb_Product_gy) * USV_P.Gain_Gain_oe;

  // Gain: '<S27>/Gain' incorporates:
  //   Concatenate: '<S31>/Vector Concatenate'
  //   Sum: '<S27>/Sum'

  VectorConcatenate[7] = (rtb_Sum1_dx + VectorConcatenate_tmp) *
    USV_P.Gain_Gain_ev;

  // Sum: '<S30>/Sum' incorporates:
  //   Concatenate: '<S31>/Vector Concatenate'

  VectorConcatenate[8] = (rtb_q2dot - rtb_fcn3) + rtb_q3dot;
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // UnitConversion: '<S91>/Unit Conversion' incorporates:
    //   Constant: '<S69>/ref_rotation'

    // Unit Conversion - from: deg to: rad
    // Expression: output = (0.0174533*input) + (0)
    rtb_sincos_o1_idx_0 = 0.017453292519943295 * USV_P.FlatEarthtoLLA_psi;

    // Trigonometry: '<S76>/SinCos'
    USV_B.SinCos_o1 = std::sin(rtb_sincos_o1_idx_0);

    // Trigonometry: '<S76>/SinCos'
    USV_B.SinCos_o2 = std::cos(rtb_sincos_o1_idx_0);

    // Sum: '<S94>/Sum' incorporates:
    //   Constant: '<S94>/Constant'
    //   Constant: '<S94>/f'

    rtb_sincos_o1_idx_0 = USV_P.f_Value - USV_P.Constant_Value_eo;

    // Sqrt: '<S95>/sqrt' incorporates:
    //   Constant: '<S95>/Constant'
    //   Product: '<S95>/Product1'
    //   Sum: '<S95>/Sum1'

    rtb_sincos_o1_idx_0 = std::sqrt(USV_P.Constant_Value_ov -
      rtb_sincos_o1_idx_0 * rtb_sincos_o1_idx_0);

    // Switch: '<S87>/Switch' incorporates:
    //   Abs: '<S87>/Abs'
    //   Bias: '<S87>/Bias'
    //   Bias: '<S87>/Bias1'
    //   Constant: '<S69>/ref_position'
    //   Constant: '<S87>/Constant2'
    //   Constant: '<S88>/Constant'
    //   Math: '<S87>/Math Function1'
    //   RelationalOperator: '<S88>/Compare'

    if (std::abs(USV_P.ModelParam_GPSLatLong[0]) > USV_P.CompareToConstant_const)
    {
      rtb_Saturation_1 = rt_modd_snf(USV_P.ModelParam_GPSLatLong[0] +
        USV_P.Bias_Bias_p, USV_P.Constant2_Value) + USV_P.Bias1_Bias_a;
    } else {
      rtb_Saturation_1 = USV_P.ModelParam_GPSLatLong[0];
    }

    // End of Switch: '<S87>/Switch'

    // Abs: '<S84>/Abs1'
    rtb_Abs1 = std::abs(rtb_Saturation_1);

    // RelationalOperator: '<S86>/Compare' incorporates:
    //   Constant: '<S86>/Constant'

    rtb_Compare_f = (rtb_Abs1 > USV_P.CompareToConstant_const_j);

    // Switch: '<S84>/Switch'
    if (rtb_Compare_f) {
      // Signum: '<S84>/Sign1'
      if (!rtIsNaN(rtb_Saturation_1)) {
        if (rtb_Saturation_1 < 0.0) {
          rtb_Saturation_1 = -1.0;
        } else {
          rtb_Saturation_1 = (rtb_Saturation_1 > 0.0);
        }
      }

      // End of Signum: '<S84>/Sign1'

      // Switch: '<S84>/Switch' incorporates:
      //   Bias: '<S84>/Bias'
      //   Bias: '<S84>/Bias1'
      //   Gain: '<S84>/Gain'
      //   Product: '<S84>/Divide1'

      USV_B.Switch = ((rtb_Abs1 + USV_P.Bias_Bias_a) * USV_P.Gain_Gain_a +
                      USV_P.Bias1_Bias_d) * rtb_Saturation_1;
    } else {
      // Switch: '<S84>/Switch'
      USV_B.Switch = rtb_Saturation_1;
    }

    // End of Switch: '<S84>/Switch'

    // UnitConversion: '<S92>/Unit Conversion'
    // Unit Conversion - from: deg to: rad
    // Expression: output = (0.0174533*input) + (0)
    rtb_Sum1_dx = 0.017453292519943295 * USV_B.Switch;

    // Trigonometry: '<S93>/Trigonometric Function1'
    rtb_Product1_i5 = std::sin(rtb_Sum1_dx);

    // Product: '<S93>/Product1' incorporates:
    //   Product: '<S90>/Product2'

    rtb_Switch_bvp = rtb_sincos_o1_idx_0 * rtb_sincos_o1_idx_0;

    // Sum: '<S93>/Sum1' incorporates:
    //   Constant: '<S93>/Constant'
    //   Product: '<S93>/Product1'

    rtb_Product1_i5 = USV_P.Constant_Value_ja - rtb_Switch_bvp * rtb_Product1_i5
      * rtb_Product1_i5;

    // Product: '<S90>/Product1' incorporates:
    //   Constant: '<S90>/Constant1'
    //   Sqrt: '<S90>/sqrt'

    rtb_Product_gy = USV_P.Constant1_Value_ex / std::sqrt(rtb_Product1_i5);

    // Trigonometry: '<S90>/Trigonometric Function1' incorporates:
    //   Constant: '<S90>/Constant'
    //   Constant: '<S90>/Constant2'
    //   Product: '<S90>/Product3'
    //   Sum: '<S90>/Sum1'

    USV_B.TrigonometricFunction1 = rt_atan2d_snf(USV_P.Constant2_Value_pu,
      (USV_P.Constant_Value_k - rtb_Switch_bvp) * rtb_Product_gy /
      rtb_Product1_i5);

    // Trigonometry: '<S90>/Trigonometric Function2' incorporates:
    //   Constant: '<S90>/Constant3'
    //   Product: '<S90>/Product4'
    //   Trigonometry: '<S90>/Trigonometric Function'

    USV_B.TrigonometricFunction2 = rt_atan2d_snf(USV_P.Constant3_Value,
      rtb_Product_gy * std::cos(rtb_Sum1_dx));

    // Switch: '<S75>/Switch1' incorporates:
    //   Constant: '<S75>/Constant'
    //   Constant: '<S75>/Constant1'

    if (rtb_Compare_f) {
      rtb_sincos_o1_idx_0 = USV_P.Constant_Value_p0;
    } else {
      rtb_sincos_o1_idx_0 = USV_P.Constant1_Value_i;
    }

    // End of Switch: '<S75>/Switch1'

    // Sum: '<S75>/Sum' incorporates:
    //   Constant: '<S69>/ref_position'

    rtb_Saturation_1 = rtb_sincos_o1_idx_0 + USV_P.ModelParam_GPSLatLong[1];

    // Switch: '<S85>/Switch' incorporates:
    //   Abs: '<S85>/Abs'
    //   Constant: '<S89>/Constant'
    //   RelationalOperator: '<S89>/Compare'

    if (std::abs(rtb_Saturation_1) > USV_P.CompareToConstant_const_b) {
      // Switch: '<S85>/Switch' incorporates:
      //   Bias: '<S85>/Bias'
      //   Bias: '<S85>/Bias1'
      //   Constant: '<S85>/Constant2'
      //   Math: '<S85>/Math Function1'

      USV_B.Switch_i = rt_modd_snf(rtb_Saturation_1 + USV_P.Bias_Bias_i,
        USV_P.Constant2_Value_a) + USV_P.Bias1_Bias_m;
    } else {
      // Switch: '<S85>/Switch'
      USV_B.Switch_i = rtb_Saturation_1;
    }

    // End of Switch: '<S85>/Switch'
  }

  // Sum: '<S69>/Sum' incorporates:
  //   Integrator: '<S9>/xe,ye,ze'
  //   Product: '<S76>/rad lat'
  //   Product: '<S76>/x*cos'
  //   Product: '<S76>/y*sin'
  //   Sum: '<S76>/Sum'
  //   UnitConversion: '<S77>/Unit Conversion'

  // Unit Conversion - from: rad to: deg
  // Expression: output = (57.2958*input) + (0)
  rtb_Sum_f4[0] = (USV_X.xeyeze_CSTATE[0] * USV_B.SinCos_o2 -
                   USV_X.xeyeze_CSTATE[1] * USV_B.SinCos_o1) *
    USV_B.TrigonometricFunction1 * 57.295779513082323 + USV_B.Switch;

  // Switch: '<S81>/Switch' incorporates:
  //   Abs: '<S81>/Abs'
  //   Bias: '<S81>/Bias'
  //   Bias: '<S81>/Bias1'
  //   Constant: '<S81>/Constant2'
  //   Constant: '<S82>/Constant'
  //   Math: '<S81>/Math Function1'
  //   RelationalOperator: '<S82>/Compare'

  if (std::abs(rtb_Sum_f4[0]) > USV_P.CompareToConstant_const_n) {
    rtb_Switch_bvp = rt_modd_snf(rtb_Sum_f4[0] + USV_P.Bias_Bias_c,
      USV_P.Constant2_Value_e) + USV_P.Bias1_Bias_k;
  } else {
    rtb_Switch_bvp = rtb_Sum_f4[0];
  }

  // End of Switch: '<S81>/Switch'

  // Abs: '<S78>/Abs1'
  rtb_Saturation_1 = std::abs(rtb_Switch_bvp);

  // Switch: '<S78>/Switch' incorporates:
  //   Bias: '<S78>/Bias'
  //   Bias: '<S78>/Bias1'
  //   Constant: '<S74>/Constant'
  //   Constant: '<S74>/Constant1'
  //   Constant: '<S80>/Constant'
  //   Gain: '<S78>/Gain'
  //   Product: '<S78>/Divide1'
  //   RelationalOperator: '<S80>/Compare'
  //   Switch: '<S74>/Switch1'

  if (rtb_Saturation_1 > USV_P.CompareToConstant_const_i) {
    // Signum: '<S78>/Sign1'
    if (!rtIsNaN(rtb_Switch_bvp)) {
      if (rtb_Switch_bvp < 0.0) {
        rtb_Switch_bvp = -1.0;
      } else {
        rtb_Switch_bvp = (rtb_Switch_bvp > 0.0);
      }
    }

    // End of Signum: '<S78>/Sign1'
    rtb_Switch_bvp *= (rtb_Saturation_1 + USV_P.Bias_Bias) * USV_P.Gain_Gain +
      USV_P.Bias1_Bias;
    rtb_sincos_o1_idx_0 = USV_P.Constant_Value_nj;
  } else {
    rtb_sincos_o1_idx_0 = USV_P.Constant1_Value_kn;
  }

  // End of Switch: '<S78>/Switch'

  // Sum: '<S74>/Sum' incorporates:
  //   Integrator: '<S9>/xe,ye,ze'
  //   Product: '<S76>/rad long '
  //   Product: '<S76>/x*sin'
  //   Product: '<S76>/y*cos'
  //   Sum: '<S69>/Sum'
  //   Sum: '<S76>/Sum1'
  //   UnitConversion: '<S77>/Unit Conversion'

  rtb_Abs1 = ((USV_X.xeyeze_CSTATE[0] * USV_B.SinCos_o1 + USV_X.xeyeze_CSTATE[1]
               * USV_B.SinCos_o2) * USV_B.TrigonometricFunction2 *
              57.295779513082323 + USV_B.Switch_i) + rtb_sincos_o1_idx_0;

  // Switch: '<S79>/Switch' incorporates:
  //   Abs: '<S79>/Abs'
  //   Bias: '<S79>/Bias'
  //   Bias: '<S79>/Bias1'
  //   Constant: '<S79>/Constant2'
  //   Constant: '<S83>/Constant'
  //   Math: '<S79>/Math Function1'
  //   RelationalOperator: '<S83>/Compare'

  if (std::abs(rtb_Abs1) > USV_P.CompareToConstant_const_e) {
    rtb_Abs1 = rt_modd_snf(rtb_Abs1 + USV_P.Bias_Bias_g,
      USV_P.Constant2_Value_a4) + USV_P.Bias1_Bias_kq;
  }

  // End of Switch: '<S79>/Switch'

  // Sum: '<S69>/Sum1' incorporates:
  //   Constant: '<S3>/ModelParam.envAltitude'
  //   Integrator: '<S9>/xe,ye,ze'
  //   UnaryMinus: '<S69>/Ze2height'

  rtb_Saturation_1 = -USV_X.xeyeze_CSTATE[2] - USV_P.ModelParam_envAltitude;

  // Saturate: '<S3>/Saturation_1'
  if (rtb_Saturation_1 > USV_P.Saturation_1_UpperSat) {
    rtb_Saturation_1 = USV_P.Saturation_1_UpperSat;
  } else if (rtb_Saturation_1 < USV_P.Saturation_1_LowerSat) {
    rtb_Saturation_1 = USV_P.Saturation_1_LowerSat;
  }

  // End of Saturate: '<S3>/Saturation_1'

  // UnitConversion: '<S97>/Unit Conversion' incorporates:
  //   SignalConversion generated from: '<S72>/Selector'

  // Unit Conversion - from: deg to: rad
  // Expression: output = (0.0174533*input) + (0)
  rtb_sincos_o1_idx_0 = 0.017453292519943295 * rtb_Switch_bvp;

  // UnitConversion: '<S99>/Unit Conversion' incorporates:
  //   SignalConversion generated from: '<S72>/Selector'

  // Unit Conversion - from: deg to: rad
  // Expression: output = (0.0174533*input) + (0)
  rtb_q3dot = 0.017453292519943295 * rtb_Abs1;

  // Selector: '<S72>/Selector' incorporates:
  //   SignalConversion generated from: '<S72>/Selector'

  rtb_q2dot = rtb_Saturation_1;

  // S-Function (saerogravity2): '<S72>/WGS84 Gravity S-Function' incorporates:
  //   Constant: '<S72>/Julian Date'


  // S-Function Block: <S72>/WGS84 Gravity S-Function
  {
    int_T i;
    real_T GM, opt_m2ft, deg2rad;
    real_T *phi_ptr, *height_ptr;
    boolean_T phi_wrapped = false;
    real_T *phi = (real_T *) &USV_DW.WGS84GravitySFunction_phi;
    real_T *h = (real_T *) &USV_DW.WGS84GravitySFunction_h;
    height_ptr = (real_T *) &rtb_q2dot;
    phi_ptr = (real_T *) &rtb_sincos_o1_idx_0;

    // get unit conversion factor
    opt_m2ft = 1.0;
    deg2rad = 1.0;

    // Use Earth's Atmosphere in Gravitational Const?
    GM = ( 1.0 == 0 ) ? WGS84_GM_DEF : WGS84_GM_PRM;

    // WGS84TAYLORSERIES
    {
      for (i = 0; i < 1; i++ ) {
        real_T fphi, pi_2;

        // create short variables for latitude (phi) and height (h)
        phi[i] = phi_ptr[i] * deg2rad;
        h[i] = height_ptr[i] / opt_m2ft;
        if (phi[i] > AERO_PI || phi[i] < -AERO_PI) {
          phi[i] = std::fmod(phi[i]+AERO_PI, 2.0*AERO_PI) - AERO_PI;
        }

        fphi = std::abs(phi[i]);
        pi_2 = AERO_PI/2.0;
        if (fphi > pi_2 ) {
          real_T sign = phi[i]/fphi;
          phi_wrapped = true;
          phi[i] = sign*(pi_2 - (fphi - pi_2));
        } else {
          phi_wrapped = false;
        }
      }

      wgs84_taylor_series(h, phi, opt_m2ft, &USV_B.MatrixConcatenate[2], 1);

      // north and east components are zero
      USV_B.MatrixConcatenate[0] = USV_DW.WGS84GravitySFunction_gamma_phi;
      USV_B.MatrixConcatenate[1] = USV_DW.WGS84GravitySFunction_gamma_phi;
    }
  }

  // Product: '<S4>/Product' incorporates:
  //   Concatenate: '<S31>/Vector Concatenate'
  //   Constant: '<S4>/ModelParam.uavMass'
  //   Product: '<S4>/Product1'

  for (i = 0; i < 3; i++) {
    rtb_DataTypeConversion2[i] = (VectorConcatenate[i + 3] *
      (USV_P.ModelParam_uavMass * USV_B.MatrixConcatenate[1]) +
      USV_P.ModelParam_uavMass * USV_B.MatrixConcatenate[0] *
      VectorConcatenate[i]) + VectorConcatenate[i + 6] *
      (USV_P.ModelParam_uavMass * USV_B.MatrixConcatenate[2]);
  }

  // End of Product: '<S4>/Product'

  // Product: '<S42>/Product' incorporates:
  //   Integrator: '<S10>/q0 q1 q2 q3'

  rtb_q2dot = USV_X.q0q1q2q3_CSTATE[0] * USV_X.q0q1q2q3_CSTATE[0];

  // Sqrt: '<S41>/sqrt' incorporates:
  //   Integrator: '<S10>/q0 q1 q2 q3'
  //   Product: '<S42>/Product1'
  //   Product: '<S42>/Product2'
  //   Product: '<S42>/Product3'
  //   Sum: '<S42>/Sum'

  rtb_q2dot = std::sqrt(((USV_X.q0q1q2q3_CSTATE[1] * USV_X.q0q1q2q3_CSTATE[1] +
    rtb_q2dot) + USV_X.q0q1q2q3_CSTATE[2] * USV_X.q0q1q2q3_CSTATE[2]) +
                        USV_X.q0q1q2q3_CSTATE[3] * USV_X.q0q1q2q3_CSTATE[3]);

  // Product: '<S36>/Product' incorporates:
  //   Integrator: '<S10>/q0 q1 q2 q3'

  rtb_Sum1_dx = USV_X.q0q1q2q3_CSTATE[0] / rtb_q2dot;

  // Product: '<S36>/Product1' incorporates:
  //   Integrator: '<S10>/q0 q1 q2 q3'

  rtb_q3dot = USV_X.q0q1q2q3_CSTATE[1] / rtb_q2dot;

  // Product: '<S36>/Product2' incorporates:
  //   Integrator: '<S10>/q0 q1 q2 q3'

  rtb_sincos_o1_idx_0 = USV_X.q0q1q2q3_CSTATE[2] / rtb_q2dot;

  // Product: '<S36>/Product3' incorporates:
  //   Integrator: '<S10>/q0 q1 q2 q3'

  rtb_q2dot = USV_X.q0q1q2q3_CSTATE[3] / rtb_q2dot;

  // Fcn: '<S19>/fcn2' incorporates:
  //   Fcn: '<S19>/fcn5'

  VectorConcatenate_tmp = rtb_Sum1_dx * rtb_Sum1_dx;
  VectorConcatenate_tmp_0 = rtb_q3dot * rtb_q3dot;
  rtb_Product1_i5 = rtb_sincos_o1_idx_0 * rtb_sincos_o1_idx_0;
  rtb_Product_gy = rtb_q2dot * rtb_q2dot;

  // Trigonometry: '<S35>/Trigonometric Function1' incorporates:
  //   Fcn: '<S19>/fcn1'
  //   Fcn: '<S19>/fcn2'

  rtb_VectorConcatenate[0] = rt_atan2d_snf((rtb_q3dot * rtb_sincos_o1_idx_0 +
    rtb_Sum1_dx * rtb_q2dot) * 2.0, ((VectorConcatenate_tmp +
    VectorConcatenate_tmp_0) - rtb_Product1_i5) - rtb_Product_gy);

  // Fcn: '<S19>/fcn3'
  rtb_fcn3 = (rtb_q3dot * rtb_q2dot - rtb_Sum1_dx * rtb_sincos_o1_idx_0) * -2.0;

  // If: '<S37>/If'
  if (rtsiIsModeUpdateTimeStep(&(&USV_M)->solverInfo)) {
    if (rtb_fcn3 > 1.0) {
      rtAction = 0;
    } else if (rtb_fcn3 < -1.0) {
      rtAction = 1;
    } else {
      rtAction = 2;
    }

    USV_DW.If_ActiveSubsystem = rtAction;
  } else {
    rtAction = USV_DW.If_ActiveSubsystem;
  }

  switch (rtAction) {
   case 0:
    // Outputs for IfAction SubSystem: '<S37>/If Action Subsystem' incorporates:
    //   ActionPort: '<S38>/Action Port'

    if (rtmIsMajorTimeStep((&USV_M)) &&
        (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
      // Merge: '<S37>/Merge' incorporates:
      //   Constant: '<S38>/Constant'

      USV_B.Merge_i = USV_P.Constant_Value;
    }

    // End of Outputs for SubSystem: '<S37>/If Action Subsystem'
    break;

   case 1:
    // Outputs for IfAction SubSystem: '<S37>/If Action Subsystem1' incorporates:
    //   ActionPort: '<S39>/Action Port'

    if (rtmIsMajorTimeStep((&USV_M)) &&
        (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
      // Merge: '<S37>/Merge' incorporates:
      //   Constant: '<S39>/Constant'

      USV_B.Merge_i = USV_P.Constant_Value_f;
    }

    // End of Outputs for SubSystem: '<S37>/If Action Subsystem1'
    break;

   case 2:
    // Outputs for IfAction SubSystem: '<S37>/If Action Subsystem2' incorporates:
    //   ActionPort: '<S40>/Action Port'

    // Merge: '<S37>/Merge' incorporates:
    //   SignalConversion generated from: '<S40>/In'

    USV_B.Merge_i = rtb_fcn3;

    // End of Outputs for SubSystem: '<S37>/If Action Subsystem2'
    break;
  }

  // End of If: '<S37>/If'

  // Trigonometry: '<S35>/trigFcn'
  if (USV_B.Merge_i > 1.0) {
    rtb_fcn3 = 1.0;
  } else if (USV_B.Merge_i < -1.0) {
    rtb_fcn3 = -1.0;
  } else {
    rtb_fcn3 = USV_B.Merge_i;
  }

  rtb_VectorConcatenate[1] = std::asin(rtb_fcn3);

  // End of Trigonometry: '<S35>/trigFcn'

  // Trigonometry: '<S35>/Trigonometric Function3' incorporates:
  //   Fcn: '<S19>/fcn4'
  //   Fcn: '<S19>/fcn5'

  rtb_VectorConcatenate[2] = rt_atan2d_snf((rtb_sincos_o1_idx_0 * rtb_q2dot +
    rtb_Sum1_dx * rtb_q3dot) * 2.0, ((VectorConcatenate_tmp -
    VectorConcatenate_tmp_0) - rtb_Product1_i5) + rtb_Product_gy);

  // Gain: '<S194>/Gain' incorporates:
  //   Inport: '<Root>/TerrainZ'
  //   Integrator: '<S9>/xe,ye,ze'
  //   Sum: '<S194>/Sum'

  rtb_sincos_o1_idx_0 = (USV_X.xeyeze_CSTATE[2] - USV_U.TerrainZ) *
    USV_P.Gain_Gain_c;

  // MATLAB Function: '<S194>/MATLAB Function' incorporates:
  //   Constant: '<S194>/BoatParam_cf'
  //   Constant: '<S194>/BoatParam_len'
  //   Constant: '<S194>/BoatParam_lenSlope'
  //   Constant: '<S194>/BoatParam_waterDensity'
  //   Constant: '<S194>/BoatParam_widSlope'
  //   Constant: '<S194>/BoatParam_width'
  //   Constant: '<S194>/ModelParam.uavMass'

  VectorConcatenate_tmp = rtb_VectorConcatenate[2];
  VectorConcatenate_tmp_0 = rtb_VectorConcatenate[1];

  //  M �����������������Mg
  //  rho ˮ���ܶ�
  //  cf ���嵱ǰ���ĵ�λ�ã�����Ϊ����������/ǰ��������ϵ
  //  dw ����ˮ���Ŀ��� d_water
  //  alpha ����ˮ���Ĳ������ˮ��ļнǣ����������ǣ�
  //  lw  ����ˮ���ĳ��� l_water
  //  beta ����ˮ����ǰ�������ˮ��ļнǣ���ǰ������ǣ�
  //  phi ���Ĺ�ת�ǣ����ֶ������ҹ���˲ʱ�룩Ϊ��
  //  theta ���ĸ����ǣ����ֶ���
  //  dz �������¸�����λ�ƣ�����Ϊ��
  // MATLAB Function 'Force and Moment Model/buoyancyModel/MATLAB Function': '<S327>:1' 
  //  ��������Ƕ��޷�
  //  ���Ƕȷ�Χӳ�䵽-180 ~ 180 ��
  // '<S327>:1:15' while phi>pi
  while (VectorConcatenate_tmp > 3.1415926535897931) {
    // '<S327>:1:16' phi = phi -2*pi;
    VectorConcatenate_tmp -= 6.2831853071795862;
  }

  // '<S327>:1:18' while phi<-pi
  while (VectorConcatenate_tmp < -3.1415926535897931) {
    // '<S327>:1:19' phi = phi +2*pi;
    VectorConcatenate_tmp += 6.2831853071795862;
  }

  //  ���Ƕȷ�Χӳ�䵽-180 ~ 180 ��
  // '<S327>:1:24' while theta>pi
  while (VectorConcatenate_tmp_0 > 3.1415926535897931) {
    // '<S327>:1:25' theta = theta -2*pi;
    VectorConcatenate_tmp_0 -= 6.2831853071795862;
  }

  // '<S327>:1:27' while theta<-pi
  while (VectorConcatenate_tmp_0 < -3.1415926535897931) {
    // '<S327>:1:28' theta = theta +2*pi;
    VectorConcatenate_tmp_0 += 6.2831853071795862;
  }

  //  ��ת���޷�
  // '<S327>:1:32' if phi>pi/4
  if (VectorConcatenate_tmp > 0.78539816339744828) {
    // �������45�ȣ������޷�
    // '<S327>:1:33' phi=pi/4;
    VectorConcatenate_tmp = 0.78539816339744828;
  }

  // '<S327>:1:36' if phi<-pi/4
  if (VectorConcatenate_tmp < -0.78539816339744828) {
    // ���С��-45�ȣ������޷�
    // '<S327>:1:37' phi=-pi/4;
    VectorConcatenate_tmp = -0.78539816339744828;
  }

  //  �������޷�
  // '<S327>:1:41' if theta>pi/4
  if (VectorConcatenate_tmp_0 > 0.78539816339744828) {
    // �������45�ȣ������޷�
    // '<S327>:1:42' theta=pi/4;
    VectorConcatenate_tmp_0 = 0.78539816339744828;
  }

  // '<S327>:1:45' if theta<-pi/4
  if (VectorConcatenate_tmp_0 < -0.78539816339744828) {
    // ���С��-45�ȣ������޷�
    // '<S327>:1:46' theta=-pi/4;
    VectorConcatenate_tmp_0 = -0.78539816339744828;
  }

  //  �������ҷ�תʱ�������ı仯����
  //  ���Ĵ��Ĵ���Ч����
  // '<S327>:1:53' lw_e = lw-2*cf*cot(beta);
  lw_b_e = 1.0 / std::tan(USV_P.BoatParam_lenSlope);
  rtb_q2dot = USV_P.BoatParam_len - 2.0 * USV_P.BoatParam_cf * lw_b_e;

  //  Ϊ���⸡�����ò��������£���Ч����ʧ�棬�������һ������0.5��
  // '<S327>:1:57' if lw_e < 0.5*lw
  if (rtb_q2dot < 0.5 * USV_P.BoatParam_len) {
    // '<S327>:1:58' lw_e = lw;
    rtb_q2dot = USV_P.BoatParam_len;
  }

  //  ����������ݽ���ĵ�Ч���
  // '<S327>:1:63' Std = M/(rho*lw_e);
  rtb_Sum1_dx = USV_P.ModelParam_uavMass / (USV_P.BoatParam_waterDensity *
    rtb_q2dot);

  //  ��һ�´������󷭣��������ҷ�
  // '<S327>:1:66' if phi<0
  if (VectorConcatenate_tmp < 0.0) {
    //  �������
    // '<S327>:1:67' phi=abs(phi);
    VectorConcatenate_tmp = std::abs(VectorConcatenate_tmp);

    // '<S327>:1:68' roll_sign=1;
    roll_sign = 1;
  } else {
    // '<S327>:1:69' else
    // �������
    // '<S327>:1:70' phi=abs(phi);
    // '<S327>:1:71' roll_sign=-1;
    roll_sign = -1;
  }

  //  ������Ƶ��ǻ��������ת�ģ��ڸ������ʱ����Ҫ����ӳ��
  //  �Ҳ���ˮ��С���������
  // '<S327>:1:77' dw_r = dw/2/(cos(phi)+sin(phi)*cot(alpha));
  // '<S327>:1:78' dw_r_e = (dw/2+dw_r)/2;
  rtb_Product1_i5 = std::sin(VectorConcatenate_tmp);
  rtb_Product_gy = std::cos(VectorConcatenate_tmp);
  rtb_WhiteNoise_b_idx_0 = 1.0 / std::tan(USV_P.BoatParam_widSlope);
  rtb_fcn3 = (USV_P.BoatParam_width / 2.0 / (rtb_WhiteNoise_b_idx_0 *
    rtb_Product1_i5 + rtb_Product_gy) + USV_P.BoatParam_width / 2.0) / 2.0;

  // '<S327>:1:80' S_dr = dw_r_e*dw_r_e*sin(phi)/2;
  rtb_q3dot = rtb_fcn3 * rtb_fcn3 * rtb_Product1_i5 / 2.0;

  // '<S327>:1:82' y_dr = 2/3*dw_r_e*sin(phi/2);
  // '<S327>:1:83' z_dr =  2/3*dw_r_e*cos(phi/2);
  //  �����ˮ�������������
  // '<S327>:1:87' dw_l = dw/2*(cos(phi)+sin(phi)*cot(alpha-phi));
  // '<S327>:1:88' dw_l_e = (dw/2+dw_l)/2;
  dw_l_e = ((1.0 / std::tan(USV_P.BoatParam_widSlope - VectorConcatenate_tmp) *
             rtb_Product1_i5 + rtb_Product_gy) * (USV_P.BoatParam_width / 2.0) +
            USV_P.BoatParam_width / 2.0) / 2.0;

  // '<S327>:1:90' S_dl = dw_l_e*dw_l_e*sin(phi)/2;
  rtb_Product1_i5 = dw_l_e * dw_l_e * rtb_Product1_i5 / 2.0;

  // '<S327>:1:92' y_dl = -2/3*dw_l_e*sin(phi/2);
  // '<S327>:1:93' z_dl =  -2/3*dw_l_e*cos(phi/2);
  //  ���������Ҳ���ˮ�������������죬�������ĸ��ı仯
  // '<S327>:1:97' cf_z1 = (Std*cf - S_dr*z_dr + S_dl*z_dl)/Std;
  // '<S327>:1:98' cf_y = (-S_dr*y_dr + S_dl*y_dl)/Std;
  //  ������б����£����ĵ�λ����������
  //  ������бʱ������Ӧ�����ƣ���ôcf_yӦ��Ϊ��ֵ
  // '<S327>:1:102' cf_y = cf_y*roll_sign;
  //  ����ǰ��תʱ�������ı仯����
  //  ���Ĵ��Ĵ���Ч����
  // '<S327>:1:107' dw_e = dw-2*cf*cot(alpha);
  dw_e = USV_P.BoatParam_width - 2.0 * USV_P.BoatParam_cf *
    rtb_WhiteNoise_b_idx_0;

  // '<S327>:1:109' if dw_e < 0.5*dw
  if (dw_e < 0.5 * USV_P.BoatParam_width) {
    // '<S327>:1:110' dw_e = dw;
    dw_e = USV_P.BoatParam_width;
  }

  // '<S327>:1:113' Stl = M/(rho*dw_e);
  rtb_Product_gy = USV_P.ModelParam_uavMass / (USV_P.BoatParam_waterDensity *
    dw_e);

  //  ��һ�´�����ǰ�����������
  // '<S327>:1:116' if theta<0
  if (VectorConcatenate_tmp_0 < 0.0) {
    //  �����ǰ
    // '<S327>:1:117' theta=abs(theta);
    VectorConcatenate_tmp_0 = std::abs(VectorConcatenate_tmp_0);

    // '<S327>:1:118' pitch_sign=1;
    pitch_sign = 1;
  } else {
    // '<S327>:1:119' else
    // ������
    // '<S327>:1:120' theta=abs(theta);
    // '<S327>:1:121' pitch_sign=-1;
    pitch_sign = -1;
  }

  //  ������Ƶ��ǻ�����ǰ��ת�ģ��ڸ������ʱ����Ҫ����ӳ��
  //  �����ˮ��С���������
  // '<S327>:1:127' lw_b = lw/2/(cos(theta)+sin(theta)*cot(beta));
  // '<S327>:1:128' lw_b_e = (lw/2+lw_b)/2;
  S_df = std::sin(VectorConcatenate_tmp_0);
  lw_f_e = std::cos(VectorConcatenate_tmp_0);
  lw_b_e = (USV_P.BoatParam_len / 2.0 / (lw_b_e * S_df + lw_f_e) +
            USV_P.BoatParam_len / 2.0) / 2.0;

  // '<S327>:1:130' S_db = lw_b_e*lw_b_e*sin(theta)/2;
  S_db = lw_b_e * lw_b_e * S_df / 2.0;

  // '<S327>:1:132' y_db = 2/3*lw_b_e*sin(theta/2);
  // '<S327>:1:133' z_db =  2/3*lw_b_e*cos(theta/2);
  //  ǰ����ˮ�������������
  // '<S327>:1:137' lw_f = lw/2*(cos(theta)+sin(theta)*cot(beta-theta));
  // '<S327>:1:138' lw_f_e = (lw/2+lw_f)/2;
  lw_f_e = ((1.0 / std::tan(USV_P.BoatParam_lenSlope - VectorConcatenate_tmp_0) *
             S_df + lw_f_e) * (USV_P.BoatParam_len / 2.0) + USV_P.BoatParam_len /
            2.0) / 2.0;

  // '<S327>:1:140' S_df = lw_f_e*lw_f_e*sin(theta)/2;
  S_df = lw_f_e * lw_f_e * S_df / 2.0;

  // '<S327>:1:142' y_df = -2/3*lw_f_e*sin(theta/2);
  // '<S327>:1:143' z_df =  -2/3*lw_f_e*cos(theta/2);
  //  ������ǰ�����ˮ�������������죬�������ĸ��ı仯
  // '<S327>:1:147' cf_z2 = (Stl*cf - S_db*z_db + S_df*z_df)/Stl;
  // '<S327>:1:148' cf_x = (-S_db*y_db + S_df*y_df)/Stl;
  //  ǰ����б����£����ĵ�λ����������
  //  �����бʱ������Ӧ�ú��ƣ���ôcf_xӦ��Ϊ��ֵ
  // '<S327>:1:152' cf_x = cf_x*pitch_sign;
  //  cf_z1
  //  cf_z2
  //  �Ը���λ�ý�������
  // '<S327>:1:157' fuPos=[cf_x,cf_y,cf_z1+cf_z2-cf];
  rtb_fuPos_tmp = std::sin(VectorConcatenate_tmp_0 / 2.0);
  rtb_fuPos_tmp_0 = std::sin(VectorConcatenate_tmp / 2.0);
  VectorConcatenate_tmp = std::cos(VectorConcatenate_tmp / 2.0);
  VectorConcatenate_tmp_0 = std::cos(VectorConcatenate_tmp_0 / 2.0);
  rtb_fuPos[0] = (0.66666666666666663 * lw_b_e * rtb_fuPos_tmp * -S_db +
                  -0.66666666666666663 * lw_f_e * rtb_fuPos_tmp * S_df) /
    rtb_Product_gy * static_cast<real_T>(pitch_sign);
  rtb_fuPos[1] = (0.66666666666666663 * rtb_fcn3 * rtb_fuPos_tmp_0 * -rtb_q3dot
                  + -0.66666666666666663 * dw_l_e * rtb_fuPos_tmp_0 *
                  rtb_Product1_i5) / rtb_Sum1_dx * static_cast<real_T>(roll_sign);
  rtb_fuPos_tmp = rtb_Sum1_dx * USV_P.BoatParam_cf;
  rtb_fuPos[2] = (((rtb_fuPos_tmp - 0.66666666666666663 * rtb_fcn3 *
                    VectorConcatenate_tmp * rtb_q3dot) + -0.66666666666666663 *
                   dw_l_e * VectorConcatenate_tmp * rtb_Product1_i5) /
                  rtb_Sum1_dx + ((rtb_Product_gy * USV_P.BoatParam_cf -
    0.66666666666666663 * lw_b_e * VectorConcatenate_tmp_0 * S_db) +
    -0.66666666666666663 * lw_f_e * VectorConcatenate_tmp_0 * S_df) /
                  rtb_Product_gy) - USV_P.BoatParam_cf;

  //  ����������ת��������������ֵ
  // '<S327>:1:161' dM0 = (S_dl - S_dr)/Std*M;
  //  ���ҷ�����ת�������Ķ�����ˮ����
  // '<S327>:1:162' dM1 = (S_df - S_db)/Stl*M;
  //  ���ҷ�����ת�������Ķ�����ˮ����
  //  ���贬��Ϊ���Σ�����һ����ȫ��ˮ�߶ȣ���Ϊ��ֵ
  // '<S327>:1:165' h_max = Std/dw_e/lw_e;
  //  ����һ����ȫ��ֵ���Դ���Ϊ������ײ�
  // '<S327>:1:167' if dz > h_max
  if (rtb_sincos_o1_idx_0 > rtb_Sum1_dx / dw_e / rtb_q2dot) {
    //  ��Ϊ���Ѿ��뿪ˮ��
    // '<S327>:1:168' fuPos=[0,0,cf];
    rtb_fuPos[0] = 0.0;
    rtb_fuPos[1] = 0.0;
    rtb_fuPos[2] = USV_P.BoatParam_cf;

    // ������Ĭ��λ��
    // '<S327>:1:169' wM=0;
    rtb_q3dot = 0.0;

    //  ��ˮ����Ϊ0
  } else {
    //  ���贬��Ϊ�������ν��棬�ױ�Ϊdw���׽�Ϊalpha��������ĸ߶� = ������Ч����lw_e 
    //  ���εĶ̱�
    // '<S327>:1:176' dw1 = dw -dz*cot(alpha)*2;
    rtb_q2dot = USV_P.BoatParam_width - rtb_WhiteNoise_b_idx_0 *
      rtb_sincos_o1_idx_0 * 2.0;

    // ���������ʽ
    // '<S327>:1:178' Sdz = dz*(dw+dw1)/2;
    rtb_WhiteNoise_b_idx_0 = USV_P.BoatParam_width + rtb_q2dot;
    rtb_fcn3 = rtb_WhiteNoise_b_idx_0 * rtb_sincos_o1_idx_0 / 2.0;

    // ������ˮ���ģ����ģ���ʽ
    // '<S327>:1:180' cf_dz = dz*(dw1+2*dw)/3/(dw1+dw);
    // '<S327>:1:182' cf_z2=(Std*cf-Sdz*cf_dz)/(Std-Sdz);
    // '<S327>:1:184' dM2 = -Sdz/Std*M;
    // '<S327>:1:186' wM=M+dM0+dM1+dM2;
    rtb_q3dot = (((rtb_Product1_i5 - rtb_q3dot) / rtb_Sum1_dx *
                  USV_P.ModelParam_uavMass + USV_P.ModelParam_uavMass) + (S_df -
      S_db) / rtb_Product_gy * USV_P.ModelParam_uavMass) + -rtb_fcn3 /
      rtb_Sum1_dx * USV_P.ModelParam_uavMass;

    // '<S327>:1:187' if wM<0
    if (rtb_q3dot < 0.0) {
      // '<S327>:1:188' wM=0;
      rtb_q3dot = 0.0;
    }

    // '<S327>:1:190' if wM >3*M
    if (rtb_q3dot > 3.0 * USV_P.ModelParam_uavMass) {
      // ��������������
      // '<S327>:1:191' wM = 3*wM;
      rtb_q3dot *= 3.0;
    }

    // '<S327>:1:194' fuPos(3)=fuPos(3)+(cf_z2-cf);
    rtb_fuPos[2] += (rtb_fuPos_tmp - (2.0 * USV_P.BoatParam_width + rtb_q2dot) *
                     rtb_sincos_o1_idx_0 / 3.0 / rtb_WhiteNoise_b_idx_0 *
                     rtb_fcn3) / (rtb_Sum1_dx - rtb_fcn3) - USV_P.BoatParam_cf;

    //  ���ϸ���ƫ����
  }

  // Product: '<S194>/Product1' incorporates:
  //   Concatenate: '<S31>/Vector Concatenate'
  //   Gain: '<S194>/Gain1'
  //   MATLAB Function: '<S194>/MATLAB Function'
  //   Product: '<S194>/Product'

  for (i = 0; i < 3; i++) {
    rtb_IntegratorSecondOrderLimi_e[i] = (rtb_q3dot * USV_B.MatrixConcatenate[1]
      * USV_P.Gain1_Gain_j * VectorConcatenate[i + 3] + rtb_q3dot *
      USV_B.MatrixConcatenate[0] * USV_P.Gain1_Gain_j * VectorConcatenate[i]) +
      rtb_q3dot * USV_B.MatrixConcatenate[2] * USV_P.Gain1_Gain_j *
      VectorConcatenate[i + 6];
  }

  // End of Product: '<S194>/Product1'
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // Trigonometry: '<S208>/sincos' incorporates:
    //   Constant: '<S198>/pose: 1 * 6'

    rtb_sincos_o1_h[0] = std::sin(USV_P.Motor1_MotorPara.pose[3]);
    rtb_sincos_o2_k[0] = std::cos(USV_P.Motor1_MotorPara.pose[3]);
    rtb_sincos_o1_h[1] = std::sin(USV_P.Motor1_MotorPara.pose[4]);
    rtb_sincos_o2_k[1] = std::cos(USV_P.Motor1_MotorPara.pose[4]);
    rtb_sincos_o1_h[2] = std::sin(USV_P.Motor1_MotorPara.pose[5]);
    rtb_sincos_o2_k[2] = std::cos(USV_P.Motor1_MotorPara.pose[5]);

    // Product: '<S211>/u(5)*u(6)' incorporates:
    //   Concatenate: '<S220>/Vector Concatenate'

    USV_B.VectorConcatenate_j[0] = rtb_sincos_o2_k[1] * rtb_sincos_o2_k[2];

    // Product: '<S214>/u(6)*u(1)*u(2)' incorporates:
    //   Product: '<S218>/u(1)*u(6)'

    rtb_sincos_o1_idx_0 = rtb_sincos_o1_h[0] * rtb_sincos_o2_k[2];

    // Sum: '<S214>/Sum' incorporates:
    //   Concatenate: '<S220>/Vector Concatenate'
    //   Product: '<S214>/u(3)*u(4)'
    //   Product: '<S214>/u(6)*u(1)*u(2)'

    USV_B.VectorConcatenate_j[1] = rtb_sincos_o1_idx_0 * rtb_sincos_o1_h[1] -
      rtb_sincos_o2_k[0] * rtb_sincos_o1_h[2];

    // Sum: '<S217>/Sum' incorporates:
    //   Concatenate: '<S220>/Vector Concatenate'
    //   Product: '<S217>/u(1)*u(3)'
    //   Product: '<S217>/u(2)*u(4)*u(6)'

    USV_B.VectorConcatenate_j[2] = rtb_sincos_o2_k[0] * rtb_sincos_o1_h[1] *
      rtb_sincos_o2_k[2] + rtb_sincos_o1_h[0] * rtb_sincos_o1_h[2];

    // Product: '<S212>/u(3)*u(5)' incorporates:
    //   Concatenate: '<S220>/Vector Concatenate'

    USV_B.VectorConcatenate_j[3] = rtb_sincos_o2_k[1] * rtb_sincos_o1_h[2];

    // Sum: '<S215>/Sum' incorporates:
    //   Concatenate: '<S220>/Vector Concatenate'
    //   Product: '<S215>/u(1)*u(2)*u(3)'
    //   Product: '<S215>/u(4)*u(6)'

    USV_B.VectorConcatenate_j[4] = rtb_sincos_o1_h[0] * rtb_sincos_o1_h[1] *
      rtb_sincos_o1_h[2] + rtb_sincos_o2_k[0] * rtb_sincos_o2_k[2];

    // Sum: '<S218>/Sum' incorporates:
    //   Concatenate: '<S220>/Vector Concatenate'
    //   Product: '<S218>/u(2)*u(3)*u(4)'

    USV_B.VectorConcatenate_j[5] = rtb_sincos_o1_h[1] * rtb_sincos_o1_h[2] *
      rtb_sincos_o2_k[0] - rtb_sincos_o1_idx_0;

    // UnaryMinus: '<S213>/Unary Minus' incorporates:
    //   Concatenate: '<S220>/Vector Concatenate'

    USV_B.VectorConcatenate_j[6] = -rtb_sincos_o1_h[1];

    // Product: '<S216>/u(1)*u(5)' incorporates:
    //   Concatenate: '<S220>/Vector Concatenate'

    USV_B.VectorConcatenate_j[7] = rtb_sincos_o1_h[0] * rtb_sincos_o2_k[1];

    // Product: '<S219>/u(4)*u(5)' incorporates:
    //   Concatenate: '<S220>/Vector Concatenate'

    USV_B.VectorConcatenate_j[8] = rtb_sincos_o2_k[0] * rtb_sincos_o2_k[1];
    for (i = 0; i < 3; i++) {
      // Math: '<S198>/Transpose' incorporates:
      //   Concatenate: '<S220>/Vector Concatenate'

      USV_B.DCM_bj[3 * i] = USV_B.VectorConcatenate_j[i];
      USV_B.DCM_bj[3 * i + 1] = USV_B.VectorConcatenate_j[i + 3];
      USV_B.DCM_bj[3 * i + 2] = USV_B.VectorConcatenate_j[i + 6];
    }

    // Constant: '<S50>/FaultID'
    USV_B.FaultID = USV_P.FaultID_Value;
  }

  for (i = 0; i < 20; i++) {
    // DataTypeConversion: '<Root>/Data Type Conversion1' incorporates:
    //   Inport: '<Root>/inSILFloats'

    inSILFloats[i] = USV_U.inSILFloats[i];
  }

  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // MATLAB Function: '<S50>/FaultParamsExtract' incorporates:
    //   Inport: '<Root>/inSILInts'

    // MATLAB Function 'ESC Fault/FaultParamsExtract': '<S55>:1'
    // '<S55>:1:5' if isempty(hFault)
    // '<S55>:1:8' if isempty(fParam)
    // '<S55>:1:12' hFaultTmp=false;
    rtb_Compare_o = false;

    // '<S55>:1:13' fParamTmp=zeros(20,1);
    std::memset(&fParamTmp[0], 0, 20U * sizeof(real_T));

    // '<S55>:1:14' j=1;
    j = 1.0;

    // '<S55>:1:15' for i=1:8
    for (roll_sign = 0; roll_sign < 8; roll_sign++) {
      // '<S55>:1:16' if inInts(i) == FaultID
      if (USV_U.inSILInts[roll_sign] == USV_B.FaultID) {
        // '<S55>:1:17' hFaultTmp=true;
        rtb_Compare_o = true;

        // '<S55>:1:18' fParamTmp(2*j-1)=inFloats(2*i-1);
        pitch_sign = (roll_sign + 1) << 1;
        fParamTmp[static_cast<int32_T>(2.0 * j - 1.0) - 1] =
          inSILFloats[pitch_sign - 2];

        // '<S55>:1:19' fParamTmp(2*j)=inFloats(2*i);
        fParamTmp[static_cast<int32_T>(2.0 * j) - 1] = inSILFloats[pitch_sign -
          1];

        // '<S55>:1:20' j=j+1;
        j++;
      }
    }

    // '<S55>:1:23' if hFaultTmp
    if (rtb_Compare_o) {
      // '<S55>:1:24' hFault=hFaultTmp;
      USV_DW.hFault_c = true;

      // '<S55>:1:25' fParamTmp(17:20) = inFloats(17:20);
      fParamTmp[16] = inSILFloats[16];
      fParamTmp[17] = inSILFloats[17];
      fParamTmp[18] = inSILFloats[18];
      fParamTmp[19] = inSILFloats[19];

      // '<S55>:1:26' fParam=fParamTmp;
      std::memcpy(&USV_DW.fParam_b[0], &fParamTmp[0], 20U * sizeof(real_T));
    }

    // '<S55>:1:29' hasFault=hFault;
    rtb_Compare_o = USV_DW.hFault_c;

    // '<S55>:1:30' FaultParam=fParam;
    std::memcpy(&fParamTmp[0], &USV_DW.fParam_b[0], 20U * sizeof(real_T));

    // End of MATLAB Function: '<S50>/FaultParamsExtract'

    // Switch: '<S61>/Switch1' incorporates:
    //   Constant: '<S61>/Constant1'
    //   Constant: '<S61>/isEnable'

    if (USV_P.ESC1_MotorPara.isEnable) {
      // Switch: '<S61>/Switch2' incorporates:
      //   Constant: '<Root>/armState'
      //   Constant: '<S61>/input_offset'
      //   Constant: '<S61>/input_scaling'
      //   Constant: '<S61>/zero_position_armed'
      //   Constant: '<S61>/zero_position_disarmed'
      //   Product: '<S61>/Product'
      //   Sum: '<S61>/Add'
      //   Sum: '<S61>/Add1'

      if (USV_P.armState_Value > USV_P.Switch2_Threshold) {
        // Switch: '<S61>/Switch' incorporates:
        //   Constant: '<S61>/Constant'
        //   Inport: '<Root>/inPWMs'

        if (USV_P.ESC1_MotorPara.isEnable) {
          rtb_fcn3 = USV_U.inPWMs[0];
        } else {
          rtb_fcn3 = USV_P.Constant_Value_j;
        }

        // End of Switch: '<S61>/Switch'
        rtb_Switch1 = (rtb_fcn3 + USV_P.ESC1_MotorPara.input_offset) *
          USV_P.ESC1_MotorPara.input_scaling +
          USV_P.ESC1_MotorPara.zero_position_armed;
      } else {
        rtb_Switch1 = USV_P.ESC1_MotorPara.zero_position_disarmed;
      }

      // End of Switch: '<S61>/Switch2'
    } else {
      rtb_Switch1 = USV_P.Constant1_Value;
    }

    // End of Switch: '<S61>/Switch1'

    // Switch: '<S62>/Switch1' incorporates:
    //   Constant: '<S62>/Constant1'
    //   Constant: '<S62>/isEnable'

    if (USV_P.ESC2_MotorPara.isEnable) {
      // Switch: '<S62>/Switch2' incorporates:
      //   Constant: '<Root>/armState'
      //   Constant: '<S62>/input_offset'
      //   Constant: '<S62>/input_scaling'
      //   Constant: '<S62>/zero_position_armed'
      //   Constant: '<S62>/zero_position_disarmed'
      //   Product: '<S62>/Product'
      //   Sum: '<S62>/Add'
      //   Sum: '<S62>/Add1'

      if (USV_P.armState_Value > USV_P.Switch2_Threshold_b) {
        // Switch: '<S62>/Switch' incorporates:
        //   Constant: '<S62>/Constant'
        //   Inport: '<Root>/inPWMs'

        if (USV_P.ESC2_MotorPara.isEnable) {
          rtb_fcn3 = USV_U.inPWMs[1];
        } else {
          rtb_fcn3 = USV_P.Constant_Value_o;
        }

        // End of Switch: '<S62>/Switch'
        rtb_Switch1_bi = (rtb_fcn3 + USV_P.ESC2_MotorPara.input_offset) *
          USV_P.ESC2_MotorPara.input_scaling +
          USV_P.ESC2_MotorPara.zero_position_armed;
      } else {
        rtb_Switch1_bi = USV_P.ESC2_MotorPara.zero_position_disarmed;
      }

      // End of Switch: '<S62>/Switch2'
    } else {
      rtb_Switch1_bi = USV_P.Constant1_Value_f;
    }

    // End of Switch: '<S62>/Switch1'

    // Switch: '<S63>/Switch1' incorporates:
    //   Constant: '<S63>/Constant1'
    //   Constant: '<S63>/isEnable'

    if (USV_P.ESC3_MotorPara.isEnable) {
      // Switch: '<S63>/Switch2' incorporates:
      //   Constant: '<Root>/armState'
      //   Constant: '<S63>/input_offset'
      //   Constant: '<S63>/input_scaling'
      //   Constant: '<S63>/zero_position_armed'
      //   Constant: '<S63>/zero_position_disarmed'
      //   Product: '<S63>/Product'
      //   Sum: '<S63>/Add'
      //   Sum: '<S63>/Add1'

      if (USV_P.armState_Value > USV_P.Switch2_Threshold_g) {
        // Switch: '<S63>/Switch' incorporates:
        //   Constant: '<S63>/Constant'
        //   Inport: '<Root>/inPWMs'

        if (USV_P.ESC3_MotorPara.isEnable) {
          rtb_fcn3 = USV_U.inPWMs[2];
        } else {
          rtb_fcn3 = USV_P.Constant_Value_d;
        }

        // End of Switch: '<S63>/Switch'
        rtb_Switch1_i = (rtb_fcn3 + USV_P.ESC3_MotorPara.input_offset) *
          USV_P.ESC3_MotorPara.input_scaling +
          USV_P.ESC3_MotorPara.zero_position_armed;
      } else {
        rtb_Switch1_i = USV_P.ESC3_MotorPara.zero_position_disarmed;
      }

      // End of Switch: '<S63>/Switch2'
    } else {
      rtb_Switch1_i = USV_P.Constant1_Value_k;
    }

    // End of Switch: '<S63>/Switch1'

    // Switch: '<S64>/Switch1' incorporates:
    //   Constant: '<S64>/Constant1'
    //   Constant: '<S64>/isEnable'

    if (USV_P.ESC4_MotorPara.isEnable) {
      // Switch: '<S64>/Switch2' incorporates:
      //   Constant: '<Root>/armState'
      //   Constant: '<S64>/input_offset'
      //   Constant: '<S64>/input_scaling'
      //   Constant: '<S64>/zero_position_armed'
      //   Constant: '<S64>/zero_position_disarmed'
      //   Product: '<S64>/Product'
      //   Sum: '<S64>/Add'
      //   Sum: '<S64>/Add1'

      if (USV_P.armState_Value > USV_P.Switch2_Threshold_l) {
        // Switch: '<S64>/Switch' incorporates:
        //   Constant: '<S64>/Constant'
        //   Inport: '<Root>/inPWMs'

        if (USV_P.ESC4_MotorPara.isEnable) {
          rtb_fcn3 = USV_U.inPWMs[3];
        } else {
          rtb_fcn3 = USV_P.Constant_Value_jh;
        }

        // End of Switch: '<S64>/Switch'
        rtb_Switch1_m2 = (rtb_fcn3 + USV_P.ESC4_MotorPara.input_offset) *
          USV_P.ESC4_MotorPara.input_scaling +
          USV_P.ESC4_MotorPara.zero_position_armed;
      } else {
        rtb_Switch1_m2 = USV_P.ESC4_MotorPara.zero_position_disarmed;
      }

      // End of Switch: '<S64>/Switch2'
    } else {
      rtb_Switch1_m2 = USV_P.Constant1_Value_k1;
    }

    // End of Switch: '<S64>/Switch1'

    // Switch: '<S65>/Switch1' incorporates:
    //   Constant: '<S65>/Constant1'
    //   Constant: '<S65>/isEnable'

    if (USV_P.ESC5_MotorPara.isEnable) {
      // Switch: '<S65>/Switch2' incorporates:
      //   Constant: '<Root>/armState'
      //   Constant: '<S65>/input_offset'
      //   Constant: '<S65>/input_scaling'
      //   Constant: '<S65>/zero_position_armed'
      //   Constant: '<S65>/zero_position_disarmed'
      //   Product: '<S65>/Product'
      //   Sum: '<S65>/Add'
      //   Sum: '<S65>/Add1'

      if (USV_P.armState_Value > USV_P.Switch2_Threshold_o) {
        // Switch: '<S65>/Switch' incorporates:
        //   Constant: '<S65>/Constant'
        //   Inport: '<Root>/inPWMs'

        if (USV_P.ESC5_MotorPara.isEnable) {
          rtb_fcn3 = USV_U.inPWMs[4];
        } else {
          rtb_fcn3 = USV_P.Constant_Value_h;
        }

        // End of Switch: '<S65>/Switch'
        rtb_Switch1_h = (rtb_fcn3 + USV_P.ESC5_MotorPara.input_offset) *
          USV_P.ESC5_MotorPara.input_scaling +
          USV_P.ESC5_MotorPara.zero_position_armed;
      } else {
        rtb_Switch1_h = USV_P.ESC5_MotorPara.zero_position_disarmed;
      }

      // End of Switch: '<S65>/Switch2'
    } else {
      rtb_Switch1_h = USV_P.Constant1_Value_n;
    }

    // End of Switch: '<S65>/Switch1'

    // Switch: '<S67>/Switch1' incorporates:
    //   Constant: '<S67>/Constant1'
    //   Constant: '<S67>/isEnable'

    if (USV_P.ESC7_MotorPara.isEnable) {
      // Switch: '<S67>/Switch2' incorporates:
      //   Constant: '<Root>/armState'
      //   Constant: '<S67>/input_offset'
      //   Constant: '<S67>/input_scaling'
      //   Constant: '<S67>/zero_position_armed'
      //   Constant: '<S67>/zero_position_disarmed'
      //   Product: '<S67>/Product'
      //   Sum: '<S67>/Add'
      //   Sum: '<S67>/Add1'

      if (USV_P.armState_Value > USV_P.Switch2_Threshold_fn) {
        // Switch: '<S67>/Switch' incorporates:
        //   Constant: '<S67>/Constant'
        //   Inport: '<Root>/inPWMs'

        if (USV_P.ESC7_MotorPara.isEnable) {
          rtb_fcn3 = USV_U.inPWMs[5];
        } else {
          rtb_fcn3 = USV_P.Constant_Value_p;
        }

        // End of Switch: '<S67>/Switch'
        j = (rtb_fcn3 + USV_P.ESC7_MotorPara.input_offset) *
          USV_P.ESC7_MotorPara.input_scaling +
          USV_P.ESC7_MotorPara.zero_position_armed;
      } else {
        j = USV_P.ESC7_MotorPara.zero_position_disarmed;
      }

      // End of Switch: '<S67>/Switch2'
    } else {
      j = USV_P.Constant1_Value_e;
    }

    // End of Switch: '<S67>/Switch1'

    // Switch: '<S66>/Switch1' incorporates:
    //   Constant: '<S66>/Constant1'
    //   Constant: '<S66>/isEnable'

    if (USV_P.ESC6_MotorPara.isEnable) {
      // Switch: '<S66>/Switch2' incorporates:
      //   Constant: '<Root>/armState'
      //   Constant: '<S66>/input_offset'
      //   Constant: '<S66>/input_scaling'
      //   Constant: '<S66>/zero_position_armed'
      //   Constant: '<S66>/zero_position_disarmed'
      //   Product: '<S66>/Product'
      //   Sum: '<S66>/Add'
      //   Sum: '<S66>/Add1'

      if (USV_P.armState_Value > USV_P.Switch2_Threshold_f) {
        // Switch: '<S66>/Switch' incorporates:
        //   Constant: '<S66>/Constant'
        //   Inport: '<Root>/inPWMs'

        if (USV_P.ESC6_MotorPara.isEnable) {
          rtb_fcn3 = USV_U.inPWMs[6];
        } else {
          rtb_fcn3 = USV_P.Constant_Value_n;
        }

        // End of Switch: '<S66>/Switch'
        rtb_Switch1_a = (rtb_fcn3 + USV_P.ESC6_MotorPara.input_offset) *
          USV_P.ESC6_MotorPara.input_scaling +
          USV_P.ESC6_MotorPara.zero_position_armed;
      } else {
        rtb_Switch1_a = USV_P.ESC6_MotorPara.zero_position_disarmed;
      }

      // End of Switch: '<S66>/Switch2'
    } else {
      rtb_Switch1_a = USV_P.Constant1_Value_g;
    }

    // End of Switch: '<S66>/Switch1'

    // Switch: '<S68>/Switch1' incorporates:
    //   Constant: '<S68>/Constant1'
    //   Constant: '<S68>/isEnable'

    if (USV_P.ESC8_MotorPara.isEnable) {
      // Switch: '<S68>/Switch2' incorporates:
      //   Constant: '<Root>/armState'
      //   Constant: '<S68>/input_offset'
      //   Constant: '<S68>/input_scaling'
      //   Constant: '<S68>/zero_position_armed'
      //   Constant: '<S68>/zero_position_disarmed'
      //   Product: '<S68>/Product'
      //   Sum: '<S68>/Add'
      //   Sum: '<S68>/Add1'

      if (USV_P.armState_Value > USV_P.Switch2_Threshold_b0) {
        // Switch: '<S68>/Switch' incorporates:
        //   Constant: '<S68>/Constant'
        //   Inport: '<Root>/inPWMs'

        if (USV_P.ESC8_MotorPara.isEnable) {
          rtb_fcn3 = USV_U.inPWMs[7];
        } else {
          rtb_fcn3 = USV_P.Constant_Value_ff;
        }

        // End of Switch: '<S68>/Switch'
        rtb_Switch1_k = (rtb_fcn3 + USV_P.ESC8_MotorPara.input_offset) *
          USV_P.ESC8_MotorPara.input_scaling +
          USV_P.ESC8_MotorPara.zero_position_armed;
      } else {
        rtb_Switch1_k = USV_P.ESC8_MotorPara.zero_position_disarmed;
      }

      // End of Switch: '<S68>/Switch2'
    } else {
      rtb_Switch1_k = USV_P.Constant1_Value_ev;
    }

    // End of Switch: '<S68>/Switch1'
  }

  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[5] == 0) {
    // Gain: '<S50>/Gain' incorporates:
    //   Gain: '<S53>/Output'
    //   RandomNumber: '<S53>/White Noise'

    USV_B.Gain = std::sqrt(USV_P.BandLimitedWhiteNoise_Cov) /
      0.31622776601683794 * USV_DW.NextOutput *
      USV_P.FaultParamAPI.FaultInParams[0];
  }

  // RelationalOperator: '<S54>/Gust Start' incorporates:
  //   Constant: '<S54>/Gust start time'

  rtb_sincos_o1_idx_0 = (rtb_Clock1_tmp >= USV_P.FaultParamAPI.FaultInParams[2]);
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // Outputs for Enabled SubSystem: '<S54>/Distance into gust (x)' incorporates:
    //   EnablePort: '<S57>/Enable'

    if (rtsiIsModeUpdateTimeStep(&(&USV_M)->solverInfo)) {
      // Logic: '<S54>/Logical Operator2' incorporates:
      //   Constant: '<S54>/Constant'

      if ((rtb_sincos_o1_idx_0 != 0.0) && USV_P.DiscreteWindGustModel_Gx) {
        if (!USV_DW.Distanceintogustx_MODE) {
          // InitializeConditions for Integrator: '<S57>/Distance into Gust (x) (Limited to gust length d)' 
          USV_X.DistanceintoGustxLimitedtogus_o =
            USV_P.DistanceintoGustxLimitedtogustl;
          USV_DW.Distanceintogustx_MODE = true;
        }
      } else {
        USV_DW.Distanceintogustx_MODE = false;
      }

      // End of Logic: '<S54>/Logical Operator2'
    }

    // End of Outputs for SubSystem: '<S54>/Distance into gust (x)'

    // SignalConversion generated from: '<S58>/Enable' incorporates:
    //   Constant: '<S54>/Constant1'
    //   Logic: '<S54>/Logical Operator1'

    USV_B.HiddenBuf_InsertedFor_Distanc_a = ((rtb_sincos_o1_idx_0 != 0.0) &&
      USV_P.DiscreteWindGustModel_Gy);
  }

  // Outputs for Enabled SubSystem: '<S54>/Distance into gust (x)' incorporates:
  //   EnablePort: '<S57>/Enable'

  if (USV_DW.Distanceintogustx_MODE) {
    // Outputs for Enabled SubSystem: '<S54>/Distance into gust (x)'
    // Integrator: '<S57>/Distance into Gust (x) (Limited to gust length d)'
    // Limited  Integrator
    if (USV_X.DistanceintoGustxLimitedtogus_o >= USV_P.Distanceintogustx_d_m) {
      USV_X.DistanceintoGustxLimitedtogus_o = USV_P.Distanceintogustx_d_m;
    } else if (USV_X.DistanceintoGustxLimitedtogus_o <=
               USV_P.DistanceintoGustxLimitedtogus_h) {
      USV_X.DistanceintoGustxLimitedtogus_o =
        USV_P.DistanceintoGustxLimitedtogus_h;
    }

    // End of Outputs for SubSystem: '<S54>/Distance into gust (x)'

    // Integrator: '<S57>/Distance into Gust (x) (Limited to gust length d)'
    USV_B.DistanceintoGustxLimitedtogustl =
      USV_X.DistanceintoGustxLimitedtogus_o;
  }

  // End of Outputs for SubSystem: '<S54>/Distance into gust (x)'

  // Outputs for Enabled SubSystem: '<S54>/Distance into gust (y)'
  // Outputs for Enabled SubSystem: '<S54>/Distance into gust (y)'
  USV_Distanceintogusty(USV_B.HiddenBuf_InsertedFor_Distanc_a,
                        USV_P.Distanceintogusty_d_m, &USV_B.Distanceintogusty,
                        &USV_DW.Distanceintogusty, &USV_P.Distanceintogusty,
                        &USV_X.Distanceintogusty);

  // End of Outputs for SubSystem: '<S54>/Distance into gust (y)'
  // End of Outputs for SubSystem: '<S54>/Distance into gust (y)'
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // SignalConversion generated from: '<S59>/Enable' incorporates:
    //   Constant: '<S54>/Constant2'
    //   Logic: '<S54>/Logical Operator3'

    USV_B.HiddenBuf_InsertedFor_Distanc_f = ((rtb_sincos_o1_idx_0 != 0.0) &&
      USV_P.DiscreteWindGustModel_Gz);
  }

  // Outputs for Enabled SubSystem: '<S54>/Distance into gust (z)'
  // Outputs for Enabled SubSystem: '<S54>/Distance into gust (z)'
  USV_Distanceintogusty(USV_B.HiddenBuf_InsertedFor_Distanc_f,
                        USV_P.Distanceintogustz_d_m, &USV_B.Distanceintogustz,
                        &USV_DW.Distanceintogustz, &USV_P.Distanceintogustz,
                        &USV_X.Distanceintogustz);

  // End of Outputs for SubSystem: '<S54>/Distance into gust (z)'
  // End of Outputs for SubSystem: '<S54>/Distance into gust (z)'

  // Gain: '<S50>/Gain1' incorporates:
  //   Constant: '<S54>/2'
  //   Gain: '<S54>/Gust magnitude//2.0'
  //   Gain: '<S54>/pi//Gust length'
  //   Sum: '<S50>/Sum'
  //   Sum: '<S54>/Sum1'
  //   Trigonometry: '<S54>/cos(pi*x//dm)'

  rtb_sincos_o1_idx_0 = ((USV_P.u_Value - std::cos(3.1415926535897931 /
    USV_P.DiscreteWindGustModel_d_m[0] * USV_B.DistanceintoGustxLimitedtogustl))
    * (USV_P.DiscreteWindGustModel_v_m[0] / 2.0) + USV_B.Gain) *
    USV_P.Gain1_Gain_k;
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // SignalConversion generated from: '<S56>/ SFunction ' incorporates:
    //   MATLAB Function: '<S50>/MotorFaultModel'

    rtb_Gain_nr[0] = rtb_Switch1;
    rtb_Gain_nr[1] = rtb_Switch1_bi;
    rtb_Gain_nr[2] = rtb_Switch1_i;
    rtb_Gain_nr[3] = rtb_Switch1_m2;
    rtb_Gain_nr[4] = rtb_Switch1_h;
    rtb_Gain_nr[5] = j;
    rtb_Gain_nr[6] = rtb_Switch1_a;
    rtb_Gain_nr[7] = rtb_Switch1_k;

    // MATLAB Function: '<S50>/MotorFaultModel' incorporates:
    //   Constant: '<S50>/MotorNum'

    pitch_sign = USV_P.ESCFault.ESCNum;

    //  ��ģ����Ҫ�õ�8άFaultParam������
    // ��˹���ID�ĸ�ʽӦ���ǣ�
    // inSILInts=[FaultID FaultID FaultID FaultID ...]
    // inSILInts=[param1 param2 param3 param4 param5 param6 param7 param8 ...] -> FaultParam 
    //  param��ÿһλ��ʾ������Ľ���ϵ����0��1����ʵ���Ͼ���pwm_out = pwm_in * param 
    //  ���param1=0������1ֱ�ӻ�����ʼ�����0
    // MATLAB Function 'ESC Fault/MotorFaultModel': '<S56>:1'
    // '<S56>:1:9' y=inPWMs;
    std::memcpy(&USV_B.y_k[0], &rtb_Gain_nr[0], sizeof(real_T) << 3U);

    // Ĭ������²�ע����ϣ�ֱ�ӽ��������
    // '<S56>:1:11' if motNum<1
    if (USV_P.ESCFault.ESCNum < 1) {
      // '<S56>:1:12' motNum=int32(1);
      pitch_sign = 1;
    }

    // '<S56>:1:15' if motNum>8
    if (pitch_sign > 8) {
      // '<S56>:1:16' motNum=int32(8);
      pitch_sign = 8;
    }

    // '<S56>:1:19' if hasFault
    if (rtb_Compare_o) {
      // ���ע���˹���
      // '<S56>:1:20' for i=1:motNum
      for (int32_T s469_iter = 0; s469_iter < pitch_sign; s469_iter++) {
        // '<S56>:1:21' y(i) = inPWMs(i) * FaultParams(i)+ noise;
        USV_B.y_k[s469_iter] = rtb_Gain_nr[s469_iter] * fParamTmp[s469_iter] +
          rtb_sincos_o1_idx_0;
      }
    }

    // Switch: '<S198>/Switch' incorporates:
    //   Constant: '<S198>/Constant'
    //   Constant: '<S198>/isEnable'

    if (USV_P.Motor1_MotorPara.isEnable) {
      rtb_Product_gy = USV_B.y_k[0];
    } else {
      rtb_Product_gy = USV_P.Constant_Value_m;
    }

    // End of Switch: '<S198>/Switch'

    // MinMax: '<S198>/MinMax' incorporates:
    //   Constant: '<S198>/maxRotVelocity'

    if ((!(rtb_Product_gy <= USV_P.Motor1_MotorPara.maxRotVelocity)) &&
        (!rtIsNaN(USV_P.Motor1_MotorPara.maxRotVelocity))) {
      rtb_Product_gy = USV_P.Motor1_MotorPara.maxRotVelocity;
    }

    // End of MinMax: '<S198>/MinMax'

    // MATLAB Function: '<S198>/MATLAB Function1' incorporates:
    //   Clock: '<S198>/Clock'
    //   Constant: '<S198>/timeConstantDown'
    //   Constant: '<S198>/timeConstantUp'

    USV_MATLABFunction1(USV_P.Motor1_MotorPara.timeConstantUp,
                        USV_P.Motor1_MotorPara.timeConstantDown, rtb_Product_gy,
                        (&USV_M)->Timing.t[0], &USV_B.sf_MATLABFunction1_f,
                        &USV_DW.sf_MATLABFunction1_f);

    // Product: '<S198>/Divide' incorporates:
    //   Constant: '<S198>/rotorVelocitySlowdownSim1'
    //   Constant: '<S198>/turningDirection'

    USV_B.Divide = USV_B.sf_MATLABFunction1_f.outputState *
      USV_P.Motor1_MotorPara.turningDirection /
      USV_P.Motor1_MotorPara.rotorVelocitySlowdownSim;

    // MATLAB Function: '<S73>/FaultParamsExtract' incorporates:
    //   Constant: '<S73>/FaultID'
    //   Inport: '<Root>/inSILInts'

    // MATLAB Function 'WindFault/FaultParamsExtract': '<S102>:1'
    // '<S102>:1:5' if isempty(hFault)
    // '<S102>:1:8' if isempty(fParam)
    // '<S102>:1:12' hFaultTmp=false;
    rtb_Compare_o = false;

    // '<S102>:1:13' fParamTmp=zeros(20,1);
    std::memset(&fParamTmp[0], 0, 20U * sizeof(real_T));

    // '<S102>:1:14' j=1;
    j = 1.0;

    // '<S102>:1:15' for i=1:8
    for (roll_sign = 0; roll_sign < 8; roll_sign++) {
      // '<S102>:1:16' if inInts(i) == FaultID
      if (USV_U.inSILInts[roll_sign] == USV_P.FaultID_Value_a) {
        // '<S102>:1:17' hFaultTmp=true;
        rtb_Compare_o = true;

        // '<S102>:1:18' fParamTmp(2*j-1)=inFloats(2*i-1);
        fParamTmp[static_cast<int32_T>(2.0 * j - 1.0) - 1] = inSILFloats
          [((roll_sign + 1) << 1) - 2];

        // '<S102>:1:19' fParamTmp(2*j)=inFloats(2*i);
        fParamTmp[static_cast<int32_T>(2.0 * j) - 1] = inSILFloats[((roll_sign +
          1) << 1) - 1];

        // '<S102>:1:20' j=j+1;
        j++;
      }
    }

    // '<S102>:1:23' if hFaultTmp
    if (rtb_Compare_o) {
      // '<S102>:1:24' hFault=hFaultTmp;
      USV_DW.hFault_n = true;

      // '<S102>:1:25' fParamTmp(17:20) = inFloats(17:20);
      fParamTmp[16] = inSILFloats[16];
      fParamTmp[17] = inSILFloats[17];
      fParamTmp[18] = inSILFloats[18];
      fParamTmp[19] = inSILFloats[19];

      // '<S102>:1:26' fParam=fParamTmp;
      std::memcpy(&USV_DW.fParam_a[0], &fParamTmp[0], 20U * sizeof(real_T));
    }

    // '<S102>:1:29' hasFault_ConstWind=hFault;
    USV_B.hasFault_ConstWind = USV_DW.hFault_n;

    // MATLAB Function: '<S73>/FaultParamsExtract1'
    // '<S102>:1:30' FaultParam=fParam;
    // MATLAB Function 'WindFault/FaultParamsExtract1': '<S103>:1'
    // '<S103>:1:5' if isempty(hFault)
    // '<S103>:1:8' if isempty(fParam)
    // '<S103>:1:12' hFaultTmp=false;
    rtb_Compare_o = false;

    // '<S103>:1:13' fParamTmp=zeros(20,1);
    for (i = 0; i < 20; i++) {
      // MATLAB Function: '<S73>/FaultParamsExtract'
      USV_B.FaultParam_l[i] = USV_DW.fParam_a[i];

      // MATLAB Function: '<S73>/FaultParamsExtract1'
      fParamTmp[i] = 0.0;
    }

    // MATLAB Function: '<S73>/FaultParamsExtract1' incorporates:
    //   Constant: '<S73>/FaultID1'
    //   Inport: '<Root>/inSILInts'

    // '<S103>:1:14' j=1;
    j = 1.0;

    // '<S103>:1:15' for i=1:8
    for (roll_sign = 0; roll_sign < 8; roll_sign++) {
      // '<S103>:1:16' if inInts(i) == FaultID
      if (USV_U.inSILInts[roll_sign] == USV_P.FaultID1_Value) {
        // '<S103>:1:17' hFaultTmp=true;
        rtb_Compare_o = true;

        // '<S103>:1:18' fParamTmp(2*j-1)=inFloats(2*i-1);
        fParamTmp[static_cast<int32_T>(2.0 * j - 1.0) - 1] = inSILFloats
          [((roll_sign + 1) << 1) - 2];

        // '<S103>:1:19' fParamTmp(2*j)=inFloats(2*i);
        fParamTmp[static_cast<int32_T>(2.0 * j) - 1] = inSILFloats[((roll_sign +
          1) << 1) - 1];

        // '<S103>:1:20' j=j+1;
        j++;
      }
    }

    // '<S103>:1:23' if hFaultTmp
    if (rtb_Compare_o) {
      // '<S103>:1:24' hFault=hFaultTmp;
      USV_DW.hFault_ik = true;

      // '<S103>:1:25' fParamTmp(17:20) = inFloats(17:20);
      fParamTmp[16] = inSILFloats[16];
      fParamTmp[17] = inSILFloats[17];
      fParamTmp[18] = inSILFloats[18];
      fParamTmp[19] = inSILFloats[19];

      // '<S103>:1:26' fParam=fParamTmp;
      std::memcpy(&USV_DW.fParam_j3[0], &fParamTmp[0], 20U * sizeof(real_T));
    }

    // '<S103>:1:29' hasFault_GustWind=hFault;
    USV_B.hasFault_GustWind = USV_DW.hFault_ik;

    // MATLAB Function: '<S73>/FaultParamsExtract2'
    // '<S103>:1:30' FaultParam=fParam;
    // MATLAB Function 'WindFault/FaultParamsExtract2': '<S104>:1'
    // '<S104>:1:5' if isempty(hFault)
    // '<S104>:1:8' if isempty(fParam)
    // '<S104>:1:12' hFaultTmp=false;
    rtb_Compare_o = false;

    // '<S104>:1:13' fParamTmp=zeros(20,1);
    for (i = 0; i < 20; i++) {
      // MATLAB Function: '<S73>/FaultParamsExtract1'
      USV_B.FaultParam_o[i] = USV_DW.fParam_j3[i];

      // MATLAB Function: '<S73>/FaultParamsExtract2'
      fParamTmp[i] = 0.0;
    }

    // MATLAB Function: '<S73>/FaultParamsExtract2' incorporates:
    //   Constant: '<S73>/FaultID2'
    //   Inport: '<Root>/inSILInts'

    // '<S104>:1:14' j=1;
    j = 1.0;

    // '<S104>:1:15' for i=1:8
    for (roll_sign = 0; roll_sign < 8; roll_sign++) {
      // '<S104>:1:16' if inInts(i) == FaultID
      if (USV_U.inSILInts[roll_sign] == USV_P.FaultID2_Value) {
        // '<S104>:1:17' hFaultTmp=true;
        rtb_Compare_o = true;

        // '<S104>:1:18' fParamTmp(2*j-1)=inFloats(2*i-1);
        fParamTmp[static_cast<int32_T>(2.0 * j - 1.0) - 1] = inSILFloats
          [((roll_sign + 1) << 1) - 2];

        // '<S104>:1:19' fParamTmp(2*j)=inFloats(2*i);
        fParamTmp[static_cast<int32_T>(2.0 * j) - 1] = inSILFloats[((roll_sign +
          1) << 1) - 1];

        // '<S104>:1:20' j=j+1;
        j++;
      }
    }

    // '<S104>:1:23' if hFaultTmp
    if (rtb_Compare_o) {
      // '<S104>:1:24' hFault=hFaultTmp;
      USV_DW.hFault_p = true;

      // '<S104>:1:25' fParamTmp(17:20) = inFloats(17:20);
      fParamTmp[16] = inSILFloats[16];
      fParamTmp[17] = inSILFloats[17];
      fParamTmp[18] = inSILFloats[18];
      fParamTmp[19] = inSILFloats[19];

      // '<S104>:1:26' fParam=fParamTmp;
      std::memcpy(&USV_DW.fParam_fl[0], &fParamTmp[0], 20U * sizeof(real_T));
    }

    // '<S104>:1:29' hasFault_TurbWind=hFault;
    USV_B.hasFault_TurbWind = USV_DW.hFault_p;

    // MATLAB Function: '<S73>/FaultParamsExtract3'
    // '<S104>:1:30' FaultParam=fParam;
    // MATLAB Function 'WindFault/FaultParamsExtract3': '<S105>:1'
    // '<S105>:1:5' if isempty(hFault)
    // '<S105>:1:8' if isempty(fParam)
    // '<S105>:1:12' hFaultTmp=false;
    rtb_Compare_o = false;

    // '<S105>:1:13' fParamTmp=zeros(20,1);
    for (i = 0; i < 20; i++) {
      // MATLAB Function: '<S73>/FaultParamsExtract2'
      USV_B.FaultParam_h[i] = USV_DW.fParam_fl[i];

      // MATLAB Function: '<S73>/FaultParamsExtract3'
      fParamTmp[i] = 0.0;
    }

    // MATLAB Function: '<S73>/FaultParamsExtract3' incorporates:
    //   Constant: '<S73>/FaultID3'
    //   Inport: '<Root>/inSILInts'

    // '<S105>:1:14' j=1;
    j = 1.0;

    // '<S105>:1:15' for i=1:8
    for (roll_sign = 0; roll_sign < 8; roll_sign++) {
      // '<S105>:1:16' if inInts(i) == FaultID
      if (USV_U.inSILInts[roll_sign] == USV_P.FaultID3_Value) {
        // '<S105>:1:17' hFaultTmp=true;
        rtb_Compare_o = true;

        // '<S105>:1:18' fParamTmp(2*j-1)=inFloats(2*i-1);
        i = (roll_sign + 1) << 1;
        fParamTmp[static_cast<int32_T>(2.0 * j - 1.0) - 1] = inSILFloats[i - 2];

        // '<S105>:1:19' fParamTmp(2*j)=inFloats(2*i);
        fParamTmp[static_cast<int32_T>(2.0 * j) - 1] = inSILFloats[i - 1];

        // '<S105>:1:20' j=j+1;
        j++;
      }
    }

    // '<S105>:1:23' if hFaultTmp
    if (rtb_Compare_o) {
      // '<S105>:1:24' hFault=hFaultTmp;
      USV_DW.hFault_i = true;

      // '<S105>:1:25' fParamTmp(17:20) = inFloats(17:20);
      fParamTmp[16] = inSILFloats[16];
      fParamTmp[17] = inSILFloats[17];
      fParamTmp[18] = inSILFloats[18];
      fParamTmp[19] = inSILFloats[19];

      // '<S105>:1:26' fParam=fParamTmp;
      std::memcpy(&USV_DW.fParam_h[0], &fParamTmp[0], 20U * sizeof(real_T));
    }

    // '<S105>:1:29' hasFault_SheerWind=hFault;
    USV_B.hasFault_SheerWind = USV_DW.hFault_i;

    // '<S105>:1:30' FaultParam=fParam;
    std::memcpy(&USV_B.FaultParam[0], &USV_DW.fParam_h[0], 20U * sizeof(real_T));
  }

  // Product: '<S198>/Product3' incorporates:
  //   Constant: '<S198>/Constant3'
  //   Integrator: '<S9>/p,q,r '

  rtb_MatrixMultiply2[0] = USV_X.pqr_CSTATE[0] * USV_P.Constant3_Value_c[0];
  rtb_MatrixMultiply2[1] = USV_X.pqr_CSTATE[1] * USV_P.Constant3_Value_c[1];
  rtb_MatrixMultiply2[2] = USV_X.pqr_CSTATE[2] * USV_P.Constant3_Value_c[2];

  // Product: '<S206>/Element product' incorporates:
  //   Constant: '<S198>/pose: 1 * 6'

  rtb_Add_l[0] = rtb_MatrixMultiply2[1] * USV_P.Motor1_MotorPara.pose[2];
  rtb_Add_l[1] = USV_P.Motor1_MotorPara.pose[0] * rtb_MatrixMultiply2[2];
  rtb_Add_l[2] = rtb_MatrixMultiply2[0] * USV_P.Motor1_MotorPara.pose[1];
  rtb_Add_l[3] = USV_P.Motor1_MotorPara.pose[1] * rtb_MatrixMultiply2[2];
  rtb_Add_l[4] = rtb_MatrixMultiply2[0] * USV_P.Motor1_MotorPara.pose[2];
  rtb_Add_l[5] = USV_P.Motor1_MotorPara.pose[0] * rtb_MatrixMultiply2[1];

  // Gain: '<S73>/Gain_-1' incorporates:
  //   Integrator: '<S9>/xe,ye,ze'

  rtb_sincos_o1_idx_0 = USV_P.Gain_1_Gain * USV_X.xeyeze_CSTATE[2];

  // Saturate: '<S73>/Saturation_2'
  if (rtb_sincos_o1_idx_0 > USV_P.Saturation_2_UpperSat) {
    rtb_sincos_o1_idx_0 = USV_P.Saturation_2_UpperSat;
  } else if (rtb_sincos_o1_idx_0 < USV_P.Saturation_2_LowerSat) {
    rtb_sincos_o1_idx_0 = USV_P.Saturation_2_LowerSat;
  }

  // End of Saturate: '<S73>/Saturation_2'

  // UnitConversion: '<S153>/Unit Conversion' incorporates:
  //   UnitConversion: '<S114>/Unit Conversion'
  //   UnitConversion: '<S190>/Unit Conversion'

  // Unit Conversion - from: m to: ft
  // Expression: output = (3.28084*input) + (0)
  rtb_Switch1 = 3.280839895013123 * rtb_sincos_o1_idx_0;
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // UnitConversion: '<S159>/Unit Conversion' incorporates:
    //   Constant: '<S73>/Constant_V'

    // Unit Conversion - from: m/s to: ft/s
    // Expression: output = (3.28084*input) + (0)
    USV_B.UnitConversion = 3.280839895013123 * USV_P.Constant_V_Value;
  }

  // Saturate: '<S186>/Limit Function 10ft to 1000ft' incorporates:
  //   UnitConversion: '<S153>/Unit Conversion'

  if (rtb_Switch1 > USV_P.LimitFunction10ftto1000ft_Upper) {
    rtb_Switch1_h = USV_P.LimitFunction10ftto1000ft_Upper;
  } else if (rtb_Switch1 < USV_P.LimitFunction10ftto1000ft_Lower) {
    rtb_Switch1_h = USV_P.LimitFunction10ftto1000ft_Lower;
  } else {
    rtb_Switch1_h = rtb_Switch1;
  }

  // End of Saturate: '<S186>/Limit Function 10ft to 1000ft'

  // Fcn: '<S186>/Low Altitude Scale Length'
  rtb_Switch1_m2 = 0.000823 * rtb_Switch1_h + 0.177;
  if (rtb_Switch1_m2 < 0.0) {
    rtb_Switch1_m2 = -rt_powd_snf(-rtb_Switch1_m2, 1.2);
  } else {
    rtb_Switch1_m2 = rt_powd_snf(rtb_Switch1_m2, 1.2);
  }

  // Fcn: '<S186>/Low Altitude Scale Length'
  rtb_Switch1_i = rtb_Switch1_h / rtb_Switch1_m2;
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // UnitConversion: '<S188>/Unit Conversion' incorporates:
    //   Constant: '<S187>/Medium//High Altitude'

    // Unit Conversion - from: m to: ft
    // Expression: output = (3.28084*input) + (0)
    USV_B.UnitConversion_m = 3.280839895013123 *
      USV_P.DrydenWindTurbulenceModelDiscre;
  }

  // Saturate: '<S169>/Limit Height h<1000ft' incorporates:
  //   UnitConversion: '<S153>/Unit Conversion'

  if (rtb_Switch1 > USV_P.LimitHeighth1000ft_UpperSat) {
    rtb_Sum1_dx = USV_P.LimitHeighth1000ft_UpperSat;
  } else if (rtb_Switch1 < USV_P.LimitHeighth1000ft_LowerSat) {
    rtb_Sum1_dx = USV_P.LimitHeighth1000ft_LowerSat;
  } else {
    rtb_Sum1_dx = rtb_Switch1;
  }

  // End of Saturate: '<S169>/Limit Height h<1000ft'

  // Fcn: '<S169>/Low Altitude Intensity'
  rtb_Switch1_m2 = 0.000823 * rtb_Sum1_dx + 0.177;
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // Gain: '<S169>/sigma_wg ' incorporates:
    //   Constant: '<S101>/Windspeed at 20ft (6m)'
    //   UnitConversion: '<S160>/Unit Conversion'

    // Unit Conversion - from: m/s to: ft/s
    // Expression: output = (3.28084*input) + (0)
    USV_B.sigma_wg = 3.280839895013123 * USV_P.FaultParamAPI.FaultInParams[7] *
      USV_P.sigma_wg_Gain;
  }

  // Fcn: '<S169>/Low Altitude Intensity'
  if (rtb_Switch1_m2 < 0.0) {
    rtb_Switch1_m2 = -rt_powd_snf(-rtb_Switch1_m2, 0.4);
  } else {
    rtb_Switch1_m2 = rt_powd_snf(rtb_Switch1_m2, 0.4);
  }

  // Product: '<S169>/sigma_ug, sigma_vg' incorporates:
  //   Fcn: '<S169>/Low Altitude Intensity'

  rtb_Switch1_m2 = 1.0 / rtb_Switch1_m2 * USV_B.sigma_wg;

  // Interpolation_n-D: '<S168>/Medium//High Altitude Intensity' incorporates:
  //   PreLookup: '<S168>/PreLook-Up Index Search  (altitude)'
  //   UnitConversion: '<S153>/Unit Conversion'

  bpIndex[0] = plook_bincpa(rtb_Switch1, USV_P.PreLookUpIndexSearchaltitude_Br,
    11U, &rtb_Sum1_dx, &USV_DW.PreLookUpIndexSearchaltitude_DW);
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // PreLookup: '<S168>/PreLook-Up Index Search  (prob of exceed)' incorporates:
    //   Constant: '<S168>/Probability of  Exceedance'

    USV_B.PreLookUpIndexSearchprobofexc_n = plook_bincpa
      (USV_P.DrydenWindTurbulenceModelDisc_n,
       USV_P.PreLookUpIndexSearchprobofexcee, 6U,
       &USV_B.PreLookUpIndexSearchprobofexcee,
       &USV_DW.PreLookUpIndexSearchprobofexcee);
  }

  // Interpolation_n-D: '<S168>/Medium//High Altitude Intensity'
  frac[0] = rtb_Sum1_dx;
  frac[1] = USV_B.PreLookUpIndexSearchprobofexcee;
  bpIndex[1] = USV_B.PreLookUpIndexSearchprobofexc_n;

  // Interpolation_n-D: '<S168>/Medium//High Altitude Intensity'
  rtb_Switch1_bi = intrp2d_la_pw(bpIndex, frac,
    USV_P.MediumHighAltitudeIntensity_Tab, 12U,
    USV_P.MediumHighAltitudeIntensity_max);
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[3] == 0) {
    // Sqrt: '<S161>/Sqrt1' incorporates:
    //   Constant: '<S161>/Constant1'

    j = std::sqrt(USV_P.WhiteNoise_Ts);

    // Product: '<S161>/Product' incorporates:
    //   Constant: '<S161>/Constant'
    //   Product: '<S161>/Divide'
    //   RandomNumber: '<S161>/White Noise'
    //   Sqrt: '<S161>/Sqrt'

    USV_B.Product[0] = std::sqrt(USV_P.WhiteNoise_pwr[0]) / j *
      USV_DW.NextOutput_g[0];
    USV_B.Product[1] = std::sqrt(USV_P.WhiteNoise_pwr[1]) / j *
      USV_DW.NextOutput_g[1];
    USV_B.Product[2] = std::sqrt(USV_P.WhiteNoise_pwr[2]) / j *
      USV_DW.NextOutput_g[2];
    USV_B.Product[3] = std::sqrt(USV_P.WhiteNoise_pwr[3]) / j *
      USV_DW.NextOutput_g[3];
  }

  // Outputs for Enabled SubSystem: '<S152>/Hugw(z)'
  // Constant: '<S152>/Constant3'
  USV_Hugwz(USV_P.DrydenWindTurbulenceModelDisc_f, USV_B.UnitConversion,
            rtb_Switch1_i, USV_B.UnitConversion_m, rtb_Switch1_m2,
            rtb_Switch1_bi, USV_B.Product[0], &USV_B.Hugwz_e, &USV_DW.Hugwz_e,
            &USV_P.Hugwz_e);

  // End of Outputs for SubSystem: '<S152>/Hugw(z)'

  // Gain: '<S158>/Lv'
  rtb_Sum_f4[0] = USV_P.Lv_Gain * rtb_Switch1_i;
  rtb_Sum_f4[1] = USV_P.Lv_Gain * USV_B.UnitConversion_m;

  // Outputs for Enabled SubSystem: '<S152>/Hvgw(z)'
  // Constant: '<S152>/Constant3'
  USV_Hvgwz(USV_P.DrydenWindTurbulenceModelDisc_f, rtb_Switch1_m2,
            rtb_Switch1_bi, rtb_Sum_f4, USV_B.UnitConversion, USV_B.Product[1],
            &USV_B.Hvgwz_m, &USV_DW.Hvgwz_m, &USV_P.Hvgwz_m);

  // End of Outputs for SubSystem: '<S152>/Hvgw(z)'

  // Gain: '<S158>/Lw'
  rtb_Sum_f4[0] = USV_P.Lw_Gain * rtb_Switch1_h;
  rtb_Sum_f4[1] = USV_P.Lw_Gain * USV_B.UnitConversion_m;

  // Outputs for Enabled SubSystem: '<S152>/Hwgw(z)'
  // Constant: '<S152>/Constant3'
  USV_Hwgwz(USV_P.DrydenWindTurbulenceModelDisc_f, USV_B.UnitConversion,
            rtb_Sum_f4, USV_B.sigma_wg, rtb_Switch1_bi, USV_B.Product[2],
            &USV_B.Hwgwz_h, &USV_DW.Hwgwz_h, &USV_P.Hwgwz_h);

  // End of Outputs for SubSystem: '<S152>/Hwgw(z)'
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // UnitConversion: '<S150>/Unit Conversion' incorporates:
    //   Constant: '<S101>/Wind direction'

    // Unit Conversion - from: deg to: rad
    // Expression: output = (0.0174533*input) + (0)
    USV_B.UnitConversion_p = 0.017453292519943295 *
      USV_P.FaultParamAPI.FaultInParams[8];
  }

  // If: '<S157>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' incorporates:
  //   Constant: '<S73>/Constant_DCM'
  //   UnitConversion: '<S153>/Unit Conversion'

  if (rtsiIsModeUpdateTimeStep(&(&USV_M)->solverInfo)) {
    if (rtb_Switch1 <= 1000.0) {
      rtAction = 0;
    } else if (rtb_Switch1 >= 2000.0) {
      rtAction = 1;
    } else {
      rtAction = 2;
    }

    USV_DW.ifHeightMaxlowaltitudeelseifHei = rtAction;
  } else {
    rtAction = USV_DW.ifHeightMaxlowaltitudeelseifHei;
  }

  switch (rtAction) {
   case 0:
    // Outputs for IfAction SubSystem: '<S157>/Low altitude  velocities' incorporates:
    //   ActionPort: '<S179>/Action Port'

    USV_Lowaltitudevelocities(USV_P.Constant_DCM_Value, USV_B.Hugwz_e.Sum,
      USV_B.Hvgwz_m.Sum, USV_B.Hwgwz_h.Sum, USV_B.UnitConversion_p,
      rtb_DataTypeConversion);

    // End of Outputs for SubSystem: '<S157>/Low altitude  velocities'
    break;

   case 1:
    // Outputs for IfAction SubSystem: '<S157>/Medium//High  altitude velocities' incorporates:
    //   ActionPort: '<S180>/Action Port'

    // DataTypeConversion: '<S5>/Data Type Conversion' incorporates:
    //   Gain: '<S180>/Gain'

    rtb_DataTypeConversion[0] = USV_P.Gain_Gain_d * USV_B.Hugwz_e.Sum[1];
    rtb_DataTypeConversion[1] = USV_P.Gain_Gain_d * USV_B.Hvgwz_m.Sum[1];
    rtb_DataTypeConversion[2] = USV_P.Gain_Gain_d * USV_B.Hwgwz_h.Sum[1];

    // End of Outputs for SubSystem: '<S157>/Medium//High  altitude velocities'
    break;

   case 2:
    // Outputs for IfAction SubSystem: '<S157>/Interpolate  velocities' incorporates:
    //   ActionPort: '<S178>/Action Port'

    USV_Interpolatevelocities(USV_B.Hugwz_e.Sum, USV_B.Hvgwz_m.Sum,
      USV_B.Hwgwz_h.Sum, USV_P.Constant_DCM_Value, USV_B.UnitConversion_p,
      rtb_Switch1, rtb_DataTypeConversion, &USV_P.Interpolatevelocities_k);

    // End of Outputs for SubSystem: '<S157>/Interpolate  velocities'
    break;
  }

  // End of If: '<S157>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 
  // Unit Conversion - from: ft/s to: m/s
  // Expression: output = (0.3048*input) + (0)
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // MATLAB Function: '<S73>/MATLAB Function' incorporates:
    //   UnitConversion: '<S101>/Unit Conversion'

    std::memcpy(&fParamTmp[0], &USV_B.FaultParam_o[0], 20U * sizeof(real_T));

    // MATLAB Function 'WindFault/MATLAB Function': '<S106>:1'
    // '<S106>:1:3' if(GustWindParams(2)<1)
    if (USV_B.FaultParam_o[1] < 1.0) {
      // '<S106>:1:4' GustWindParams(2)=1;
      fParamTmp[1] = 1.0;
    }

    // '<S106>:1:6' timeVel=60/GustWindParams(2);
    rtb_Switch1_i = 60.0 / fParamTmp[1];

    // '<S106>:1:8' vmax=GustWindParams(1);
    rtb_Switch1_m2 = USV_B.FaultParam_o[0];

    // '<S106>:1:11' if isempty(t0)
    // '<S106>:1:16' if isempty(isInGust)
    // '<S106>:1:21' if isempty(t1)
    // '<S106>:1:26' if isempty(a)
    // '<S106>:1:31' if isempty(ang)
    // '<S106>:1:36' if isempty(wlast)
    if (!USV_DW.wlast_not_empty) {
      // '<S106>:1:37' wlast=vmax*0.5;
      USV_DW.wlast = USV_B.FaultParam_o[0] * 0.5;
      USV_DW.wlast_not_empty = true;
    }

    // '<S106>:1:41' if isempty(wNow)
    if (!USV_DW.wNow_not_empty) {
      // '<S106>:1:42' wNow=1.4*0.8*vmax;
      USV_DW.wNow = 1.1199999999999999 * USV_B.FaultParam_o[0];
      USV_DW.wNow_not_empty = true;
    }

    // '<S106>:1:46' if isGustWind&&isInGust<0.5
    if (USV_B.hasFault_GustWind && (USV_DW.isInGust < 0.5)) {
      // '<S106>:1:47' t0=t;
      USV_DW.t0 = rtb_Clock1_tmp;

      // '<S106>:1:48' t1=timeVel*(3/4+1/2*rand(1));
      USV_DW.t1 = (0.5 * USV_rand() + 0.75) * rtb_Switch1_i;

      // '<S106>:1:49' a=1/4+1/2*rand(1);
      USV_DW.a = 0.5 * USV_rand() + 0.25;

      // '<S106>:1:50' ang=pi*2*rand(1);
      USV_DW.ang = 6.2831853071795862 * USV_rand();

      // '<S106>:1:51' wlast=wNow;
      USV_DW.wlast = USV_DW.wNow;

      // '<S106>:1:52' wNow=1.2*(rand(1)*0.5+0.5)*vmax;
      USV_DW.wNow = (USV_rand() * 0.5 + 0.5) * 1.2 * rtb_Switch1_m2;

      // '<S106>:1:54' isInGust=1;
      USV_DW.isInGust = 1.0;
    }

    // '<S106>:1:57' if ~isGustWind
    if (!USV_B.hasFault_GustWind) {
      // '<S106>:1:58' isInGust=0;
      USV_DW.isInGust = 0.0;
    }

    // '<S106>:1:61' gWind=[0;0;0];
    // '<S106>:1:63' if(t<t0+t1*a)
    rtb_fcn3 = USV_DW.t1 * USV_DW.a;
    if (rtb_Clock1_tmp < rtb_fcn3 + USV_DW.t0) {
      // '<S106>:1:64' gWindMag=(wNow-wlast)/2*(1-cos((t-t0)/(t1*a)*pi))+wlast;
      rtb_Switch1_h = (1.0 - std::cos((rtb_Clock1_tmp - USV_DW.t0) / rtb_fcn3 *
        3.1415926535897931)) * ((USV_DW.wNow - USV_DW.wlast) / 2.0) +
        USV_DW.wlast;
    } else {
      // '<S106>:1:65' else
      // '<S106>:1:66' gWindMag=wNow;
      rtb_Switch1_h = USV_DW.wNow;
    }

    // '<S106>:1:69' if abs(t-(t0+t1))<0.05
    if (std::abs(rtb_Clock1_tmp - (USV_DW.t0 + USV_DW.t1)) < 0.05) {
      uint32_T seed;

      // '<S106>:1:70' rng(t*1000);
      rtb_fcn3 = rtb_Clock1_tmp * 1000.0;
      if (rtb_fcn3 < 4.294967296E+9) {
        if (rtb_fcn3 >= 0.0) {
          seed = static_cast<uint32_T>(rtb_fcn3);
        } else {
          seed = 0U;
        }
      } else {
        seed = MAX_uint32_T;
      }

      switch (USV_DW.method) {
       case 7U:
        if (seed == 0U) {
          seed = 5489U;
        }

        USV_DW.state_is[0] = seed;
        for (roll_sign = 0; roll_sign < 623; roll_sign++) {
          seed = ((seed >> 30U ^ seed) * 1812433253U + roll_sign) + 1U;
          USV_DW.state_is[roll_sign + 1] = seed;
        }

        USV_DW.state_is[624] = 624U;
        break;

       case 5U:
        USV_DW.state_i[0] = 362436069U;
        USV_DW.state_i[1] = seed;
        if (USV_DW.state_i[1] == 0U) {
          USV_DW.state_i[1] = 521288629U;
        }
        break;

       default:
        roll_sign = static_cast<int32_T>(seed >> 16U);
        pitch_sign = static_cast<int32_T>(seed & 32768U);
        seed = ((((seed - (static_cast<uint32_T>(roll_sign) << 16U)) -
                  pitch_sign) << 16U) + pitch_sign) + roll_sign;
        if (seed < 1U) {
          seed = 1144108930U;
        } else if (seed > 2147483646U) {
          seed = 2147483646U;
        }

        USV_DW.state = seed;
        break;
      }

      // '<S106>:1:71' t0=t;
      USV_DW.t0 = rtb_Clock1_tmp;

      // '<S106>:1:72' t1=timeVel*(3/4+1/2*rand(1));
      USV_DW.t1 = (0.5 * USV_rand() + 0.75) * rtb_Switch1_i;

      // '<S106>:1:73' a=1/4+1/2*rand(1);
      USV_DW.a = 0.5 * USV_rand() + 0.25;

      // '<S106>:1:74' ang=ang+0.1*pi*rand(1);
      USV_DW.ang += 0.31415926535897931 * USV_rand();

      // '<S106>:1:75' wlast=wNow;
      USV_DW.wlast = USV_DW.wNow;

      // '<S106>:1:76' wNow=1.2*(rand(1)*0.5+0.5)*vmax;
      USV_DW.wNow = (USV_rand() * 0.5 + 0.5) * 1.2 * rtb_Switch1_m2;
    }

    // '<S106>:1:79' gWind(1)=gWindMag*cos(ang)*0.8+turb(1)*0.4;
    USV_B.gWind[0] = rtb_Switch1_h * std::cos(USV_DW.ang) * 0.8 + 0.3048 *
      rtb_DataTypeConversion[0] * 0.4;

    // '<S106>:1:80' gWind(2)=gWindMag*sin(ang)*0.8+turb(2)*0.4;
    USV_B.gWind[1] = rtb_Switch1_h * std::sin(USV_DW.ang) * 0.8 + 0.3048 *
      rtb_DataTypeConversion[1] * 0.4;

    // '<S106>:1:81' gWind(3)=turb(3)*0.4;
    USV_B.gWind[2] = 0.3048 * rtb_DataTypeConversion[2] * 0.4;

    // End of MATLAB Function: '<S73>/MATLAB Function'

    // UnitConversion: '<S120>/Unit Conversion' incorporates:
    //   Constant: '<S73>/Constant_V'

    // Unit Conversion - from: m/s to: ft/s
    // Expression: output = (3.28084*input) + (0)
    USV_B.UnitConversion_n = 3.280839895013123 * USV_P.Constant_V_Value;
  }

  // Saturate: '<S147>/Limit Function 10ft to 1000ft'
  // Unit Conversion - from: m to: ft
  // Expression: output = (3.28084*input) + (0)
  if (rtb_Switch1 > USV_P.LimitFunction10ftto1000ft_Upp_m) {
    rtb_Switch1_h = USV_P.LimitFunction10ftto1000ft_Upp_m;
  } else if (rtb_Switch1 < USV_P.LimitFunction10ftto1000ft_Low_m) {
    rtb_Switch1_h = USV_P.LimitFunction10ftto1000ft_Low_m;
  } else {
    rtb_Switch1_h = rtb_Switch1;
  }

  // End of Saturate: '<S147>/Limit Function 10ft to 1000ft'

  // Fcn: '<S147>/Low Altitude Scale Length'
  rtb_Switch1_m2 = 0.000823 * rtb_Switch1_h + 0.177;
  if (rtb_Switch1_m2 < 0.0) {
    rtb_Switch1_m2 = -rt_powd_snf(-rtb_Switch1_m2, 1.2);
  } else {
    rtb_Switch1_m2 = rt_powd_snf(rtb_Switch1_m2, 1.2);
  }

  // Fcn: '<S147>/Low Altitude Scale Length'
  rtb_Switch1_a = rtb_Switch1_h / rtb_Switch1_m2;
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // UnitConversion: '<S149>/Unit Conversion' incorporates:
    //   Constant: '<S148>/Medium//High Altitude'

    // Unit Conversion - from: m to: ft
    // Expression: output = (3.28084*input) + (0)
    USV_B.UnitConversion_mq = 3.280839895013123 *
      USV_P.DrydenWindTurbulenceModelDisc_i;
  }

  // Saturate: '<S130>/Limit Height h<1000ft'
  if (rtb_Switch1 > USV_P.LimitHeighth1000ft_UpperSat_b) {
    rtb_Sum1_dx = USV_P.LimitHeighth1000ft_UpperSat_b;
  } else if (rtb_Switch1 < USV_P.LimitHeighth1000ft_LowerSat_b) {
    rtb_Sum1_dx = USV_P.LimitHeighth1000ft_LowerSat_b;
  } else {
    rtb_Sum1_dx = rtb_Switch1;
  }

  // End of Saturate: '<S130>/Limit Height h<1000ft'

  // Fcn: '<S130>/Low Altitude Intensity'
  rtb_Switch1_m2 = 0.000823 * rtb_Sum1_dx + 0.177;
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // Gain: '<S130>/sigma_wg ' incorporates:
    //   Constant: '<S100>/Windspeed at 20ft (6m)'
    //   UnitConversion: '<S121>/Unit Conversion'

    // Unit Conversion - from: m/s to: ft/s
    // Expression: output = (3.28084*input) + (0)
    USV_B.sigma_wg_e = 3.280839895013123 * USV_P.FaultParamAPI.FaultInParams[3] *
      USV_P.sigma_wg_Gain_n;
  }

  // Fcn: '<S130>/Low Altitude Intensity'
  if (rtb_Switch1_m2 < 0.0) {
    rtb_Switch1_m2 = -rt_powd_snf(-rtb_Switch1_m2, 0.4);
  } else {
    rtb_Switch1_m2 = rt_powd_snf(rtb_Switch1_m2, 0.4);
  }

  // Product: '<S130>/sigma_ug, sigma_vg' incorporates:
  //   Fcn: '<S130>/Low Altitude Intensity'

  rtb_Switch1_k = 1.0 / rtb_Switch1_m2 * USV_B.sigma_wg_e;

  // Interpolation_n-D: '<S129>/Medium//High Altitude Intensity' incorporates:
  //   PreLookup: '<S129>/PreLook-Up Index Search  (altitude)'

  bpIndex_0[0] = plook_bincpa(rtb_Switch1, USV_P.PreLookUpIndexSearchaltitude__f,
    11U, &rtb_Sum1_dx, &USV_DW.PreLookUpIndexSearchaltitude__e);
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // PreLookup: '<S129>/PreLook-Up Index Search  (prob of exceed)' incorporates:
    //   Constant: '<S129>/Probability of  Exceedance'

    USV_B.PreLookUpIndexSearchprobofexc_c = plook_bincpa
      (USV_P.DrydenWindTurbulenceModelDisc_d,
       USV_P.PreLookUpIndexSearchprobofexc_m, 6U,
       &USV_B.PreLookUpIndexSearchprobofexc_b,
       &USV_DW.PreLookUpIndexSearchprobofexc_l);
  }

  // Interpolation_n-D: '<S129>/Medium//High Altitude Intensity'
  frac_0[0] = rtb_Sum1_dx;
  frac_0[1] = USV_B.PreLookUpIndexSearchprobofexc_b;
  bpIndex_0[1] = USV_B.PreLookUpIndexSearchprobofexc_c;

  // Interpolation_n-D: '<S129>/Medium//High Altitude Intensity'
  rtb_Switch1_m2 = intrp2d_la_pw(bpIndex_0, frac_0,
    USV_P.MediumHighAltitudeIntensity_T_b, 12U,
    USV_P.MediumHighAltitudeIntensity_m_g);
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[3] == 0) {
    // Sqrt: '<S122>/Sqrt1' incorporates:
    //   Constant: '<S122>/Constant1'

    j = std::sqrt(USV_P.WhiteNoise_Ts_b);

    // Product: '<S122>/Product' incorporates:
    //   Constant: '<S122>/Constant'
    //   Product: '<S122>/Divide'
    //   RandomNumber: '<S122>/White Noise'
    //   Sqrt: '<S122>/Sqrt'

    USV_B.Product_j[0] = std::sqrt(USV_P.WhiteNoise_pwr_m[0]) / j *
      USV_DW.NextOutput_l[0];
    USV_B.Product_j[1] = std::sqrt(USV_P.WhiteNoise_pwr_m[1]) / j *
      USV_DW.NextOutput_l[1];
    USV_B.Product_j[2] = std::sqrt(USV_P.WhiteNoise_pwr_m[2]) / j *
      USV_DW.NextOutput_l[2];
    USV_B.Product_j[3] = std::sqrt(USV_P.WhiteNoise_pwr_m[3]) / j *
      USV_DW.NextOutput_l[3];
  }

  // Outputs for Enabled SubSystem: '<S113>/Hugw(z)'
  // Constant: '<S113>/Constant3'
  USV_Hugwz(USV_P.DrydenWindTurbulenceModelDisc_a, USV_B.UnitConversion_n,
            rtb_Switch1_a, USV_B.UnitConversion_mq, rtb_Switch1_k,
            rtb_Switch1_m2, USV_B.Product_j[0], &USV_B.Hugwz, &USV_DW.Hugwz,
            &USV_P.Hugwz);

  // End of Outputs for SubSystem: '<S113>/Hugw(z)'

  // Gain: '<S119>/Lv'
  frac_0[0] = USV_P.Lv_Gain_e * rtb_Switch1_a;
  frac_0[1] = USV_P.Lv_Gain_e * USV_B.UnitConversion_mq;

  // Outputs for Enabled SubSystem: '<S113>/Hvgw(z)'
  // Constant: '<S113>/Constant3'
  USV_Hvgwz(USV_P.DrydenWindTurbulenceModelDisc_a, rtb_Switch1_k, rtb_Switch1_m2,
            frac_0, USV_B.UnitConversion_n, USV_B.Product_j[1], &USV_B.Hvgwz,
            &USV_DW.Hvgwz, &USV_P.Hvgwz);

  // End of Outputs for SubSystem: '<S113>/Hvgw(z)'

  // Gain: '<S119>/Lw'
  frac_0[0] = USV_P.Lw_Gain_a * rtb_Switch1_h;
  frac_0[1] = USV_P.Lw_Gain_a * USV_B.UnitConversion_mq;

  // Outputs for Enabled SubSystem: '<S113>/Hwgw(z)'
  // Constant: '<S113>/Constant3'
  USV_Hwgwz(USV_P.DrydenWindTurbulenceModelDisc_a, USV_B.UnitConversion_n,
            frac_0, USV_B.sigma_wg_e, rtb_Switch1_m2, USV_B.Product_j[2],
            &USV_B.Hwgwz, &USV_DW.Hwgwz, &USV_P.Hwgwz);

  // End of Outputs for SubSystem: '<S113>/Hwgw(z)'
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // UnitConversion: '<S111>/Unit Conversion' incorporates:
    //   Constant: '<S100>/Wind direction'

    // Unit Conversion - from: deg to: rad
    // Expression: output = (0.0174533*input) + (0)
    USV_B.UnitConversion_o = 0.017453292519943295 *
      USV_P.FaultParamAPI.FaultInParams[4];
  }

  // If: '<S118>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' incorporates:
  //   Constant: '<S73>/Constant_DCM'

  if (rtsiIsModeUpdateTimeStep(&(&USV_M)->solverInfo)) {
    if (rtb_Switch1 <= 1000.0) {
      rtAction = 0;
    } else if (rtb_Switch1 >= 2000.0) {
      rtAction = 1;
    } else {
      rtAction = 2;
    }

    USV_DW.ifHeightMaxlowaltitudeelseifH_b = rtAction;
  } else {
    rtAction = USV_DW.ifHeightMaxlowaltitudeelseifH_b;
  }

  switch (rtAction) {
   case 0:
    // Outputs for IfAction SubSystem: '<S118>/Low altitude  velocities' incorporates:
    //   ActionPort: '<S140>/Action Port'

    USV_Lowaltitudevelocities(USV_P.Constant_DCM_Value, USV_B.Hugwz.Sum,
      USV_B.Hvgwz.Sum, USV_B.Hwgwz.Sum, USV_B.UnitConversion_o,
      rtb_DataTypeConversion);

    // End of Outputs for SubSystem: '<S118>/Low altitude  velocities'
    break;

   case 1:
    // Outputs for IfAction SubSystem: '<S118>/Medium//High  altitude velocities' incorporates:
    //   ActionPort: '<S141>/Action Port'

    // DataTypeConversion: '<S5>/Data Type Conversion' incorporates:
    //   Gain: '<S141>/Gain'

    rtb_DataTypeConversion[0] = USV_P.Gain_Gain_k * USV_B.Hugwz.Sum[1];
    rtb_DataTypeConversion[1] = USV_P.Gain_Gain_k * USV_B.Hvgwz.Sum[1];
    rtb_DataTypeConversion[2] = USV_P.Gain_Gain_k * USV_B.Hwgwz.Sum[1];

    // End of Outputs for SubSystem: '<S118>/Medium//High  altitude velocities'
    break;

   case 2:
    // Outputs for IfAction SubSystem: '<S118>/Interpolate  velocities' incorporates:
    //   ActionPort: '<S139>/Action Port'

    USV_Interpolatevelocities(USV_B.Hugwz.Sum, USV_B.Hvgwz.Sum, USV_B.Hwgwz.Sum,
      USV_P.Constant_DCM_Value, USV_B.UnitConversion_o, rtb_Switch1,
      rtb_DataTypeConversion, &USV_P.Interpolatevelocities);

    // End of Outputs for SubSystem: '<S118>/Interpolate  velocities'
    break;
  }

  // End of If: '<S118>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 

  // UnitConversion: '<S100>/Unit Conversion'
  // Unit Conversion - from: ft/s to: m/s
  // Expression: output = (0.3048*input) + (0)
  UnitConversion_i[0] = 0.3048 * rtb_DataTypeConversion[0];
  UnitConversion_i[1] = 0.3048 * rtb_DataTypeConversion[1];
  UnitConversion_i[2] = 0.3048 * rtb_DataTypeConversion[2];

  // MATLAB Function 'WindFault/TurbWindStrength_Dec_Switch': '<S109>:1'
  // '<S109>:1:3' TurbWind=vwind*TurbWindParams(1);
  // Unit Conversion - from: m to: ft
  // Expression: output = (3.28084*input) + (0)
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // Math: '<S110>/ln(ref_height//z0)' incorporates:
    //   Constant: '<S110>/ref_height//z0'
    //
    //  About '<S110>/ln(ref_height//z0)':
    //   Operator: log

    USV_B.lnref_heightz0 = std::log(USV_P.ref_heightz0_Value);
  }

  // Saturate: '<S110>/3ft-->inf'
  if (rtb_Switch1 > USV_P.uftinf_UpperSat) {
    rtb_Switch1_k = USV_P.uftinf_UpperSat;
  } else if (rtb_Switch1 < USV_P.uftinf_LowerSat) {
    rtb_Switch1_k = USV_P.uftinf_LowerSat;
  } else {
    rtb_Switch1_k = rtb_Switch1;
  }

  // End of Saturate: '<S110>/3ft-->inf'

  // Product: '<S110>/Product' incorporates:
  //   Gain: '<S110>/h//z0'
  //   Math: '<S110>/ln(h//z0)'
  //
  //  About '<S110>/ln(h//z0)':
  //   Operator: log

  rtb_Switch1_h = std::log(USV_P.hz0_Gain * rtb_Switch1_k) /
    USV_B.lnref_heightz0;
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // UnitConversion: '<S189>/Unit Conversion' incorporates:
    //   Constant: '<S110>/Wind Direction'

    // Unit Conversion - from: deg to: rad
    // Expression: output = (0.0174533*input) + (0)
    rtb_Product_gy = 0.017453292519943295 * USV_P.FaultParamAPI.FaultInParams[6];

    // Gain: '<S110>/Wind speed at reference height' incorporates:
    //   Constant: '<S110>/Wdeg1'
    //   Trigonometry: '<S110>/SinCos'

    USV_B.Windspeedatreferenceheight[0] = -USV_P.FaultParamAPI.FaultInParams[5] *
      std::cos(rtb_Product_gy);
    USV_B.Windspeedatreferenceheight[1] = -USV_P.FaultParamAPI.FaultInParams[5] *
      std::sin(rtb_Product_gy);
    USV_B.Windspeedatreferenceheight[2] = -USV_P.FaultParamAPI.FaultInParams[5] *
      USV_P.Wdeg1_Value;
  }

  // DataTypeConversion: '<S5>/Data Type Conversion' incorporates:
  //   Product: '<S110>/Product1'

  // MATLAB Function 'WindFault/SheerWindStrength_Dec_Switch': '<S108>:1'
  // '<S108>:1:2' SheerWind=vwind*SheerWindParams(1);
  // MATLAB Function 'WindFault/MATLAB Function1': '<S107>:1'
  // '<S107>:1:2' wind=[0;0;0];
  rtb_DataTypeConversion[0] = rtb_Switch1_h * USV_B.Windspeedatreferenceheight[0];

  // MATLAB Function: '<S73>/MATLAB Function1'
  rtb_MatrixMultiply2[0] = 0.0;

  // DataTypeConversion: '<S5>/Data Type Conversion' incorporates:
  //   Product: '<S110>/Product1'

  rtb_DataTypeConversion[1] = rtb_Switch1_h * USV_B.Windspeedatreferenceheight[1];

  // MATLAB Function: '<S73>/MATLAB Function1'
  rtb_MatrixMultiply2[1] = 0.0;

  // DataTypeConversion: '<S5>/Data Type Conversion' incorporates:
  //   Product: '<S110>/Product1'

  rtb_DataTypeConversion[2] = rtb_Switch1_h * USV_B.Windspeedatreferenceheight[2];

  // MATLAB Function: '<S73>/MATLAB Function1' incorporates:
  //   MATLAB Function: '<S73>/TurbWindStrength_Dec_Switch'

  rtb_MatrixMultiply2[2] = 0.0;

  // '<S107>:1:3' if isConstWind
  if (USV_B.hasFault_ConstWind) {
    // '<S107>:1:4' wind=[ConstWind(1);ConstWind(2);ConstWind(3)];
    rtb_MatrixMultiply2[0] = USV_B.FaultParam_l[0];
    rtb_MatrixMultiply2[1] = USV_B.FaultParam_l[1];
    rtb_MatrixMultiply2[2] = USV_B.FaultParam_l[2];
  } else if (USV_B.hasFault_GustWind) {
    // '<S107>:1:5' elseif isGustWind
    // '<S107>:1:6' wind=GustWind;
    rtb_MatrixMultiply2[0] = USV_B.gWind[0];
    rtb_MatrixMultiply2[1] = USV_B.gWind[1];
    rtb_MatrixMultiply2[2] = USV_B.gWind[2];
  } else if (USV_B.hasFault_TurbWind) {
    // '<S107>:1:7' elseif isTurbWind
    // '<S107>:1:8' wind=TurbWind;
    rtb_MatrixMultiply2[0] = UnitConversion_i[0] * USV_B.FaultParam_h[0];
    rtb_MatrixMultiply2[1] = USV_B.FaultParam_h[0] * UnitConversion_i[1];
    rtb_MatrixMultiply2[2] = USV_B.FaultParam_h[0] * UnitConversion_i[2];
  } else if (USV_B.hasFault_SheerWind) {
    // MATLAB Function: '<S73>/SheerWindStrength_Dec_Switch'
    // '<S107>:1:9' elseif isSheerWind
    // '<S107>:1:10' wind=SheerWind;
    rtb_fcn3 = USV_B.FaultParam[0];

    // Product: '<S110>/Transform from Inertial to Body axes' incorporates:
    //   Constant: '<S73>/Constant_DCM'
    //   DataTypeConversion: '<S5>/Data Type Conversion'
    //   MATLAB Function: '<S73>/SheerWindStrength_Dec_Switch'

    for (i = 0; i < 3; i++) {
      rtb_MatrixMultiply2[i] = ((USV_P.Constant_DCM_Value[i + 3] *
        rtb_DataTypeConversion[1] + USV_P.Constant_DCM_Value[i] *
        rtb_DataTypeConversion[0]) + USV_P.Constant_DCM_Value[i + 6] *
        rtb_DataTypeConversion[2]) * rtb_fcn3;
    }

    // End of Product: '<S110>/Transform from Inertial to Body axes'
  }

  for (i = 0; i < 3; i++) {
    // DataTypeConversion: '<S5>/Data Type Conversion' incorporates:
    //   Concatenate: '<S31>/Vector Concatenate'
    //   Product: '<S73>/Product'

    rtb_DataTypeConversion[i] = 0.0;
    rtb_DataTypeConversion[i] += VectorConcatenate[i] * rtb_MatrixMultiply2[0];
    rtb_DataTypeConversion[i] += VectorConcatenate[i + 3] * rtb_MatrixMultiply2
      [1];
    rtb_DataTypeConversion[i] += VectorConcatenate[i + 6] * rtb_MatrixMultiply2
      [2];

    // Sum: '<S73>/Sum' incorporates:
    //   Integrator: '<S9>/ub,vb,wb'

    rtb_Switch1_h = USV_X.ubvbwb_CSTATE[i] - rtb_DataTypeConversion[i];

    // Product: '<S198>/Product4' incorporates:
    //   Constant: '<S198>/Constant3'
    //   Product: '<S198>/Product'
    //   Sum: '<S198>/Sum'
    //   Sum: '<S206>/Add3'

    rtb_Add_kk[i] = (rtb_Add_l[i] - rtb_Add_l[i + 3]) +
      USV_P.Constant3_Value_c[i] * rtb_Switch1_h;

    // Sum: '<S73>/Sum'
    UnitConversion_i[i] = rtb_Switch1_h;
  }

  for (i = 0; i < 3; i++) {
    // Product: '<S198>/Product4' incorporates:
    //   Concatenate: '<S220>/Vector Concatenate'

    rtb_MatrixMultiply2[i] = (USV_B.VectorConcatenate_j[i + 3] * rtb_Add_kk[1] +
      USV_B.VectorConcatenate_j[i] * rtb_Add_kk[0]) +
      USV_B.VectorConcatenate_j[i + 6] * rtb_Add_kk[2];
  }

  // MATLAB Function: '<S198>/���ģ��' incorporates:
  //   Constant: '<S198>/momentConstant'
  //   Constant: '<S198>/motorConstant'
  //   Constant: '<S198>/reversible'
  //   Constant: '<S198>/rollingMomentCoefficient'
  //   Constant: '<S198>/rotorDragCoefficient'
  //   Constant: '<S198>/rotorVelocitySlowdownSim'
  //   Constant: '<S198>/turningDirection1'

  USV_u(USV_B.Divide, rtb_MatrixMultiply2,
        USV_P.Motor1_MotorPara.turningDirection,
        USV_P.Motor1_MotorPara.rotorVelocitySlowdownSim,
        USV_P.Motor1_MotorPara.motorConstant,
        USV_P.Motor1_MotorPara.momentConstant,
        USV_P.Motor1_MotorPara.rotorDragCoefficient,
        USV_P.Motor1_MotorPara.rollingMomentCoefficient,
        USV_P.Motor1_MotorPara.reversible, &USV_B.sf_);

  // Switch: '<S198>/Switch1' incorporates:
  //   Constant: '<S198>/Constant1'
  //   Constant: '<S198>/Constant2'
  //   Constant: '<S198>/isEnable'
  //   Product: '<S198>/Product2'
  //   Product: '<S198>/Product5'

  if (USV_P.Motor1_MotorPara.isEnable) {
    // Product: '<S198>/Product1' incorporates:
    //   Math: '<S198>/Transpose'

    for (i = 0; i < 3; i++) {
      rtb_MatrixMultiply2[i] = (USV_B.DCM_bj[i + 3] * USV_B.sf_.Fb[1] +
        USV_B.DCM_bj[i] * USV_B.sf_.Fb[0]) + USV_B.DCM_bj[i + 6] * USV_B.sf_.Fb
        [2];
    }

    // End of Product: '<S198>/Product1'

    // Product: '<S207>/Element product' incorporates:
    //   Constant: '<S198>/pose'

    rtb_Elementproduct_cn[0] = USV_P.Motor1_MotorPara.pose[1] *
      rtb_MatrixMultiply2[2];
    rtb_Elementproduct_cn[1] = rtb_MatrixMultiply2[0] *
      USV_P.Motor1_MotorPara.pose[2];
    rtb_Elementproduct_cn[2] = USV_P.Motor1_MotorPara.pose[0] *
      rtb_MatrixMultiply2[1];
    rtb_Elementproduct_cn[3] = rtb_MatrixMultiply2[1] *
      USV_P.Motor1_MotorPara.pose[2];
    rtb_Elementproduct_cn[4] = USV_P.Motor1_MotorPara.pose[0] *
      rtb_MatrixMultiply2[2];
    rtb_Elementproduct_cn[5] = rtb_MatrixMultiply2[0] *
      USV_P.Motor1_MotorPara.pose[1];

    // Sum: '<S198>/Sum1' incorporates:
    //   Math: '<S198>/Transpose'
    //   Product: '<S198>/Product6'
    //   Sum: '<S207>/Add3'

    for (i = 0; i < 3; i++) {
      rtb_Add_kk[i] = ((USV_B.DCM_bj[i + 3] * USV_B.sf_.Mb[1] + USV_B.DCM_bj[i] *
                        USV_B.sf_.Mb[0]) + USV_B.DCM_bj[i + 6] * USV_B.sf_.Mb[2])
        + (rtb_Elementproduct_cn[i] - rtb_Elementproduct_cn[i + 3]);
    }

    // End of Sum: '<S198>/Sum1'
    rtb_Add_l[0] = rtb_MatrixMultiply2[0] * USV_P.Constant2_Value_g[0];
    rtb_Add_l[3] = USV_P.Constant2_Value_g[0] * rtb_Add_kk[0];
    rtb_Add_l[1] = rtb_MatrixMultiply2[1] * USV_P.Constant2_Value_g[1];
    rtb_Add_l[4] = USV_P.Constant2_Value_g[1] * rtb_Add_kk[1];
    rtb_Add_l[2] = rtb_MatrixMultiply2[2] * USV_P.Constant2_Value_g[2];
    rtb_Add_l[5] = USV_P.Constant2_Value_g[2] * rtb_Add_kk[2];
  } else {
    for (i = 0; i < 6; i++) {
      rtb_Add_l[i] = USV_P.Constant1_Value_hj[i];
    }
  }

  // End of Switch: '<S198>/Switch1'
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // Trigonometry: '<S223>/sincos' incorporates:
    //   Constant: '<S199>/pose: 1 * 6'

    rtb_sincos_o1_h[0] = std::sin(USV_P.Motor2_MotorPara.pose[3]);
    rtb_sincos_o2_k[0] = std::cos(USV_P.Motor2_MotorPara.pose[3]);
    rtb_sincos_o1_h[1] = std::sin(USV_P.Motor2_MotorPara.pose[4]);
    rtb_sincos_o2_k[1] = std::cos(USV_P.Motor2_MotorPara.pose[4]);
    rtb_sincos_o1_h[2] = std::sin(USV_P.Motor2_MotorPara.pose[5]);
    rtb_sincos_o2_k[2] = std::cos(USV_P.Motor2_MotorPara.pose[5]);

    // Product: '<S226>/u(5)*u(6)' incorporates:
    //   Concatenate: '<S235>/Vector Concatenate'

    USV_B.VectorConcatenate_p[0] = rtb_sincos_o2_k[1] * rtb_sincos_o2_k[2];

    // Product: '<S229>/u(6)*u(1)*u(2)' incorporates:
    //   Product: '<S233>/u(1)*u(6)'

    rtb_Switch1_h = rtb_sincos_o1_h[0] * rtb_sincos_o2_k[2];

    // Sum: '<S229>/Sum' incorporates:
    //   Concatenate: '<S235>/Vector Concatenate'
    //   Product: '<S229>/u(3)*u(4)'
    //   Product: '<S229>/u(6)*u(1)*u(2)'

    USV_B.VectorConcatenate_p[1] = rtb_Switch1_h * rtb_sincos_o1_h[1] -
      rtb_sincos_o2_k[0] * rtb_sincos_o1_h[2];

    // Sum: '<S232>/Sum' incorporates:
    //   Concatenate: '<S235>/Vector Concatenate'
    //   Product: '<S232>/u(1)*u(3)'
    //   Product: '<S232>/u(2)*u(4)*u(6)'

    USV_B.VectorConcatenate_p[2] = rtb_sincos_o2_k[0] * rtb_sincos_o1_h[1] *
      rtb_sincos_o2_k[2] + rtb_sincos_o1_h[0] * rtb_sincos_o1_h[2];

    // Product: '<S227>/u(3)*u(5)' incorporates:
    //   Concatenate: '<S235>/Vector Concatenate'

    USV_B.VectorConcatenate_p[3] = rtb_sincos_o2_k[1] * rtb_sincos_o1_h[2];

    // Sum: '<S230>/Sum' incorporates:
    //   Concatenate: '<S235>/Vector Concatenate'
    //   Product: '<S230>/u(1)*u(2)*u(3)'
    //   Product: '<S230>/u(4)*u(6)'

    USV_B.VectorConcatenate_p[4] = rtb_sincos_o1_h[0] * rtb_sincos_o1_h[1] *
      rtb_sincos_o1_h[2] + rtb_sincos_o2_k[0] * rtb_sincos_o2_k[2];

    // Sum: '<S233>/Sum' incorporates:
    //   Concatenate: '<S235>/Vector Concatenate'
    //   Product: '<S233>/u(2)*u(3)*u(4)'

    USV_B.VectorConcatenate_p[5] = rtb_sincos_o1_h[1] * rtb_sincos_o1_h[2] *
      rtb_sincos_o2_k[0] - rtb_Switch1_h;

    // UnaryMinus: '<S228>/Unary Minus' incorporates:
    //   Concatenate: '<S235>/Vector Concatenate'

    USV_B.VectorConcatenate_p[6] = -rtb_sincos_o1_h[1];

    // Product: '<S231>/u(1)*u(5)' incorporates:
    //   Concatenate: '<S235>/Vector Concatenate'

    USV_B.VectorConcatenate_p[7] = rtb_sincos_o1_h[0] * rtb_sincos_o2_k[1];

    // Product: '<S234>/u(4)*u(5)' incorporates:
    //   Concatenate: '<S235>/Vector Concatenate'

    USV_B.VectorConcatenate_p[8] = rtb_sincos_o2_k[0] * rtb_sincos_o2_k[1];
    for (i = 0; i < 3; i++) {
      // Math: '<S199>/Transpose' incorporates:
      //   Concatenate: '<S235>/Vector Concatenate'

      USV_B.DCM_bj_d[3 * i] = USV_B.VectorConcatenate_p[i];
      USV_B.DCM_bj_d[3 * i + 1] = USV_B.VectorConcatenate_p[i + 3];
      USV_B.DCM_bj_d[3 * i + 2] = USV_B.VectorConcatenate_p[i + 6];
    }

    // Switch: '<S199>/Switch' incorporates:
    //   Constant: '<S199>/Constant'
    //   Constant: '<S199>/isEnable'

    if (USV_P.Motor2_MotorPara.isEnable) {
      rtb_Product_gy = USV_B.y_k[1];
    } else {
      rtb_Product_gy = USV_P.Constant_Value_od;
    }

    // End of Switch: '<S199>/Switch'

    // MinMax: '<S199>/MinMax' incorporates:
    //   Constant: '<S199>/maxRotVelocity'

    if ((!(rtb_Product_gy <= USV_P.Motor2_MotorPara.maxRotVelocity)) &&
        (!rtIsNaN(USV_P.Motor2_MotorPara.maxRotVelocity))) {
      rtb_Product_gy = USV_P.Motor2_MotorPara.maxRotVelocity;
    }

    // End of MinMax: '<S199>/MinMax'

    // MATLAB Function: '<S199>/MATLAB Function1' incorporates:
    //   Clock: '<S199>/Clock'
    //   Constant: '<S199>/timeConstantDown'
    //   Constant: '<S199>/timeConstantUp'

    USV_MATLABFunction1(USV_P.Motor2_MotorPara.timeConstantUp,
                        USV_P.Motor2_MotorPara.timeConstantDown, rtb_Product_gy,
                        (&USV_M)->Timing.t[0], &USV_B.sf_MATLABFunction1_o,
                        &USV_DW.sf_MATLABFunction1_o);

    // Product: '<S199>/Divide' incorporates:
    //   Constant: '<S199>/rotorVelocitySlowdownSim1'
    //   Constant: '<S199>/turningDirection'

    USV_B.Divide_a = USV_B.sf_MATLABFunction1_o.outputState *
      USV_P.Motor2_MotorPara.turningDirection /
      USV_P.Motor2_MotorPara.rotorVelocitySlowdownSim;
  }

  // DataTypeConversion: '<S5>/Data Type Conversion' incorporates:
  //   Constant: '<S199>/Constant3'
  //   Integrator: '<S9>/p,q,r '
  //   Product: '<S199>/Product3'

  rtb_DataTypeConversion[0] = USV_X.pqr_CSTATE[0] * USV_P.Constant3_Value_p[0];
  rtb_DataTypeConversion[1] = USV_X.pqr_CSTATE[1] * USV_P.Constant3_Value_p[1];
  rtb_DataTypeConversion[2] = USV_X.pqr_CSTATE[2] * USV_P.Constant3_Value_p[2];

  // Product: '<S221>/Element product' incorporates:
  //   Constant: '<S199>/pose: 1 * 6'

  rtb_Elementproduct_cn[2] = rtb_DataTypeConversion[0] *
    USV_P.Motor2_MotorPara.pose[1];
  rtb_Elementproduct_cn[4] = rtb_DataTypeConversion[0] *
    USV_P.Motor2_MotorPara.pose[2];
  rtb_Elementproduct_cn[5] = USV_P.Motor2_MotorPara.pose[0] *
    rtb_DataTypeConversion[1];

  // DataTypeConversion: '<S5>/Data Type Conversion' incorporates:
  //   Constant: '<S199>/Constant3'
  //   Constant: '<S199>/pose: 1 * 6'
  //   Product: '<S199>/Product'
  //   Product: '<S221>/Element product'
  //   Sum: '<S199>/Sum'
  //   Sum: '<S221>/Add3'

  rtb_DataTypeConversion[0] = rtb_DataTypeConversion[1] *
    USV_P.Motor2_MotorPara.pose[2] - USV_P.Motor2_MotorPara.pose[1] *
    rtb_DataTypeConversion[2];
  rtb_DataTypeConversion[0] += USV_P.Constant3_Value_p[0] * UnitConversion_i[0];
  rtb_DataTypeConversion[1] = USV_P.Motor2_MotorPara.pose[0] *
    rtb_DataTypeConversion[2] - rtb_Elementproduct_cn[4];
  rtb_DataTypeConversion[1] += USV_P.Constant3_Value_p[1] * UnitConversion_i[1];
  rtb_DataTypeConversion[2] = rtb_Elementproduct_cn[2] - rtb_Elementproduct_cn[5];
  rtb_DataTypeConversion[2] += USV_P.Constant3_Value_p[2] * UnitConversion_i[2];
  for (i = 0; i < 3; i++) {
    // Product: '<S199>/Product4' incorporates:
    //   Concatenate: '<S235>/Vector Concatenate'
    //   DataTypeConversion: '<S5>/Data Type Conversion'

    rtb_MatrixMultiply2[i] = (USV_B.VectorConcatenate_p[i + 3] *
      rtb_DataTypeConversion[1] + USV_B.VectorConcatenate_p[i] *
      rtb_DataTypeConversion[0]) + USV_B.VectorConcatenate_p[i + 6] *
      rtb_DataTypeConversion[2];
  }

  // MATLAB Function: '<S199>/���ģ��' incorporates:
  //   Constant: '<S199>/momentConstant'
  //   Constant: '<S199>/motorConstant'
  //   Constant: '<S199>/reversible'
  //   Constant: '<S199>/rollingMomentCoefficient'
  //   Constant: '<S199>/rotorDragCoefficient'
  //   Constant: '<S199>/rotorVelocitySlowdownSim'
  //   Constant: '<S199>/turningDirection1'

  USV_u(USV_B.Divide_a, rtb_MatrixMultiply2,
        USV_P.Motor2_MotorPara.turningDirection,
        USV_P.Motor2_MotorPara.rotorVelocitySlowdownSim,
        USV_P.Motor2_MotorPara.motorConstant,
        USV_P.Motor2_MotorPara.momentConstant,
        USV_P.Motor2_MotorPara.rotorDragCoefficient,
        USV_P.Motor2_MotorPara.rollingMomentCoefficient,
        USV_P.Motor2_MotorPara.reversible, &USV_B.sf__f);

  // Switch: '<S199>/Switch1' incorporates:
  //   Constant: '<S199>/Constant1'
  //   Constant: '<S199>/Constant2'
  //   Constant: '<S199>/isEnable'
  //   Product: '<S199>/Product2'
  //   Product: '<S199>/Product5'

  if (USV_P.Motor2_MotorPara.isEnable) {
    // Product: '<S199>/Product1' incorporates:
    //   Math: '<S199>/Transpose'

    for (i = 0; i < 3; i++) {
      rtb_MatrixMultiply2[i] = (USV_B.DCM_bj_d[i + 3] * USV_B.sf__f.Fb[1] +
        USV_B.DCM_bj_d[i] * USV_B.sf__f.Fb[0]) + USV_B.DCM_bj_d[i + 6] *
        USV_B.sf__f.Fb[2];
    }

    // End of Product: '<S199>/Product1'

    // Product: '<S222>/Element product' incorporates:
    //   Constant: '<S199>/pose'

    rtb_Elementproduct_l[0] = USV_P.Motor2_MotorPara.pose[1] *
      rtb_MatrixMultiply2[2];
    rtb_Elementproduct_l[1] = rtb_MatrixMultiply2[0] *
      USV_P.Motor2_MotorPara.pose[2];
    rtb_Elementproduct_l[2] = USV_P.Motor2_MotorPara.pose[0] *
      rtb_MatrixMultiply2[1];
    rtb_Elementproduct_l[3] = rtb_MatrixMultiply2[1] *
      USV_P.Motor2_MotorPara.pose[2];
    rtb_Elementproduct_l[4] = USV_P.Motor2_MotorPara.pose[0] *
      rtb_MatrixMultiply2[2];
    rtb_Elementproduct_l[5] = rtb_MatrixMultiply2[0] *
      USV_P.Motor2_MotorPara.pose[1];

    // Sum: '<S199>/Sum1' incorporates:
    //   Math: '<S199>/Transpose'
    //   Product: '<S199>/Product6'
    //   Sum: '<S222>/Add3'

    for (i = 0; i < 3; i++) {
      rtb_Add_kk[i] = ((USV_B.DCM_bj_d[i + 3] * USV_B.sf__f.Mb[1] +
                        USV_B.DCM_bj_d[i] * USV_B.sf__f.Mb[0]) +
                       USV_B.DCM_bj_d[i + 6] * USV_B.sf__f.Mb[2]) +
        (rtb_Elementproduct_l[i] - rtb_Elementproduct_l[i + 3]);
    }

    // End of Sum: '<S199>/Sum1'
    rtb_Elementproduct_cn[0] = rtb_MatrixMultiply2[0] * USV_P.Constant2_Value_k
      [0];
    rtb_Elementproduct_cn[3] = USV_P.Constant2_Value_k[0] * rtb_Add_kk[0];
    rtb_Elementproduct_cn[1] = rtb_MatrixMultiply2[1] * USV_P.Constant2_Value_k
      [1];
    rtb_Elementproduct_cn[4] = USV_P.Constant2_Value_k[1] * rtb_Add_kk[1];
    rtb_Elementproduct_cn[2] = rtb_MatrixMultiply2[2] * USV_P.Constant2_Value_k
      [2];
    rtb_Elementproduct_cn[5] = USV_P.Constant2_Value_k[2] * rtb_Add_kk[2];
  } else {
    for (i = 0; i < 6; i++) {
      rtb_Elementproduct_cn[i] = USV_P.Constant1_Value_ku[i];
    }
  }

  // End of Switch: '<S199>/Switch1'
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // Trigonometry: '<S238>/sincos' incorporates:
    //   Constant: '<S200>/pose: 1 * 6'

    rtb_sincos_o1_h[0] = std::sin(USV_P.Motor3_MotorPara.pose[3]);
    rtb_sincos_o2_k[0] = std::cos(USV_P.Motor3_MotorPara.pose[3]);
    rtb_sincos_o1_h[1] = std::sin(USV_P.Motor3_MotorPara.pose[4]);
    rtb_sincos_o2_k[1] = std::cos(USV_P.Motor3_MotorPara.pose[4]);
    rtb_sincos_o1_h[2] = std::sin(USV_P.Motor3_MotorPara.pose[5]);
    rtb_sincos_o2_k[2] = std::cos(USV_P.Motor3_MotorPara.pose[5]);

    // Product: '<S241>/u(5)*u(6)' incorporates:
    //   Concatenate: '<S250>/Vector Concatenate'

    USV_B.VectorConcatenate_o[0] = rtb_sincos_o2_k[1] * rtb_sincos_o2_k[2];

    // Product: '<S244>/u(6)*u(1)*u(2)' incorporates:
    //   Product: '<S248>/u(1)*u(6)'

    rtb_Switch1_h = rtb_sincos_o1_h[0] * rtb_sincos_o2_k[2];

    // Sum: '<S244>/Sum' incorporates:
    //   Concatenate: '<S250>/Vector Concatenate'
    //   Product: '<S244>/u(3)*u(4)'
    //   Product: '<S244>/u(6)*u(1)*u(2)'

    USV_B.VectorConcatenate_o[1] = rtb_Switch1_h * rtb_sincos_o1_h[1] -
      rtb_sincos_o2_k[0] * rtb_sincos_o1_h[2];

    // Sum: '<S247>/Sum' incorporates:
    //   Concatenate: '<S250>/Vector Concatenate'
    //   Product: '<S247>/u(1)*u(3)'
    //   Product: '<S247>/u(2)*u(4)*u(6)'

    USV_B.VectorConcatenate_o[2] = rtb_sincos_o2_k[0] * rtb_sincos_o1_h[1] *
      rtb_sincos_o2_k[2] + rtb_sincos_o1_h[0] * rtb_sincos_o1_h[2];

    // Product: '<S242>/u(3)*u(5)' incorporates:
    //   Concatenate: '<S250>/Vector Concatenate'

    USV_B.VectorConcatenate_o[3] = rtb_sincos_o2_k[1] * rtb_sincos_o1_h[2];

    // Sum: '<S245>/Sum' incorporates:
    //   Concatenate: '<S250>/Vector Concatenate'
    //   Product: '<S245>/u(1)*u(2)*u(3)'
    //   Product: '<S245>/u(4)*u(6)'

    USV_B.VectorConcatenate_o[4] = rtb_sincos_o1_h[0] * rtb_sincos_o1_h[1] *
      rtb_sincos_o1_h[2] + rtb_sincos_o2_k[0] * rtb_sincos_o2_k[2];

    // Sum: '<S248>/Sum' incorporates:
    //   Concatenate: '<S250>/Vector Concatenate'
    //   Product: '<S248>/u(2)*u(3)*u(4)'

    USV_B.VectorConcatenate_o[5] = rtb_sincos_o1_h[1] * rtb_sincos_o1_h[2] *
      rtb_sincos_o2_k[0] - rtb_Switch1_h;

    // UnaryMinus: '<S243>/Unary Minus' incorporates:
    //   Concatenate: '<S250>/Vector Concatenate'

    USV_B.VectorConcatenate_o[6] = -rtb_sincos_o1_h[1];

    // Product: '<S246>/u(1)*u(5)' incorporates:
    //   Concatenate: '<S250>/Vector Concatenate'

    USV_B.VectorConcatenate_o[7] = rtb_sincos_o1_h[0] * rtb_sincos_o2_k[1];

    // Product: '<S249>/u(4)*u(5)' incorporates:
    //   Concatenate: '<S250>/Vector Concatenate'

    USV_B.VectorConcatenate_o[8] = rtb_sincos_o2_k[0] * rtb_sincos_o2_k[1];
    for (i = 0; i < 3; i++) {
      // Math: '<S200>/Transpose' incorporates:
      //   Concatenate: '<S250>/Vector Concatenate'

      USV_B.DCM_bj_b[3 * i] = USV_B.VectorConcatenate_o[i];
      USV_B.DCM_bj_b[3 * i + 1] = USV_B.VectorConcatenate_o[i + 3];
      USV_B.DCM_bj_b[3 * i + 2] = USV_B.VectorConcatenate_o[i + 6];
    }

    // Switch: '<S200>/Switch' incorporates:
    //   Constant: '<S200>/Constant'
    //   Constant: '<S200>/isEnable'

    if (USV_P.Motor3_MotorPara.isEnable) {
      rtb_Product_gy = USV_B.y_k[2];
    } else {
      rtb_Product_gy = USV_P.Constant_Value_o3;
    }

    // End of Switch: '<S200>/Switch'

    // MinMax: '<S200>/MinMax' incorporates:
    //   Constant: '<S200>/maxRotVelocity'

    if ((!(rtb_Product_gy <= USV_P.Motor3_MotorPara.maxRotVelocity)) &&
        (!rtIsNaN(USV_P.Motor3_MotorPara.maxRotVelocity))) {
      rtb_Product_gy = USV_P.Motor3_MotorPara.maxRotVelocity;
    }

    // End of MinMax: '<S200>/MinMax'

    // MATLAB Function: '<S200>/MATLAB Function1' incorporates:
    //   Clock: '<S200>/Clock'
    //   Constant: '<S200>/timeConstantDown'
    //   Constant: '<S200>/timeConstantUp'

    USV_MATLABFunction1(USV_P.Motor3_MotorPara.timeConstantUp,
                        USV_P.Motor3_MotorPara.timeConstantDown, rtb_Product_gy,
                        (&USV_M)->Timing.t[0], &USV_B.sf_MATLABFunction1_g,
                        &USV_DW.sf_MATLABFunction1_g);

    // Product: '<S200>/Divide' incorporates:
    //   Constant: '<S200>/rotorVelocitySlowdownSim1'
    //   Constant: '<S200>/turningDirection'

    USV_B.Divide_l = USV_B.sf_MATLABFunction1_g.outputState *
      USV_P.Motor3_MotorPara.turningDirection /
      USV_P.Motor3_MotorPara.rotorVelocitySlowdownSim;
  }

  // DataTypeConversion: '<S5>/Data Type Conversion' incorporates:
  //   Constant: '<S200>/Constant3'
  //   Integrator: '<S9>/p,q,r '
  //   Product: '<S200>/Product3'

  rtb_DataTypeConversion[0] = USV_X.pqr_CSTATE[0] * USV_P.Constant3_Value_i[0];
  rtb_DataTypeConversion[1] = USV_X.pqr_CSTATE[1] * USV_P.Constant3_Value_i[1];
  rtb_DataTypeConversion[2] = USV_X.pqr_CSTATE[2] * USV_P.Constant3_Value_i[2];

  // Product: '<S236>/Element product' incorporates:
  //   Constant: '<S200>/pose: 1 * 6'

  rtb_Elementproduct_l[2] = rtb_DataTypeConversion[0] *
    USV_P.Motor3_MotorPara.pose[1];
  rtb_Elementproduct_l[4] = rtb_DataTypeConversion[0] *
    USV_P.Motor3_MotorPara.pose[2];
  rtb_Elementproduct_l[5] = USV_P.Motor3_MotorPara.pose[0] *
    rtb_DataTypeConversion[1];

  // DataTypeConversion: '<S5>/Data Type Conversion' incorporates:
  //   Constant: '<S200>/Constant3'
  //   Constant: '<S200>/pose: 1 * 6'
  //   Product: '<S200>/Product'
  //   Product: '<S236>/Element product'
  //   Sum: '<S200>/Sum'
  //   Sum: '<S236>/Add3'

  rtb_DataTypeConversion[0] = rtb_DataTypeConversion[1] *
    USV_P.Motor3_MotorPara.pose[2] - USV_P.Motor3_MotorPara.pose[1] *
    rtb_DataTypeConversion[2];
  rtb_DataTypeConversion[0] += USV_P.Constant3_Value_i[0] * UnitConversion_i[0];
  rtb_DataTypeConversion[1] = USV_P.Motor3_MotorPara.pose[0] *
    rtb_DataTypeConversion[2] - rtb_Elementproduct_l[4];
  rtb_DataTypeConversion[1] += USV_P.Constant3_Value_i[1] * UnitConversion_i[1];
  rtb_DataTypeConversion[2] = rtb_Elementproduct_l[2] - rtb_Elementproduct_l[5];
  rtb_DataTypeConversion[2] += USV_P.Constant3_Value_i[2] * UnitConversion_i[2];
  for (i = 0; i < 3; i++) {
    // Product: '<S200>/Product4' incorporates:
    //   Concatenate: '<S250>/Vector Concatenate'
    //   DataTypeConversion: '<S5>/Data Type Conversion'

    rtb_MatrixMultiply2[i] = (USV_B.VectorConcatenate_o[i + 3] *
      rtb_DataTypeConversion[1] + USV_B.VectorConcatenate_o[i] *
      rtb_DataTypeConversion[0]) + USV_B.VectorConcatenate_o[i + 6] *
      rtb_DataTypeConversion[2];
  }

  // MATLAB Function: '<S200>/���ģ��' incorporates:
  //   Constant: '<S200>/momentConstant'
  //   Constant: '<S200>/motorConstant'
  //   Constant: '<S200>/reversible'
  //   Constant: '<S200>/rollingMomentCoefficient'
  //   Constant: '<S200>/rotorDragCoefficient'
  //   Constant: '<S200>/rotorVelocitySlowdownSim'
  //   Constant: '<S200>/turningDirection1'

  USV_u(USV_B.Divide_l, rtb_MatrixMultiply2,
        USV_P.Motor3_MotorPara.turningDirection,
        USV_P.Motor3_MotorPara.rotorVelocitySlowdownSim,
        USV_P.Motor3_MotorPara.motorConstant,
        USV_P.Motor3_MotorPara.momentConstant,
        USV_P.Motor3_MotorPara.rotorDragCoefficient,
        USV_P.Motor3_MotorPara.rollingMomentCoefficient,
        USV_P.Motor3_MotorPara.reversible, &USV_B.sf__m);

  // Switch: '<S200>/Switch1' incorporates:
  //   Constant: '<S200>/Constant1'
  //   Constant: '<S200>/Constant2'
  //   Constant: '<S200>/isEnable'
  //   Product: '<S200>/Product2'
  //   Product: '<S200>/Product5'

  if (USV_P.Motor3_MotorPara.isEnable) {
    // Product: '<S200>/Product1' incorporates:
    //   Math: '<S200>/Transpose'

    for (i = 0; i < 3; i++) {
      rtb_MatrixMultiply2[i] = (USV_B.DCM_bj_b[i + 3] * USV_B.sf__m.Fb[1] +
        USV_B.DCM_bj_b[i] * USV_B.sf__m.Fb[0]) + USV_B.DCM_bj_b[i + 6] *
        USV_B.sf__m.Fb[2];
    }

    // End of Product: '<S200>/Product1'

    // Product: '<S237>/Element product' incorporates:
    //   Constant: '<S200>/pose'

    rtb_Elementproduct_cd[0] = USV_P.Motor3_MotorPara.pose[1] *
      rtb_MatrixMultiply2[2];
    rtb_Elementproduct_cd[1] = rtb_MatrixMultiply2[0] *
      USV_P.Motor3_MotorPara.pose[2];
    rtb_Elementproduct_cd[2] = USV_P.Motor3_MotorPara.pose[0] *
      rtb_MatrixMultiply2[1];
    rtb_Elementproduct_cd[3] = rtb_MatrixMultiply2[1] *
      USV_P.Motor3_MotorPara.pose[2];
    rtb_Elementproduct_cd[4] = USV_P.Motor3_MotorPara.pose[0] *
      rtb_MatrixMultiply2[2];
    rtb_Elementproduct_cd[5] = rtb_MatrixMultiply2[0] *
      USV_P.Motor3_MotorPara.pose[1];

    // Sum: '<S200>/Sum1' incorporates:
    //   Math: '<S200>/Transpose'
    //   Product: '<S200>/Product6'
    //   Sum: '<S237>/Add3'

    for (i = 0; i < 3; i++) {
      rtb_Add_kk[i] = ((USV_B.DCM_bj_b[i + 3] * USV_B.sf__m.Mb[1] +
                        USV_B.DCM_bj_b[i] * USV_B.sf__m.Mb[0]) +
                       USV_B.DCM_bj_b[i + 6] * USV_B.sf__m.Mb[2]) +
        (rtb_Elementproduct_cd[i] - rtb_Elementproduct_cd[i + 3]);
    }

    // End of Sum: '<S200>/Sum1'
    rtb_Elementproduct_l[0] = rtb_MatrixMultiply2[0] * USV_P.Constant2_Value_p0
      [0];
    rtb_Elementproduct_l[3] = USV_P.Constant2_Value_p0[0] * rtb_Add_kk[0];
    rtb_Elementproduct_l[1] = rtb_MatrixMultiply2[1] * USV_P.Constant2_Value_p0
      [1];
    rtb_Elementproduct_l[4] = USV_P.Constant2_Value_p0[1] * rtb_Add_kk[1];
    rtb_Elementproduct_l[2] = rtb_MatrixMultiply2[2] * USV_P.Constant2_Value_p0
      [2];
    rtb_Elementproduct_l[5] = USV_P.Constant2_Value_p0[2] * rtb_Add_kk[2];
  } else {
    for (i = 0; i < 6; i++) {
      rtb_Elementproduct_l[i] = USV_P.Constant1_Value_l[i];
    }
  }

  // End of Switch: '<S200>/Switch1'
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // Trigonometry: '<S253>/sincos' incorporates:
    //   Constant: '<S201>/pose: 1 * 6'

    rtb_sincos_o1_h[0] = std::sin(USV_P.Motor4_MotorPara.pose[3]);
    rtb_sincos_o2_k[0] = std::cos(USV_P.Motor4_MotorPara.pose[3]);
    rtb_sincos_o1_h[1] = std::sin(USV_P.Motor4_MotorPara.pose[4]);
    rtb_sincos_o2_k[1] = std::cos(USV_P.Motor4_MotorPara.pose[4]);
    rtb_sincos_o1_h[2] = std::sin(USV_P.Motor4_MotorPara.pose[5]);
    rtb_sincos_o2_k[2] = std::cos(USV_P.Motor4_MotorPara.pose[5]);

    // Product: '<S256>/u(5)*u(6)' incorporates:
    //   Concatenate: '<S265>/Vector Concatenate'

    USV_B.VectorConcatenate_k[0] = rtb_sincos_o2_k[1] * rtb_sincos_o2_k[2];

    // Product: '<S259>/u(6)*u(1)*u(2)' incorporates:
    //   Product: '<S263>/u(1)*u(6)'

    rtb_Switch1_h = rtb_sincos_o1_h[0] * rtb_sincos_o2_k[2];

    // Sum: '<S259>/Sum' incorporates:
    //   Concatenate: '<S265>/Vector Concatenate'
    //   Product: '<S259>/u(3)*u(4)'
    //   Product: '<S259>/u(6)*u(1)*u(2)'

    USV_B.VectorConcatenate_k[1] = rtb_Switch1_h * rtb_sincos_o1_h[1] -
      rtb_sincos_o2_k[0] * rtb_sincos_o1_h[2];

    // Sum: '<S262>/Sum' incorporates:
    //   Concatenate: '<S265>/Vector Concatenate'
    //   Product: '<S262>/u(1)*u(3)'
    //   Product: '<S262>/u(2)*u(4)*u(6)'

    USV_B.VectorConcatenate_k[2] = rtb_sincos_o2_k[0] * rtb_sincos_o1_h[1] *
      rtb_sincos_o2_k[2] + rtb_sincos_o1_h[0] * rtb_sincos_o1_h[2];

    // Product: '<S257>/u(3)*u(5)' incorporates:
    //   Concatenate: '<S265>/Vector Concatenate'

    USV_B.VectorConcatenate_k[3] = rtb_sincos_o2_k[1] * rtb_sincos_o1_h[2];

    // Sum: '<S260>/Sum' incorporates:
    //   Concatenate: '<S265>/Vector Concatenate'
    //   Product: '<S260>/u(1)*u(2)*u(3)'
    //   Product: '<S260>/u(4)*u(6)'

    USV_B.VectorConcatenate_k[4] = rtb_sincos_o1_h[0] * rtb_sincos_o1_h[1] *
      rtb_sincos_o1_h[2] + rtb_sincos_o2_k[0] * rtb_sincos_o2_k[2];

    // Sum: '<S263>/Sum' incorporates:
    //   Concatenate: '<S265>/Vector Concatenate'
    //   Product: '<S263>/u(2)*u(3)*u(4)'

    USV_B.VectorConcatenate_k[5] = rtb_sincos_o1_h[1] * rtb_sincos_o1_h[2] *
      rtb_sincos_o2_k[0] - rtb_Switch1_h;

    // UnaryMinus: '<S258>/Unary Minus' incorporates:
    //   Concatenate: '<S265>/Vector Concatenate'

    USV_B.VectorConcatenate_k[6] = -rtb_sincos_o1_h[1];

    // Product: '<S261>/u(1)*u(5)' incorporates:
    //   Concatenate: '<S265>/Vector Concatenate'

    USV_B.VectorConcatenate_k[7] = rtb_sincos_o1_h[0] * rtb_sincos_o2_k[1];

    // Product: '<S264>/u(4)*u(5)' incorporates:
    //   Concatenate: '<S265>/Vector Concatenate'

    USV_B.VectorConcatenate_k[8] = rtb_sincos_o2_k[0] * rtb_sincos_o2_k[1];
    for (i = 0; i < 3; i++) {
      // Math: '<S201>/Transpose' incorporates:
      //   Concatenate: '<S265>/Vector Concatenate'

      USV_B.DCM_bj_h[3 * i] = USV_B.VectorConcatenate_k[i];
      USV_B.DCM_bj_h[3 * i + 1] = USV_B.VectorConcatenate_k[i + 3];
      USV_B.DCM_bj_h[3 * i + 2] = USV_B.VectorConcatenate_k[i + 6];
    }

    // Switch: '<S201>/Switch' incorporates:
    //   Constant: '<S201>/Constant'
    //   Constant: '<S201>/isEnable'

    if (USV_P.Motor4_MotorPara.isEnable) {
      rtb_Product_gy = USV_B.y_k[3];
    } else {
      rtb_Product_gy = USV_P.Constant_Value_fl;
    }

    // End of Switch: '<S201>/Switch'

    // MinMax: '<S201>/MinMax' incorporates:
    //   Constant: '<S201>/maxRotVelocity'

    if ((!(rtb_Product_gy <= USV_P.Motor4_MotorPara.maxRotVelocity)) &&
        (!rtIsNaN(USV_P.Motor4_MotorPara.maxRotVelocity))) {
      rtb_Product_gy = USV_P.Motor4_MotorPara.maxRotVelocity;
    }

    // End of MinMax: '<S201>/MinMax'

    // MATLAB Function: '<S201>/MATLAB Function1' incorporates:
    //   Clock: '<S201>/Clock'
    //   Constant: '<S201>/timeConstantDown'
    //   Constant: '<S201>/timeConstantUp'

    USV_MATLABFunction1(USV_P.Motor4_MotorPara.timeConstantUp,
                        USV_P.Motor4_MotorPara.timeConstantDown, rtb_Product_gy,
                        (&USV_M)->Timing.t[0], &USV_B.sf_MATLABFunction1_k,
                        &USV_DW.sf_MATLABFunction1_k);

    // Product: '<S201>/Divide' incorporates:
    //   Constant: '<S201>/rotorVelocitySlowdownSim1'
    //   Constant: '<S201>/turningDirection'

    USV_B.Divide_h = USV_B.sf_MATLABFunction1_k.outputState *
      USV_P.Motor4_MotorPara.turningDirection /
      USV_P.Motor4_MotorPara.rotorVelocitySlowdownSim;
  }

  // DataTypeConversion: '<S5>/Data Type Conversion' incorporates:
  //   Constant: '<S201>/Constant3'
  //   Integrator: '<S9>/p,q,r '
  //   Product: '<S201>/Product3'

  rtb_DataTypeConversion[0] = USV_X.pqr_CSTATE[0] * USV_P.Constant3_Value_e[0];
  rtb_DataTypeConversion[1] = USV_X.pqr_CSTATE[1] * USV_P.Constant3_Value_e[1];
  rtb_DataTypeConversion[2] = USV_X.pqr_CSTATE[2] * USV_P.Constant3_Value_e[2];

  // Product: '<S251>/Element product' incorporates:
  //   Constant: '<S201>/pose: 1 * 6'

  rtb_Elementproduct_cd[2] = rtb_DataTypeConversion[0] *
    USV_P.Motor4_MotorPara.pose[1];
  rtb_Elementproduct_cd[4] = rtb_DataTypeConversion[0] *
    USV_P.Motor4_MotorPara.pose[2];
  rtb_Elementproduct_cd[5] = USV_P.Motor4_MotorPara.pose[0] *
    rtb_DataTypeConversion[1];

  // DataTypeConversion: '<S5>/Data Type Conversion' incorporates:
  //   Constant: '<S201>/Constant3'
  //   Constant: '<S201>/pose: 1 * 6'
  //   Product: '<S201>/Product'
  //   Product: '<S251>/Element product'
  //   Sum: '<S201>/Sum'
  //   Sum: '<S251>/Add3'

  rtb_DataTypeConversion[0] = rtb_DataTypeConversion[1] *
    USV_P.Motor4_MotorPara.pose[2] - USV_P.Motor4_MotorPara.pose[1] *
    rtb_DataTypeConversion[2];
  rtb_DataTypeConversion[0] += USV_P.Constant3_Value_e[0] * UnitConversion_i[0];
  rtb_DataTypeConversion[1] = USV_P.Motor4_MotorPara.pose[0] *
    rtb_DataTypeConversion[2] - rtb_Elementproduct_cd[4];
  rtb_DataTypeConversion[1] += USV_P.Constant3_Value_e[1] * UnitConversion_i[1];
  rtb_DataTypeConversion[2] = rtb_Elementproduct_cd[2] - rtb_Elementproduct_cd[5];
  rtb_DataTypeConversion[2] += USV_P.Constant3_Value_e[2] * UnitConversion_i[2];
  for (i = 0; i < 3; i++) {
    // Product: '<S201>/Product4' incorporates:
    //   Concatenate: '<S265>/Vector Concatenate'
    //   DataTypeConversion: '<S5>/Data Type Conversion'

    rtb_MatrixMultiply2[i] = (USV_B.VectorConcatenate_k[i + 3] *
      rtb_DataTypeConversion[1] + USV_B.VectorConcatenate_k[i] *
      rtb_DataTypeConversion[0]) + USV_B.VectorConcatenate_k[i + 6] *
      rtb_DataTypeConversion[2];
  }

  // MATLAB Function: '<S201>/���ģ��' incorporates:
  //   Constant: '<S201>/momentConstant'
  //   Constant: '<S201>/motorConstant'
  //   Constant: '<S201>/reversible'
  //   Constant: '<S201>/rollingMomentCoefficient'
  //   Constant: '<S201>/rotorDragCoefficient'
  //   Constant: '<S201>/rotorVelocitySlowdownSim'
  //   Constant: '<S201>/turningDirection1'

  USV_u(USV_B.Divide_h, rtb_MatrixMultiply2,
        USV_P.Motor4_MotorPara.turningDirection,
        USV_P.Motor4_MotorPara.rotorVelocitySlowdownSim,
        USV_P.Motor4_MotorPara.motorConstant,
        USV_P.Motor4_MotorPara.momentConstant,
        USV_P.Motor4_MotorPara.rotorDragCoefficient,
        USV_P.Motor4_MotorPara.rollingMomentCoefficient,
        USV_P.Motor4_MotorPara.reversible, &USV_B.sf__j);

  // Switch: '<S201>/Switch1' incorporates:
  //   Constant: '<S201>/Constant1'
  //   Constant: '<S201>/Constant2'
  //   Constant: '<S201>/isEnable'
  //   Product: '<S201>/Product2'
  //   Product: '<S201>/Product5'

  if (USV_P.Motor4_MotorPara.isEnable) {
    // Product: '<S201>/Product1' incorporates:
    //   Math: '<S201>/Transpose'

    for (i = 0; i < 3; i++) {
      rtb_MatrixMultiply2[i] = (USV_B.DCM_bj_h[i + 3] * USV_B.sf__j.Fb[1] +
        USV_B.DCM_bj_h[i] * USV_B.sf__j.Fb[0]) + USV_B.DCM_bj_h[i + 6] *
        USV_B.sf__j.Fb[2];
    }

    // End of Product: '<S201>/Product1'

    // Product: '<S252>/Element product' incorporates:
    //   Constant: '<S201>/pose'

    rtb_Elementproduct_d[0] = USV_P.Motor4_MotorPara.pose[1] *
      rtb_MatrixMultiply2[2];
    rtb_Elementproduct_d[1] = rtb_MatrixMultiply2[0] *
      USV_P.Motor4_MotorPara.pose[2];
    rtb_Elementproduct_d[2] = USV_P.Motor4_MotorPara.pose[0] *
      rtb_MatrixMultiply2[1];
    rtb_Elementproduct_d[3] = rtb_MatrixMultiply2[1] *
      USV_P.Motor4_MotorPara.pose[2];
    rtb_Elementproduct_d[4] = USV_P.Motor4_MotorPara.pose[0] *
      rtb_MatrixMultiply2[2];
    rtb_Elementproduct_d[5] = rtb_MatrixMultiply2[0] *
      USV_P.Motor4_MotorPara.pose[1];

    // Sum: '<S201>/Sum1' incorporates:
    //   Math: '<S201>/Transpose'
    //   Product: '<S201>/Product6'
    //   Sum: '<S252>/Add3'

    for (i = 0; i < 3; i++) {
      rtb_Add_kk[i] = ((USV_B.DCM_bj_h[i + 3] * USV_B.sf__j.Mb[1] +
                        USV_B.DCM_bj_h[i] * USV_B.sf__j.Mb[0]) +
                       USV_B.DCM_bj_h[i + 6] * USV_B.sf__j.Mb[2]) +
        (rtb_Elementproduct_d[i] - rtb_Elementproduct_d[i + 3]);
    }

    // End of Sum: '<S201>/Sum1'
    rtb_Elementproduct_cd[0] = rtb_MatrixMultiply2[0] *
      USV_P.Constant2_Value_p5[0];
    rtb_Elementproduct_cd[3] = USV_P.Constant2_Value_p5[0] * rtb_Add_kk[0];
    rtb_Elementproduct_cd[1] = rtb_MatrixMultiply2[1] *
      USV_P.Constant2_Value_p5[1];
    rtb_Elementproduct_cd[4] = USV_P.Constant2_Value_p5[1] * rtb_Add_kk[1];
    rtb_Elementproduct_cd[2] = rtb_MatrixMultiply2[2] *
      USV_P.Constant2_Value_p5[2];
    rtb_Elementproduct_cd[5] = USV_P.Constant2_Value_p5[2] * rtb_Add_kk[2];
  } else {
    for (i = 0; i < 6; i++) {
      rtb_Elementproduct_cd[i] = USV_P.Constant1_Value_ns[i];
    }
  }

  // End of Switch: '<S201>/Switch1'
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // Trigonometry: '<S268>/sincos' incorporates:
    //   Constant: '<S202>/pose: 1 * 6'

    rtb_sincos_o1_h[0] = std::sin(USV_P.Motor5_MotorPara.pose[3]);
    rtb_sincos_o2_k[0] = std::cos(USV_P.Motor5_MotorPara.pose[3]);
    rtb_sincos_o1_h[1] = std::sin(USV_P.Motor5_MotorPara.pose[4]);
    rtb_sincos_o2_k[1] = std::cos(USV_P.Motor5_MotorPara.pose[4]);
    rtb_sincos_o1_h[2] = std::sin(USV_P.Motor5_MotorPara.pose[5]);
    rtb_sincos_o2_k[2] = std::cos(USV_P.Motor5_MotorPara.pose[5]);

    // Product: '<S271>/u(5)*u(6)' incorporates:
    //   Concatenate: '<S280>/Vector Concatenate'

    USV_B.VectorConcatenate_m[0] = rtb_sincos_o2_k[1] * rtb_sincos_o2_k[2];

    // Product: '<S274>/u(6)*u(1)*u(2)' incorporates:
    //   Product: '<S278>/u(1)*u(6)'

    rtb_Switch1_h = rtb_sincos_o1_h[0] * rtb_sincos_o2_k[2];

    // Sum: '<S274>/Sum' incorporates:
    //   Concatenate: '<S280>/Vector Concatenate'
    //   Product: '<S274>/u(3)*u(4)'
    //   Product: '<S274>/u(6)*u(1)*u(2)'

    USV_B.VectorConcatenate_m[1] = rtb_Switch1_h * rtb_sincos_o1_h[1] -
      rtb_sincos_o2_k[0] * rtb_sincos_o1_h[2];

    // Sum: '<S277>/Sum' incorporates:
    //   Concatenate: '<S280>/Vector Concatenate'
    //   Product: '<S277>/u(1)*u(3)'
    //   Product: '<S277>/u(2)*u(4)*u(6)'

    USV_B.VectorConcatenate_m[2] = rtb_sincos_o2_k[0] * rtb_sincos_o1_h[1] *
      rtb_sincos_o2_k[2] + rtb_sincos_o1_h[0] * rtb_sincos_o1_h[2];

    // Product: '<S272>/u(3)*u(5)' incorporates:
    //   Concatenate: '<S280>/Vector Concatenate'

    USV_B.VectorConcatenate_m[3] = rtb_sincos_o2_k[1] * rtb_sincos_o1_h[2];

    // Sum: '<S275>/Sum' incorporates:
    //   Concatenate: '<S280>/Vector Concatenate'
    //   Product: '<S275>/u(1)*u(2)*u(3)'
    //   Product: '<S275>/u(4)*u(6)'

    USV_B.VectorConcatenate_m[4] = rtb_sincos_o1_h[0] * rtb_sincos_o1_h[1] *
      rtb_sincos_o1_h[2] + rtb_sincos_o2_k[0] * rtb_sincos_o2_k[2];

    // Sum: '<S278>/Sum' incorporates:
    //   Concatenate: '<S280>/Vector Concatenate'
    //   Product: '<S278>/u(2)*u(3)*u(4)'

    USV_B.VectorConcatenate_m[5] = rtb_sincos_o1_h[1] * rtb_sincos_o1_h[2] *
      rtb_sincos_o2_k[0] - rtb_Switch1_h;

    // UnaryMinus: '<S273>/Unary Minus' incorporates:
    //   Concatenate: '<S280>/Vector Concatenate'

    USV_B.VectorConcatenate_m[6] = -rtb_sincos_o1_h[1];

    // Product: '<S276>/u(1)*u(5)' incorporates:
    //   Concatenate: '<S280>/Vector Concatenate'

    USV_B.VectorConcatenate_m[7] = rtb_sincos_o1_h[0] * rtb_sincos_o2_k[1];

    // Product: '<S279>/u(4)*u(5)' incorporates:
    //   Concatenate: '<S280>/Vector Concatenate'

    USV_B.VectorConcatenate_m[8] = rtb_sincos_o2_k[0] * rtb_sincos_o2_k[1];
    for (i = 0; i < 3; i++) {
      // Math: '<S202>/Transpose' incorporates:
      //   Concatenate: '<S280>/Vector Concatenate'

      USV_B.DCM_bj_d2[3 * i] = USV_B.VectorConcatenate_m[i];
      USV_B.DCM_bj_d2[3 * i + 1] = USV_B.VectorConcatenate_m[i + 3];
      USV_B.DCM_bj_d2[3 * i + 2] = USV_B.VectorConcatenate_m[i + 6];
    }

    // Switch: '<S202>/Switch' incorporates:
    //   Constant: '<S202>/Constant'
    //   Constant: '<S202>/isEnable'

    if (USV_P.Motor5_MotorPara.isEnable) {
      rtb_Product_gy = USV_B.y_k[4];
    } else {
      rtb_Product_gy = USV_P.Constant_Value_l;
    }

    // End of Switch: '<S202>/Switch'

    // MinMax: '<S202>/MinMax' incorporates:
    //   Constant: '<S202>/maxRotVelocity'

    if ((!(rtb_Product_gy <= USV_P.Motor5_MotorPara.maxRotVelocity)) &&
        (!rtIsNaN(USV_P.Motor5_MotorPara.maxRotVelocity))) {
      rtb_Product_gy = USV_P.Motor5_MotorPara.maxRotVelocity;
    }

    // End of MinMax: '<S202>/MinMax'

    // MATLAB Function: '<S202>/MATLAB Function1' incorporates:
    //   Clock: '<S202>/Clock'
    //   Constant: '<S202>/timeConstantDown'
    //   Constant: '<S202>/timeConstantUp'

    USV_MATLABFunction1(USV_P.Motor5_MotorPara.timeConstantUp,
                        USV_P.Motor5_MotorPara.timeConstantDown, rtb_Product_gy,
                        (&USV_M)->Timing.t[0], &USV_B.sf_MATLABFunction1_ga,
                        &USV_DW.sf_MATLABFunction1_ga);

    // Product: '<S202>/Divide' incorporates:
    //   Constant: '<S202>/rotorVelocitySlowdownSim1'
    //   Constant: '<S202>/turningDirection'

    USV_B.Divide_p = USV_B.sf_MATLABFunction1_ga.outputState *
      USV_P.Motor5_MotorPara.turningDirection /
      USV_P.Motor5_MotorPara.rotorVelocitySlowdownSim;
  }

  // DataTypeConversion: '<S5>/Data Type Conversion' incorporates:
  //   Constant: '<S202>/Constant3'
  //   Integrator: '<S9>/p,q,r '
  //   Product: '<S202>/Product3'

  rtb_DataTypeConversion[0] = USV_X.pqr_CSTATE[0] * USV_P.Constant3_Value_cy[0];
  rtb_DataTypeConversion[1] = USV_X.pqr_CSTATE[1] * USV_P.Constant3_Value_cy[1];
  rtb_DataTypeConversion[2] = USV_X.pqr_CSTATE[2] * USV_P.Constant3_Value_cy[2];

  // Product: '<S266>/Element product' incorporates:
  //   Constant: '<S202>/pose: 1 * 6'

  rtb_Elementproduct_d[2] = rtb_DataTypeConversion[0] *
    USV_P.Motor5_MotorPara.pose[1];
  rtb_Elementproduct_d[4] = rtb_DataTypeConversion[0] *
    USV_P.Motor5_MotorPara.pose[2];
  rtb_Elementproduct_d[5] = USV_P.Motor5_MotorPara.pose[0] *
    rtb_DataTypeConversion[1];

  // DataTypeConversion: '<S5>/Data Type Conversion' incorporates:
  //   Constant: '<S202>/Constant3'
  //   Constant: '<S202>/pose: 1 * 6'
  //   Product: '<S202>/Product'
  //   Product: '<S266>/Element product'
  //   Sum: '<S202>/Sum'
  //   Sum: '<S266>/Add3'

  rtb_DataTypeConversion[0] = rtb_DataTypeConversion[1] *
    USV_P.Motor5_MotorPara.pose[2] - USV_P.Motor5_MotorPara.pose[1] *
    rtb_DataTypeConversion[2];
  rtb_DataTypeConversion[0] += USV_P.Constant3_Value_cy[0] * UnitConversion_i[0];
  rtb_DataTypeConversion[1] = USV_P.Motor5_MotorPara.pose[0] *
    rtb_DataTypeConversion[2] - rtb_Elementproduct_d[4];
  rtb_DataTypeConversion[1] += USV_P.Constant3_Value_cy[1] * UnitConversion_i[1];
  rtb_DataTypeConversion[2] = rtb_Elementproduct_d[2] - rtb_Elementproduct_d[5];
  rtb_DataTypeConversion[2] += USV_P.Constant3_Value_cy[2] * UnitConversion_i[2];
  for (i = 0; i < 3; i++) {
    // Product: '<S202>/Product4' incorporates:
    //   Concatenate: '<S280>/Vector Concatenate'
    //   DataTypeConversion: '<S5>/Data Type Conversion'

    rtb_MatrixMultiply2[i] = (USV_B.VectorConcatenate_m[i + 3] *
      rtb_DataTypeConversion[1] + USV_B.VectorConcatenate_m[i] *
      rtb_DataTypeConversion[0]) + USV_B.VectorConcatenate_m[i + 6] *
      rtb_DataTypeConversion[2];
  }

  // MATLAB Function: '<S202>/���ģ��' incorporates:
  //   Constant: '<S202>/momentConstant'
  //   Constant: '<S202>/motorConstant'
  //   Constant: '<S202>/reversible'
  //   Constant: '<S202>/rollingMomentCoefficient'
  //   Constant: '<S202>/rotorDragCoefficient'
  //   Constant: '<S202>/rotorVelocitySlowdownSim'
  //   Constant: '<S202>/turningDirection1'

  USV_u(USV_B.Divide_p, rtb_MatrixMultiply2,
        USV_P.Motor5_MotorPara.turningDirection,
        USV_P.Motor5_MotorPara.rotorVelocitySlowdownSim,
        USV_P.Motor5_MotorPara.motorConstant,
        USV_P.Motor5_MotorPara.momentConstant,
        USV_P.Motor5_MotorPara.rotorDragCoefficient,
        USV_P.Motor5_MotorPara.rollingMomentCoefficient,
        USV_P.Motor5_MotorPara.reversible, &USV_B.sf__d);

  // Switch: '<S202>/Switch1' incorporates:
  //   Constant: '<S202>/Constant1'
  //   Constant: '<S202>/Constant2'
  //   Constant: '<S202>/isEnable'
  //   Product: '<S202>/Product2'
  //   Product: '<S202>/Product5'

  if (USV_P.Motor5_MotorPara.isEnable) {
    // Product: '<S202>/Product1' incorporates:
    //   Math: '<S202>/Transpose'

    for (i = 0; i < 3; i++) {
      rtb_MatrixMultiply2[i] = (USV_B.DCM_bj_d2[i + 3] * USV_B.sf__d.Fb[1] +
        USV_B.DCM_bj_d2[i] * USV_B.sf__d.Fb[0]) + USV_B.DCM_bj_d2[i + 6] *
        USV_B.sf__d.Fb[2];
    }

    // End of Product: '<S202>/Product1'

    // Product: '<S267>/Element product' incorporates:
    //   Constant: '<S202>/pose'

    rtb_Elementproduct_o[0] = USV_P.Motor5_MotorPara.pose[1] *
      rtb_MatrixMultiply2[2];
    rtb_Elementproduct_o[1] = rtb_MatrixMultiply2[0] *
      USV_P.Motor5_MotorPara.pose[2];
    rtb_Elementproduct_o[2] = USV_P.Motor5_MotorPara.pose[0] *
      rtb_MatrixMultiply2[1];
    rtb_Elementproduct_o[3] = rtb_MatrixMultiply2[1] *
      USV_P.Motor5_MotorPara.pose[2];
    rtb_Elementproduct_o[4] = USV_P.Motor5_MotorPara.pose[0] *
      rtb_MatrixMultiply2[2];
    rtb_Elementproduct_o[5] = rtb_MatrixMultiply2[0] *
      USV_P.Motor5_MotorPara.pose[1];

    // Sum: '<S202>/Sum1' incorporates:
    //   Math: '<S202>/Transpose'
    //   Product: '<S202>/Product6'
    //   Sum: '<S267>/Add3'

    for (i = 0; i < 3; i++) {
      rtb_Add_kk[i] = ((USV_B.DCM_bj_d2[i + 3] * USV_B.sf__d.Mb[1] +
                        USV_B.DCM_bj_d2[i] * USV_B.sf__d.Mb[0]) +
                       USV_B.DCM_bj_d2[i + 6] * USV_B.sf__d.Mb[2]) +
        (rtb_Elementproduct_o[i] - rtb_Elementproduct_o[i + 3]);
    }

    // End of Sum: '<S202>/Sum1'
    rtb_Elementproduct_d[0] = rtb_MatrixMultiply2[0] * USV_P.Constant2_Value_az
      [0];
    rtb_Elementproduct_d[3] = USV_P.Constant2_Value_az[0] * rtb_Add_kk[0];
    rtb_Elementproduct_d[1] = rtb_MatrixMultiply2[1] * USV_P.Constant2_Value_az
      [1];
    rtb_Elementproduct_d[4] = USV_P.Constant2_Value_az[1] * rtb_Add_kk[1];
    rtb_Elementproduct_d[2] = rtb_MatrixMultiply2[2] * USV_P.Constant2_Value_az
      [2];
    rtb_Elementproduct_d[5] = USV_P.Constant2_Value_az[2] * rtb_Add_kk[2];
  } else {
    for (i = 0; i < 6; i++) {
      rtb_Elementproduct_d[i] = USV_P.Constant1_Value_my[i];
    }
  }

  // End of Switch: '<S202>/Switch1'
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // Trigonometry: '<S283>/sincos' incorporates:
    //   Constant: '<S203>/pose: 1 * 6'

    rtb_sincos_o1_h[0] = std::sin(USV_P.Motor6_MotorPara.pose[3]);
    rtb_sincos_o2_k[0] = std::cos(USV_P.Motor6_MotorPara.pose[3]);
    rtb_sincos_o1_h[1] = std::sin(USV_P.Motor6_MotorPara.pose[4]);
    rtb_sincos_o2_k[1] = std::cos(USV_P.Motor6_MotorPara.pose[4]);
    rtb_sincos_o1_h[2] = std::sin(USV_P.Motor6_MotorPara.pose[5]);
    rtb_sincos_o2_k[2] = std::cos(USV_P.Motor6_MotorPara.pose[5]);

    // Product: '<S286>/u(5)*u(6)' incorporates:
    //   Concatenate: '<S295>/Vector Concatenate'

    USV_B.VectorConcatenate_l[0] = rtb_sincos_o2_k[1] * rtb_sincos_o2_k[2];

    // Product: '<S289>/u(6)*u(1)*u(2)' incorporates:
    //   Product: '<S293>/u(1)*u(6)'

    rtb_Switch1_h = rtb_sincos_o1_h[0] * rtb_sincos_o2_k[2];

    // Sum: '<S289>/Sum' incorporates:
    //   Concatenate: '<S295>/Vector Concatenate'
    //   Product: '<S289>/u(3)*u(4)'
    //   Product: '<S289>/u(6)*u(1)*u(2)'

    USV_B.VectorConcatenate_l[1] = rtb_Switch1_h * rtb_sincos_o1_h[1] -
      rtb_sincos_o2_k[0] * rtb_sincos_o1_h[2];

    // Sum: '<S292>/Sum' incorporates:
    //   Concatenate: '<S295>/Vector Concatenate'
    //   Product: '<S292>/u(1)*u(3)'
    //   Product: '<S292>/u(2)*u(4)*u(6)'

    USV_B.VectorConcatenate_l[2] = rtb_sincos_o2_k[0] * rtb_sincos_o1_h[1] *
      rtb_sincos_o2_k[2] + rtb_sincos_o1_h[0] * rtb_sincos_o1_h[2];

    // Product: '<S287>/u(3)*u(5)' incorporates:
    //   Concatenate: '<S295>/Vector Concatenate'

    USV_B.VectorConcatenate_l[3] = rtb_sincos_o2_k[1] * rtb_sincos_o1_h[2];

    // Sum: '<S290>/Sum' incorporates:
    //   Concatenate: '<S295>/Vector Concatenate'
    //   Product: '<S290>/u(1)*u(2)*u(3)'
    //   Product: '<S290>/u(4)*u(6)'

    USV_B.VectorConcatenate_l[4] = rtb_sincos_o1_h[0] * rtb_sincos_o1_h[1] *
      rtb_sincos_o1_h[2] + rtb_sincos_o2_k[0] * rtb_sincos_o2_k[2];

    // Sum: '<S293>/Sum' incorporates:
    //   Concatenate: '<S295>/Vector Concatenate'
    //   Product: '<S293>/u(2)*u(3)*u(4)'

    USV_B.VectorConcatenate_l[5] = rtb_sincos_o1_h[1] * rtb_sincos_o1_h[2] *
      rtb_sincos_o2_k[0] - rtb_Switch1_h;

    // UnaryMinus: '<S288>/Unary Minus' incorporates:
    //   Concatenate: '<S295>/Vector Concatenate'

    USV_B.VectorConcatenate_l[6] = -rtb_sincos_o1_h[1];

    // Product: '<S291>/u(1)*u(5)' incorporates:
    //   Concatenate: '<S295>/Vector Concatenate'

    USV_B.VectorConcatenate_l[7] = rtb_sincos_o1_h[0] * rtb_sincos_o2_k[1];

    // Product: '<S294>/u(4)*u(5)' incorporates:
    //   Concatenate: '<S295>/Vector Concatenate'

    USV_B.VectorConcatenate_l[8] = rtb_sincos_o2_k[0] * rtb_sincos_o2_k[1];
    for (i = 0; i < 3; i++) {
      // Math: '<S203>/Transpose' incorporates:
      //   Concatenate: '<S295>/Vector Concatenate'

      USV_B.DCM_bj_a[3 * i] = USV_B.VectorConcatenate_l[i];
      USV_B.DCM_bj_a[3 * i + 1] = USV_B.VectorConcatenate_l[i + 3];
      USV_B.DCM_bj_a[3 * i + 2] = USV_B.VectorConcatenate_l[i + 6];
    }

    // Switch: '<S203>/Switch' incorporates:
    //   Constant: '<S203>/Constant'
    //   Constant: '<S203>/isEnable'

    if (USV_P.Motor6_MotorPara.isEnable) {
      rtb_Product_gy = USV_B.y_k[5];
    } else {
      rtb_Product_gy = USV_P.Constant_Value_jw;
    }

    // End of Switch: '<S203>/Switch'

    // MinMax: '<S203>/MinMax' incorporates:
    //   Constant: '<S203>/maxRotVelocity'

    if ((!(rtb_Product_gy <= USV_P.Motor6_MotorPara.maxRotVelocity)) &&
        (!rtIsNaN(USV_P.Motor6_MotorPara.maxRotVelocity))) {
      rtb_Product_gy = USV_P.Motor6_MotorPara.maxRotVelocity;
    }

    // End of MinMax: '<S203>/MinMax'

    // MATLAB Function: '<S203>/MATLAB Function1' incorporates:
    //   Clock: '<S203>/Clock'
    //   Constant: '<S203>/timeConstantDown'
    //   Constant: '<S203>/timeConstantUp'

    USV_MATLABFunction1(USV_P.Motor6_MotorPara.timeConstantUp,
                        USV_P.Motor6_MotorPara.timeConstantDown, rtb_Product_gy,
                        (&USV_M)->Timing.t[0], &USV_B.sf_MATLABFunction1_j,
                        &USV_DW.sf_MATLABFunction1_j);

    // Product: '<S203>/Divide' incorporates:
    //   Constant: '<S203>/rotorVelocitySlowdownSim1'
    //   Constant: '<S203>/turningDirection'

    USV_B.Divide_hs = USV_B.sf_MATLABFunction1_j.outputState *
      USV_P.Motor6_MotorPara.turningDirection /
      USV_P.Motor6_MotorPara.rotorVelocitySlowdownSim;
  }

  // DataTypeConversion: '<S5>/Data Type Conversion' incorporates:
  //   Constant: '<S203>/Constant3'
  //   Integrator: '<S9>/p,q,r '
  //   Product: '<S203>/Product3'

  rtb_DataTypeConversion[0] = USV_X.pqr_CSTATE[0] * USV_P.Constant3_Value_p2[0];
  rtb_DataTypeConversion[1] = USV_X.pqr_CSTATE[1] * USV_P.Constant3_Value_p2[1];
  rtb_DataTypeConversion[2] = USV_X.pqr_CSTATE[2] * USV_P.Constant3_Value_p2[2];

  // Product: '<S281>/Element product' incorporates:
  //   Constant: '<S203>/pose: 1 * 6'

  rtb_Elementproduct_o[2] = rtb_DataTypeConversion[0] *
    USV_P.Motor6_MotorPara.pose[1];
  rtb_Elementproduct_o[4] = rtb_DataTypeConversion[0] *
    USV_P.Motor6_MotorPara.pose[2];
  rtb_Elementproduct_o[5] = USV_P.Motor6_MotorPara.pose[0] *
    rtb_DataTypeConversion[1];

  // DataTypeConversion: '<S5>/Data Type Conversion' incorporates:
  //   Constant: '<S203>/Constant3'
  //   Constant: '<S203>/pose: 1 * 6'
  //   Product: '<S203>/Product'
  //   Product: '<S281>/Element product'
  //   Sum: '<S203>/Sum'
  //   Sum: '<S281>/Add3'

  rtb_DataTypeConversion[0] = rtb_DataTypeConversion[1] *
    USV_P.Motor6_MotorPara.pose[2] - USV_P.Motor6_MotorPara.pose[1] *
    rtb_DataTypeConversion[2];
  rtb_DataTypeConversion[0] += USV_P.Constant3_Value_p2[0] * UnitConversion_i[0];
  rtb_DataTypeConversion[1] = USV_P.Motor6_MotorPara.pose[0] *
    rtb_DataTypeConversion[2] - rtb_Elementproduct_o[4];
  rtb_DataTypeConversion[1] += USV_P.Constant3_Value_p2[1] * UnitConversion_i[1];
  rtb_DataTypeConversion[2] = rtb_Elementproduct_o[2] - rtb_Elementproduct_o[5];
  rtb_DataTypeConversion[2] += USV_P.Constant3_Value_p2[2] * UnitConversion_i[2];
  for (i = 0; i < 3; i++) {
    // Product: '<S203>/Product4' incorporates:
    //   Concatenate: '<S295>/Vector Concatenate'
    //   DataTypeConversion: '<S5>/Data Type Conversion'

    rtb_MatrixMultiply2[i] = (USV_B.VectorConcatenate_l[i + 3] *
      rtb_DataTypeConversion[1] + USV_B.VectorConcatenate_l[i] *
      rtb_DataTypeConversion[0]) + USV_B.VectorConcatenate_l[i + 6] *
      rtb_DataTypeConversion[2];
  }

  // MATLAB Function: '<S203>/���ģ��' incorporates:
  //   Constant: '<S203>/momentConstant'
  //   Constant: '<S203>/motorConstant'
  //   Constant: '<S203>/reversible'
  //   Constant: '<S203>/rollingMomentCoefficient'
  //   Constant: '<S203>/rotorDragCoefficient'
  //   Constant: '<S203>/rotorVelocitySlowdownSim'
  //   Constant: '<S203>/turningDirection1'

  USV_u(USV_B.Divide_hs, rtb_MatrixMultiply2,
        USV_P.Motor6_MotorPara.turningDirection,
        USV_P.Motor6_MotorPara.rotorVelocitySlowdownSim,
        USV_P.Motor6_MotorPara.motorConstant,
        USV_P.Motor6_MotorPara.momentConstant,
        USV_P.Motor6_MotorPara.rotorDragCoefficient,
        USV_P.Motor6_MotorPara.rollingMomentCoefficient,
        USV_P.Motor6_MotorPara.reversible, &USV_B.sf__h);

  // Switch: '<S203>/Switch1' incorporates:
  //   Constant: '<S203>/Constant1'
  //   Constant: '<S203>/Constant2'
  //   Constant: '<S203>/isEnable'
  //   Product: '<S203>/Product2'
  //   Product: '<S203>/Product5'

  if (USV_P.Motor6_MotorPara.isEnable) {
    // Product: '<S203>/Product1' incorporates:
    //   Math: '<S203>/Transpose'

    for (i = 0; i < 3; i++) {
      rtb_MatrixMultiply2[i] = (USV_B.DCM_bj_a[i + 3] * USV_B.sf__h.Fb[1] +
        USV_B.DCM_bj_a[i] * USV_B.sf__h.Fb[0]) + USV_B.DCM_bj_a[i + 6] *
        USV_B.sf__h.Fb[2];
    }

    // End of Product: '<S203>/Product1'

    // Product: '<S282>/Element product' incorporates:
    //   Constant: '<S203>/pose'

    rtb_Elementproduct_fe[0] = USV_P.Motor6_MotorPara.pose[1] *
      rtb_MatrixMultiply2[2];
    rtb_Elementproduct_fe[1] = rtb_MatrixMultiply2[0] *
      USV_P.Motor6_MotorPara.pose[2];
    rtb_Elementproduct_fe[2] = USV_P.Motor6_MotorPara.pose[0] *
      rtb_MatrixMultiply2[1];
    rtb_Elementproduct_fe[3] = rtb_MatrixMultiply2[1] *
      USV_P.Motor6_MotorPara.pose[2];
    rtb_Elementproduct_fe[4] = USV_P.Motor6_MotorPara.pose[0] *
      rtb_MatrixMultiply2[2];
    rtb_Elementproduct_fe[5] = rtb_MatrixMultiply2[0] *
      USV_P.Motor6_MotorPara.pose[1];

    // Sum: '<S203>/Sum1' incorporates:
    //   Math: '<S203>/Transpose'
    //   Product: '<S203>/Product6'
    //   Sum: '<S282>/Add3'

    for (i = 0; i < 3; i++) {
      rtb_Add_kk[i] = ((USV_B.DCM_bj_a[i + 3] * USV_B.sf__h.Mb[1] +
                        USV_B.DCM_bj_a[i] * USV_B.sf__h.Mb[0]) +
                       USV_B.DCM_bj_a[i + 6] * USV_B.sf__h.Mb[2]) +
        (rtb_Elementproduct_fe[i] - rtb_Elementproduct_fe[i + 3]);
    }

    // End of Sum: '<S203>/Sum1'
    rtb_Elementproduct_o[0] = rtb_MatrixMultiply2[0] *
      USV_P.Constant2_Value_hcw[0];
    rtb_Elementproduct_o[3] = USV_P.Constant2_Value_hcw[0] * rtb_Add_kk[0];
    rtb_Elementproduct_o[1] = rtb_MatrixMultiply2[1] *
      USV_P.Constant2_Value_hcw[1];
    rtb_Elementproduct_o[4] = USV_P.Constant2_Value_hcw[1] * rtb_Add_kk[1];
    rtb_Elementproduct_o[2] = rtb_MatrixMultiply2[2] *
      USV_P.Constant2_Value_hcw[2];
    rtb_Elementproduct_o[5] = USV_P.Constant2_Value_hcw[2] * rtb_Add_kk[2];
  } else {
    for (i = 0; i < 6; i++) {
      rtb_Elementproduct_o[i] = USV_P.Constant1_Value_hx[i];
    }
  }

  // End of Switch: '<S203>/Switch1'
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // Trigonometry: '<S298>/sincos' incorporates:
    //   Constant: '<S204>/pose: 1 * 6'

    rtb_sincos_o1_h[0] = std::sin(USV_P.Motor7_MotorPara.pose[3]);
    rtb_sincos_o2_k[0] = std::cos(USV_P.Motor7_MotorPara.pose[3]);
    rtb_sincos_o1_h[1] = std::sin(USV_P.Motor7_MotorPara.pose[4]);
    rtb_sincos_o2_k[1] = std::cos(USV_P.Motor7_MotorPara.pose[4]);
    rtb_sincos_o1_h[2] = std::sin(USV_P.Motor7_MotorPara.pose[5]);
    rtb_sincos_o2_k[2] = std::cos(USV_P.Motor7_MotorPara.pose[5]);

    // Product: '<S301>/u(5)*u(6)' incorporates:
    //   Concatenate: '<S310>/Vector Concatenate'

    USV_B.VectorConcatenate_h[0] = rtb_sincos_o2_k[1] * rtb_sincos_o2_k[2];

    // Product: '<S304>/u(6)*u(1)*u(2)' incorporates:
    //   Product: '<S308>/u(1)*u(6)'

    rtb_Switch1_h = rtb_sincos_o1_h[0] * rtb_sincos_o2_k[2];

    // Sum: '<S304>/Sum' incorporates:
    //   Concatenate: '<S310>/Vector Concatenate'
    //   Product: '<S304>/u(3)*u(4)'
    //   Product: '<S304>/u(6)*u(1)*u(2)'

    USV_B.VectorConcatenate_h[1] = rtb_Switch1_h * rtb_sincos_o1_h[1] -
      rtb_sincos_o2_k[0] * rtb_sincos_o1_h[2];

    // Sum: '<S307>/Sum' incorporates:
    //   Concatenate: '<S310>/Vector Concatenate'
    //   Product: '<S307>/u(1)*u(3)'
    //   Product: '<S307>/u(2)*u(4)*u(6)'

    USV_B.VectorConcatenate_h[2] = rtb_sincos_o2_k[0] * rtb_sincos_o1_h[1] *
      rtb_sincos_o2_k[2] + rtb_sincos_o1_h[0] * rtb_sincos_o1_h[2];

    // Product: '<S302>/u(3)*u(5)' incorporates:
    //   Concatenate: '<S310>/Vector Concatenate'

    USV_B.VectorConcatenate_h[3] = rtb_sincos_o2_k[1] * rtb_sincos_o1_h[2];

    // Sum: '<S305>/Sum' incorporates:
    //   Concatenate: '<S310>/Vector Concatenate'
    //   Product: '<S305>/u(1)*u(2)*u(3)'
    //   Product: '<S305>/u(4)*u(6)'

    USV_B.VectorConcatenate_h[4] = rtb_sincos_o1_h[0] * rtb_sincos_o1_h[1] *
      rtb_sincos_o1_h[2] + rtb_sincos_o2_k[0] * rtb_sincos_o2_k[2];

    // Sum: '<S308>/Sum' incorporates:
    //   Concatenate: '<S310>/Vector Concatenate'
    //   Product: '<S308>/u(2)*u(3)*u(4)'

    USV_B.VectorConcatenate_h[5] = rtb_sincos_o1_h[1] * rtb_sincos_o1_h[2] *
      rtb_sincos_o2_k[0] - rtb_Switch1_h;

    // UnaryMinus: '<S303>/Unary Minus' incorporates:
    //   Concatenate: '<S310>/Vector Concatenate'

    USV_B.VectorConcatenate_h[6] = -rtb_sincos_o1_h[1];

    // Product: '<S306>/u(1)*u(5)' incorporates:
    //   Concatenate: '<S310>/Vector Concatenate'

    USV_B.VectorConcatenate_h[7] = rtb_sincos_o1_h[0] * rtb_sincos_o2_k[1];

    // Product: '<S309>/u(4)*u(5)' incorporates:
    //   Concatenate: '<S310>/Vector Concatenate'

    USV_B.VectorConcatenate_h[8] = rtb_sincos_o2_k[0] * rtb_sincos_o2_k[1];
    for (i = 0; i < 3; i++) {
      // Math: '<S204>/Transpose' incorporates:
      //   Concatenate: '<S310>/Vector Concatenate'

      USV_B.DCM_bj_i[3 * i] = USV_B.VectorConcatenate_h[i];
      USV_B.DCM_bj_i[3 * i + 1] = USV_B.VectorConcatenate_h[i + 3];
      USV_B.DCM_bj_i[3 * i + 2] = USV_B.VectorConcatenate_h[i + 6];
    }

    // Switch: '<S204>/Switch' incorporates:
    //   Constant: '<S204>/Constant'
    //   Constant: '<S204>/isEnable'

    if (USV_P.Motor7_MotorPara.isEnable) {
      rtb_Product_gy = USV_B.y_k[6];
    } else {
      rtb_Product_gy = USV_P.Constant_Value_d1;
    }

    // End of Switch: '<S204>/Switch'

    // MinMax: '<S204>/MinMax' incorporates:
    //   Constant: '<S204>/maxRotVelocity'

    if ((!(rtb_Product_gy <= USV_P.Motor7_MotorPara.maxRotVelocity)) &&
        (!rtIsNaN(USV_P.Motor7_MotorPara.maxRotVelocity))) {
      rtb_Product_gy = USV_P.Motor7_MotorPara.maxRotVelocity;
    }

    // End of MinMax: '<S204>/MinMax'

    // MATLAB Function: '<S204>/MATLAB Function1' incorporates:
    //   Clock: '<S204>/Clock'
    //   Constant: '<S204>/timeConstantDown'
    //   Constant: '<S204>/timeConstantUp'

    USV_MATLABFunction1(USV_P.Motor7_MotorPara.timeConstantUp,
                        USV_P.Motor7_MotorPara.timeConstantDown, rtb_Product_gy,
                        (&USV_M)->Timing.t[0], &USV_B.sf_MATLABFunction1_i,
                        &USV_DW.sf_MATLABFunction1_i);

    // Product: '<S204>/Divide' incorporates:
    //   Constant: '<S204>/rotorVelocitySlowdownSim1'
    //   Constant: '<S204>/turningDirection'

    USV_B.Divide_f = USV_B.sf_MATLABFunction1_i.outputState *
      USV_P.Motor7_MotorPara.turningDirection /
      USV_P.Motor7_MotorPara.rotorVelocitySlowdownSim;
  }

  // DataTypeConversion: '<S5>/Data Type Conversion' incorporates:
  //   Constant: '<S204>/Constant3'
  //   Integrator: '<S9>/p,q,r '
  //   Product: '<S204>/Product3'

  rtb_DataTypeConversion[0] = USV_X.pqr_CSTATE[0] * USV_P.Constant3_Value_k[0];
  rtb_DataTypeConversion[1] = USV_X.pqr_CSTATE[1] * USV_P.Constant3_Value_k[1];
  rtb_DataTypeConversion[2] = USV_X.pqr_CSTATE[2] * USV_P.Constant3_Value_k[2];

  // Product: '<S296>/Element product' incorporates:
  //   Constant: '<S204>/pose: 1 * 6'

  rtb_Elementproduct_fe[2] = rtb_DataTypeConversion[0] *
    USV_P.Motor7_MotorPara.pose[1];
  rtb_Elementproduct_fe[4] = rtb_DataTypeConversion[0] *
    USV_P.Motor7_MotorPara.pose[2];
  rtb_Elementproduct_fe[5] = USV_P.Motor7_MotorPara.pose[0] *
    rtb_DataTypeConversion[1];

  // DataTypeConversion: '<S5>/Data Type Conversion' incorporates:
  //   Constant: '<S204>/Constant3'
  //   Constant: '<S204>/pose: 1 * 6'
  //   Product: '<S204>/Product'
  //   Product: '<S296>/Element product'
  //   Sum: '<S204>/Sum'
  //   Sum: '<S296>/Add3'

  rtb_DataTypeConversion[0] = rtb_DataTypeConversion[1] *
    USV_P.Motor7_MotorPara.pose[2] - USV_P.Motor7_MotorPara.pose[1] *
    rtb_DataTypeConversion[2];
  rtb_DataTypeConversion[0] += USV_P.Constant3_Value_k[0] * UnitConversion_i[0];
  rtb_DataTypeConversion[1] = USV_P.Motor7_MotorPara.pose[0] *
    rtb_DataTypeConversion[2] - rtb_Elementproduct_fe[4];
  rtb_DataTypeConversion[1] += USV_P.Constant3_Value_k[1] * UnitConversion_i[1];
  rtb_DataTypeConversion[2] = rtb_Elementproduct_fe[2] - rtb_Elementproduct_fe[5];
  rtb_DataTypeConversion[2] += USV_P.Constant3_Value_k[2] * UnitConversion_i[2];
  for (i = 0; i < 3; i++) {
    // Product: '<S204>/Product4' incorporates:
    //   Concatenate: '<S310>/Vector Concatenate'
    //   DataTypeConversion: '<S5>/Data Type Conversion'

    rtb_MatrixMultiply2[i] = (USV_B.VectorConcatenate_h[i + 3] *
      rtb_DataTypeConversion[1] + USV_B.VectorConcatenate_h[i] *
      rtb_DataTypeConversion[0]) + USV_B.VectorConcatenate_h[i + 6] *
      rtb_DataTypeConversion[2];
  }

  // MATLAB Function: '<S204>/���ģ��' incorporates:
  //   Constant: '<S204>/momentConstant'
  //   Constant: '<S204>/motorConstant'
  //   Constant: '<S204>/reversible'
  //   Constant: '<S204>/rollingMomentCoefficient'
  //   Constant: '<S204>/rotorDragCoefficient'
  //   Constant: '<S204>/rotorVelocitySlowdownSim'
  //   Constant: '<S204>/turningDirection1'

  USV_u(USV_B.Divide_f, rtb_MatrixMultiply2,
        USV_P.Motor7_MotorPara.turningDirection,
        USV_P.Motor7_MotorPara.rotorVelocitySlowdownSim,
        USV_P.Motor7_MotorPara.motorConstant,
        USV_P.Motor7_MotorPara.momentConstant,
        USV_P.Motor7_MotorPara.rotorDragCoefficient,
        USV_P.Motor7_MotorPara.rollingMomentCoefficient,
        USV_P.Motor7_MotorPara.reversible, &USV_B.sf__c);

  // Switch: '<S204>/Switch1' incorporates:
  //   Constant: '<S204>/Constant1'
  //   Constant: '<S204>/Constant2'
  //   Constant: '<S204>/isEnable'
  //   Product: '<S204>/Product2'
  //   Product: '<S204>/Product5'

  if (USV_P.Motor7_MotorPara.isEnable) {
    // Product: '<S204>/Product1' incorporates:
    //   Math: '<S204>/Transpose'

    for (i = 0; i < 3; i++) {
      rtb_MatrixMultiply2[i] = (USV_B.DCM_bj_i[i + 3] * USV_B.sf__c.Fb[1] +
        USV_B.DCM_bj_i[i] * USV_B.sf__c.Fb[0]) + USV_B.DCM_bj_i[i + 6] *
        USV_B.sf__c.Fb[2];
    }

    // End of Product: '<S204>/Product1'

    // Product: '<S297>/Element product' incorporates:
    //   Constant: '<S204>/pose'

    rtb_Elementproduct_j[0] = USV_P.Motor7_MotorPara.pose[1] *
      rtb_MatrixMultiply2[2];
    rtb_Elementproduct_j[1] = rtb_MatrixMultiply2[0] *
      USV_P.Motor7_MotorPara.pose[2];
    rtb_Elementproduct_j[2] = USV_P.Motor7_MotorPara.pose[0] *
      rtb_MatrixMultiply2[1];
    rtb_Elementproduct_j[3] = rtb_MatrixMultiply2[1] *
      USV_P.Motor7_MotorPara.pose[2];
    rtb_Elementproduct_j[4] = USV_P.Motor7_MotorPara.pose[0] *
      rtb_MatrixMultiply2[2];
    rtb_Elementproduct_j[5] = rtb_MatrixMultiply2[0] *
      USV_P.Motor7_MotorPara.pose[1];

    // Sum: '<S204>/Sum1' incorporates:
    //   Math: '<S204>/Transpose'
    //   Product: '<S204>/Product6'
    //   Sum: '<S297>/Add3'

    for (i = 0; i < 3; i++) {
      rtb_Add_kk[i] = ((USV_B.DCM_bj_i[i + 3] * USV_B.sf__c.Mb[1] +
                        USV_B.DCM_bj_i[i] * USV_B.sf__c.Mb[0]) +
                       USV_B.DCM_bj_i[i + 6] * USV_B.sf__c.Mb[2]) +
        (rtb_Elementproduct_j[i] - rtb_Elementproduct_j[i + 3]);
    }

    // End of Sum: '<S204>/Sum1'
    rtb_Elementproduct_fe[0] = rtb_MatrixMultiply2[0] *
      USV_P.Constant2_Value_ad[0];
    rtb_Elementproduct_fe[3] = USV_P.Constant2_Value_ad[0] * rtb_Add_kk[0];
    rtb_Elementproduct_fe[1] = rtb_MatrixMultiply2[1] *
      USV_P.Constant2_Value_ad[1];
    rtb_Elementproduct_fe[4] = USV_P.Constant2_Value_ad[1] * rtb_Add_kk[1];
    rtb_Elementproduct_fe[2] = rtb_MatrixMultiply2[2] *
      USV_P.Constant2_Value_ad[2];
    rtb_Elementproduct_fe[5] = USV_P.Constant2_Value_ad[2] * rtb_Add_kk[2];
  } else {
    for (i = 0; i < 6; i++) {
      rtb_Elementproduct_fe[i] = USV_P.Constant1_Value_a[i];
    }
  }

  // End of Switch: '<S204>/Switch1'
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // Trigonometry: '<S313>/sincos' incorporates:
    //   Constant: '<S205>/pose: 1 * 6'

    rtb_sincos_o1_h[0] = std::sin(USV_P.Motor8_MotorPara.pose[3]);
    rtb_sincos_o2_k[0] = std::cos(USV_P.Motor8_MotorPara.pose[3]);
    rtb_sincos_o1_h[1] = std::sin(USV_P.Motor8_MotorPara.pose[4]);
    rtb_sincos_o2_k[1] = std::cos(USV_P.Motor8_MotorPara.pose[4]);
    rtb_sincos_o1_h[2] = std::sin(USV_P.Motor8_MotorPara.pose[5]);
    rtb_sincos_o2_k[2] = std::cos(USV_P.Motor8_MotorPara.pose[5]);

    // Product: '<S316>/u(5)*u(6)' incorporates:
    //   Concatenate: '<S325>/Vector Concatenate'

    USV_B.VectorConcatenate_m3[0] = rtb_sincos_o2_k[1] * rtb_sincos_o2_k[2];

    // Product: '<S319>/u(6)*u(1)*u(2)' incorporates:
    //   Product: '<S323>/u(1)*u(6)'

    rtb_Switch1_h = rtb_sincos_o1_h[0] * rtb_sincos_o2_k[2];

    // Sum: '<S319>/Sum' incorporates:
    //   Concatenate: '<S325>/Vector Concatenate'
    //   Product: '<S319>/u(3)*u(4)'
    //   Product: '<S319>/u(6)*u(1)*u(2)'

    USV_B.VectorConcatenate_m3[1] = rtb_Switch1_h * rtb_sincos_o1_h[1] -
      rtb_sincos_o2_k[0] * rtb_sincos_o1_h[2];

    // Sum: '<S322>/Sum' incorporates:
    //   Concatenate: '<S325>/Vector Concatenate'
    //   Product: '<S322>/u(1)*u(3)'
    //   Product: '<S322>/u(2)*u(4)*u(6)'

    USV_B.VectorConcatenate_m3[2] = rtb_sincos_o2_k[0] * rtb_sincos_o1_h[1] *
      rtb_sincos_o2_k[2] + rtb_sincos_o1_h[0] * rtb_sincos_o1_h[2];

    // Product: '<S317>/u(3)*u(5)' incorporates:
    //   Concatenate: '<S325>/Vector Concatenate'

    USV_B.VectorConcatenate_m3[3] = rtb_sincos_o2_k[1] * rtb_sincos_o1_h[2];

    // Sum: '<S320>/Sum' incorporates:
    //   Concatenate: '<S325>/Vector Concatenate'
    //   Product: '<S320>/u(1)*u(2)*u(3)'
    //   Product: '<S320>/u(4)*u(6)'

    USV_B.VectorConcatenate_m3[4] = rtb_sincos_o1_h[0] * rtb_sincos_o1_h[1] *
      rtb_sincos_o1_h[2] + rtb_sincos_o2_k[0] * rtb_sincos_o2_k[2];

    // Sum: '<S323>/Sum' incorporates:
    //   Concatenate: '<S325>/Vector Concatenate'
    //   Product: '<S323>/u(2)*u(3)*u(4)'

    USV_B.VectorConcatenate_m3[5] = rtb_sincos_o1_h[1] * rtb_sincos_o1_h[2] *
      rtb_sincos_o2_k[0] - rtb_Switch1_h;

    // UnaryMinus: '<S318>/Unary Minus' incorporates:
    //   Concatenate: '<S325>/Vector Concatenate'

    USV_B.VectorConcatenate_m3[6] = -rtb_sincos_o1_h[1];

    // Product: '<S321>/u(1)*u(5)' incorporates:
    //   Concatenate: '<S325>/Vector Concatenate'

    USV_B.VectorConcatenate_m3[7] = rtb_sincos_o1_h[0] * rtb_sincos_o2_k[1];

    // Product: '<S324>/u(4)*u(5)' incorporates:
    //   Concatenate: '<S325>/Vector Concatenate'

    USV_B.VectorConcatenate_m3[8] = rtb_sincos_o2_k[0] * rtb_sincos_o2_k[1];
    for (i = 0; i < 3; i++) {
      // Math: '<S205>/Transpose' incorporates:
      //   Concatenate: '<S325>/Vector Concatenate'

      USV_B.DCM_bj_c[3 * i] = USV_B.VectorConcatenate_m3[i];
      USV_B.DCM_bj_c[3 * i + 1] = USV_B.VectorConcatenate_m3[i + 3];
      USV_B.DCM_bj_c[3 * i + 2] = USV_B.VectorConcatenate_m3[i + 6];
    }

    // Switch: '<S205>/Switch' incorporates:
    //   Constant: '<S205>/Constant'
    //   Constant: '<S205>/isEnable'

    if (USV_P.Motor8_MotorPara.isEnable) {
      rtb_Product_gy = USV_B.y_k[7];
    } else {
      rtb_Product_gy = USV_P.Constant_Value_c;
    }

    // End of Switch: '<S205>/Switch'

    // MinMax: '<S205>/MinMax' incorporates:
    //   Constant: '<S205>/maxRotVelocity'

    if ((!(rtb_Product_gy <= USV_P.Motor8_MotorPara.maxRotVelocity)) &&
        (!rtIsNaN(USV_P.Motor8_MotorPara.maxRotVelocity))) {
      rtb_Product_gy = USV_P.Motor8_MotorPara.maxRotVelocity;
    }

    // End of MinMax: '<S205>/MinMax'

    // MATLAB Function: '<S205>/MATLAB Function1' incorporates:
    //   Clock: '<S205>/Clock'
    //   Constant: '<S205>/timeConstantDown'
    //   Constant: '<S205>/timeConstantUp'

    USV_MATLABFunction1(USV_P.Motor8_MotorPara.timeConstantUp,
                        USV_P.Motor8_MotorPara.timeConstantDown, rtb_Product_gy,
                        (&USV_M)->Timing.t[0], &USV_B.sf_MATLABFunction1_n,
                        &USV_DW.sf_MATLABFunction1_n);

    // Product: '<S205>/Divide' incorporates:
    //   Constant: '<S205>/rotorVelocitySlowdownSim1'
    //   Constant: '<S205>/turningDirection'

    USV_B.Divide_k = USV_B.sf_MATLABFunction1_n.outputState *
      USV_P.Motor8_MotorPara.turningDirection /
      USV_P.Motor8_MotorPara.rotorVelocitySlowdownSim;
  }

  // DataTypeConversion: '<S5>/Data Type Conversion' incorporates:
  //   Constant: '<S205>/Constant3'
  //   Integrator: '<S9>/p,q,r '
  //   Product: '<S205>/Product3'

  rtb_DataTypeConversion[0] = USV_X.pqr_CSTATE[0] * USV_P.Constant3_Value_f[0];
  rtb_DataTypeConversion[1] = USV_X.pqr_CSTATE[1] * USV_P.Constant3_Value_f[1];
  rtb_DataTypeConversion[2] = USV_X.pqr_CSTATE[2] * USV_P.Constant3_Value_f[2];

  // Product: '<S311>/Element product' incorporates:
  //   Constant: '<S205>/pose: 1 * 6'

  rtb_Elementproduct_j[2] = rtb_DataTypeConversion[0] *
    USV_P.Motor8_MotorPara.pose[1];
  rtb_Elementproduct_j[4] = rtb_DataTypeConversion[0] *
    USV_P.Motor8_MotorPara.pose[2];
  rtb_Elementproduct_j[5] = USV_P.Motor8_MotorPara.pose[0] *
    rtb_DataTypeConversion[1];

  // DataTypeConversion: '<S5>/Data Type Conversion' incorporates:
  //   Constant: '<S205>/Constant3'
  //   Constant: '<S205>/pose: 1 * 6'
  //   Product: '<S205>/Product'
  //   Product: '<S311>/Element product'
  //   Sum: '<S205>/Sum'
  //   Sum: '<S311>/Add3'

  rtb_DataTypeConversion[0] = rtb_DataTypeConversion[1] *
    USV_P.Motor8_MotorPara.pose[2] - USV_P.Motor8_MotorPara.pose[1] *
    rtb_DataTypeConversion[2];
  rtb_DataTypeConversion[0] += USV_P.Constant3_Value_f[0] * UnitConversion_i[0];
  rtb_DataTypeConversion[1] = USV_P.Motor8_MotorPara.pose[0] *
    rtb_DataTypeConversion[2] - rtb_Elementproduct_j[4];
  rtb_DataTypeConversion[1] += USV_P.Constant3_Value_f[1] * UnitConversion_i[1];
  rtb_DataTypeConversion[2] = rtb_Elementproduct_j[2] - rtb_Elementproduct_j[5];
  rtb_DataTypeConversion[2] += USV_P.Constant3_Value_f[2] * UnitConversion_i[2];
  for (i = 0; i < 3; i++) {
    // Product: '<S205>/Product4' incorporates:
    //   Concatenate: '<S325>/Vector Concatenate'
    //   DataTypeConversion: '<S5>/Data Type Conversion'

    rtb_sincos_o2_k[i] = (USV_B.VectorConcatenate_m3[i + 3] *
                          rtb_DataTypeConversion[1] +
                          USV_B.VectorConcatenate_m3[i] *
                          rtb_DataTypeConversion[0]) +
      USV_B.VectorConcatenate_m3[i + 6] * rtb_DataTypeConversion[2];
  }

  // MATLAB Function: '<S205>/���ģ��' incorporates:
  //   Constant: '<S205>/momentConstant'
  //   Constant: '<S205>/motorConstant'
  //   Constant: '<S205>/reversible'
  //   Constant: '<S205>/rollingMomentCoefficient'
  //   Constant: '<S205>/rotorDragCoefficient'
  //   Constant: '<S205>/rotorVelocitySlowdownSim'
  //   Constant: '<S205>/turningDirection1'

  USV_u(USV_B.Divide_k, rtb_sincos_o2_k, USV_P.Motor8_MotorPara.turningDirection,
        USV_P.Motor8_MotorPara.rotorVelocitySlowdownSim,
        USV_P.Motor8_MotorPara.motorConstant,
        USV_P.Motor8_MotorPara.momentConstant,
        USV_P.Motor8_MotorPara.rotorDragCoefficient,
        USV_P.Motor8_MotorPara.rollingMomentCoefficient,
        USV_P.Motor8_MotorPara.reversible, &USV_B.sf__i);

  // Switch: '<S205>/Switch1' incorporates:
  //   Constant: '<S205>/Constant1'
  //   Constant: '<S205>/Constant2'
  //   Constant: '<S205>/isEnable'
  //   Product: '<S205>/Product2'
  //   Product: '<S205>/Product5'

  if (USV_P.Motor8_MotorPara.isEnable) {
    // Product: '<S205>/Product1' incorporates:
    //   Math: '<S205>/Transpose'

    for (i = 0; i < 3; i++) {
      rtb_sincos_o2_k[i] = (USV_B.DCM_bj_c[i + 3] * USV_B.sf__i.Fb[1] +
                            USV_B.DCM_bj_c[i] * USV_B.sf__i.Fb[0]) +
        USV_B.DCM_bj_c[i + 6] * USV_B.sf__i.Fb[2];
    }

    // End of Product: '<S205>/Product1'

    // Product: '<S312>/Element product' incorporates:
    //   Constant: '<S205>/pose'

    rtb_Elementproduct[0] = USV_P.Motor8_MotorPara.pose[1] * rtb_sincos_o2_k[2];
    rtb_Elementproduct[1] = rtb_sincos_o2_k[0] * USV_P.Motor8_MotorPara.pose[2];
    rtb_Elementproduct[2] = USV_P.Motor8_MotorPara.pose[0] * rtb_sincos_o2_k[1];
    rtb_Elementproduct[3] = rtb_sincos_o2_k[1] * USV_P.Motor8_MotorPara.pose[2];
    rtb_Elementproduct[4] = USV_P.Motor8_MotorPara.pose[0] * rtb_sincos_o2_k[2];
    rtb_Elementproduct[5] = rtb_sincos_o2_k[0] * USV_P.Motor8_MotorPara.pose[1];

    // Sum: '<S205>/Sum1' incorporates:
    //   Math: '<S205>/Transpose'
    //   Product: '<S205>/Product6'
    //   Sum: '<S312>/Add3'

    for (i = 0; i < 3; i++) {
      rtb_Add_kk[i] = ((USV_B.DCM_bj_c[i + 3] * USV_B.sf__i.Mb[1] +
                        USV_B.DCM_bj_c[i] * USV_B.sf__i.Mb[0]) +
                       USV_B.DCM_bj_c[i + 6] * USV_B.sf__i.Mb[2]) +
        (rtb_Elementproduct[i] - rtb_Elementproduct[i + 3]);
    }

    // End of Sum: '<S205>/Sum1'
    rtb_Elementproduct_j[0] = rtb_sincos_o2_k[0] * USV_P.Constant2_Value_l[0];
    rtb_Elementproduct_j[3] = USV_P.Constant2_Value_l[0] * rtb_Add_kk[0];
    rtb_Elementproduct_j[1] = rtb_sincos_o2_k[1] * USV_P.Constant2_Value_l[1];
    rtb_Elementproduct_j[4] = USV_P.Constant2_Value_l[1] * rtb_Add_kk[1];
    rtb_Elementproduct_j[2] = rtb_sincos_o2_k[2] * USV_P.Constant2_Value_l[2];
    rtb_Elementproduct_j[5] = USV_P.Constant2_Value_l[2] * rtb_Add_kk[2];
  } else {
    for (i = 0; i < 6; i++) {
      rtb_Elementproduct_j[i] = USV_P.Constant1_Value_oc[i];
    }
  }

  // End of Switch: '<S205>/Switch1'

  // MATLAB Function: '<S192>/Body AeroCenter' incorporates:
  //   Integrator: '<S9>/p,q,r '

  //  This is control effectiveness model, where Fb is the force produced by motors, Mb is 
  //  the moment produced by motors, and Fd is the resistance produced by the air. 
  //  The gyroscopic torque is not considered here.
  //  uavDearo ��������λ�ã�����Ϊ��
  // MATLAB Function 'Force and Moment Model/BoatWaterDrag/Body AeroCenter': '<S197>:1' 
  // Mfd=cross(uavDearo',Fd);
  // Mfd=[Fd(2)*uavDearo;-Fd(1)*uavDearo;0];
  // Md=Mfd+Md;
  //   CCm=4.72e-3;
  //   Md=-CCm*wb.*abs(wb)*0.5;%0.3
  //   Md= Mfd+Md;
  //  -----------------------------
  //  Fd = -Cd'.*Vb.*abs(Vb);
  //  Md=-CCm.*wb.*abs(wb);
  //  -----------------------------
  // '<S197>:1:19' Fd=[0;0;0];
  // '<S197>:1:20' Md=[0;0;0];
  // '<S197>:1:21' V=[Vb(1);Vb(2);Vb(3);wb(1);wb(2);wb(3)];
  // ���ٶȺͽ��ٶ�
  // ˮ������
  // '<S197>:1:24' FkDvec = -1.0 * Dmat * V;
  rtb_Elementproduct[0] = UnitConversion_i[0];
  rtb_Elementproduct[1] = UnitConversion_i[1];
  rtb_Elementproduct[2] = UnitConversion_i[2];
  rtb_Elementproduct[3] = USV_X.pqr_CSTATE[0];
  rtb_Elementproduct[4] = USV_X.pqr_CSTATE[1];
  rtb_Elementproduct[5] = USV_X.pqr_CSTATE[2];
  for (i = 0; i < 6; i++) {
    // Sum: '<S193>/Add'
    rtb_Add_l[i] = ((((((rtb_Add_l[i] + rtb_Elementproduct_cn[i]) +
                        rtb_Elementproduct_l[i]) + rtb_Elementproduct_cd[i]) +
                      rtb_Elementproduct_d[i]) + rtb_Elementproduct_o[i]) +
                    rtb_Elementproduct_fe[i]) + rtb_Elementproduct_j[i];

    // MATLAB Function: '<S192>/Body AeroCenter' incorporates:
    //   Constant: '<S192>/USVPara_Dmat'

    rtb_Elementproduct_cn[i] = 0.0;
  }

  // MATLAB Function: '<S192>/Body AeroCenter' incorporates:
  //   Constant: '<S192>/USVPara_Dmat'

  for (i = 0; i < 6; i++) {
    for (roll_sign = 0; roll_sign < 6; roll_sign++) {
      rtb_Elementproduct_cn[roll_sign] += -USV_P.USVPara.Dmat[6 * i + roll_sign]
        * rtb_Elementproduct[i];
    }
  }

  // DataTypeConversion: '<S5>/Data Type Conversion' incorporates:
  //   MATLAB Function: '<S192>/Body AeroCenter'
  //   Sum: '<S4>/Add1'

  // '<S197>:1:25' Fd=FkDvec(1:3);
  // '<S197>:1:26' Md=FkDvec(4:6);
  rtb_DataTypeConversion[0] = ((rtb_DataTypeConversion2[0] +
    rtb_IntegratorSecondOrderLimi_e[0]) + rtb_Add_l[0]) + rtb_Elementproduct_cn
    [0];

  // Product: '<S8>/Divide' incorporates:
  //   Constant: '<S8>/ModelParam.uavMass'

  rtb_MatrixMultiply2[0] = rtb_DataTypeConversion[0] / USV_P.ModelParam_uavMass;

  // Gain: '<S426>/Zero-Order Hold' incorporates:
  //   Integrator: '<S9>/p,q,r '

  rtb_sincos_o2_k[0] = USV_P.ZeroOrderHold_Gain * USV_X.pqr_CSTATE[0];

  // DataTypeConversion: '<S5>/Data Type Conversion' incorporates:
  //   MATLAB Function: '<S192>/Body AeroCenter'
  //   Sum: '<S4>/Add1'

  rtb_DataTypeConversion[1] = ((rtb_DataTypeConversion2[1] +
    rtb_IntegratorSecondOrderLimi_e[1]) + rtb_Add_l[1]) + rtb_Elementproduct_cn
    [1];

  // Product: '<S8>/Divide' incorporates:
  //   Constant: '<S8>/ModelParam.uavMass'

  rtb_MatrixMultiply2[1] = rtb_DataTypeConversion[1] / USV_P.ModelParam_uavMass;

  // Gain: '<S426>/Zero-Order Hold' incorporates:
  //   Integrator: '<S9>/p,q,r '

  rtb_sincos_o2_k[1] = USV_P.ZeroOrderHold_Gain * USV_X.pqr_CSTATE[1];

  // DataTypeConversion: '<S5>/Data Type Conversion' incorporates:
  //   MATLAB Function: '<S192>/Body AeroCenter'
  //   Sum: '<S4>/Add1'

  rtb_DataTypeConversion[2] = ((rtb_DataTypeConversion2[2] +
    rtb_IntegratorSecondOrderLimi_e[2]) + rtb_Add_l[2]) + rtb_Elementproduct_cn
    [2];

  // Product: '<S8>/Divide' incorporates:
  //   Constant: '<S8>/ModelParam.uavMass'
  //   Product: '<S9>/Product'

  rtb_Switch1_i = rtb_DataTypeConversion[2] / USV_P.ModelParam_uavMass;
  rtb_MatrixMultiply2[2] = rtb_Switch1_i;

  // Gain: '<S426>/Zero-Order Hold' incorporates:
  //   Integrator: '<S9>/p,q,r '

  rtb_sincos_o2_k[2] = USV_P.ZeroOrderHold_Gain * USV_X.pqr_CSTATE[2];
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // Gain: '<S426>/Gain' incorporates:
    //   Constant: '<S406>/center of gravity'
    //   Constant: '<S426>/wl_ins'
    //   Gain: '<S426>/Zero-Order Hold4'
    //   Sum: '<S426>/Sum7'

    USV_B.Gain_g[0] = (USV_P.ZeroOrderHold4_Gain * USV_P.centerofgravity_Value[0]
                       - USV_P.ThreeaxisInertialMeasurementU_j[0]) *
      USV_P.Gain_Gain_ka[0];
    USV_B.Gain_g[1] = (USV_P.ZeroOrderHold4_Gain * USV_P.centerofgravity_Value[1]
                       - USV_P.ThreeaxisInertialMeasurementU_j[1]) *
      USV_P.Gain_Gain_ka[1];
    USV_B.Gain_g[2] = (USV_P.ZeroOrderHold4_Gain * USV_P.centerofgravity_Value[2]
                       - USV_P.ThreeaxisInertialMeasurementU_j[2]) *
      USV_P.Gain_Gain_ka[2];
    for (i = 0; i < 3; i++) {
      // Concatenate: '<S12>/Vector Concatenate' incorporates:
      //   Constant: '<S12>/Constant1'
      //   Constant: '<S12>/Constant2'
      //   Selector: '<S11>/Selector1'

      rtb_VectorConcatenate_n[6 * i] = USV_P.ModelParam_uavJ[3 * i];
      roll_sign = 6 * i + 3;
      rtb_VectorConcatenate_n[roll_sign] = USV_P.Constant2_Value_m[3 * i];

      // Selector: '<S11>/Selector1' incorporates:
      //   Concatenate: '<S12>/Vector Concatenate'

      USV_B.Selector1[3 * i] = rtb_VectorConcatenate_n[roll_sign];

      // Concatenate: '<S12>/Vector Concatenate' incorporates:
      //   Constant: '<S12>/Constant1'
      //   Constant: '<S12>/Constant2'
      //   Selector: '<S11>/Selector1'

      roll_sign = 3 * i + 1;
      rtb_VectorConcatenate_n[6 * i + 1] = USV_P.ModelParam_uavJ[roll_sign];
      pitch_sign = 6 * i + 4;
      rtb_VectorConcatenate_n[pitch_sign] = USV_P.Constant2_Value_m[roll_sign];

      // Selector: '<S11>/Selector1' incorporates:
      //   Concatenate: '<S12>/Vector Concatenate'

      USV_B.Selector1[roll_sign] = rtb_VectorConcatenate_n[pitch_sign];

      // Concatenate: '<S12>/Vector Concatenate' incorporates:
      //   Constant: '<S12>/Constant1'
      //   Constant: '<S12>/Constant2'
      //   Selector: '<S11>/Selector1'

      roll_sign = 3 * i + 2;
      rtb_VectorConcatenate_n[6 * i + 2] = USV_P.ModelParam_uavJ[roll_sign];
      pitch_sign = 6 * i + 5;
      rtb_VectorConcatenate_n[pitch_sign] = USV_P.Constant2_Value_m[roll_sign];

      // Selector: '<S11>/Selector1' incorporates:
      //   Concatenate: '<S12>/Vector Concatenate'

      USV_B.Selector1[roll_sign] = rtb_VectorConcatenate_n[pitch_sign];
    }
  }

  // Product: '<S438>/k x j'
  rtb_q2dot = USV_B.Gain_g[1] * rtb_sincos_o2_k[2];

  // Sum: '<S434>/Sum' incorporates:
  //   Product: '<S437>/i x j'
  //   Product: '<S437>/j x k'
  //   Product: '<S437>/k x i'
  //   Product: '<S438>/i x k'
  //   Product: '<S438>/j x i'

  rtb_sincos_o1_h[0] = rtb_sincos_o2_k[1] * USV_B.Gain_g[2] - rtb_q2dot;
  rtb_sincos_o1_h[1] = USV_B.Gain_g[0] * rtb_sincos_o2_k[2] - rtb_sincos_o2_k[0]
    * USV_B.Gain_g[2];
  rtb_sincos_o1_h[2] = rtb_sincos_o2_k[0] * USV_B.Gain_g[1] - USV_B.Gain_g[0] *
    rtb_sincos_o2_k[1];

  // Sum: '<S433>/Sum' incorporates:
  //   Product: '<S435>/i x j'
  //   Product: '<S435>/j x k'
  //   Product: '<S435>/k x i'
  //   Product: '<S436>/i x k'
  //   Product: '<S436>/j x i'
  //   Product: '<S436>/k x j'

  rtb_sincos_o1_idx_0 = rtb_sincos_o1_h[1] * rtb_sincos_o2_k[2];
  rtb_Sum1_dx = rtb_sincos_o2_k[1] * rtb_sincos_o1_h[2];
  j = rtb_sincos_o1_h[0] * rtb_sincos_o2_k[2];
  rtb_Switch1_h = rtb_sincos_o2_k[0] * rtb_sincos_o1_h[1];
  rtb_Switch1_k = rtb_sincos_o2_k[0] * rtb_sincos_o1_h[2];
  rtb_Switch1_a = rtb_sincos_o1_h[0] * rtb_sincos_o2_k[1];

  // Product: '<S196>/k x j' incorporates:
  //   Constant: '<S4>/Constant1'

  rtb_q2dot = USV_P.BoatParam_cg * rtb_DataTypeConversion2[1];

  // Sum: '<S191>/Sum' incorporates:
  //   Constant: '<S4>/Constant'
  //   Product: '<S195>/j x k'

  rtb_sincos_o2_k[0] = USV_P.Constant_Value_ed[1] * rtb_DataTypeConversion2[2] -
    rtb_q2dot;

  // Product: '<S329>/k x j'
  rtb_q2dot = rtb_IntegratorSecondOrderLimi_e[1] * rtb_fuPos[2];

  // Sum: '<S433>/Sum'
  rtb_sincos_o1_h[0] = rtb_Sum1_dx - rtb_sincos_o1_idx_0;

  // Sum: '<S4>/Sum1' incorporates:
  //   MATLAB Function: '<S192>/Body AeroCenter'
  //   Product: '<S328>/j x k'
  //   Sum: '<S326>/Sum'

  rtb_sincos_o1_idx_0 = ((rtb_fuPos[1] * rtb_IntegratorSecondOrderLimi_e[2] -
    rtb_q2dot) + (rtb_sincos_o2_k[0] + rtb_Add_l[3])) + rtb_Elementproduct_cn[3];

  // Sum: '<S433>/Sum'
  rtb_sincos_o1_h[1] = j - rtb_Switch1_k;

  // Sum: '<S4>/Sum1' incorporates:
  //   Constant: '<S4>/Constant'
  //   Constant: '<S4>/Constant1'
  //   MATLAB Function: '<S192>/Body AeroCenter'
  //   Product: '<S195>/k x i'
  //   Product: '<S196>/i x k'
  //   Product: '<S328>/k x i'
  //   Product: '<S329>/i x k'
  //   Sum: '<S191>/Sum'
  //   Sum: '<S326>/Sum'

  rtb_Sum1_dx = (((USV_P.BoatParam_cg * rtb_DataTypeConversion2[0] -
                   USV_P.Constant_Value_ed[0] * rtb_DataTypeConversion2[2]) +
                  rtb_Add_l[4]) + (rtb_IntegratorSecondOrderLimi_e[0] *
    rtb_fuPos[2] - rtb_fuPos[0] * rtb_IntegratorSecondOrderLimi_e[2])) +
    rtb_Elementproduct_cn[4];

  // Sum: '<S433>/Sum'
  rtb_sincos_o1_h[2] = rtb_Switch1_h - rtb_Switch1_a;

  // Sum: '<S4>/Sum1' incorporates:
  //   Constant: '<S4>/Constant'
  //   MATLAB Function: '<S192>/Body AeroCenter'
  //   Product: '<S195>/i x j'
  //   Product: '<S196>/j x i'
  //   Product: '<S328>/i x j'
  //   Product: '<S329>/j x i'
  //   Sum: '<S191>/Sum'
  //   Sum: '<S326>/Sum'

  rtb_fcn3 = (((USV_P.Constant_Value_ed[0] * rtb_DataTypeConversion2[1] -
                rtb_DataTypeConversion2[0] * USV_P.Constant_Value_ed[1]) +
               rtb_Add_l[5]) + (rtb_fuPos[0] * rtb_IntegratorSecondOrderLimi_e[1]
    - rtb_IntegratorSecondOrderLimi_e[0] * rtb_fuPos[1])) +
    rtb_Elementproduct_cn[5];

  // Product: '<S45>/Product' incorporates:
  //   Integrator: '<S9>/p,q,r '
  //   SecondOrderIntegrator: '<S443>/Integrator, Second-Order Limited'
  //   Selector: '<S11>/Selector1'

  for (i = 0; i < 3; i++) {
    rtb_IntegratorSecondOrderLimi_e[i] = (USV_B.Selector1[i + 3] *
      USV_X.pqr_CSTATE[1] + USV_B.Selector1[i] * USV_X.pqr_CSTATE[0]) +
      USV_B.Selector1[i + 6] * USV_X.pqr_CSTATE[2];
  }

  // End of Product: '<S45>/Product'
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    for (i = 0; i < 3; i++) {
      // Selector: '<S11>/Selector' incorporates:
      //   Concatenate: '<S12>/Vector Concatenate'

      USV_B.Selector[3 * i] = rtb_VectorConcatenate_n[6 * i];
      USV_B.Selector[3 * i + 1] = rtb_VectorConcatenate_n[6 * i + 1];
      USV_B.Selector[3 * i + 2] = rtb_VectorConcatenate_n[6 * i + 2];
    }
  }

  // Product: '<S44>/Product' incorporates:
  //   DataTypeConversion: '<S5>/Data Type Conversion2'
  //   Integrator: '<S9>/p,q,r '
  //   Selector: '<S11>/Selector'

  for (i = 0; i < 3; i++) {
    rtb_DataTypeConversion2[i] = (USV_B.Selector[i + 3] * USV_X.pqr_CSTATE[1] +
      USV_B.Selector[i] * USV_X.pqr_CSTATE[0]) + USV_B.Selector[i + 6] *
      USV_X.pqr_CSTATE[2];
  }

  // End of Product: '<S44>/Product'

  // Product: '<S47>/k x j' incorporates:
  //   Integrator: '<S9>/p,q,r '

  rtb_q2dot = rtb_DataTypeConversion2[1] * USV_X.pqr_CSTATE[2];

  // Sum: '<S11>/Sum2' incorporates:
  //   Integrator: '<S9>/p,q,r '
  //   Product: '<S46>/i x j'
  //   Product: '<S46>/j x k'
  //   Product: '<S46>/k x i'
  //   Product: '<S47>/i x k'
  //   Product: '<S47>/j x i'
  //   Sum: '<S43>/Sum'

  rtb_sincos_o2_k[0] = (rtb_sincos_o1_idx_0 - rtb_IntegratorSecondOrderLimi_e[0])
    - (USV_X.pqr_CSTATE[1] * rtb_DataTypeConversion2[2] - rtb_q2dot);
  rtb_sincos_o2_k[1] = (rtb_Sum1_dx - rtb_IntegratorSecondOrderLimi_e[1]) -
    (rtb_DataTypeConversion2[0] * USV_X.pqr_CSTATE[2] - USV_X.pqr_CSTATE[0] *
     rtb_DataTypeConversion2[2]);
  rtb_sincos_o2_k[2] = (rtb_fcn3 - rtb_IntegratorSecondOrderLimi_e[2]) -
    (USV_X.pqr_CSTATE[0] * rtb_DataTypeConversion2[1] - rtb_DataTypeConversion2
     [0] * USV_X.pqr_CSTATE[1]);
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    for (i = 0; i < 3; i++) {
      // Selector: '<S11>/Selector2' incorporates:
      //   Concatenate: '<S12>/Vector Concatenate'

      USV_B.Selector2[3 * i] = rtb_VectorConcatenate_n[6 * i];
      USV_B.Selector2[3 * i + 1] = rtb_VectorConcatenate_n[6 * i + 1];
      USV_B.Selector2[3 * i + 2] = rtb_VectorConcatenate_n[6 * i + 2];
    }
  }

  // Product: '<S11>/Product2' incorporates:
  //   Selector: '<S11>/Selector2'
  //   Sum: '<S426>/Sum4'

  rt_mrdivide_U1d1x3_U2d_9vOrDY9Z(rtb_sincos_o2_k, USV_B.Selector2,
    USV_B.Product2);

  // Gain: '<S426>/Zero-Order Hold3'
  rtb_sincos_o2_k[0] = USV_P.ZeroOrderHold3_Gain * USV_B.Product2[0];
  rtb_sincos_o2_k[1] = USV_P.ZeroOrderHold3_Gain * USV_B.Product2[1];
  rtb_sincos_o2_k[2] = USV_P.ZeroOrderHold3_Gain * USV_B.Product2[2];

  // Sum: '<S430>/Sum' incorporates:
  //   Product: '<S439>/i x j'
  //   Product: '<S439>/j x k'
  //   Product: '<S439>/k x i'
  //   Product: '<S440>/i x k'
  //   Product: '<S440>/j x i'
  //   Product: '<S440>/k x j'

  rtb_q2dot_0[0] = USV_B.Gain_g[1] * rtb_sincos_o2_k[2];
  rtb_fuPos[0] = rtb_sincos_o2_k[1] * USV_B.Gain_g[2];
  rtb_fuPos[1] = USV_B.Gain_g[0] * rtb_sincos_o2_k[2];
  rtb_fuPos[2] = rtb_sincos_o2_k[0] * USV_B.Gain_g[1];
  rtb_q2dot_0[1] = rtb_sincos_o2_k[0] * USV_B.Gain_g[2];
  rtb_q2dot_0[2] = USV_B.Gain_g[0] * rtb_sincos_o2_k[1];
  for (i = 0; i < 3; i++) {
    // Sum: '<S426>/Sum' incorporates:
    //   Concatenate: '<S31>/Vector Concatenate'
    //   Gain: '<S426>/Zero-Order Hold1'
    //   Gain: '<S426>/Zero-Order Hold2'
    //   Product: '<S406>/Matrix Multiply1'
    //   Sum: '<S430>/Sum'

    rtb_IntegratorSecondOrderLimi_e[i] = ((USV_P.ZeroOrderHold1_Gain *
      rtb_MatrixMultiply2[i] - ((VectorConcatenate[i + 3] *
      USV_B.MatrixConcatenate[1] + VectorConcatenate[i] *
      USV_B.MatrixConcatenate[0]) + VectorConcatenate[i + 6] *
      USV_B.MatrixConcatenate[2]) * USV_P.ZeroOrderHold2_Gain) +
      rtb_sincos_o1_h[i]) + (rtb_fuPos[i] - rtb_q2dot_0[i]);
  }

  // Sum: '<S426>/Sum4' incorporates:
  //   Constant: '<S426>/Measurement bias'
  //   Constant: '<S426>/Scale factors & Cross-coupling  errors'
  //   Product: '<S426>/Product'

  for (i = 0; i < 3; i++) {
    rtb_sincos_o2_k[i] = ((USV_P.ThreeaxisInertialMeasurementU_n[i + 3] *
      rtb_IntegratorSecondOrderLimi_e[1] +
      USV_P.ThreeaxisInertialMeasurementU_n[i] *
      rtb_IntegratorSecondOrderLimi_e[0]) +
                          USV_P.ThreeaxisInertialMeasurementU_n[i + 6] *
                          rtb_IntegratorSecondOrderLimi_e[2]) +
      USV_P.ThreeaxisInertialMeasurementUni[i];
  }

  // End of Sum: '<S426>/Sum4'
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[2] == 0) {
    // Gain: '<S406>/Gain10' incorporates:
    //   UniformRandomNumber: '<S406>/Uniform Random Number5'

    USV_B.Gain10[0] = USV_P.Gain10_Gain *
      USV_DW.UniformRandomNumber5_NextOutput[0];
    USV_B.Gain10[1] = USV_P.Gain10_Gain *
      USV_DW.UniformRandomNumber5_NextOutput[1];
    USV_B.Gain10[2] = USV_P.Gain10_Gain *
      USV_DW.UniformRandomNumber5_NextOutput[2];
  }

  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // MATLAB Function: '<S406>/FaultParamsExtract' incorporates:
    //   Constant: '<S406>/FaultID'
    //   Inport: '<Root>/inSILInts'

    // MATLAB Function 'SensorFault/FaultParamsExtract': '<S409>:1'
    // '<S409>:1:5' if isempty(hFault)
    // '<S409>:1:8' if isempty(fParam)
    // '<S409>:1:12' hFaultTmp=false;
    rtb_Compare_o = false;

    // '<S409>:1:13' fParamTmp=zeros(20,1);
    std::memset(&fParamTmp[0], 0, 20U * sizeof(real_T));

    // '<S409>:1:14' j=1;
    j = 1.0;

    // '<S409>:1:15' for i=1:8
    for (roll_sign = 0; roll_sign < 8; roll_sign++) {
      // '<S409>:1:16' if inInts(i) == FaultID
      if (USV_U.inSILInts[roll_sign] == USV_P.FaultID_Value_e) {
        // '<S409>:1:17' hFaultTmp=true;
        rtb_Compare_o = true;

        // '<S409>:1:18' fParamTmp(2*j-1)=inFloats(2*i-1);
        pitch_sign = (roll_sign + 1) << 1;
        fParamTmp[static_cast<int32_T>(2.0 * j - 1.0) - 1] =
          inSILFloats[pitch_sign - 2];

        // '<S409>:1:19' fParamTmp(2*j)=inFloats(2*i);
        fParamTmp[static_cast<int32_T>(2.0 * j) - 1] = inSILFloats[pitch_sign -
          1];

        // '<S409>:1:20' j=j+1;
        j++;
      }
    }

    // '<S409>:1:23' if hFaultTmp
    if (rtb_Compare_o) {
      // '<S409>:1:24' hFault=hFaultTmp;
      USV_DW.hFault_a = true;

      // '<S409>:1:25' fParamTmp(17:20) = inFloats(17:20);
      fParamTmp[16] = inSILFloats[16];
      fParamTmp[17] = inSILFloats[17];
      fParamTmp[18] = inSILFloats[18];
      fParamTmp[19] = inSILFloats[19];

      // '<S409>:1:26' fParam=fParamTmp;
      std::memcpy(&USV_DW.fParam_m[0], &fParamTmp[0], 20U * sizeof(real_T));
    }

    // MATLAB Function: '<S407>/Acc NoiseFun' incorporates:
    //   MATLAB Function: '<S406>/FaultParamsExtract'

    // '<S409>:1:29' hasFault_acc=hFault;
    // '<S409>:1:30' FaultParam=fParam;
    USV_AccNoiseFun(USV_B.Gain10, USV_DW.hFault_a, USV_DW.fParam_m,
                    &USV_B.sf_AccNoiseFun_j);
  }

  // Switch: '<S428>/Switch' incorporates:
  //   Constant: '<S428>/Constant'
  //   SecondOrderIntegrator: '<S432>/Integrator, Second-Order Limited'

  if (USV_P.Constant_Value_a2 >= USV_P.Switch_Threshold) {
    rtb_fcn3 = USV_X.IntegratorSecondOrderLimited_CS[0];
  } else {
    rtb_fcn3 = rtb_sincos_o2_k[0];
  }

  // Saturate: '<S426>/Saturation'
  if (rtb_fcn3 > USV_P.Saturation_UpperSat[0]) {
    rtb_fcn3 = USV_P.Saturation_UpperSat[0];
  } else if (rtb_fcn3 < USV_P.Saturation_LowerSat[0]) {
    rtb_fcn3 = USV_P.Saturation_LowerSat[0];
  }

  // Sum: '<S406>/Sum1'
  rtb_sincos_o1_h[0] = rtb_fcn3 + USV_B.sf_AccNoiseFun_j.y[0];

  // Switch: '<S428>/Switch' incorporates:
  //   Constant: '<S428>/Constant'
  //   SecondOrderIntegrator: '<S432>/Integrator, Second-Order Limited'

  if (USV_P.Constant_Value_a2 >= USV_P.Switch_Threshold) {
    rtb_fcn3 = USV_X.IntegratorSecondOrderLimited_CS[1];
  } else {
    rtb_fcn3 = rtb_sincos_o2_k[1];
  }

  // Saturate: '<S426>/Saturation'
  if (rtb_fcn3 > USV_P.Saturation_UpperSat[1]) {
    rtb_fcn3 = USV_P.Saturation_UpperSat[1];
  } else if (rtb_fcn3 < USV_P.Saturation_LowerSat[1]) {
    rtb_fcn3 = USV_P.Saturation_LowerSat[1];
  }

  // Sum: '<S406>/Sum1'
  rtb_sincos_o1_h[1] = rtb_fcn3 + USV_B.sf_AccNoiseFun_j.y[1];

  // Switch: '<S428>/Switch' incorporates:
  //   Constant: '<S428>/Constant'
  //   SecondOrderIntegrator: '<S432>/Integrator, Second-Order Limited'

  if (USV_P.Constant_Value_a2 >= USV_P.Switch_Threshold) {
    rtb_fcn3 = USV_X.IntegratorSecondOrderLimited_CS[2];
  } else {
    rtb_fcn3 = rtb_sincos_o2_k[2];
  }

  // Saturate: '<S426>/Saturation'
  if (rtb_fcn3 > USV_P.Saturation_UpperSat[2]) {
    rtb_fcn3 = USV_P.Saturation_UpperSat[2];
  } else if (rtb_fcn3 < USV_P.Saturation_LowerSat[2]) {
    rtb_fcn3 = USV_P.Saturation_LowerSat[2];
  }

  // Sum: '<S406>/Sum1'
  rtb_sincos_o1_h[2] = rtb_fcn3 + USV_B.sf_AccNoiseFun_j.y[2];

  // SecondOrderIntegrator: '<S443>/Integrator, Second-Order Limited'
  roll_sign = 3;

  // Unit Conversion - from: m/s^2 to: gn
  // Expression: output = (0.101972*input) + (0)
  for (pitch_sign = 0; pitch_sign < 3; pitch_sign++) {
    // DataTypeConversion: '<S406>/Data Type Conversion2'
    rtb_AngEuler[pitch_sign] = static_cast<real32_T>(rtb_sincos_o1_h[pitch_sign]);

    // SecondOrderIntegrator: '<S443>/Integrator, Second-Order Limited'
    rtb_IntegratorSecondOrderLimi_e[pitch_sign] =
      USV_X.IntegratorSecondOrderLimited__p[roll_sign];
    roll_sign++;

    // Sum: '<S427>/Sum4' incorporates:
    //   Constant: '<S427>/Measurement bias'
    //   Constant: '<S427>/Scale factors & Cross-coupling  errors '
    //   Constant: '<S427>/g-sensitive bias'
    //   Gain: '<S427>/Zero-Order Hold'
    //   Gain: '<S427>/Zero-Order Hold1'
    //   Integrator: '<S9>/p,q,r '
    //   Product: '<S427>/Product'
    //   Product: '<S427>/Product1'
    //   UnitConversion: '<S425>/Unit Conversion'

    rtb_fuPos[pitch_sign] = (((USV_P.ZeroOrderHold_Gain_m * USV_X.pqr_CSTATE[0] *
      USV_P.ThreeaxisInertialMeasurementU_f[pitch_sign] +
      USV_P.ThreeaxisInertialMeasurementU_f[pitch_sign + 3] *
      (USV_P.ZeroOrderHold_Gain_m * USV_X.pqr_CSTATE[1])) +
      USV_P.ThreeaxisInertialMeasurementU_f[pitch_sign + 6] *
      (USV_P.ZeroOrderHold_Gain_m * USV_X.pqr_CSTATE[2])) +
      USV_P.ThreeaxisInertialMeasurementU_b[pitch_sign]) + 0.10197162129779282 *
      rtb_MatrixMultiply2[pitch_sign] * USV_P.ZeroOrderHold1_Gain_l *
      USV_P.ThreeaxisInertialMeasurementU_o[pitch_sign];

    // SecondOrderIntegrator: '<S443>/Integrator, Second-Order Limited'
    rtb_sincos_o1_h[pitch_sign] =
      USV_X.IntegratorSecondOrderLimited__p[pitch_sign];
  }

  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[2] == 0) {
    // Gain: '<S406>/Gain6' incorporates:
    //   UniformRandomNumber: '<S406>/Uniform Random Number1'

    USV_B.Gain6[0] = USV_P.Gain6_Gain * USV_DW.UniformRandomNumber1_NextOutput[0];
    USV_B.Gain6[1] = USV_P.Gain6_Gain * USV_DW.UniformRandomNumber1_NextOutput[1];
    USV_B.Gain6[2] = USV_P.Gain6_Gain * USV_DW.UniformRandomNumber1_NextOutput[2];
  }

  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // MATLAB Function: '<S406>/FaultParamsExtract1' incorporates:
    //   Constant: '<S406>/FaultID1'
    //   Inport: '<Root>/inSILInts'

    // MATLAB Function 'SensorFault/FaultParamsExtract1': '<S410>:1'
    // '<S410>:1:5' if isempty(hFault)
    // '<S410>:1:8' if isempty(fParam)
    // '<S410>:1:12' hFaultTmp=false;
    rtb_Compare_o = false;

    // '<S410>:1:13' fParamTmp=zeros(20,1);
    std::memset(&fParamTmp[0], 0, 20U * sizeof(real_T));

    // '<S410>:1:14' j=1;
    j = 1.0;

    // '<S410>:1:15' for i=1:8
    for (roll_sign = 0; roll_sign < 8; roll_sign++) {
      // '<S410>:1:16' if inInts(i) == FaultID
      if (USV_U.inSILInts[roll_sign] == USV_P.FaultID1_Value_a) {
        // '<S410>:1:17' hFaultTmp=true;
        rtb_Compare_o = true;

        // '<S410>:1:18' fParamTmp(2*j-1)=inFloats(2*i-1);
        pitch_sign = (roll_sign + 1) << 1;
        fParamTmp[static_cast<int32_T>(2.0 * j - 1.0) - 1] =
          inSILFloats[pitch_sign - 2];

        // '<S410>:1:19' fParamTmp(2*j)=inFloats(2*i);
        fParamTmp[static_cast<int32_T>(2.0 * j) - 1] = inSILFloats[pitch_sign -
          1];

        // '<S410>:1:20' j=j+1;
        j++;
      }
    }

    // '<S410>:1:23' if hFaultTmp
    if (rtb_Compare_o) {
      // '<S410>:1:24' hFault=hFaultTmp;
      USV_DW.hFault_f = true;

      // '<S410>:1:25' fParamTmp(17:20) = inFloats(17:20);
      fParamTmp[16] = inSILFloats[16];
      fParamTmp[17] = inSILFloats[17];
      fParamTmp[18] = inSILFloats[18];
      fParamTmp[19] = inSILFloats[19];

      // '<S410>:1:26' fParam=fParamTmp;
      std::memcpy(&USV_DW.fParam_e[0], &fParamTmp[0], 20U * sizeof(real_T));
    }

    // MATLAB Function: '<S413>/Acc NoiseFun' incorporates:
    //   MATLAB Function: '<S406>/FaultParamsExtract1'

    // '<S410>:1:29' hasFault_gyro=hFault;
    // '<S410>:1:30' FaultParam=fParam;
    USV_AccNoiseFun(USV_B.Gain6, USV_DW.hFault_f, USV_DW.fParam_e,
                    &USV_B.sf_AccNoiseFun_i);
  }

  // Switch: '<S441>/Switch' incorporates:
  //   Constant: '<S441>/Constant'

  if (USV_P.Constant_Value_au >= USV_P.Switch_Threshold_j) {
    rtb_fcn3 = rtb_sincos_o1_h[0];
  } else {
    rtb_fcn3 = rtb_fuPos[0];
  }

  // Saturate: '<S427>/Saturation'
  if (rtb_fcn3 > USV_P.Saturation_UpperSat_n[0]) {
    VectorConcatenate_tmp = USV_P.Saturation_UpperSat_n[0];
  } else if (rtb_fcn3 < USV_P.Saturation_LowerSat_f[0]) {
    VectorConcatenate_tmp = USV_P.Saturation_LowerSat_f[0];
  } else {
    VectorConcatenate_tmp = rtb_fcn3;
  }

  // Switch: '<S441>/Switch' incorporates:
  //   Constant: '<S441>/Constant'

  if (USV_P.Constant_Value_au >= USV_P.Switch_Threshold_j) {
    rtb_fcn3 = rtb_sincos_o1_h[1];
  } else {
    rtb_fcn3 = rtb_fuPos[1];
  }

  // Saturate: '<S427>/Saturation'
  if (rtb_fcn3 > USV_P.Saturation_UpperSat_n[1]) {
    VectorConcatenate_tmp_0 = USV_P.Saturation_UpperSat_n[1];
  } else if (rtb_fcn3 < USV_P.Saturation_LowerSat_f[1]) {
    VectorConcatenate_tmp_0 = USV_P.Saturation_LowerSat_f[1];
  } else {
    VectorConcatenate_tmp_0 = rtb_fcn3;
  }

  // Switch: '<S441>/Switch' incorporates:
  //   Constant: '<S441>/Constant'

  if (USV_P.Constant_Value_au >= USV_P.Switch_Threshold_j) {
    rtb_fcn3 = rtb_sincos_o1_h[2];
  } else {
    rtb_fcn3 = rtb_fuPos[2];
  }

  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // Sum: '<S453>/Sum' incorporates:
    //   Constant: '<S419>/Decimal Year'
    //   Constant: '<S453>/epoch'

    rtb_Sum_hp = USV_P.DecimalYear_Value - USV_P.epoch_Value;

    // RelationalOperator: '<S467>/Relational Operator' incorporates:
    //   Constant: '<S419>/Decimal Year'
    //   Memory: '<S467>/otime'

    rtb_RelationalOperator = (USV_P.DecimalYear_Value !=
      USV_DW.otime_PreviousInput);
  }

  // Saturate: '<S406>/Saturation2'
  if (rtb_Switch_bvp > USV_P.Saturation2_UpperSat) {
    rtb_Switch_bvp = USV_P.Saturation2_UpperSat;
  } else if (rtb_Switch_bvp < USV_P.Saturation2_LowerSat) {
    rtb_Switch_bvp = USV_P.Saturation2_LowerSat;
  }

  // End of Saturate: '<S406>/Saturation2'

  // Switch: '<S458>/Switch' incorporates:
  //   Abs: '<S458>/Abs'
  //   Bias: '<S458>/Bias'
  //   Bias: '<S458>/Bias1'
  //   Constant: '<S458>/Constant2'
  //   Constant: '<S459>/Constant'
  //   Math: '<S458>/Math Function1'
  //   RelationalOperator: '<S459>/Compare'

  if (std::abs(rtb_Switch_bvp) > USV_P.CompareToConstant_const_h) {
    rtb_Switch1_h = rt_modd_snf(rtb_Switch_bvp + USV_P.Bias_Bias_gv,
      USV_P.Constant2_Value_b) + USV_P.Bias1_Bias_kz;
  } else {
    rtb_Switch1_h = rtb_Switch_bvp;
  }

  // End of Switch: '<S458>/Switch'

  // Abs: '<S455>/Abs1'
  j = std::abs(rtb_Switch1_h);

  // RelationalOperator: '<S457>/Compare' incorporates:
  //   Constant: '<S457>/Constant'

  rtb_Compare_o = (j > USV_P.CompareToConstant_const_k);

  // Switch: '<S449>/Switch1' incorporates:
  //   Constant: '<S449>/Constant'
  //   Constant: '<S449>/Constant1'

  if (rtb_Compare_o) {
    rtb_sincos_o1_idx_0 = USV_P.Constant_Value_fly;
  } else {
    rtb_sincos_o1_idx_0 = USV_P.Constant1_Value_nz;
  }

  // End of Switch: '<S449>/Switch1'

  // Sum: '<S449>/Sum'
  rtb_Switch1_a = rtb_sincos_o1_idx_0 + rtb_Abs1;

  // Switch: '<S456>/Switch' incorporates:
  //   Abs: '<S456>/Abs'
  //   Constant: '<S460>/Constant'
  //   RelationalOperator: '<S460>/Compare'

  if (std::abs(rtb_Switch1_a) > USV_P.CompareToConstant_const_ee) {
    // Switch: '<S456>/Switch' incorporates:
    //   Bias: '<S456>/Bias'
    //   Bias: '<S456>/Bias1'
    //   Constant: '<S456>/Constant2'
    //   Math: '<S456>/Math Function1'

    USV_B.Switch_h = rt_modd_snf(rtb_Switch1_a + USV_P.Bias_Bias_m,
      USV_P.Constant2_Value_d) + USV_P.Bias1_Bias_eu;
  } else {
    // Switch: '<S456>/Switch'
    USV_B.Switch_h = rtb_Switch1_a;
  }

  // End of Switch: '<S456>/Switch'

  // Switch: '<S455>/Switch'
  if (rtb_Compare_o) {
    // Signum: '<S455>/Sign1'
    if (!rtIsNaN(rtb_Switch1_h)) {
      if (rtb_Switch1_h < 0.0) {
        rtb_Switch1_h = -1.0;
      } else {
        rtb_Switch1_h = (rtb_Switch1_h > 0.0);
      }
    }

    // End of Signum: '<S455>/Sign1'

    // Switch: '<S455>/Switch' incorporates:
    //   Bias: '<S455>/Bias'
    //   Bias: '<S455>/Bias1'
    //   Gain: '<S455>/Gain'
    //   Product: '<S455>/Divide1'

    USV_B.Switch_j = ((j + USV_P.Bias_Bias_l) * USV_P.Gain_Gain_kv +
                      USV_P.Bias1_Bias_ax) * rtb_Switch1_h;
  } else {
    // Switch: '<S455>/Switch'
    USV_B.Switch_j = rtb_Switch1_h;
  }

  // End of Switch: '<S455>/Switch'

  // UnitConversion: '<S511>/Unit Conversion'
  // Unit Conversion - from: deg to: rad
  // Expression: output = (0.0174533*input) + (0)
  rtb_Sum1_dx = 0.017453292519943295 * USV_B.Switch_h;
  rtb_Switch1_k = 0.017453292519943295 * USV_B.Switch_j;

  // Trigonometry: '<S464>/sincos'
  rtb_sincos_o1_idx_0 = std::sin(rtb_Sum1_dx);
  rtb_Switch1_h = std::cos(rtb_Sum1_dx);
  j = std::sin(rtb_Switch1_k);
  rtb_q2dot = std::cos(rtb_Switch1_k);
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // Outputs for Enabled SubSystem: '<S453>/Convert from geodetic to  spherical coordinates ' incorporates:
    //   EnablePort: '<S463>/Enable'

    if (rtsiIsModeUpdateTimeStep(&(&USV_M)->solverInfo)) {
      // RelationalOperator: '<S466>/Relational Operator' incorporates:
      //   Memory: '<S466>/olon'

      USV_DW.Convertfromgeodetictosphericalc = (USV_B.Switch_h !=
        USV_DW.olon_PreviousInput);
    }

    // End of Outputs for SubSystem: '<S453>/Convert from geodetic to  spherical coordinates ' 

    // Memory: '<S465>/olat'
    USV_B.olat = USV_DW.olat_PreviousInput;
  }

  // Outputs for Enabled SubSystem: '<S453>/Convert from geodetic to  spherical coordinates ' incorporates:
  //   EnablePort: '<S463>/Enable'

  if (USV_DW.Convertfromgeodetictosphericalc) {
    if (rtmIsMajorTimeStep((&USV_M)) &&
        (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
      // Outputs for Iterator SubSystem: '<S463>/For Iterator Subsystem' incorporates:
      //   ForIterator: '<S510>/For Iterator'

      for (roll_sign = 1; roll_sign <= USV_P.ForIterator_IterationLimit;
           roll_sign++) {
        // Switch: '<S510>/cp[m-1] sp[m-1]' incorporates:
        //   SignalConversion generated from: '<S463>/cp[2]'
        //   SignalConversion generated from: '<S463>/sp[2]'
        //   UnitDelay: '<S510>/Unit Delay1'

        if (roll_sign > USV_P.cpm1spm1_Threshold) {
          rtb_Sum1_dx = USV_DW.UnitDelay1_DSTATE[0];
          rtb_Switch1_k = USV_DW.UnitDelay1_DSTATE[1];
        } else {
          rtb_Sum1_dx = rtb_Switch1_h;
          rtb_Switch1_k = rtb_sincos_o1_idx_0;
        }

        // End of Switch: '<S510>/cp[m-1] sp[m-1]'

        // Sum: '<S510>/Sum2' incorporates:
        //   Product: '<S510>/Product1'
        //   Product: '<S510>/Product2'
        //   SignalConversion generated from: '<S463>/cp[2]'
        //   SignalConversion generated from: '<S463>/sp[2]'

        rtb_Switch1_a = rtb_Sum1_dx * rtb_sincos_o1_idx_0 + rtb_Switch1_k *
          rtb_Switch1_h;

        // Sum: '<S510>/Sum1' incorporates:
        //   Product: '<S510>/Product3'
        //   Product: '<S510>/Product8'
        //   SignalConversion generated from: '<S463>/cp[2]'
        //   SignalConversion generated from: '<S463>/sp[2]'

        rtb_Switch1_k = rtb_Sum1_dx * rtb_Switch1_h - rtb_Switch1_k *
          rtb_sincos_o1_idx_0;

        // Assignment: '<S510>/Assignment' incorporates:
        //   Assignment: '<S510>/Assignment1'
        //   Constant: '<S510>/Constant'
        //   Constant: '<S510>/Constant1'

        if (roll_sign == 1) {
          std::memcpy(&rtb_Assignment[0], &USV_P.Constant_Value_p3[0], 11U *
                      sizeof(real_T));
          std::memcpy(&rtb_Assignment1[0], &USV_P.Constant1_Value_mb[0], 11U *
                      sizeof(real_T));
        }

        rtb_Assignment[roll_sign - 1] = rtb_Switch1_a;

        // End of Assignment: '<S510>/Assignment'

        // Assignment: '<S510>/Assignment1'
        rtb_Assignment1[roll_sign - 1] = rtb_Switch1_k;

        // Update for UnitDelay: '<S510>/Unit Delay1'
        USV_DW.UnitDelay1_DSTATE[0] = rtb_Switch1_k;
        USV_DW.UnitDelay1_DSTATE[1] = rtb_Switch1_a;
      }

      // End of Outputs for SubSystem: '<S463>/For Iterator Subsystem'
      for (i = 0; i < 11; i++) {
        // Gain: '<S463>/Gain'
        USV_B.Gain_g4[i] = USV_P.Gain_Gain_o * rtb_Assignment1[i];

        // Gain: '<S463>/Gain1'
        USV_B.Gain1_l[i] = USV_P.Gain1_Gain_pk * rtb_Assignment[i];
      }
    }

    // SignalConversion generated from: '<S463>/cp[13]' incorporates:
    //   Constant: '<S463>/cp[1]'
    //   SignalConversion generated from: '<S463>/cp[2]'

    USV_B.OutportBufferForcp13[0] = USV_P.cp1_Value;
    USV_B.OutportBufferForcp13[1] = rtb_Switch1_h;

    // SignalConversion generated from: '<S463>/sp[13]' incorporates:
    //   Constant: '<S463>/sp[1]'
    //   SignalConversion generated from: '<S463>/sp[2]'

    USV_B.OutportBufferForsp13[0] = USV_P.sp1_Value;
    USV_B.OutportBufferForsp13[1] = rtb_sincos_o1_idx_0;

    // SignalConversion generated from: '<S463>/cp[13]'
    std::memcpy(&USV_B.OutportBufferForcp13[2], &USV_B.Gain_g4[0], 11U * sizeof
                (real_T));

    // SignalConversion generated from: '<S463>/sp[13]'
    std::memcpy(&USV_B.OutportBufferForsp13[2], &USV_B.Gain1_l[0], 11U * sizeof
                (real_T));
  }

  // End of Outputs for SubSystem: '<S453>/Convert from geodetic to  spherical coordinates ' 

  // Gain: '<S419>/Gain'
  USV_B.Gain_k = USV_P.Gain_Gain_o3 * rtb_Saturation_1;
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // Memory: '<S465>/oalt'
    USV_B.oalt = USV_DW.oalt_PreviousInput;
  }

  // Logic: '<S465>/Logical Operator' incorporates:
  //   RelationalOperator: '<S465>/Relational Operator'
  //   RelationalOperator: '<S465>/Relational Operator1'

  rtb_Compare_o = ((USV_B.Switch_j != USV_B.olat) || (USV_B.Gain_k != USV_B.oalt));

  // Product: '<S464>/Product'
  rtb_Product_gy = j * j;

  // Product: '<S464>/Product1'
  rtb_Product1_i5 = rtb_q2dot * rtb_q2dot;
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // Outputs for Enabled SubSystem: '<S453>/Convert from geodetic to  spherical coordinates' incorporates:
    //   EnablePort: '<S462>/Enable'

    if (rtsiIsModeUpdateTimeStep(&(&USV_M)->solverInfo)) {
      // SignalConversion generated from: '<S462>/Enable'
      USV_DW.Convertfromgeodetictospherica_d = rtb_Compare_o;
    }

    // End of Outputs for SubSystem: '<S453>/Convert from geodetic to  spherical coordinates' 
  }

  // Outputs for Enabled SubSystem: '<S453>/Convert from geodetic to  spherical coordinates' incorporates:
  //   EnablePort: '<S462>/Enable'

  if (USV_DW.Convertfromgeodetictospherica_d) {
    if (rtmIsMajorTimeStep((&USV_M)) &&
        (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
      // Product: '<S462>/b2' incorporates:
      //   Constant: '<S462>/b'

      USV_B.b2 = USV_P.b_Value * USV_P.b_Value;

      // Product: '<S462>/a2' incorporates:
      //   Constant: '<S462>/a'

      USV_B.a2 = USV_P.a_Value * USV_P.a_Value;

      // Sum: '<S505>/Sum1'
      USV_B.c2 = USV_B.a2 - USV_B.b2;
    }

    // Sqrt: '<S505>/sqrt' incorporates:
    //   Product: '<S505>/Product'
    //   Sum: '<S505>/Sum'

    rtb_sincos_o1_idx_0 = std::sqrt(USV_B.a2 - rtb_Product_gy * USV_B.c2);

    // Product: '<S462>/Product1'
    rtb_Switch1_h = rtb_sincos_o1_idx_0 * USV_B.Gain_k;

    // Sqrt: '<S504>/sqrt' incorporates:
    //   Product: '<S504>/Product10'
    //   Product: '<S504>/Product9'
    //   Sum: '<S504>/Sum7'

    rtb_Sum1_dx = std::sqrt(rtb_Product1_i5 * USV_B.a2 + USV_B.b2 *
      rtb_Product_gy);
    if (rtmIsMajorTimeStep((&USV_M)) &&
        (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
      // Product: '<S507>/a4'
      USV_B.a4 = USV_B.a2 * USV_B.a2;

      // Sum: '<S507>/Sum9' incorporates:
      //   Product: '<S507>/b4'

      USV_B.c4 = USV_B.a4 - USV_B.b2 * USV_B.b2;
    }

    // Sqrt: '<S462>/sqrt' incorporates:
    //   Gain: '<S507>/Gain'
    //   Product: '<S507>/Product1'
    //   Product: '<S507>/Product6'
    //   Product: '<S507>/Product7'
    //   Product: '<S507>/Product8'
    //   Sum: '<S507>/Sum5'
    //   Sum: '<S507>/Sum6'

    USV_B.sqrt_i = std::sqrt((USV_B.a4 - USV_B.c4 * rtb_Product_gy) /
      (rtb_sincos_o1_idx_0 * rtb_sincos_o1_idx_0) + (USV_P.Gain_Gain_h *
      rtb_Switch1_h + USV_B.Gain_k * USV_B.Gain_k));

    // Product: '<S502>/Product11' incorporates:
    //   Sum: '<S502>/Sum8'

    USV_B.Product11 = (USV_B.Gain_k + rtb_Sum1_dx) / USV_B.sqrt_i;

    // Sum: '<S506>/Sum2'
    rtb_sincos_o1_idx_0 = USV_B.a2 + rtb_Switch1_h;

    // Sum: '<S506>/Sum1'
    rtb_Switch1_h += USV_B.b2;

    // Product: '<S503>/Product4' incorporates:
    //   Product: '<S503>/Product3'
    //   Product: '<S506>/Product1'
    //   Product: '<S506>/Product2'
    //   Sqrt: '<S503>/sqrt'
    //   Sum: '<S503>/Sum3'

    USV_B.Product4_j = j / std::sqrt(rtb_sincos_o1_idx_0 * rtb_sincos_o1_idx_0 /
      (rtb_Switch1_h * rtb_Switch1_h) * rtb_Product1_i5 + rtb_Product_gy);

    // Product: '<S508>/Product1'
    rtb_Sum1_dx *= USV_B.sqrt_i;
    if (rtmIsMajorTimeStep((&USV_M)) &&
        (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
      // Sum: '<S508>/Sum1'
      USV_B.c2_j = USV_B.a2 - USV_B.b2;
    }

    // Product: '<S508>/Product12'
    USV_B.Product12 = USV_B.c2_j / rtb_Sum1_dx * rtb_q2dot * j;

    // Sqrt: '<S509>/sqrt' incorporates:
    //   Constant: '<S509>/Constant'
    //   Product: '<S509>/Product5'
    //   Sum: '<S509>/Sum4'

    USV_B.sqrt_ix = std::sqrt(USV_P.Constant_Value_pt - USV_B.Product4_j *
      USV_B.Product4_j);
  }

  // End of Outputs for SubSystem: '<S453>/Convert from geodetic to  spherical coordinates' 

  // Product: '<S453>/aor' incorporates:
  //   Constant: '<S453>/re'

  rtb_Product1_i5 = USV_P.re_Value / USV_B.sqrt_i;
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // Outputs for Iterator SubSystem: '<S453>/Compute magnetic vector in spherical coordinates' incorporates:
    //   ForIterator: '<S461>/For Iterator'

    // InitializeConditions for UnitDelay: '<S461>/Unit Delay'
    rtb_Product_gy = USV_P.UnitDelay_InitialCondition_g;

    // InitializeConditions for UnitDelay: '<S461>/Unit Delay2'
    rtb_WhiteNoise_b_idx_0 = USV_P.UnitDelay2_InitialCondition_d[0];
    dw_l_e = USV_P.UnitDelay2_InitialCondition_d[1];
    dw_e = USV_P.UnitDelay2_InitialCondition_d[2];
    S_df = USV_P.UnitDelay2_InitialCondition_d[3];
    for (roll_sign = 1; roll_sign <= USV_P.ForIterator_IterationLimit_f;
         roll_sign++) {
      // Switch: '<S461>/ar(n)' incorporates:
      //   Product: '<S453>/ar'

      if (roll_sign <= USV_P.arn_Threshold) {
        rtb_Product_gy = rtb_Product1_i5 * rtb_Product1_i5;
      }

      // End of Switch: '<S461>/ar(n)'

      // Product: '<S461>/Product8'
      rtb_Switch1_h = rtb_Product_gy * rtb_Product1_i5;

      // Sum: '<S461>/Sum' incorporates:
      //   Constant: '<S461>/Constant'

      if ((roll_sign < 0) && (USV_P.Constant_Value_mk < MIN_int32_T - roll_sign))
      {
        pitch_sign = MIN_int32_T;
      } else if ((roll_sign > 0) && (USV_P.Constant_Value_mk > MAX_int32_T
                  - roll_sign)) {
        pitch_sign = MAX_int32_T;
      } else {
        pitch_sign = roll_sign + USV_P.Constant_Value_mk;
      }

      // Outputs for Iterator SubSystem: '<S461>/For Iterator Subsystem' incorporates:
      //   ForIterator: '<S469>/For Iterator'

      // InitializeConditions for UnitDelay: '<S470>/Unit Delay1'
      j = USV_P.UnitDelay1_InitialCondition_e;

      // InitializeConditions for UnitDelay: '<S470>/Unit Delay3'
      rtb_Switch1_a = USV_P.UnitDelay3_InitialCondition;

      // InitializeConditions for UnitDelay: '<S470>/Unit Delay2'
      rtb_Switch1_k = USV_P.UnitDelay2_InitialCondition;

      // InitializeConditions for UnitDelay: '<S470>/Unit Delay4'
      rtb_sincos_o1_idx_0 = USV_P.UnitDelay4_InitialCondition;
      for (i = 0; i < 6; i++) {
        ForIterator_IterationMarker[i] = 1U;
      }

      // Sum: '<S461>/Sum'
      if (pitch_sign > 2147483646) {
        pitch_sign = 2147483646;
      } else if (pitch_sign < 0) {
        pitch_sign = 0;
      }

      if (pitch_sign >= 1) {
        // Sum: '<S470>/Sum' incorporates:
        //   Constant: '<S470>/Constant'

        if ((roll_sign < 0) && (USV_P.Constant_Value_d3e < MIN_int32_T
                                - roll_sign)) {
          Product_f_tmp_tmp = MIN_int32_T;
        } else if ((roll_sign > 0) && (USV_P.Constant_Value_d3e > MAX_int32_T
                    - roll_sign)) {
          Product_f_tmp_tmp = MAX_int32_T;
        } else {
          Product_f_tmp_tmp = roll_sign + USV_P.Constant_Value_d3e;
        }

        // Selector: '<S470>/snorm[n+m*13]' incorporates:
        //   Constant: '<S474>/Constant'
        //   Sum: '<S474>/Sum1'

        if ((USV_P.Constant_Value_mg < 0) && (roll_sign < MIN_int32_T
             - USV_P.Constant_Value_mg)) {
          qY = MIN_int32_T;
        } else if ((USV_P.Constant_Value_mg > 0) && (roll_sign > MAX_int32_T
                    - USV_P.Constant_Value_mg)) {
          qY = MAX_int32_T;
        } else {
          qY = USV_P.Constant_Value_mg + roll_sign;
        }

        // Sum: '<S470>/Sum4' incorporates:
        //   Constant: '<S470>/Constant1'

        if ((roll_sign < 0) && (USV_P.Constant1_Value_lk < MIN_int32_T
                                - roll_sign)) {
          roll_sign_0 = MIN_int32_T;
        } else if ((roll_sign > 0) && (USV_P.Constant1_Value_lk > MAX_int32_T
                    - roll_sign)) {
          roll_sign_0 = MAX_int32_T;
        } else {
          roll_sign_0 = roll_sign + USV_P.Constant1_Value_lk;
        }
      }

      for (int32_T s469_iter = 1; s469_iter <= pitch_sign; s469_iter++) {
        int32_T qY_0;
        int32_T qY_1;
        int32_T qY_2;
        int32_T rtb_Sum1_nn;

        // Sum: '<S469>/Sum1' incorporates:
        //   Constant: '<S469>/Constant'

        if (USV_P.Constant_Value_gj < s469_iter - MAX_int32_T) {
          qY_2 = MAX_int32_T;
        } else {
          qY_2 = s469_iter - USV_P.Constant_Value_gj;
        }

        // Outputs for Enabled SubSystem: '<S469>/Time adjust the gauss coefficients' incorporates:
        //   EnablePort: '<S472>/Enable'

        if (rtb_RelationalOperator) {
          // Outputs for Atomic SubSystem: '<S472>/If Action Subsystem'
          // Sum: '<S498>/Sum1' incorporates:
          //   Constant: '<S498>/Constant1'
          //   Sum: '<S469>/Sum1'

          if ((qY_2 < 0) && (USV_P.Constant1_Value_me < MIN_int32_T - qY_2)) {
            qY_1 = MIN_int32_T;
          } else if ((qY_2 > 0) && (USV_P.Constant1_Value_me > MAX_int32_T
                      - qY_2)) {
            qY_1 = MAX_int32_T;
          } else {
            qY_1 = qY_2 + USV_P.Constant1_Value_me;
          }

          // Sum: '<S498>/Sum2' incorporates:
          //   Constant: '<S498>/Constant'

          if ((roll_sign < 0) && (USV_P.Constant_Value_bl < MIN_int32_T
                                  - roll_sign)) {
            qY_0 = MIN_int32_T;
          } else if ((roll_sign > 0) && (USV_P.Constant_Value_bl > MAX_int32_T -
                      roll_sign)) {
            qY_0 = MAX_int32_T;
          } else {
            qY_0 = roll_sign + USV_P.Constant_Value_bl;
          }

          // End of Outputs for SubSystem: '<S472>/If Action Subsystem'

          // Assignment: '<S472>/Assignment'
          if (ForIterator_IterationMarker[4] < 2) {
            ForIterator_IterationMarker[4] = 2U;

            // Assignment: '<S472>/Assignment' incorporates:
            //   UnitDelay: '<S472>/Unit Delay'

            std::memcpy(&USV_B.Assignment[0], &USV_DW.UnitDelay_DSTATE_m[0],
                        169U * sizeof(real_T));
          }

          // Outputs for Atomic SubSystem: '<S472>/If Action Subsystem'
          // Selector: '<S498>/cd[m][n]' incorporates:
          //   Assignment: '<S472>/Assignment'
          //   Constant: '<S472>/cd[maxdef][maxdef]'
          //   Selector: '<S498>/c[m][n]'
          //   Sum: '<S498>/Sum1'
          //   Sum: '<S498>/Sum2'

          qY_1 = ((qY_0 - 1) * 13 + qY_1) - 1;

          // Assignment: '<S472>/Assignment' incorporates:
          //   Constant: '<S472>/c[maxdef][maxdef]'
          //   Constant: '<S472>/cd[maxdef][maxdef]'
          //   Product: '<S498>/Product'
          //   Selector: '<S498>/c[m][n]'
          //   Selector: '<S498>/cd[m][n]'
          //   Sum: '<S498>/Sum'

          USV_B.Assignment[qY_1] = USV_P.cdmaxdefmaxdef_Value[qY_1] * rtb_Sum_hp
            + USV_P.cmaxdefmaxdef_Value[qY_1];

          // End of Outputs for SubSystem: '<S472>/If Action Subsystem'

          // Switch: '<S499>/tc_old' incorporates:
          //   Constant: '<S499>/zeros(maxdef+1,maxdef+1)'
          //   UnitDelay: '<S499>/Unit Delay'

          if (roll_sign > USV_P.tc_old_Threshold) {
            std::memcpy(&rtb_tc_old[0], &USV_DW.UnitDelay_DSTATE_d[0], 169U *
                        sizeof(real_T));
          } else {
            std::memcpy(&rtb_tc_old[0], &USV_P.zerosmaxdef1maxdef1_Value[0],
                        169U * sizeof(real_T));
          }

          // End of Switch: '<S499>/tc_old'

          // If: '<S499>/If' incorporates:
          //   Sum: '<S469>/Sum1'

          if (qY_2 != 0) {
            // Outputs for IfAction SubSystem: '<S499>/If Action Subsystem1' incorporates:
            //   ActionPort: '<S500>/Action Port'

            // Sum: '<S500>/Sum2' incorporates:
            //   Constant: '<S500>/Constant'

            if ((roll_sign < 0) && (USV_P.Constant_Value_op < MIN_int32_T
                                    - roll_sign)) {
              qY_1 = MIN_int32_T;
            } else if ((roll_sign > 0) && (USV_P.Constant_Value_op > MAX_int32_T
                        - roll_sign)) {
              qY_1 = MAX_int32_T;
            } else {
              qY_1 = roll_sign + USV_P.Constant_Value_op;
            }

            // Assignment: '<S500>/Assignment2' incorporates:
            //   Constant: '<S472>/c[maxdef][maxdef]'
            //   Constant: '<S472>/cd[maxdef][maxdef]'
            //   Product: '<S500>/Product'
            //   Selector: '<S500>/c[m][n]'
            //   Selector: '<S500>/cd[m][n]'
            //   Sum: '<S500>/Sum'
            //   Sum: '<S500>/Sum2'
            //   Switch: '<S499>/tc_old'

            if (ForIterator_IterationMarker[5] < 2) {
              ForIterator_IterationMarker[5] = 2U;
              std::memcpy(&USV_B.Assignment2[0], &rtb_tc_old[0], 169U * sizeof
                          (real_T));
            }

            qY_1 = ((qY_2 - 1) * 13 + qY_1) - 1;
            USV_B.Assignment2[qY_1] = USV_P.cdmaxdefmaxdef_Value[qY_1] *
              rtb_Sum_hp + USV_P.cmaxdefmaxdef_Value[qY_1];

            // End of Assignment: '<S500>/Assignment2'

            // Gain: '<S500>/Gain' incorporates:
            //   Assignment: '<S500>/Assignment2'
            //   Merge: '<S499>/Merge'

            for (i = 0; i < 169; i++) {
              rtb_tc_old[i] = USV_P.Gain_Gain_e * USV_B.Assignment2[i];
            }

            // End of Gain: '<S500>/Gain'
            // End of Outputs for SubSystem: '<S499>/If Action Subsystem1'
          }

          // End of If: '<S499>/If'
          for (i = 0; i < 169; i++) {
            // Sum: '<S472>/Sum2' incorporates:
            //   Merge: '<S499>/Merge'

            rtb_q2dot = rtb_tc_old[i];

            // Sum: '<S472>/Sum2' incorporates:
            //   Assignment: '<S472>/Assignment'

            USV_B.Sum2_a[i] = USV_B.Assignment[i] + rtb_q2dot;

            // Update for UnitDelay: '<S472>/Unit Delay' incorporates:
            //   Assignment: '<S472>/Assignment'

            USV_DW.UnitDelay_DSTATE_m[i] = USV_B.Assignment[i];

            // Update for UnitDelay: '<S499>/Unit Delay'
            USV_DW.UnitDelay_DSTATE_d[i] = rtb_q2dot;
          }
        }

        // End of Outputs for SubSystem: '<S469>/Time adjust the gauss coefficients' 

        // Sum: '<S475>/Sum4' incorporates:
        //   Constant: '<S475>/Constant1'
        //   Sum: '<S469>/Sum1'

        rtb_Product_gy = static_cast<real_T>(qY_2) + USV_P.Constant1_Value_o;

        // If: '<S475>/If' incorporates:
        //   Sum: '<S469>/Sum1'

        if (qY_2 == 0) {
          // Outputs for IfAction SubSystem: '<S475>/If Action Subsystem' incorporates:
          //   ActionPort: '<S481>/Action Port'

          // Product: '<S481>/Product' incorporates:
          //   Constant: '<S481>/Constant'
          //   Selector: '<S481>/Selector'
          //   Sum: '<S472>/Sum2'
          //   Sum: '<S481>/Sum'

          rtb_q2dot = USV_B.Sum2_a[((static_cast<int32_T>(static_cast<real_T>
            (roll_sign) + USV_P.Constant_Value_a) - 1) * 13 +
            static_cast<int32_T>(USV_P.Constant_Value_a)) - 1];

          // Merge: '<S475>/Merge' incorporates:
          //   Gain: '<S481>/Gain1'
          //   Product: '<S481>/Product'
          //   Selector: '<S475>/cp[m+1]'
          //   Selector: '<S481>/Selector'

          rtb_Sum1_dx = USV_B.OutportBufferForcp13[static_cast<int32_T>
            (rtb_Product_gy) - 1] * rtb_q2dot * USV_P.Gain1_Gain_m;

          // Merge: '<S475>/Merge1' incorporates:
          //   Gain: '<S481>/Gain2'
          //   Product: '<S481>/Product'
          //   Selector: '<S475>/cp[m+1]'
          //   Selector: '<S475>/sp[m+1]'

          rtb_q3dot = USV_B.OutportBufferForsp13[static_cast<int32_T>
            (rtb_Product_gy) - 1] * rtb_q2dot * USV_P.Gain2_Gain_ia;

          // End of Outputs for SubSystem: '<S475>/If Action Subsystem'
        } else {
          // Outputs for IfAction SubSystem: '<S475>/If Action Subsystem1' incorporates:
          //   ActionPort: '<S482>/Action Port'

          // Product: '<S482>/Product1' incorporates:
          //   Constant: '<S484>/Constant'
          //   Product: '<S482>/Product'
          //   Selector: '<S475>/cp[m+1]'
          //   Selector: '<S482>/Selector1'
          //   Sum: '<S472>/Sum2'
          //   Sum: '<S484>/Sum'

          rtb_q3dot = USV_B.Sum2_a[((qY_2 - 1) * 13 + static_cast<int32_T>(
            static_cast<real_T>(roll_sign) + USV_P.Constant_Value_m4)) - 1];
          lw_f_e = USV_B.OutportBufferForcp13[static_cast<int32_T>
            (rtb_Product_gy) - 1];

          // Product: '<S482>/Product' incorporates:
          //   Constant: '<S483>/Constant'
          //   Selector: '<S482>/Selector'
          //   Sum: '<S472>/Sum2'
          //   Sum: '<S483>/Sum'

          rtb_q2dot = USV_B.Sum2_a[((static_cast<int32_T>(static_cast<real_T>
            (roll_sign) + USV_P.Constant_Value_iw) - 1) * 13 +
            static_cast<int32_T>(static_cast<real_T>(qY_2) +
            USV_P.Constant_Value_iw)) - 1];

          // Product: '<S482>/Product1' incorporates:
          //   Product: '<S482>/Product'
          //   Selector: '<S475>/cp[m+1]'
          //   Selector: '<S475>/sp[m+1]'

          rtb_Product_gy = USV_B.OutportBufferForsp13[static_cast<int32_T>
            (rtb_Product_gy) - 1];

          // Merge: '<S475>/Merge' incorporates:
          //   Product: '<S482>/Product'
          //   Product: '<S482>/Product1'
          //   Selector: '<S475>/sp[m+1]'
          //   Selector: '<S482>/Selector'
          //   Sum: '<S482>/Sum'

          rtb_Sum1_dx = rtb_q3dot * rtb_Product_gy + rtb_q2dot * lw_f_e;

          // Merge: '<S475>/Merge1' incorporates:
          //   Product: '<S482>/Product'
          //   Product: '<S482>/Product1'
          //   Selector: '<S475>/cp[m+1]'
          //   Selector: '<S482>/Selector1'
          //   Sum: '<S482>/Sum1'

          rtb_q3dot = rtb_q2dot * rtb_Product_gy - rtb_q3dot * lw_f_e;

          // End of Outputs for SubSystem: '<S475>/If Action Subsystem1'
        }

        // End of If: '<S475>/If'

        // Outputs for Enabled SubSystem: '<S469>/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations' incorporates:
        //   EnablePort: '<S471>/Enable'

        // SignalConversion generated from: '<S471>/Enable'
        if (rtb_Compare_o) {
          // If: '<S471>/if n == m elseif (n==1&m==0) elseif (n>1&m~=n)' incorporates:
          //   Sum: '<S469>/Sum1'

          if (roll_sign == qY_2) {
            // Outputs for IfAction SubSystem: '<S471>/If Action Subsystem' incorporates:
            //   ActionPort: '<S485>/Action Port'

            // Selector: '<S485>/Selector' incorporates:
            //   Constant: '<S489>/Constant'
            //   Gain: '<S489>/Gain'
            //   Sum: '<S489>/Sum1'
            //   Sum: '<S489>/Sum2'

            if ((qY_2 >= 0) && (USV_P.Constant_Value_jv < qY_2 - MAX_int32_T)) {
              qY_1 = MAX_int32_T;
            } else if ((qY_2 < 0) && (USV_P.Constant_Value_jv > qY_2 -
                        MIN_int32_T)) {
              qY_1 = MIN_int32_T;
            } else {
              qY_1 = qY_2 - USV_P.Constant_Value_jv;
            }

            i = mul_s32_sat(USV_P.Gain_Gain_aq, qY_1);
            if ((roll_sign < 0) && (i < MIN_int32_T - roll_sign)) {
              i = MIN_int32_T;
            } else if ((roll_sign > 0) && (i > MAX_int32_T - roll_sign)) {
              i = MAX_int32_T;
            } else {
              i += roll_sign;
            }

            // Merge: '<S471>/Merge' incorporates:
            //   Product: '<S485>/Product1'
            //   Selector: '<S485>/Selector'
            //   UnitDelay: '<S471>/Unit Delay1'

            USV_B.Merge_c = USV_DW.UnitDelay1_DSTATE_m[i - 1] * USV_B.sqrt_ix;

            // Selector: '<S485>/Selector' incorporates:
            //   Constant: '<S489>/Constant'
            //   Gain: '<S489>/Gain'
            //   Sum: '<S489>/Sum1'
            //   Sum: '<S489>/Sum2'

            if ((qY_2 >= 0) && (USV_P.Constant_Value_jv < qY_2 - MAX_int32_T)) {
              qY_1 = MAX_int32_T;
            } else if ((qY_2 < 0) && (USV_P.Constant_Value_jv > qY_2 -
                        MIN_int32_T)) {
              qY_1 = MIN_int32_T;
            } else {
              qY_1 = qY_2 - USV_P.Constant_Value_jv;
            }

            i = mul_s32_sat(USV_P.Gain_Gain_aq, qY_1);
            if ((roll_sign < 0) && (i < MIN_int32_T - roll_sign)) {
              i = MIN_int32_T;
            } else if ((roll_sign > 0) && (i > MAX_int32_T - roll_sign)) {
              i = MAX_int32_T;
            } else {
              i += roll_sign;
            }

            // Merge: '<S471>/Merge1' incorporates:
            //   Product: '<S485>/Product'
            //   Product: '<S485>/Product2'
            //   Selector: '<S485>/Selector'
            //   Selector: '<S485>/Selector1'
            //   Sum: '<S485>/Sum'
            //   UnitDelay: '<S471>/Unit Delay'
            //   UnitDelay: '<S471>/Unit Delay1'

            USV_B.Merge1_p = USV_DW.UnitDelay_DSTATE_o[((roll_sign - 1) * 13 +
              qY_2) - 1] * USV_B.sqrt_ix + USV_DW.UnitDelay1_DSTATE_m[i - 1] *
              USV_B.Product4_j;

            // End of Outputs for SubSystem: '<S471>/If Action Subsystem'
          } else if ((roll_sign == 1) && (qY_2 == 0)) {
            // Outputs for IfAction SubSystem: '<S471>/If Action Subsystem1' incorporates:
            //   ActionPort: '<S486>/Action Port'

            // Selector: '<S486>/Selector' incorporates:
            //   Gain: '<S491>/Gain'
            //   Sum: '<S491>/Sum1'

            qY_1 = mul_s32_sat(USV_P.Gain_Gain_l, 0);
            if (qY_1 > 2147483646) {
              i = MAX_int32_T;
            } else {
              i = qY_1 + 1;
            }

            // Merge: '<S471>/Merge' incorporates:
            //   Product: '<S486>/Product3'
            //   Selector: '<S486>/Selector'
            //   UnitDelay: '<S471>/Unit Delay1'

            USV_B.Merge_c = USV_DW.UnitDelay1_DSTATE_m[i - 1] * USV_B.Product4_j;

            // Selector: '<S486>/Selector' incorporates:
            //   Sum: '<S491>/Sum1'

            if (qY_1 > 2147483646) {
              i = MAX_int32_T;
            } else {
              i = qY_1 + 1;
            }

            // Merge: '<S471>/Merge1' incorporates:
            //   Constant: '<S492>/Constant'
            //   Product: '<S486>/Product'
            //   Product: '<S486>/Product2'
            //   Selector: '<S486>/Selector'
            //   Selector: '<S486>/Selector1'
            //   Sum: '<S486>/Sum'
            //   UnitDelay: '<S471>/Unit Delay'
            //   UnitDelay: '<S471>/Unit Delay1'

            USV_B.Merge1_p = USV_DW.UnitDelay_DSTATE_o[USV_P.Constant_Value_ld -
              1] * USV_B.Product4_j - USV_DW.UnitDelay1_DSTATE_m[i - 1] *
              USV_B.sqrt_ix;

            // End of Outputs for SubSystem: '<S471>/If Action Subsystem1'
          } else if ((roll_sign > 1) && (roll_sign != qY_2)) {
            int32_T qY_3;

            // Outputs for IfAction SubSystem: '<S471>/If Action Subsystem2' incorporates:
            //   ActionPort: '<S487>/Action Port'

            // Sum: '<S494>/Sum' incorporates:
            //   Constant: '<S494>/Constant'

            if (USV_P.Constant_Value_cw > MAX_int32_T - roll_sign) {
              qY_1 = MAX_int32_T;
            } else {
              qY_1 = roll_sign + USV_P.Constant_Value_cw;
            }

            if ((qY_2 < 0) && (USV_P.Constant_Value_cw < MIN_int32_T - qY_2)) {
              qY_0 = MIN_int32_T;
            } else if ((qY_2 > 0) && (USV_P.Constant_Value_cw > MAX_int32_T
                        - qY_2)) {
              qY_0 = MAX_int32_T;
            } else {
              qY_0 = qY_2 + USV_P.Constant_Value_cw;
            }

            // Gain: '<S493>/Gain'
            rtb_Sum1_nn = mul_s32_sat(USV_P.Gain_Gain_cl, qY_2);

            // Sum: '<S496>/Sum2' incorporates:
            //   Constant: '<S496>/Constant1'

            if (USV_P.Constant1_Value_b < roll_sign - MAX_int32_T) {
              i = MAX_int32_T;
            } else {
              i = roll_sign - USV_P.Constant1_Value_b;
            }

            // End of Sum: '<S496>/Sum2'

            // Switch: '<S487>/Switch' incorporates:
            //   Constant: '<S487>/Constant'
            //   RelationalOperator: '<S496>/Relational Operator'
            //   Selector: '<S487>/Selector1'
            //   UnitDelay: '<S471>/Unit Delay'

            if (i >= qY_2) {
              // Sum: '<S495>/Sum' incorporates:
              //   Constant: '<S495>/Constant'

              if ((qY_2 < 0) && (USV_P.Constant_Value_al < MIN_int32_T - qY_2))
              {
                qY_3 = MIN_int32_T;
              } else if ((qY_2 > 0) && (USV_P.Constant_Value_al > MAX_int32_T
                          - qY_2)) {
                qY_3 = MAX_int32_T;
              } else {
                qY_3 = qY_2 + USV_P.Constant_Value_al;
              }

              // Selector: '<S487>/Selector1' incorporates:
              //   Constant: '<S495>/Constant1'
              //   Sum: '<S495>/Sum2'

              if (USV_P.Constant1_Value_dk < roll_sign - MAX_int32_T) {
                i = MAX_int32_T;
              } else {
                i = roll_sign - USV_P.Constant1_Value_dk;
              }

              rtb_q2dot = USV_DW.UnitDelay_DSTATE_o[((i - 1) * 13 + qY_3) - 1];
            } else {
              rtb_q2dot = USV_P.Constant_Value_af;
            }

            // End of Switch: '<S487>/Switch'

            // Sum: '<S495>/Sum' incorporates:
            //   Constant: '<S495>/Constant'

            if ((qY_2 < 0) && (USV_P.Constant_Value_al < MIN_int32_T - qY_2)) {
              qY_3 = MIN_int32_T;
            } else if ((qY_2 > 0) && (USV_P.Constant_Value_al > MAX_int32_T
                        - qY_2)) {
              qY_3 = MAX_int32_T;
            } else {
              qY_3 = qY_2 + USV_P.Constant_Value_al;
            }

            // Selector: '<S487>/Selector' incorporates:
            //   Sum: '<S493>/Sum1'

            if (rtb_Sum1_nn > MAX_int32_T - roll_sign) {
              i = MAX_int32_T;
            } else {
              i = roll_sign + rtb_Sum1_nn;
            }

            // Selector: '<S487>/Selector2' incorporates:
            //   Constant: '<S487>/k[13][13]'
            //   Sum: '<S494>/Sum'

            rtb_Product_gy = USV_P.k1313_Value_g[((qY_1 - 1) * 13 + qY_0) - 1];

            // Merge: '<S471>/Merge1' incorporates:
            //   Constant: '<S487>/k[13][13]'
            //   Product: '<S487>/Product'
            //   Product: '<S487>/Product1'
            //   Product: '<S487>/Product4'
            //   Selector: '<S487>/Selector'
            //   Selector: '<S487>/Selector1'
            //   Selector: '<S487>/Selector2'
            //   Sum: '<S487>/Sum'
            //   UnitDelay: '<S471>/Unit Delay'
            //   UnitDelay: '<S471>/Unit Delay1'

            USV_B.Merge1_p = (USV_DW.UnitDelay_DSTATE_o[((roll_sign - 1) * 13 +
              qY_3) - 1] * USV_B.Product4_j - USV_DW.UnitDelay1_DSTATE_m[i - 1] *
                              USV_B.sqrt_ix) - rtb_Product_gy * rtb_q2dot;

            // Sum: '<S497>/Sum2' incorporates:
            //   Constant: '<S497>/Constant1'

            if (USV_P.Constant1_Value_iz < roll_sign - MAX_int32_T) {
              i = MAX_int32_T;
            } else {
              i = roll_sign - USV_P.Constant1_Value_iz;
            }

            // End of Sum: '<S497>/Sum2'

            // Switch: '<S487>/Switch1' incorporates:
            //   Constant: '<S487>/Constant1'
            //   RelationalOperator: '<S497>/Relational Operator'
            //   Selector: '<S487>/Selector'
            //   UnitDelay: '<S471>/Unit Delay1'

            if (i >= qY_2) {
              // Selector: '<S487>/Selector' incorporates:
              //   Constant: '<S493>/Constant1'
              //   Sum: '<S493>/Sum1'
              //   Sum: '<S493>/Sum2'

              if (USV_P.Constant1_Value_js < roll_sign - MAX_int32_T) {
                qY_1 = MAX_int32_T;
              } else {
                qY_1 = roll_sign - USV_P.Constant1_Value_js;
              }

              if ((qY_1 < 0) && (rtb_Sum1_nn < MIN_int32_T - qY_1)) {
                qY_1 = MIN_int32_T;
              } else if ((qY_1 > 0) && (rtb_Sum1_nn > MAX_int32_T - qY_1)) {
                qY_1 = MAX_int32_T;
              } else {
                qY_1 += rtb_Sum1_nn;
              }

              rtb_q2dot = USV_DW.UnitDelay1_DSTATE_m[qY_1 - 1];
            } else {
              rtb_q2dot = USV_P.Constant1_Value_ha;
            }

            // End of Switch: '<S487>/Switch1'

            // Selector: '<S487>/Selector' incorporates:
            //   Sum: '<S493>/Sum1'

            if (rtb_Sum1_nn > MAX_int32_T - roll_sign) {
              rtb_Sum1_nn = MAX_int32_T;
            } else {
              rtb_Sum1_nn += roll_sign;
            }

            // Merge: '<S471>/Merge' incorporates:
            //   Product: '<S487>/Product2'
            //   Product: '<S487>/Product3'
            //   Selector: '<S487>/Selector'
            //   Sum: '<S487>/Sum1'
            //   UnitDelay: '<S471>/Unit Delay1'

            USV_B.Merge_c = USV_DW.UnitDelay1_DSTATE_m[rtb_Sum1_nn - 1] *
              USV_B.Product4_j - rtb_Product_gy * rtb_q2dot;

            // End of Outputs for SubSystem: '<S471>/If Action Subsystem2'
          }

          // End of If: '<S471>/if n == m elseif (n==1&m==0) elseif (n>1&m~=n)'

          // Sum: '<S471>/Sum' incorporates:
          //   Constant: '<S471>/Constant'
          //   Sum: '<S469>/Sum1'

          if ((roll_sign < 0) && (USV_P.Constant_Value_ds < MIN_int32_T
                                  - roll_sign)) {
            qY_1 = MIN_int32_T;
          } else if ((roll_sign > 0) && (USV_P.Constant_Value_ds > MAX_int32_T -
                      roll_sign)) {
            qY_1 = MAX_int32_T;
          } else {
            qY_1 = roll_sign + USV_P.Constant_Value_ds;
          }

          if ((qY_2 < 0) && (USV_P.Constant_Value_ds < MIN_int32_T - qY_2)) {
            qY_0 = MIN_int32_T;
          } else if ((qY_2 > 0) && (USV_P.Constant_Value_ds > MAX_int32_T - qY_2))
          {
            qY_0 = MAX_int32_T;
          } else {
            qY_0 = qY_2 + USV_P.Constant_Value_ds;
          }

          // Assignment: '<S471>/Assignment' incorporates:
          //   Sum: '<S471>/Sum'
          //   UnitDelay: '<S471>/Unit Delay'

          if (ForIterator_IterationMarker[2] < 2) {
            ForIterator_IterationMarker[2] = 2U;
            std::memcpy(&USV_B.Assignment_c[0], &USV_DW.UnitDelay_DSTATE_o[0],
                        169U * sizeof(real_T));
          }

          USV_B.Assignment_c[(qY_0 + 13 * (qY_1 - 1)) - 1] = USV_B.Merge1_p;

          // End of Assignment: '<S471>/Assignment'

          // Assignment: '<S471>/Assignment_snorm'
          if (ForIterator_IterationMarker[3] < 2) {
            ForIterator_IterationMarker[3] = 2U;

            // Assignment: '<S471>/Assignment_snorm' incorporates:
            //   UnitDelay: '<S471>/Unit Delay1'

            std::memcpy(&USV_B.Assignment_snorm[0], &USV_DW.UnitDelay1_DSTATE_m
                        [0], 169U * sizeof(real_T));
          }

          // Sum: '<S488>/Sum2' incorporates:
          //   Constant: '<S488>/Constant'
          //   Sum: '<S471>/Sum'

          if ((qY_0 >= 0) && (USV_P.Constant_Value_hb < qY_0 - MAX_int32_T)) {
            qY_0 = MAX_int32_T;
          } else if ((qY_0 < 0) && (USV_P.Constant_Value_hb > qY_0 - MIN_int32_T))
          {
            qY_0 = MIN_int32_T;
          } else {
            qY_0 -= USV_P.Constant_Value_hb;
          }

          // End of Sum: '<S488>/Sum2'

          // Sum: '<S488>/Sum1' incorporates:
          //   Gain: '<S488>/Gain'
          //   Sum: '<S471>/Sum'

          i = mul_s32_sat(USV_P.Gain_Gain_cx, qY_0);
          if ((qY_1 < 0) && (i < MIN_int32_T - qY_1)) {
            qY_1 = MIN_int32_T;
          } else if ((qY_1 > 0) && (i > MAX_int32_T - qY_1)) {
            qY_1 = MAX_int32_T;
          } else {
            qY_1 += i;
          }

          // End of Sum: '<S488>/Sum1'

          // Assignment: '<S471>/Assignment_snorm'
          USV_B.Assignment_snorm[qY_1 - 1] = USV_B.Merge_c;

          // Update for UnitDelay: '<S471>/Unit Delay' incorporates:
          //   Assignment: '<S471>/Assignment'

          std::memcpy(&USV_DW.UnitDelay_DSTATE_o[0], &USV_B.Assignment_c[0],
                      169U * sizeof(real_T));

          // Update for UnitDelay: '<S471>/Unit Delay1'
          std::memcpy(&USV_DW.UnitDelay1_DSTATE_m[0], &USV_B.Assignment_snorm[0],
                      169U * sizeof(real_T));
        }

        // End of SignalConversion generated from: '<S471>/Enable'
        // End of Outputs for SubSystem: '<S469>/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations' 

        // Sum: '<S470>/Sum' incorporates:
        //   Constant: '<S470>/Constant'
        //   Sum: '<S469>/Sum1'

        if ((qY_2 < 0) && (USV_P.Constant_Value_d3e < MIN_int32_T - qY_2)) {
          qY_1 = MIN_int32_T;
        } else if ((qY_2 > 0) && (USV_P.Constant_Value_d3e > MAX_int32_T - qY_2))
        {
          qY_1 = MAX_int32_T;
        } else {
          qY_1 = qY_2 + USV_P.Constant_Value_d3e;
        }

        // Product: '<S470>/Product' incorporates:
        //   Assignment: '<S471>/Assignment'
        //   Selector: '<S470>/dp[n][m]'

        rtb_q2dot = USV_B.Assignment_c[((Product_f_tmp_tmp - 1) * 13 + qY_1) - 1]
          * rtb_Sum1_dx * rtb_Switch1_h;

        // Selector: '<S470>/snorm[n+m*13]' incorporates:
        //   Gain: '<S474>/Gain'
        //   Sum: '<S469>/Sum1'
        //   Sum: '<S474>/Sum1'

        i = mul_s32_sat(USV_P.Gain_Gain_kp, qY_2);
        if ((qY < 0) && (i < MIN_int32_T - qY)) {
          qY_1 = MIN_int32_T;
        } else if ((qY > 0) && (i > MAX_int32_T - qY)) {
          qY_1 = MAX_int32_T;
        } else {
          qY_1 = qY + i;
        }

        // Product: '<S470>/par' incorporates:
        //   Selector: '<S470>/snorm[n+m*13]'

        rtb_Product_gy = USV_B.Assignment_snorm[qY_1 - 1] * rtb_Switch1_h;

        // Outputs for Enabled SubSystem: '<S470>/Special case - North//South Geographic Pole' incorporates:
        //   EnablePort: '<S473>/Enable'

        // Logic: '<S476>/Logical Operator' incorporates:
        //   Constant: '<S476>/Constant'
        //   Constant: '<S476>/Constant1'
        //   RelationalOperator: '<S476>/Relational Operator'
        //   RelationalOperator: '<S476>/Relational Operator1'
        //   Sum: '<S469>/Sum1'

        if ((USV_B.sqrt_ix == USV_P.Constant1_Value_ng) &&
            (USV_P.Constant_Value_jq == qY_2)) {
          USV_DW.SpecialcaseNorthSouthGeographic = true;

          // If: '<S473>/n ==1' incorporates:
          //   Assignment: '<S478>/Assignment2'

          if (roll_sign == 1) {
            // Outputs for IfAction SubSystem: '<S473>/If Action Subsystem1' incorporates:
            //   ActionPort: '<S477>/Action Port'

            // Assignment: '<S477>/Assignment2' incorporates:
            //   Constant: '<S477>/Constant'
            //   Selector: '<S477>/pp[n-1]'
            //   Sum: '<S477>/Sum2'
            //   UnitDelay: '<S473>/Unit Delay1'

            if (ForIterator_IterationMarker[0] < 2) {
              ForIterator_IterationMarker[0] = 2U;
              std::memcpy(&USV_B.Assignment2_a[0], &USV_DW.UnitDelay1_DSTATE_h[0],
                          13U * sizeof(real_T));
            }

            USV_B.Assignment2_a[static_cast<int32_T>(USV_P.Constant_Value_cs +
              1.0) - 1] = USV_DW.UnitDelay1_DSTATE_h[0];

            // End of Assignment: '<S477>/Assignment2'
            // End of Outputs for SubSystem: '<S473>/If Action Subsystem1'
          } else {
            // Outputs for IfAction SubSystem: '<S473>/If Action Subsystem2' incorporates:
            //   ActionPort: '<S478>/Action Port'

            if (ForIterator_IterationMarker[1] < 2) {
              // Assignment: '<S478>/Assignment2'
              ForIterator_IterationMarker[1] = 2U;

              // Assignment: '<S478>/Assignment2' incorporates:
              //   UnitDelay: '<S473>/Unit Delay1'

              std::memcpy(&USV_B.Assignment2_o[0], &USV_DW.UnitDelay1_DSTATE_h[0],
                          13U * sizeof(real_T));
            }

            // Sum: '<S478>/Sum2' incorporates:
            //   Constant: '<S478>/Constant'

            if ((roll_sign < 0) && (USV_P.Constant_Value_b < MIN_int32_T
                                    - roll_sign)) {
              i = MIN_int32_T;
            } else if ((roll_sign > 0) && (USV_P.Constant_Value_b > MAX_int32_T
                        - roll_sign)) {
              i = MAX_int32_T;
            } else {
              i = roll_sign + USV_P.Constant_Value_b;
            }

            // End of Sum: '<S478>/Sum2'

            // Sum: '<S480>/Sum' incorporates:
            //   Constant: '<S480>/Constant'

            if ((qY_2 < 0) && (USV_P.Constant_Value_pi < MIN_int32_T - qY_2)) {
              qY_1 = MIN_int32_T;
            } else if ((qY_2 > 0) && (USV_P.Constant_Value_pi > MAX_int32_T
                        - qY_2)) {
              qY_1 = MAX_int32_T;
            } else {
              qY_1 = qY_2 + USV_P.Constant_Value_pi;
            }

            if ((roll_sign < 0) && (USV_P.Constant_Value_pi < MIN_int32_T
                                    - roll_sign)) {
              qY_0 = MIN_int32_T;
            } else if ((roll_sign > 0) && (USV_P.Constant_Value_pi > MAX_int32_T
                        - roll_sign)) {
              qY_0 = MAX_int32_T;
            } else {
              qY_0 = roll_sign + USV_P.Constant_Value_pi;
            }

            // End of Sum: '<S480>/Sum'

            // Selector: '<S478>/pp[n-2] pp[n-1]' incorporates:
            //   Constant: '<S479>/Constant1'
            //   Sum: '<S479>/Sum2'

            if ((roll_sign >= 0) && (USV_P.Constant1_Value_h3 < roll_sign -
                 MAX_int32_T)) {
              rtb_Sum1_nn = MAX_int32_T;
            } else if ((roll_sign < 0) && (USV_P.Constant1_Value_h3 > roll_sign
                        - MIN_int32_T)) {
              rtb_Sum1_nn = MIN_int32_T;
            } else {
              rtb_Sum1_nn = roll_sign - USV_P.Constant1_Value_h3;
            }

            // Assignment: '<S478>/Assignment2' incorporates:
            //   Constant: '<S478>/k[13][13]'
            //   Product: '<S478>/Product1'
            //   Product: '<S478>/Product2'
            //   Selector: '<S478>/Selector2'
            //   Selector: '<S478>/pp[n-2] pp[n-1]'
            //   Sum: '<S478>/Sum1'
            //   UnitDelay: '<S473>/Unit Delay1'

            USV_B.Assignment2_o[i - 1] = USV_DW.UnitDelay1_DSTATE_h[roll_sign -
              1] * USV_B.Product4_j - USV_P.k1313_Value[((qY_0 - 1) * 13 + qY_1)
              - 1] * USV_DW.UnitDelay1_DSTATE_h[rtb_Sum1_nn - 1];

            // End of Outputs for SubSystem: '<S473>/If Action Subsystem2'
          }

          // End of If: '<S473>/n ==1'

          // SignalConversion generated from: '<S473>/pp[n]' incorporates:
          //   UnitDelay: '<S473>/Unit Delay1'

          rtb_TmpSignalConversionAtppnInp[0] = USV_DW.UnitDelay1_DSTATE_h[0];
          rtb_TmpSignalConversionAtppnInp[1] = USV_B.Assignment2_a[1];
          std::memcpy(&rtb_TmpSignalConversionAtppnInp[2], &USV_B.Assignment2_o
                      [2], 11U * sizeof(real_T));

          // Product: '<S473>/Product2' incorporates:
          //   Constant: '<S473>/Constant'
          //   Constant: '<S473>/Constant1'
          //   Selector: '<S473>/pp[n]'
          //   Sum: '<S473>/Sum2'

          USV_B.Product2_a = rtb_TmpSignalConversionAtppnInp[static_cast<int32_T>
            (static_cast<real_T>(roll_sign) + USV_P.Constant1_Value_c) - 1] *
            rtb_Switch1_h * USV_P.Constant_Value_i * rtb_q3dot;

          // Update for UnitDelay: '<S473>/Unit Delay1'
          std::memcpy(&USV_DW.UnitDelay1_DSTATE_h[0],
                      &rtb_TmpSignalConversionAtppnInp[0], 13U * sizeof(real_T));
        } else if (USV_DW.SpecialcaseNorthSouthGeographic) {
          // Disable for Product: '<S473>/Product2' incorporates:
          //   Outport: '<S473>/bpp'

          USV_B.Product2_a = USV_P.bpp_Y0;
          USV_DW.SpecialcaseNorthSouthGeographic = false;
        }

        // End of Logic: '<S476>/Logical Operator'
        // End of Outputs for SubSystem: '<S470>/Special case - North//South Geographic Pole' 

        // Sum: '<S470>/Sum1' incorporates:
        //   UnitDelay: '<S470>/Unit Delay1'

        USV_B.Sum1_h = j - rtb_q2dot;

        // Sum: '<S470>/Sum4' incorporates:
        //   Constant: '<S470>/Constant1'
        //   Sum: '<S469>/Sum1'

        if ((qY_2 < 0) && (USV_P.Constant1_Value_lk < MIN_int32_T - qY_2)) {
          qY_2 = MIN_int32_T;
        } else if ((qY_2 > 0) && (USV_P.Constant1_Value_lk > MAX_int32_T - qY_2))
        {
          qY_2 = MAX_int32_T;
        } else {
          qY_2 += USV_P.Constant1_Value_lk;
        }

        // Sum: '<S470>/Sum2' incorporates:
        //   Constant: '<S470>/fm'
        //   Product: '<S470>/Product1'
        //   Selector: '<S470>/fm[m]'
        //   UnitDelay: '<S470>/Unit Delay3'

        USV_B.Sum2_h = USV_P.fm_Value[qY_2 - 1] * rtb_Product_gy * rtb_q3dot +
          rtb_Switch1_a;

        // Sum: '<S470>/Sum3' incorporates:
        //   Constant: '<S470>/fn'
        //   Product: '<S470>/Product2'
        //   Selector: '<S470>/fn[m]'
        //   UnitDelay: '<S470>/Unit Delay2'

        USV_B.Sum3 = USV_P.fn_Value[roll_sign_0 - 1] * rtb_Product_gy *
          rtb_Sum1_dx + rtb_Switch1_k;

        // Sum: '<S470>/Sum5' incorporates:
        //   UnitDelay: '<S470>/Unit Delay4'

        USV_B.Sum5 = rtb_sincos_o1_idx_0 + USV_B.Product2_a;

        // Update for UnitDelay: '<S470>/Unit Delay1'
        j = USV_B.Sum1_h;

        // Update for UnitDelay: '<S470>/Unit Delay3'
        rtb_Switch1_a = USV_B.Sum2_h;

        // Update for UnitDelay: '<S470>/Unit Delay2'
        rtb_Switch1_k = USV_B.Sum3;

        // Update for UnitDelay: '<S470>/Unit Delay4'
        rtb_sincos_o1_idx_0 = USV_B.Sum5;
      }

      // End of Outputs for SubSystem: '<S461>/For Iterator Subsystem'

      // Sum: '<S461>/Sum1' incorporates:
      //   UnitDelay: '<S461>/Unit Delay2'

      USV_B.Sum1[0] = rtb_WhiteNoise_b_idx_0 + USV_B.Sum1_h;
      USV_B.Sum1[1] = dw_l_e + USV_B.Sum2_h;
      USV_B.Sum1[2] = dw_e + USV_B.Sum3;
      USV_B.Sum1[3] = S_df + USV_B.Sum5;

      // Update for UnitDelay: '<S461>/Unit Delay'
      rtb_Product_gy = rtb_Switch1_h;

      // Update for UnitDelay: '<S461>/Unit Delay2'
      rtb_WhiteNoise_b_idx_0 = USV_B.Sum1[0];
      dw_l_e = USV_B.Sum1[1];
      dw_e = USV_B.Sum1[2];
      S_df = USV_B.Sum1[3];
    }

    // End of Outputs for SubSystem: '<S453>/Compute magnetic vector in spherical coordinates' 
  }

  // Switch: '<S513>/Switch' incorporates:
  //   Product: '<S513>/Product'

  if (USV_B.sqrt_ix != 0.0) {
    rtb_sincos_o1_idx_0 = USV_B.Sum1[1] / USV_B.sqrt_ix;
  } else {
    rtb_sincos_o1_idx_0 = USV_B.Sum1[3];
  }

  // End of Switch: '<S513>/Switch'

  // Sum: '<S512>/Sum1' incorporates:
  //   Product: '<S512>/Product1'
  //   Product: '<S512>/Product4'

  rtb_Switch1_h = (0.0 - USV_B.Product11 * USV_B.Sum1[0]) - USV_B.Sum1[2] *
    USV_B.Product12;

  // Trigonometry: '<S515>/Trigonometric Function1'
  rtb_Sum1_dx = rt_atan2d_snf(rtb_sincos_o1_idx_0, rtb_Switch1_h);

  // Product: '<S514>/Product1'
  // Unit Conversion - from: rad to: deg
  // Expression: output = (57.2958*input) + (0)
  rtb_q2dot = USV_B.Product12 * USV_B.Sum1[0];

  // Sum: '<S514>/Sum1' incorporates:
  //   Product: '<S514>/Product4'

  rtb_q2dot -= USV_B.Sum1[2] * USV_B.Product11;

  // Sum: '<S515>/Sum' incorporates:
  //   Product: '<S515>/Product'
  //   Product: '<S515>/Product1'

  rtb_sincos_o1_idx_0 = rtb_sincos_o1_idx_0 * rtb_sincos_o1_idx_0 +
    rtb_Switch1_h * rtb_Switch1_h;

  // UnitConversion: '<S454>/Unit Conversion' incorporates:
  //   Sqrt: '<S515>/sqrt1'
  //   Trigonometry: '<S515>/Trigonometric Function'
  //   UnitConversion: '<S516>/Unit Conversion'
  //   UnitConversion: '<S517>/Unit Conversion'

  // Unit Conversion - from: rad to: deg
  // Expression: output = (57.2958*input) + (0)
  // Unit Conversion - from: deg to: rad
  // Expression: output = (0.0174533*input) + (0)
  rtb_Sum1_dx = 57.295779513082323 * rtb_Sum1_dx * 0.017453292519943295;
  rtb_Switch1_k = 57.295779513082323 * rt_atan2d_snf(rtb_q2dot, std::sqrt
    (rtb_sincos_o1_idx_0)) * 0.017453292519943295;

  // Sqrt: '<S515>/sqrt' incorporates:
  //   Product: '<S515>/Product2'
  //   Sum: '<S515>/Sum1'

  rtb_sincos_o1_idx_0 = std::sqrt(rtb_q2dot * rtb_q2dot + rtb_sincos_o1_idx_0);

  // Product: '<S447>/h1' incorporates:
  //   Trigonometry: '<S447>/sincos'

  rtb_Switch1_h = std::cos(rtb_Switch1_k) * rtb_sincos_o1_idx_0;
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[2] == 0) {
    // Gain: '<S406>/Gain11' incorporates:
    //   UniformRandomNumber: '<S406>/Uniform Random Number7'

    USV_B.Gain11[0] = USV_P.Gain11_Gain *
      USV_DW.UniformRandomNumber7_NextOutput[0];
    USV_B.Gain11[1] = USV_P.Gain11_Gain *
      USV_DW.UniformRandomNumber7_NextOutput[1];
    USV_B.Gain11[2] = USV_P.Gain11_Gain *
      USV_DW.UniformRandomNumber7_NextOutput[2];
  }

  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // MATLAB Function: '<S406>/FaultParamsExtract2' incorporates:
    //   Constant: '<S406>/FaultID2'
    //   Inport: '<Root>/inSILInts'

    // MATLAB Function 'SensorFault/FaultParamsExtract2': '<S411>:1'
    // '<S411>:1:5' if isempty(hFault)
    // '<S411>:1:8' if isempty(fParam)
    // '<S411>:1:12' hFaultTmp=false;
    rtb_Compare_o = false;

    // '<S411>:1:13' fParamTmp=zeros(20,1);
    std::memset(&fParamTmp[0], 0, 20U * sizeof(real_T));

    // '<S411>:1:14' j=1;
    j = 1.0;

    // '<S411>:1:15' for i=1:8
    for (roll_sign = 0; roll_sign < 8; roll_sign++) {
      // '<S411>:1:16' if inInts(i) == FaultID
      if (USV_U.inSILInts[roll_sign] == USV_P.FaultID2_Value_l) {
        // '<S411>:1:17' hFaultTmp=true;
        rtb_Compare_o = true;

        // '<S411>:1:18' fParamTmp(2*j-1)=inFloats(2*i-1);
        pitch_sign = (roll_sign + 1) << 1;
        fParamTmp[static_cast<int32_T>(2.0 * j - 1.0) - 1] =
          inSILFloats[pitch_sign - 2];

        // '<S411>:1:19' fParamTmp(2*j)=inFloats(2*i);
        fParamTmp[static_cast<int32_T>(2.0 * j) - 1] = inSILFloats[pitch_sign -
          1];

        // '<S411>:1:20' j=j+1;
        j++;
      }
    }

    // '<S411>:1:23' if hFaultTmp
    if (rtb_Compare_o) {
      // '<S411>:1:24' hFault=hFaultTmp;
      USV_DW.hFault_g = true;

      // '<S411>:1:25' fParamTmp(17:20) = inFloats(17:20);
      fParamTmp[16] = inSILFloats[16];
      fParamTmp[17] = inSILFloats[17];
      fParamTmp[18] = inSILFloats[18];
      fParamTmp[19] = inSILFloats[19];

      // '<S411>:1:26' fParam=fParamTmp;
      std::memcpy(&USV_DW.fParam_f[0], &fParamTmp[0], 20U * sizeof(real_T));
    }

    // MATLAB Function: '<S417>/Acc NoiseFun' incorporates:
    //   MATLAB Function: '<S406>/FaultParamsExtract2'

    // '<S411>:1:29' hasFault_mag=hFault;
    // '<S411>:1:30' FaultParam=fParam;
    USV_AccNoiseFun(USV_B.Gain11, USV_DW.hFault_g, USV_DW.fParam_f,
                    &USV_B.sf_AccNoiseFun_n);
  }

  // SignalConversion generated from: '<S406>/Matrix Multiply2' incorporates:
  //   Product: '<S447>/x1'
  //   Product: '<S447>/y1'
  //   Product: '<S447>/z1'
  //   Trigonometry: '<S447>/sincos'

  j = std::cos(rtb_Sum1_dx) * rtb_Switch1_h;
  rtb_Switch1_h *= std::sin(rtb_Sum1_dx);
  rtb_Switch1_a = std::sin(rtb_Switch1_k) * rtb_sincos_o1_idx_0;

  // Product: '<S406>/Matrix Multiply2' incorporates:
  //   Concatenate: '<S31>/Vector Concatenate'

  for (i = 0; i < 3; i++) {
    rtb_MatrixMultiply2[i] = (VectorConcatenate[i + 3] * rtb_Switch1_h +
      VectorConcatenate[i] * j) + VectorConcatenate[i + 6] * rtb_Switch1_a;
  }

  // End of Product: '<S406>/Matrix Multiply2'

  // Saturate: '<S70>/Limit  altitude  to troposhere'
  if (rtb_Saturation_1 > USV_P.Limitaltitudetotroposhere_Upper) {
    rtb_Switch1_h = USV_P.Limitaltitudetotroposhere_Upper;
  } else if (rtb_Saturation_1 < USV_P.Limitaltitudetotroposhere_Lower) {
    rtb_Switch1_h = USV_P.Limitaltitudetotroposhere_Lower;
  } else {
    rtb_Switch1_h = rtb_Saturation_1;
  }

  // End of Saturate: '<S70>/Limit  altitude  to troposhere'

  // Sum: '<S70>/Sum1' incorporates:
  //   Constant: '<S70>/Sea Level  Temperature'
  //   Gain: '<S70>/Lapse Rate'

  rtb_sincos_o1_idx_0 = USV_P.SeaLevelTemperature_Value_j - USV_P.LapseRate_Gain
    * rtb_Switch1_h;

  // Gain: '<S70>/1//T0'
  rtb_Switch1_h = USV_P.uT0_Gain * rtb_sincos_o1_idx_0;

  // Sum: '<S70>/Sum' incorporates:
  //   Constant: '<S70>/Altitude of Troposphere'

  rtb_Switch1_k = USV_P.AltitudeofTroposphere_Value - rtb_Saturation_1;

  // Math: '<S70>/(T//T0)^(g//LR) ' incorporates:
  //   Constant: '<S70>/Constant'

  if ((rtb_Switch1_h < 0.0) && (USV_P.Constant_Value_g3 > std::floor
       (USV_P.Constant_Value_g3))) {
    rtb_Switch1_a = -rt_powd_snf(-rtb_Switch1_h, USV_P.Constant_Value_g3);
  } else {
    rtb_Switch1_a = rt_powd_snf(rtb_Switch1_h, USV_P.Constant_Value_g3);
  }

  // End of Math: '<S70>/(T//T0)^(g//LR) '

  // Saturate: '<S70>/Limit  altitude  to Stratosphere'
  if (rtb_Switch1_k > USV_P.LimitaltitudetoStratosphere_Upp) {
    rtb_Switch1_k = USV_P.LimitaltitudetoStratosphere_Upp;
  } else if (rtb_Switch1_k < USV_P.LimitaltitudetoStratosphere_Low) {
    rtb_Switch1_k = USV_P.LimitaltitudetoStratosphere_Low;
  }

  // End of Saturate: '<S70>/Limit  altitude  to Stratosphere'

  // Gain: '<S408>/1//2rhoV^2' incorporates:
  //   Gain: '<S70>/g//R'
  //   Gain: '<S70>/rho0'
  //   Math: '<S70>/Stratosphere Model'
  //   Product: '<S408>/Product2'
  //   Product: '<S422>/Product'
  //   Product: '<S422>/Product1'
  //   Product: '<S422>/Product2'
  //   Product: '<S70>/Product'
  //   Product: '<S70>/Product1'
  //   Product: '<S70>/Product3'
  //   Sum: '<S422>/Sum'
  //
  //  About '<S70>/Stratosphere Model':
  //   Operator: exp

  rtb_sincos_o1_idx_0 = ((UnitConversion_i[0] * UnitConversion_i[0] +
    UnitConversion_i[1] * UnitConversion_i[1]) + UnitConversion_i[2] *
    UnitConversion_i[2]) * (rtb_Switch1_a / rtb_Switch1_h * USV_P.rho0_Gain *
    std::exp(1.0 / rtb_sincos_o1_idx_0 * (USV_P.gR_Gain * rtb_Switch1_k))) *
    USV_P.u2rhoV2_Gain;
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // MATLAB Function: '<S406>/FaultParamsExtract3' incorporates:
    //   Constant: '<S406>/FaultID3'
    //   Inport: '<Root>/inSILInts'

    // MATLAB Function 'SensorFault/FaultParamsExtract3': '<S412>:1'
    // '<S412>:1:5' if isempty(hFault)
    // '<S412>:1:8' if isempty(fParam)
    // '<S412>:1:12' hFaultTmp=false;
    rtb_Compare_o = false;

    // '<S412>:1:13' fParamTmp=zeros(20,1);
    std::memset(&fParamTmp[0], 0, 20U * sizeof(real_T));

    // '<S412>:1:14' j=1;
    j = 1.0;

    // '<S412>:1:15' for i=1:8
    for (roll_sign = 0; roll_sign < 8; roll_sign++) {
      // '<S412>:1:16' if inInts(i) == FaultID
      if (USV_U.inSILInts[roll_sign] == USV_P.FaultID3_Value_n) {
        // '<S412>:1:17' hFaultTmp=true;
        rtb_Compare_o = true;

        // '<S412>:1:18' fParamTmp(2*j-1)=inFloats(2*i-1);
        fParamTmp[static_cast<int32_T>(2.0 * j - 1.0) - 1] = inSILFloats
          [((roll_sign + 1) << 1) - 2];

        // '<S412>:1:19' fParamTmp(2*j)=inFloats(2*i);
        fParamTmp[static_cast<int32_T>(2.0 * j) - 1] = inSILFloats[((roll_sign +
          1) << 1) - 1];

        // '<S412>:1:20' j=j+1;
        j++;
      }
    }

    // '<S412>:1:23' if hFaultTmp
    if (rtb_Compare_o) {
      // '<S412>:1:24' hFault=hFaultTmp;
      USV_DW.hFault = true;

      // '<S412>:1:25' fParamTmp(17:20) = inFloats(17:20);
      fParamTmp[16] = inSILFloats[16];
      fParamTmp[17] = inSILFloats[17];
      fParamTmp[18] = inSILFloats[18];
      fParamTmp[19] = inSILFloats[19];

      // '<S412>:1:26' fParam=fParamTmp;
      std::memcpy(&USV_DW.fParam[0], &fParamTmp[0], 20U * sizeof(real_T));
    }

    // MATLAB Function: '<S406>/baro NoiseFun' incorporates:
    //   MATLAB Function: '<S406>/FaultParamsExtract3'

    // '<S412>:1:29' hasFault_baro=hFault;
    // '<S412>:1:30' FaultParam=fParam;
    // MATLAB Function 'SensorFault/baro NoiseFun': '<S420>:1'
    // '<S420>:1:3' y = 0;
    USV_B.y = 0.0;

    // '<S420>:1:4' if isbyroFault
    if (USV_DW.hFault) {
      // '<S420>:1:5' y = baroFaultParam(1);
      USV_B.y = USV_DW.fParam[0];
    }

    // End of MATLAB Function: '<S406>/baro NoiseFun'
  }

  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[4] == 0) {
    // Product: '<S414>/Product4' incorporates:
    //   Constant: '<S414>/Constant2'
    //   Gain: '<S406>/Gain5'
    //   UniformRandomNumber: '<S406>/Uniform Random Number'

    USV_B.Product4 = USV_P.Gain5_Gain * USV_DW.UniformRandomNumber_NextOutput *
      USV_P.Constant2_Value_le;
  }

  // Sum: '<S406>/Add2' incorporates:
  //   Product: '<S406>/Product'

  rtb_Switch1_h = (rtb_sincos_o1_idx_0 * USV_B.y + rtb_Saturation_1) +
    USV_B.Product4;

  // Saturate: '<S406>/Saturation1'
  if (rtb_Switch1_h > USV_P.Saturation1_UpperSat) {
    rtb_Sum1_dx = USV_P.Saturation1_UpperSat;
  } else if (rtb_Switch1_h < USV_P.Saturation1_LowerSat) {
    rtb_Sum1_dx = USV_P.Saturation1_LowerSat;
  } else {
    rtb_Sum1_dx = rtb_Switch1_h;
  }

  // End of Saturate: '<S406>/Saturation1'

  // Saturate: '<S416>/Limit  altitude  to troposhere'
  if (rtb_Sum1_dx > USV_P.Limitaltitudetotroposhere_Upp_n) {
    rtb_q2dot = USV_P.Limitaltitudetotroposhere_Upp_n;
  } else if (rtb_Sum1_dx < USV_P.Limitaltitudetotroposhere_Low_o) {
    rtb_q2dot = USV_P.Limitaltitudetotroposhere_Low_o;
  } else {
    rtb_q2dot = rtb_Sum1_dx;
  }

  // End of Saturate: '<S416>/Limit  altitude  to troposhere'

  // Sum: '<S416>/Sum1' incorporates:
  //   Constant: '<S416>/Sea Level  Temperature'
  //   Gain: '<S416>/Lapse Rate'

  rtb_q2dot = USV_P.SeaLevelTemperature_Value - USV_P.LapseRate_Gain_b *
    rtb_q2dot;

  // Gain: '<S416>/1//T0'
  rtb_q3dot = USV_P.uT0_Gain_j * rtb_q2dot;

  // Sum: '<S416>/Sum' incorporates:
  //   Constant: '<S416>/Altitude of Troposphere'

  rtb_Switch1_k = USV_P.AltitudeofTroposphere_Value_p - rtb_Sum1_dx;
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[3] == 0) {
    // Product: '<S415>/Product4' incorporates:
    //   Constant: '<S415>/Constant'
    //   Constant: '<S415>/Constant2'
    //   Gain: '<S406>/Gain9'
    //   Gain: '<S415>/Gain2'
    //   Sum: '<S415>/Sum'
    //   UniformRandomNumber: '<S406>/Uniform Random Number4'

    USV_B.Product4_l = (USV_P.Gain2_Gain_j * USV_P.Constant_Value_nz +
                        USV_P.Constant2_Value_ed) * (USV_P.Gain9_Gain *
      USV_DW.UniformRandomNumber4_NextOutput);
  }

  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // DataTypeConversion: '<S402>/Data Type Conversion6' incorporates:
    //   Constant: '<S402>/Constant'

    j = std::floor(USV_P.Constant_Value_da);
    if (rtIsNaN(j) || rtIsInf(j)) {
      j = 0.0;
    } else {
      j = std::fmod(j, 4.294967296E+9);
    }

    // DataTypeConversion: '<S402>/Data Type Conversion6'
    USV_B.fields_updated = j < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>
      (static_cast<uint32_T>(-j))) : static_cast<uint32_T>(j);
  }

  // Outport: '<Root>/MavHILSensor' incorporates:
  //   BusCreator: '<S402>/Bus Creator'
  //   DataTypeConversion: '<S406>/Data Type Conversion3'
  //   Sum: '<S406>/Sum2'

  USV_Y.MavHILSensor.time_usec = rtb_time_usec;
  USV_Y.MavHILSensor.xacc = rtb_AngEuler[0];
  USV_Y.MavHILSensor.yacc = rtb_AngEuler[1];
  USV_Y.MavHILSensor.zacc = rtb_AngEuler[2];
  USV_Y.MavHILSensor.xgyro = static_cast<real32_T>(VectorConcatenate_tmp +
    USV_B.sf_AccNoiseFun_i.y[0]);
  USV_Y.MavHILSensor.ygyro = static_cast<real32_T>(VectorConcatenate_tmp_0 +
    USV_B.sf_AccNoiseFun_i.y[1]);

  // Saturate: '<S427>/Saturation'
  if (rtb_fcn3 > USV_P.Saturation_UpperSat_n[2]) {
    rtb_fcn3 = USV_P.Saturation_UpperSat_n[2];
  } else if (rtb_fcn3 < USV_P.Saturation_LowerSat_f[2]) {
    rtb_fcn3 = USV_P.Saturation_LowerSat_f[2];
  }

  // Outport: '<Root>/MavHILSensor' incorporates:
  //   DataTypeConversion: '<S406>/Data Type Conversion3'
  //   DataTypeConversion: '<S406>/Data Type Conversion4'
  //   Gain: '<S406>/Gain_Mag'
  //   Gain: '<S406>/nT2Gauss'
  //   Sum: '<S406>/Sum2'
  //   Sum: '<S406>/Sum3'

  USV_Y.MavHILSensor.zgyro = static_cast<real32_T>(rtb_fcn3 +
    USV_B.sf_AccNoiseFun_i.y[2]);
  USV_Y.MavHILSensor.xmag = static_cast<real32_T>(USV_P.Gain_Mag_Gain *
    rtb_MatrixMultiply2[0] * USV_P.nT2Gauss_Gain + USV_B.sf_AccNoiseFun_n.y[0]);
  USV_Y.MavHILSensor.ymag = static_cast<real32_T>(USV_P.Gain_Mag_Gain *
    rtb_MatrixMultiply2[1] * USV_P.nT2Gauss_Gain + USV_B.sf_AccNoiseFun_n.y[1]);
  USV_Y.MavHILSensor.zmag = static_cast<real32_T>(USV_P.Gain_Mag_Gain *
    rtb_MatrixMultiply2[2] * USV_P.nT2Gauss_Gain + USV_B.sf_AccNoiseFun_n.y[2]);

  // Math: '<S416>/(T//T0)^(g//LR) ' incorporates:
  //   Constant: '<S416>/Constant'

  if ((rtb_q3dot < 0.0) && (USV_P.Constant_Value_d3 > std::floor
       (USV_P.Constant_Value_d3))) {
    rtb_q3dot = -rt_powd_snf(-rtb_q3dot, USV_P.Constant_Value_d3);
  } else {
    rtb_q3dot = rt_powd_snf(rtb_q3dot, USV_P.Constant_Value_d3);
  }

  // End of Math: '<S416>/(T//T0)^(g//LR) '

  // Saturate: '<S416>/Limit  altitude  to Stratosphere'
  if (rtb_Switch1_k > USV_P.LimitaltitudetoStratosphere_U_n) {
    rtb_Switch1_k = USV_P.LimitaltitudetoStratosphere_U_n;
  } else if (rtb_Switch1_k < USV_P.LimitaltitudetoStratosphere_L_n) {
    rtb_Switch1_k = USV_P.LimitaltitudetoStratosphere_L_n;
  }

  // End of Saturate: '<S416>/Limit  altitude  to Stratosphere'

  // Outport: '<Root>/MavHILSensor' incorporates:
  //   BusCreator: '<S402>/Bus Creator'
  //   Constant: '<S3>/TemperatureConstant'
  //   DataTypeConversion: '<S406>/Data Type Conversion5'
  //   Gain: '<S406>/Gain'
  //   Gain: '<S406>/Gain1'
  //   Gain: '<S416>/P0'
  //   Gain: '<S416>/g//R'
  //   Math: '<S416>/Stratosphere Model'
  //   Product: '<S416>/Product1'
  //   Product: '<S416>/Product2'
  //   Sum: '<S406>/Sum'
  //
  //  About '<S416>/Stratosphere Model':
  //   Operator: exp

  USV_Y.MavHILSensor.abs_pressure = static_cast<real32_T>(std::exp(1.0 /
    rtb_q2dot * (USV_P.gR_Gain_a * rtb_Switch1_k)) * (USV_P.P0_Gain * rtb_q3dot)
    * USV_P.Gain_Gain_d4);
  USV_Y.MavHILSensor.diff_pressure = static_cast<real32_T>(USV_P.Gain1_Gain_e *
    rtb_sincos_o1_idx_0 + USV_B.Product4_l);
  USV_Y.MavHILSensor.pressure_alt = static_cast<real32_T>(rtb_Switch1_h);
  USV_Y.MavHILSensor.temperature = static_cast<real32_T>
    (USV_P.TemperatureConstant_Value);
  USV_Y.MavHILSensor.fields_updated = USV_B.fields_updated;

  // MATLAB Function: '<S8>/ZLimit' incorporates:
  //   Inport: '<Root>/TerrainZ'
  //   Integrator: '<S9>/xe,ye,ze'

  // MATLAB Function 'SensorModel/ZLimit': '<S334>:1'
  // '<S334>:1:2' Xee=xe;
  rtb_Switch1_a = USV_X.xeyeze_CSTATE[2];

  // '<S334>:1:3' if Xee(3)>zt
  if (USV_X.xeyeze_CSTATE[2] > USV_U.TerrainZ) {
    // '<S334>:1:4' Xee(3)=zt;
    rtb_Switch1_a = USV_U.TerrainZ;
  }

  // End of MATLAB Function: '<S8>/ZLimit'
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[6] == 0) {
    // Gain: '<S373>/BiasGain2' incorporates:
    //   UniformRandomNumber: '<S373>/Uniform Random Number5'

    USV_B.BiasGain2[0] = USV_P.BiasGain2_Gain *
      USV_DW.UniformRandomNumber5_NextOutp_n[0];
    USV_B.BiasGain2[1] = USV_P.BiasGain2_Gain *
      USV_DW.UniformRandomNumber5_NextOutp_n[1];
    USV_B.BiasGain2[2] = USV_P.BiasGain2_Gain *
      USV_DW.UniformRandomNumber5_NextOutp_n[2];
  }

  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // MATLAB Function: '<S373>/FaultParamsExtract' incorporates:
    //   Constant: '<S373>/FaultID'
    //   Inport: '<Root>/inSILInts'

    // MATLAB Function 'GPSFault/FaultParamsExtract': '<S377>:1'
    // '<S377>:1:5' if isempty(hFault)
    // '<S377>:1:8' if isempty(fParam)
    // '<S377>:1:12' hFaultTmp=false;
    rtb_Compare_o = false;

    // '<S377>:1:13' fParamTmp=zeros(20,1);
    std::memset(&fParamTmp[0], 0, 20U * sizeof(real_T));

    // '<S377>:1:14' j=1;
    j = 1.0;

    // '<S377>:1:15' for i=1:8
    for (roll_sign = 0; roll_sign < 8; roll_sign++) {
      // '<S377>:1:16' if inInts(i) == FaultID
      if (USV_U.inSILInts[roll_sign] == USV_P.FaultID_Value_p) {
        // '<S377>:1:17' hFaultTmp=true;
        rtb_Compare_o = true;

        // '<S377>:1:18' fParamTmp(2*j-1)=inFloats(2*i-1);
        fParamTmp[static_cast<int32_T>(2.0 * j - 1.0) - 1] = inSILFloats
          [((roll_sign + 1) << 1) - 2];

        // '<S377>:1:19' fParamTmp(2*j)=inFloats(2*i);
        fParamTmp[static_cast<int32_T>(2.0 * j) - 1] = inSILFloats[((roll_sign +
          1) << 1) - 1];

        // '<S377>:1:20' j=j+1;
        j++;
      }
    }

    // '<S377>:1:23' if hFaultTmp
    if (rtb_Compare_o) {
      // '<S377>:1:24' hFault=hFaultTmp;
      USV_DW.hFault_o = true;

      // '<S377>:1:25' fParamTmp(17:20) = inFloats(17:20);
      fParamTmp[16] = inSILFloats[16];
      fParamTmp[17] = inSILFloats[17];
      fParamTmp[18] = inSILFloats[18];
      fParamTmp[19] = inSILFloats[19];

      // '<S377>:1:26' fParam=fParamTmp;
      std::memcpy(&USV_DW.fParam_j[0], &fParamTmp[0], 20U * sizeof(real_T));
    }

    // MATLAB Function: '<S376>/Acc NoiseFun' incorporates:
    //   MATLAB Function: '<S373>/FaultParamsExtract'

    // '<S377>:1:29' hasFault_GPS=hFault;
    // '<S377>:1:30' FaultParam=fParam;
    // MATLAB Function 'GPSFault/AccNoiseSwitch1/Acc NoiseFun': '<S379>:1'
    // '<S379>:1:3' yNoise = 0.3*u;
    USV_B.yNoise[0] = 0.3 * USV_B.BiasGain2[0];
    USV_B.yNoise[1] = 0.3 * USV_B.BiasGain2[1];
    USV_B.yNoise[2] = 0.3 * USV_B.BiasGain2[2];

    // '<S379>:1:4' y3DFix = 3;
    rtb_y3DFix = 3.0;

    // '<S379>:1:5' ySats = 10;
    rtb_ySats = 10.0;

    // '<S379>:1:7' if isGPSFault
    if (USV_DW.hFault_o) {
      // '<S379>:1:8' yNoise = (GPSFaultParams(1))*u;
      USV_B.yNoise[0] = USV_DW.fParam_j[0] * USV_B.BiasGain2[0];
      USV_B.yNoise[1] = USV_DW.fParam_j[0] * USV_B.BiasGain2[1];
      USV_B.yNoise[2] = USV_DW.fParam_j[0] * USV_B.BiasGain2[2];

      // '<S379>:1:9' y3DFix = GPSFaultParams(2);
      rtb_y3DFix = USV_DW.fParam_j[1];

      // '<S379>:1:10' ySats = GPSFaultParams(3);
      rtb_ySats = USV_DW.fParam_j[2];
    }

    // End of MATLAB Function: '<S376>/Acc NoiseFun'

    // UnitConversion: '<S397>/Unit Conversion' incorporates:
    //   Constant: '<S378>/ref_rotation'

    // Unit Conversion - from: deg to: rad
    // Expression: output = (0.0174533*input) + (0)
    rtb_Product_gy = 0.017453292519943295 * USV_P.FlatEarthtoLLA_psi_h;

    // Trigonometry: '<S382>/SinCos'
    USV_B.SinCos_o1_e = std::sin(rtb_Product_gy);

    // Trigonometry: '<S382>/SinCos'
    USV_B.SinCos_o2_g = std::cos(rtb_Product_gy);

    // Sum: '<S400>/Sum' incorporates:
    //   Constant: '<S400>/Constant'
    //   Constant: '<S400>/f'

    rtb_Product_gy = USV_P.f_Value_n - USV_P.Constant_Value_odh;

    // Sqrt: '<S401>/sqrt' incorporates:
    //   Constant: '<S401>/Constant'
    //   Product: '<S401>/Product1'
    //   Sum: '<S401>/Sum1'

    rtb_Product_gy = std::sqrt(USV_P.Constant_Value_jd - rtb_Product_gy *
      rtb_Product_gy);

    // Switch: '<S393>/Switch' incorporates:
    //   Abs: '<S393>/Abs'
    //   Bias: '<S393>/Bias'
    //   Bias: '<S393>/Bias1'
    //   Constant: '<S378>/ref_position'
    //   Constant: '<S393>/Constant2'
    //   Constant: '<S394>/Constant'
    //   Math: '<S393>/Math Function1'
    //   RelationalOperator: '<S394>/Compare'

    if (std::abs(USV_P.ModelParam_GPSLatLong[0]) >
        USV_P.CompareToConstant_const_a) {
      rtb_Product1_i5 = rt_modd_snf(USV_P.ModelParam_GPSLatLong[0] +
        USV_P.Bias_Bias_ao, USV_P.Constant2_Value_j) + USV_P.Bias1_Bias_n;
    } else {
      rtb_Product1_i5 = USV_P.ModelParam_GPSLatLong[0];
    }

    // End of Switch: '<S393>/Switch'

    // Abs: '<S390>/Abs1'
    rtb_Switch1_h = std::abs(rtb_Product1_i5);

    // RelationalOperator: '<S392>/Compare' incorporates:
    //   Constant: '<S392>/Constant'

    rtb_Compare_f = (rtb_Switch1_h > USV_P.CompareToConstant_const_a2);

    // Switch: '<S390>/Switch'
    if (rtb_Compare_f) {
      // Signum: '<S390>/Sign1'
      if (!rtIsNaN(rtb_Product1_i5)) {
        if (rtb_Product1_i5 < 0.0) {
          rtb_Product1_i5 = -1.0;
        } else {
          rtb_Product1_i5 = (rtb_Product1_i5 > 0.0);
        }
      }

      // End of Signum: '<S390>/Sign1'

      // Switch: '<S390>/Switch' incorporates:
      //   Bias: '<S390>/Bias'
      //   Bias: '<S390>/Bias1'
      //   Gain: '<S390>/Gain'
      //   Product: '<S390>/Divide1'

      USV_B.Switch_m = ((rtb_Switch1_h + USV_P.Bias_Bias_ah) *
                        USV_P.Gain_Gain_fe + USV_P.Bias1_Bias_ao) *
        rtb_Product1_i5;
    } else {
      // Switch: '<S390>/Switch'
      USV_B.Switch_m = rtb_Product1_i5;
    }

    // End of Switch: '<S390>/Switch'

    // UnitConversion: '<S398>/Unit Conversion'
    // Unit Conversion - from: deg to: rad
    // Expression: output = (0.0174533*input) + (0)
    rtb_Product1_i5 = 0.017453292519943295 * USV_B.Switch_m;

    // Trigonometry: '<S399>/Trigonometric Function1'
    rtb_Sum1_dx = std::sin(rtb_Product1_i5);

    // Product: '<S399>/Product1' incorporates:
    //   Product: '<S396>/Product2'

    rtb_q2dot = rtb_Product_gy * rtb_Product_gy;

    // Sum: '<S399>/Sum1' incorporates:
    //   Constant: '<S399>/Constant'
    //   Product: '<S399>/Product1'

    rtb_Sum1_dx = USV_P.Constant_Value_jam - rtb_q2dot * rtb_Sum1_dx *
      rtb_Sum1_dx;

    // Product: '<S396>/Product1' incorporates:
    //   Constant: '<S396>/Constant1'
    //   Sqrt: '<S396>/sqrt'

    rtb_sincos_o1_idx_0 = USV_P.Constant1_Value_jyn / std::sqrt(rtb_Sum1_dx);

    // Trigonometry: '<S396>/Trigonometric Function1' incorporates:
    //   Constant: '<S396>/Constant'
    //   Constant: '<S396>/Constant2'
    //   Product: '<S396>/Product3'
    //   Sum: '<S396>/Sum1'

    USV_B.TrigonometricFunction1_c = rt_atan2d_snf(USV_P.Constant2_Value_e4,
      (USV_P.Constant_Value_d1y - rtb_q2dot) * rtb_sincos_o1_idx_0 / rtb_Sum1_dx);

    // Trigonometry: '<S396>/Trigonometric Function2' incorporates:
    //   Constant: '<S396>/Constant3'
    //   Product: '<S396>/Product4'
    //   Trigonometry: '<S396>/Trigonometric Function'

    USV_B.TrigonometricFunction2_k = rt_atan2d_snf(USV_P.Constant3_Value_l,
      rtb_sincos_o1_idx_0 * std::cos(rtb_Product1_i5));
  }

  // Sum: '<S373>/Sum' incorporates:
  //   Integrator: '<S9>/xe,ye,ze'

  rtb_DataTypeConversion2[0] = USV_X.xeyeze_CSTATE[0] + USV_B.yNoise[0];
  rtb_DataTypeConversion2[1] = USV_X.xeyeze_CSTATE[1] + USV_B.yNoise[1];

  // Unit Conversion - from: rad to: deg
  // Expression: output = (57.2958*input) + (0)
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // Switch: '<S381>/Switch1' incorporates:
    //   Constant: '<S381>/Constant'
    //   Constant: '<S381>/Constant1'

    if (rtb_Compare_f) {
      rtb_sincos_o1_idx_0 = USV_P.Constant_Value_ma;
    } else {
      rtb_sincos_o1_idx_0 = USV_P.Constant1_Value_m;
    }

    // End of Switch: '<S381>/Switch1'

    // Sum: '<S381>/Sum' incorporates:
    //   Constant: '<S378>/ref_position'

    rtb_Product_gy = rtb_sincos_o1_idx_0 + USV_P.ModelParam_GPSLatLong[1];

    // Switch: '<S391>/Switch' incorporates:
    //   Abs: '<S391>/Abs'
    //   Constant: '<S395>/Constant'
    //   RelationalOperator: '<S395>/Compare'

    if (std::abs(rtb_Product_gy) > USV_P.CompareToConstant_const_d) {
      // Switch: '<S391>/Switch' incorporates:
      //   Bias: '<S391>/Bias'
      //   Bias: '<S391>/Bias1'
      //   Constant: '<S391>/Constant2'
      //   Math: '<S391>/Math Function1'

      USV_B.Switch_f = rt_modd_snf(rtb_Product_gy + USV_P.Bias_Bias_ck,
        USV_P.Constant2_Value_hc) + USV_P.Bias1_Bias_mx;
    } else {
      // Switch: '<S391>/Switch'
      USV_B.Switch_f = rtb_Product_gy;
    }

    // End of Switch: '<S391>/Switch'
  }

  // Sum: '<S378>/Sum' incorporates:
  //   Product: '<S382>/rad lat'
  //   Product: '<S382>/x*cos'
  //   Product: '<S382>/y*sin'
  //   Sum: '<S382>/Sum'
  //   UnitConversion: '<S383>/Unit Conversion'

  rtb_sincos_o1_idx_0 = (rtb_DataTypeConversion2[0] * USV_B.SinCos_o2_g -
    rtb_DataTypeConversion2[1] * USV_B.SinCos_o1_e) *
    USV_B.TrigonometricFunction1_c * 57.295779513082323 + USV_B.Switch_m;

  // Switch: '<S387>/Switch' incorporates:
  //   Abs: '<S387>/Abs'
  //   Bias: '<S387>/Bias'
  //   Bias: '<S387>/Bias1'
  //   Constant: '<S387>/Constant2'
  //   Constant: '<S388>/Constant'
  //   Math: '<S387>/Math Function1'
  //   RelationalOperator: '<S388>/Compare'

  if (std::abs(rtb_sincos_o1_idx_0) > USV_P.CompareToConstant_const_ew) {
    rtb_sincos_o1_idx_0 = rt_modd_snf(rtb_sincos_o1_idx_0 + USV_P.Bias_Bias_ap,
      USV_P.Constant2_Value_aj) + USV_P.Bias1_Bias_kg;
  }

  // End of Switch: '<S387>/Switch'

  // Abs: '<S384>/Abs1'
  rtb_Product_gy = std::abs(rtb_sincos_o1_idx_0);

  // RelationalOperator: '<S386>/Compare' incorporates:
  //   Constant: '<S386>/Constant'

  rtb_Compare_o = (rtb_Product_gy > USV_P.CompareToConstant_const_l);

  // Switch: '<S384>/Switch' incorporates:
  //   Bias: '<S384>/Bias'
  //   Bias: '<S384>/Bias1'
  //   Gain: '<S384>/Gain'
  //   Product: '<S384>/Divide1'

  if (rtb_Compare_o) {
    // Signum: '<S384>/Sign1'
    if (!rtIsNaN(rtb_sincos_o1_idx_0)) {
      if (rtb_sincos_o1_idx_0 < 0.0) {
        rtb_sincos_o1_idx_0 = -1.0;
      } else {
        rtb_sincos_o1_idx_0 = (rtb_sincos_o1_idx_0 > 0.0);
      }
    }

    // End of Signum: '<S384>/Sign1'
    rtb_sincos_o1_idx_0 *= (rtb_Product_gy + USV_P.Bias_Bias_h) *
      USV_P.Gain_Gain_n + USV_P.Bias1_Bias_e;
  }

  // End of Switch: '<S384>/Switch'

  // DataTypeConversion: '<S331>/Data Type Conversion4' incorporates:
  //   Gain: '<S331>/latScale'

  rtb_fcn3 = rt_roundd_snf(USV_P.latScale_Gain * rtb_sincos_o1_idx_0);
  if (rtIsNaN(rtb_fcn3) || rtIsInf(rtb_fcn3)) {
    rtb_fcn3 = 0.0;
  } else {
    rtb_fcn3 = std::fmod(rtb_fcn3, 4.294967296E+9);
  }

  // Outport: '<Root>/MavHILGPS' incorporates:
  //   DataTypeConversion: '<S331>/Data Type Conversion4'

  USV_Y.MavHILGPS.lat = rtb_fcn3 < 0.0 ? -static_cast<int32_T>
    (static_cast<uint32_T>(-rtb_fcn3)) : static_cast<int32_T>
    (static_cast<uint32_T>(rtb_fcn3));

  // Switch: '<S380>/Switch1' incorporates:
  //   Constant: '<S380>/Constant'
  //   Constant: '<S380>/Constant1'

  if (rtb_Compare_o) {
    rtb_sincos_o1_idx_0 = USV_P.Constant_Value_ph;
  } else {
    rtb_sincos_o1_idx_0 = USV_P.Constant1_Value_d;
  }

  // End of Switch: '<S380>/Switch1'

  // Sum: '<S380>/Sum' incorporates:
  //   Product: '<S382>/rad long '
  //   Product: '<S382>/x*sin'
  //   Product: '<S382>/y*cos'
  //   Sum: '<S378>/Sum'
  //   Sum: '<S382>/Sum1'
  //   UnitConversion: '<S383>/Unit Conversion'

  rtb_sincos_o1_idx_0 += (rtb_DataTypeConversion2[0] * USV_B.SinCos_o1_e +
    rtb_DataTypeConversion2[1] * USV_B.SinCos_o2_g) *
    USV_B.TrigonometricFunction2_k * 57.295779513082323 + USV_B.Switch_f;

  // Switch: '<S385>/Switch' incorporates:
  //   Abs: '<S385>/Abs'
  //   Bias: '<S385>/Bias'
  //   Bias: '<S385>/Bias1'
  //   Constant: '<S385>/Constant2'
  //   Constant: '<S389>/Constant'
  //   Math: '<S385>/Math Function1'
  //   RelationalOperator: '<S389>/Compare'

  if (std::abs(rtb_sincos_o1_idx_0) > USV_P.CompareToConstant_const_an) {
    rtb_sincos_o1_idx_0 = rt_modd_snf(rtb_sincos_o1_idx_0 + USV_P.Bias_Bias_j,
      USV_P.Constant2_Value_jc) + USV_P.Bias1_Bias_d4;
  }

  // End of Switch: '<S385>/Switch'

  // DataTypeConversion: '<S331>/Data Type Conversion5' incorporates:
  //   Gain: '<S331>/lonScale'

  rtb_fcn3 = rt_roundd_snf(USV_P.lonScale_Gain * rtb_sincos_o1_idx_0);
  if (rtIsNaN(rtb_fcn3) || rtIsInf(rtb_fcn3)) {
    rtb_fcn3 = 0.0;
  } else {
    rtb_fcn3 = std::fmod(rtb_fcn3, 4.294967296E+9);
  }

  // Outport: '<Root>/MavHILGPS' incorporates:
  //   DataTypeConversion: '<S331>/Data Type Conversion5'

  USV_Y.MavHILGPS.lon = rtb_fcn3 < 0.0 ? -static_cast<int32_T>
    (static_cast<uint32_T>(-rtb_fcn3)) : static_cast<int32_T>
    (static_cast<uint32_T>(rtb_fcn3));

  // Sum: '<S378>/Sum1' incorporates:
  //   Constant: '<S373>/ModelParam.envAltitude'
  //   Sum: '<S373>/Sum'
  //   UnaryMinus: '<S378>/Ze2height'

  rtb_Switch1_k = -(rtb_Switch1_a + USV_B.yNoise[2]) -
    USV_P.ModelParam_envAltitude;

  // Saturate: '<S373>/Saturation'
  if (rtb_Switch1_k > USV_P.Saturation_UpperSat_e) {
    rtb_Switch1_k = USV_P.Saturation_UpperSat_e;
  } else if (rtb_Switch1_k < USV_P.Saturation_LowerSat_a) {
    rtb_Switch1_k = USV_P.Saturation_LowerSat_a;
  }

  // End of Saturate: '<S373>/Saturation'

  // Gain: '<S331>/altScale'
  rtb_sincos_o1_idx_0 = USV_P.altScale_Gain * rtb_Switch1_k;

  // DataTypeConversion: '<S331>/Data Type Conversion6'
  rtb_fcn3 = rt_roundd_snf(rtb_sincos_o1_idx_0);
  if (rtIsNaN(rtb_fcn3) || rtIsInf(rtb_fcn3)) {
    rtb_fcn3 = 0.0;
  } else {
    rtb_fcn3 = std::fmod(rtb_fcn3, 4.294967296E+9);
  }

  // Outport: '<Root>/MavHILGPS' incorporates:
  //   DataTypeConversion: '<S331>/Data Type Conversion6'

  USV_Y.MavHILGPS.alt = rtb_fcn3 < 0.0 ? -static_cast<int32_T>
    (static_cast<uint32_T>(-rtb_fcn3)) : static_cast<int32_T>
    (static_cast<uint32_T>(rtb_fcn3));
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // DataTypeConversion: '<S331>/Data Type Conversion8' incorporates:
    //   Constant: '<S331>/ModelParam.GPSEphFinal'
    //   Gain: '<S331>/Gain6'

    rtb_fcn3 = rt_roundd_snf(USV_P.Gain6_Gain_o * USV_P.ModelParam_GPSEphFinal);
    if (rtIsNaN(rtb_fcn3) || rtIsInf(rtb_fcn3)) {
      rtb_fcn3 = 0.0;
    } else {
      rtb_fcn3 = std::fmod(rtb_fcn3, 65536.0);
    }

    // DataTypeConversion: '<S331>/Data Type Conversion8'
    USV_B.eph = static_cast<uint16_T>(rtb_fcn3 < 0.0 ? static_cast<int32_T>(
      static_cast<uint16_T>(-static_cast<int16_T>(static_cast<uint16_T>
      (-rtb_fcn3)))) : static_cast<int32_T>(static_cast<uint16_T>(rtb_fcn3)));

    // DataTypeConversion: '<S331>/Data Type Conversion9' incorporates:
    //   Constant: '<S331>/ModelParam.GPSEpvFinal'
    //   Gain: '<S331>/Gain8'

    rtb_fcn3 = rt_roundd_snf(USV_P.Gain8_Gain * USV_P.ModelParam_GPSEpvFinal);
    if (rtIsNaN(rtb_fcn3) || rtIsInf(rtb_fcn3)) {
      rtb_fcn3 = 0.0;
    } else {
      rtb_fcn3 = std::fmod(rtb_fcn3, 65536.0);
    }

    // DataTypeConversion: '<S331>/Data Type Conversion9'
    USV_B.epv = static_cast<uint16_T>(rtb_fcn3 < 0.0 ? static_cast<int32_T>(
      static_cast<uint16_T>(-static_cast<int16_T>(static_cast<uint16_T>
      (-rtb_fcn3)))) : static_cast<int32_T>(static_cast<uint16_T>(rtb_fcn3)));
  }

  // Outputs for IfAction SubSystem: '<S337>/If Warning//Error' incorporates:
  //   ActionPort: '<S361>/if'

  for (i = 0; i < 3; i++) {
    // If: '<S337>/If1' incorporates:
    //   Concatenate: '<S31>/Vector Concatenate'
    //   Math: '<S364>/Math Function'
    //   Math: '<S9>/Transpose'

    Product_f_tmp[3 * i] = VectorConcatenate[i];
    Product_f_tmp[3 * i + 1] = VectorConcatenate[i + 3];
    Product_f_tmp[3 * i + 2] = VectorConcatenate[i + 6];
  }

  // End of Outputs for SubSystem: '<S337>/If Warning//Error'
  for (i = 0; i < 3; i++) {
    // Product: '<S17>/Product' incorporates:
    //   Integrator: '<S9>/ub,vb,wb'
    //   Math: '<S9>/Transpose'

    USV_B.Product_f[i] = 0.0;
    USV_B.Product_f[i] += Product_f_tmp[i] * USV_X.ubvbwb_CSTATE[0];
    USV_B.Product_f[i] += Product_f_tmp[i + 3] * USV_X.ubvbwb_CSTATE[1];
    USV_B.Product_f[i] += Product_f_tmp[i + 6] * USV_X.ubvbwb_CSTATE[2];
  }

  // TransferFcn: '<S375>/Transfer Fcn4'
  rtb_sincos_o1_idx_0 = USV_P.TransferFcn4_C * USV_X.TransferFcn4_CSTATE;

  // Sum: '<S331>/Sum3' incorporates:
  //   TransferFcn: '<S375>/Transfer Fcn1'

  rtb_DataTypeConversion2[0] = USV_B.Product_f[0] + rtb_sincos_o1_idx_0;
  rtb_DataTypeConversion2[1] = USV_P.TransferFcn1_C * USV_X.TransferFcn1_CSTATE
    + USV_B.Product_f[1];

  // MATLAB Function: '<S331>/GenCogVel'
  // MATLAB Function 'SensorModel/HILGPSModel/GenCogVel': '<S374>:1'
  // '<S374>:1:2' v=norm(u(1:2));
  rtb_Product1_i5 = 3.3121686421112381E-170;
  rtb_Switch1_h = std::abs(rtb_DataTypeConversion2[0]);
  if (rtb_Switch1_h > 3.3121686421112381E-170) {
    rtb_Product_gy = 1.0;
    rtb_Product1_i5 = rtb_Switch1_h;
  } else {
    j = rtb_Switch1_h / 3.3121686421112381E-170;
    rtb_Product_gy = j * j;
  }

  rtb_Switch1_h = std::abs(rtb_DataTypeConversion2[1]);
  if (rtb_Switch1_h > rtb_Product1_i5) {
    j = rtb_Product1_i5 / rtb_Switch1_h;
    rtb_Product_gy = rtb_Product_gy * j * j + 1.0;
    rtb_Product1_i5 = rtb_Switch1_h;
  } else {
    j = rtb_Switch1_h / rtb_Product1_i5;
    rtb_Product_gy += j * j;
  }

  rtb_Product_gy = rtb_Product1_i5 * std::sqrt(rtb_Product_gy);

  // '<S374>:1:4' if v < 1
  if (rtb_Product_gy < 1.0) {
    // '<S374>:1:5' cot = 0;
    rtb_Product1_i5 = 0.0;
  } else {
    // '<S374>:1:6' else
    // '<S374>:1:7' cot=atan2d(u(2),u(1));
    rtb_Product1_i5 = 57.295779513082323 * rt_atan2d_snf
      (rtb_DataTypeConversion2[1], rtb_DataTypeConversion2[0]);
  }

  // '<S374>:1:10' if cot<0
  if (rtb_Product1_i5 < 0.0) {
    // '<S374>:1:11' cot=cot+360;
    rtb_Product1_i5 += 360.0;
  }

  // DataTypeConversion: '<S331>/Data Type Conversion3' incorporates:
  //   Gain: '<S331>/VeScale'
  //   Sum: '<S331>/Sum3'
  //   TransferFcn: '<S375>/Transfer Fcn2'

  rtb_fcn3 = rt_roundd_snf(USV_P.VeScale_Gain * rtb_DataTypeConversion2[0]);
  if (rtIsNaN(rtb_fcn3) || rtIsInf(rtb_fcn3)) {
    rtb_fcn3 = 0.0;
  } else {
    rtb_fcn3 = std::fmod(rtb_fcn3, 65536.0);
  }

  j = rt_roundd_snf(USV_P.VeScale_Gain * rtb_DataTypeConversion2[1]);
  if (rtIsNaN(j) || rtIsInf(j)) {
    j = 0.0;
  } else {
    j = std::fmod(j, 65536.0);
  }

  rtb_Switch1_h = rt_roundd_snf((USV_P.TransferFcn2_C *
    USV_X.TransferFcn2_CSTATE + USV_B.Product_f[2]) * USV_P.VeScale_Gain);
  if (rtIsNaN(rtb_Switch1_h) || rtIsInf(rtb_Switch1_h)) {
    rtb_Switch1_h = 0.0;
  } else {
    rtb_Switch1_h = std::fmod(rtb_Switch1_h, 65536.0);
  }

  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // DataTypeConversion: '<S331>/Data Type Conversion10'
    rtb_y3DFix = rt_roundd_snf(rtb_y3DFix);
    if (rtIsNaN(rtb_y3DFix) || rtIsInf(rtb_y3DFix)) {
      rtb_y3DFix = 0.0;
    } else {
      rtb_y3DFix = std::fmod(rtb_y3DFix, 256.0);
    }

    // DataTypeConversion: '<S331>/Data Type Conversion10'
    USV_B.fix_type = static_cast<uint8_T>(rtb_y3DFix < 0.0 ? static_cast<int32_T>
      (static_cast<uint8_T>(-static_cast<int8_T>(static_cast<uint8_T>
      (-rtb_y3DFix)))) : static_cast<int32_T>(static_cast<uint8_T>(rtb_y3DFix)));

    // DataTypeConversion: '<S331>/Data Type Conversion11'
    rtb_y3DFix = rt_roundd_snf(rtb_ySats);
    if (rtIsNaN(rtb_y3DFix) || rtIsInf(rtb_y3DFix)) {
      rtb_y3DFix = 0.0;
    } else {
      rtb_y3DFix = std::fmod(rtb_y3DFix, 256.0);
    }

    // DataTypeConversion: '<S331>/Data Type Conversion11'
    USV_B.satellites_visible = static_cast<uint8_T>(rtb_y3DFix < 0.0 ?
      static_cast<int32_T>(static_cast<uint8_T>(-static_cast<int8_T>(
      static_cast<uint8_T>(-rtb_y3DFix)))) : static_cast<int32_T>
      (static_cast<uint8_T>(rtb_y3DFix)));
  }

  // Outport: '<Root>/MavHILGPS' incorporates:
  //   BusCreator: '<S331>/Bus Creator'

  USV_Y.MavHILGPS.time_usec = rtb_time_usec;
  USV_Y.MavHILGPS.eph = USV_B.eph;
  USV_Y.MavHILGPS.epv = USV_B.epv;

  // DataTypeConversion: '<S331>/Data Type Conversion2' incorporates:
  //   Gain: '<S331>/VelScale'
  //   MATLAB Function: '<S331>/GenCogVel'

  rtb_y3DFix = rt_roundd_snf(USV_P.VelScale_Gain * rtb_Product_gy);
  if (rtIsNaN(rtb_y3DFix) || rtIsInf(rtb_y3DFix)) {
    rtb_y3DFix = 0.0;
  } else {
    rtb_y3DFix = std::fmod(rtb_y3DFix, 65536.0);
  }

  // Outport: '<Root>/MavHILGPS' incorporates:
  //   DataTypeConversion: '<S331>/Data Type Conversion2'
  //   DataTypeConversion: '<S331>/Data Type Conversion3'

  USV_Y.MavHILGPS.vel = static_cast<uint16_T>(rtb_y3DFix < 0.0 ?
    static_cast<int32_T>(static_cast<uint16_T>(-static_cast<int16_T>(
    static_cast<uint16_T>(-rtb_y3DFix)))) : static_cast<int32_T>
    (static_cast<uint16_T>(rtb_y3DFix)));
  USV_Y.MavHILGPS.vn = static_cast<int16_T>(rtb_fcn3 < 0.0 ? static_cast<int32_T>
    (static_cast<int16_T>(-static_cast<int16_T>(static_cast<uint16_T>(-rtb_fcn3))))
    : static_cast<int32_T>(static_cast<int16_T>(static_cast<uint16_T>(rtb_fcn3))));
  USV_Y.MavHILGPS.ve = static_cast<int16_T>(j < 0.0 ? static_cast<int32_T>(
    static_cast<int16_T>(-static_cast<int16_T>(static_cast<uint16_T>(-j)))) :
    static_cast<int32_T>(static_cast<int16_T>(static_cast<uint16_T>(j))));
  USV_Y.MavHILGPS.vd = static_cast<int16_T>(rtb_Switch1_h < 0.0 ? static_cast<
    int32_T>(static_cast<int16_T>(-static_cast<int16_T>(static_cast<uint16_T>
    (-rtb_Switch1_h)))) : static_cast<int32_T>(static_cast<int16_T>(static_cast<
    uint16_T>(rtb_Switch1_h))));

  // DataTypeConversion: '<S331>/Data Type Conversion7' incorporates:
  //   Gain: '<S331>/AngleScale'
  //   MATLAB Function: '<S331>/GenCogVel'

  rtb_fcn3 = rt_roundd_snf(USV_P.AngleScale_Gain * rtb_Product1_i5);
  if (rtIsNaN(rtb_fcn3) || rtIsInf(rtb_fcn3)) {
    rtb_fcn3 = 0.0;
  } else {
    rtb_fcn3 = std::fmod(rtb_fcn3, 65536.0);
  }

  // Outport: '<Root>/MavHILGPS' incorporates:
  //   BusCreator: '<S331>/Bus Creator'
  //   DataTypeConversion: '<S331>/Data Type Conversion7'

  USV_Y.MavHILGPS.cog = static_cast<uint16_T>(rtb_fcn3 < 0.0 ?
    static_cast<int32_T>(static_cast<uint16_T>(-static_cast<int16_T>(
    static_cast<uint16_T>(-rtb_fcn3)))) : static_cast<int32_T>
    (static_cast<uint16_T>(rtb_fcn3)));
  USV_Y.MavHILGPS.fix_type = USV_B.fix_type;
  USV_Y.MavHILGPS.satellites_visible = USV_B.satellites_visible;
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // DataTypeConversion: '<S8>/Data Type Conversion' incorporates:
    //   Constant: '<S8>/CopterID'

    rtb_fcn3 = std::floor(USV_P.CopterID_Value);
    if (rtIsNaN(rtb_fcn3) || rtIsInf(rtb_fcn3)) {
      rtb_fcn3 = 0.0;
    } else {
      rtb_fcn3 = std::fmod(rtb_fcn3, 4.294967296E+9);
    }

    // DataTypeConversion: '<S8>/Data Type Conversion'
    USV_B.copterID = rtb_fcn3 < 0.0 ? -static_cast<int32_T>(static_cast<uint32_T>
      (-rtb_fcn3)) : static_cast<int32_T>(static_cast<uint32_T>(rtb_fcn3));

    // DataTypeConversion: '<S8>/Data Type Conversion2' incorporates:
    //   Constant: '<S8>/UAVType'

    USV_B.vehicleType = USV_P.ModelParam_uavType;
  }

  // Sum: '<S338>/Add'
  rtb_ySats = (VectorConcatenate[0] + VectorConcatenate[4]) + VectorConcatenate
    [8];

  // If: '<S330>/If'
  if (rtsiIsModeUpdateTimeStep(&(&USV_M)->solverInfo)) {
    rtAction = static_cast<int8_T>(!(rtb_ySats > 0.0));
    USV_DW.If_ActiveSubsystem_g = rtAction;
  } else {
    rtAction = USV_DW.If_ActiveSubsystem_g;
  }

  switch (rtAction) {
   case 0:
    // Outputs for IfAction SubSystem: '<S330>/Positive Trace' incorporates:
    //   ActionPort: '<S336>/Action Port'

    // Sqrt: '<S336>/sqrt' incorporates:
    //   Constant: '<S336>/Constant'
    //   Sum: '<S336>/Sum'

    rtb_y3DFix = std::sqrt(rtb_ySats + USV_P.Constant_Value_e);

    // Gain: '<S336>/Gain' incorporates:
    //   Merge: '<S330>/Merge'

    USV_B.Merge[0] = USV_P.Gain_Gain_b * rtb_y3DFix;

    // Gain: '<S336>/Gain1'
    rtb_y3DFix *= USV_P.Gain1_Gain;

    // Product: '<S336>/Product' incorporates:
    //   Merge: '<S330>/Merge'
    //   Sum: '<S358>/Add'
    //   Sum: '<S359>/Add'
    //   Sum: '<S360>/Add'

    USV_B.Merge[1] = (VectorConcatenate[7] - VectorConcatenate[5]) / rtb_y3DFix;
    USV_B.Merge[2] = (VectorConcatenate[2] - VectorConcatenate[6]) / rtb_y3DFix;
    USV_B.Merge[3] = (VectorConcatenate[3] - VectorConcatenate[1]) / rtb_y3DFix;

    // End of Outputs for SubSystem: '<S330>/Positive Trace'
    break;

   case 1:
    // Outputs for IfAction SubSystem: '<S330>/Negative Trace' incorporates:
    //   ActionPort: '<S335>/Action Port'

    // If: '<S335>/Find Maximum Diagonal Value'
    if (rtsiIsModeUpdateTimeStep(&(&USV_M)->solverInfo)) {
      if ((VectorConcatenate[4] > VectorConcatenate[0]) && (VectorConcatenate[4]
           > VectorConcatenate[8])) {
        rtAction = 0;
      } else if (VectorConcatenate[8] > VectorConcatenate[0]) {
        rtAction = 1;
      } else {
        rtAction = 2;
      }

      USV_DW.FindMaximumDiagonalValue_Active = rtAction;
    } else {
      rtAction = USV_DW.FindMaximumDiagonalValue_Active;
    }

    switch (rtAction) {
     case 0:
      // Outputs for IfAction SubSystem: '<S335>/Maximum Value at DCM(2,2)' incorporates:
      //   ActionPort: '<S340>/Action Port'

      // Sqrt: '<S340>/sqrt' incorporates:
      //   Constant: '<S352>/Constant'
      //   Sum: '<S352>/Add'

      rtb_y3DFix = std::sqrt(((VectorConcatenate[4] - VectorConcatenate[0]) -
        VectorConcatenate[8]) + USV_P.Constant_Value_dn);

      // Gain: '<S340>/Gain' incorporates:
      //   Merge: '<S330>/Merge'

      USV_B.Merge[2] = USV_P.Gain_Gain_iq * rtb_y3DFix;

      // Switch: '<S351>/Switch' incorporates:
      //   Constant: '<S351>/Constant1'
      //   Constant: '<S351>/Constant2'

      if (rtb_y3DFix != 0.0) {
        j = USV_P.Constant1_Value_j;
      } else {
        j = USV_P.Constant2_Value_p[0];
        rtb_y3DFix = USV_P.Constant2_Value_p[1];
      }

      // End of Switch: '<S351>/Switch'

      // Product: '<S351>/Product'
      rtb_y3DFix = j / rtb_y3DFix;

      // Gain: '<S340>/Gain1' incorporates:
      //   Merge: '<S330>/Merge'
      //   Product: '<S340>/Product'
      //   Sum: '<S350>/Add'

      USV_B.Merge[1] = (VectorConcatenate[1] + VectorConcatenate[3]) *
        rtb_y3DFix * USV_P.Gain1_Gain_p;

      // Gain: '<S340>/Gain3' incorporates:
      //   Merge: '<S330>/Merge'
      //   Product: '<S340>/Product'
      //   Sum: '<S349>/Add'

      USV_B.Merge[3] = (VectorConcatenate[5] + VectorConcatenate[7]) *
        rtb_y3DFix * USV_P.Gain3_Gain;

      // Gain: '<S340>/Gain4' incorporates:
      //   Merge: '<S330>/Merge'
      //   Product: '<S340>/Product'
      //   Sum: '<S348>/Add'

      USV_B.Merge[0] = (VectorConcatenate[2] - VectorConcatenate[6]) *
        rtb_y3DFix * USV_P.Gain4_Gain;

      // End of Outputs for SubSystem: '<S335>/Maximum Value at DCM(2,2)'
      break;

     case 1:
      // Outputs for IfAction SubSystem: '<S335>/Maximum Value at DCM(3,3)' incorporates:
      //   ActionPort: '<S341>/Action Port'

      // Sqrt: '<S341>/sqrt' incorporates:
      //   Constant: '<S357>/Constant'
      //   Sum: '<S357>/Add'

      rtb_y3DFix = std::sqrt(((VectorConcatenate[8] - VectorConcatenate[0]) -
        VectorConcatenate[4]) + USV_P.Constant_Value_g);

      // Gain: '<S341>/Gain' incorporates:
      //   Merge: '<S330>/Merge'

      USV_B.Merge[3] = USV_P.Gain_Gain_f * rtb_y3DFix;

      // Switch: '<S356>/Switch' incorporates:
      //   Constant: '<S356>/Constant1'
      //   Constant: '<S356>/Constant2'

      if (rtb_y3DFix != 0.0) {
        j = USV_P.Constant1_Value_jw;
      } else {
        j = USV_P.Constant2_Value_h[0];
        rtb_y3DFix = USV_P.Constant2_Value_h[1];
      }

      // End of Switch: '<S356>/Switch'

      // Product: '<S356>/Product'
      rtb_y3DFix = j / rtb_y3DFix;

      // Gain: '<S341>/Gain1' incorporates:
      //   Merge: '<S330>/Merge'
      //   Product: '<S341>/Product'
      //   Sum: '<S353>/Add'

      USV_B.Merge[1] = (VectorConcatenate[2] + VectorConcatenate[6]) *
        rtb_y3DFix * USV_P.Gain1_Gain_a;

      // Gain: '<S341>/Gain2' incorporates:
      //   Merge: '<S330>/Merge'
      //   Product: '<S341>/Product'
      //   Sum: '<S354>/Add'

      USV_B.Merge[2] = (VectorConcatenate[5] + VectorConcatenate[7]) *
        rtb_y3DFix * USV_P.Gain2_Gain;

      // Gain: '<S341>/Gain3' incorporates:
      //   Merge: '<S330>/Merge'
      //   Product: '<S341>/Product'
      //   Sum: '<S355>/Add'

      USV_B.Merge[0] = (VectorConcatenate[3] - VectorConcatenate[1]) *
        rtb_y3DFix * USV_P.Gain3_Gain_e;

      // End of Outputs for SubSystem: '<S335>/Maximum Value at DCM(3,3)'
      break;

     case 2:
      // Outputs for IfAction SubSystem: '<S335>/Maximum Value at DCM(1,1)' incorporates:
      //   ActionPort: '<S339>/Action Port'

      // Sqrt: '<S339>/sqrt' incorporates:
      //   Constant: '<S347>/Constant'
      //   Sum: '<S347>/Add'

      rtb_y3DFix = std::sqrt(((VectorConcatenate[0] - VectorConcatenate[4]) -
        VectorConcatenate[8]) + USV_P.Constant_Value_eb);

      // Gain: '<S339>/Gain' incorporates:
      //   Merge: '<S330>/Merge'

      USV_B.Merge[1] = USV_P.Gain_Gain_am * rtb_y3DFix;

      // Switch: '<S346>/Switch' incorporates:
      //   Constant: '<S346>/Constant1'
      //   Constant: '<S346>/Constant2'

      if (rtb_y3DFix != 0.0) {
        j = USV_P.Constant1_Value_h;
      } else {
        j = USV_P.Constant2_Value_f[0];
        rtb_y3DFix = USV_P.Constant2_Value_f[1];
      }

      // End of Switch: '<S346>/Switch'

      // Product: '<S346>/Product'
      rtb_y3DFix = j / rtb_y3DFix;

      // Gain: '<S339>/Gain1' incorporates:
      //   Merge: '<S330>/Merge'
      //   Product: '<S339>/Product'
      //   Sum: '<S345>/Add'

      USV_B.Merge[2] = (VectorConcatenate[1] + VectorConcatenate[3]) *
        rtb_y3DFix * USV_P.Gain1_Gain_n;

      // Gain: '<S339>/Gain2' incorporates:
      //   Merge: '<S330>/Merge'
      //   Product: '<S339>/Product'
      //   Sum: '<S343>/Add'

      USV_B.Merge[3] = (VectorConcatenate[2] + VectorConcatenate[6]) *
        rtb_y3DFix * USV_P.Gain2_Gain_i;

      // Gain: '<S339>/Gain3' incorporates:
      //   Merge: '<S330>/Merge'
      //   Product: '<S339>/Product'
      //   Sum: '<S344>/Add'

      USV_B.Merge[0] = (VectorConcatenate[7] - VectorConcatenate[5]) *
        rtb_y3DFix * USV_P.Gain3_Gain_d;

      // End of Outputs for SubSystem: '<S335>/Maximum Value at DCM(1,1)'
      break;
    }

    // End of If: '<S335>/Find Maximum Diagonal Value'
    // End of Outputs for SubSystem: '<S330>/Negative Trace'
    break;
  }

  // End of If: '<S330>/If'
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    real32_T MotorRPMS_tmp;

    // DataTypeConversion: '<S8>/Data Type Conversion8' incorporates:
    //   Gain: '<S8>/Gain'

    USV_B.MotorRPMS[0] = static_cast<real32_T>(USV_P.Gain_Gain_da * USV_B.y_k[0]);
    USV_B.MotorRPMS[1] = static_cast<real32_T>(USV_P.Gain_Gain_da * USV_B.y_k[1]);
    USV_B.MotorRPMS[2] = static_cast<real32_T>(USV_P.Gain_Gain_da * USV_B.y_k[2]);

    // DataTypeConversion: '<S8>/Data Type Conversion8' incorporates:
    //   Gain: '<S8>/Gain'

    MotorRPMS_tmp = static_cast<real32_T>(USV_P.Gain_Gain_da * USV_B.y_k[3]);

    // DataTypeConversion: '<S8>/Data Type Conversion8' incorporates:
    //   Gain: '<S8>/Gain'

    USV_B.MotorRPMS[3] = MotorRPMS_tmp;
    USV_B.MotorRPMS[4] = MotorRPMS_tmp;
    USV_B.MotorRPMS[5] = static_cast<real32_T>(USV_P.Gain_Gain_da * USV_B.y_k[4]);

    // DataTypeConversion: '<S8>/Data Type Conversion8' incorporates:
    //   Constant: '<S52>/Constant1'
    //   Gain: '<S8>/Gain'

    MotorRPMS_tmp = static_cast<real32_T>(USV_P.Gain_Gain_da *
      USV_P.Constant1_Value_l2);

    // DataTypeConversion: '<S8>/Data Type Conversion8'
    USV_B.MotorRPMS[6] = MotorRPMS_tmp;
    USV_B.MotorRPMS[7] = MotorRPMS_tmp;
  }

  // Product: '<S9>/Product' incorporates:
  //   Constant: '<S12>/Constant'

  rtb_DataTypeConversion2[0] = rtb_DataTypeConversion[0] /
    USV_P.ModelParam_uavMass;
  rtb_DataTypeConversion2[1] = rtb_DataTypeConversion[1] /
    USV_P.ModelParam_uavMass;

  // Product: '<S48>/j x k' incorporates:
  //   Integrator: '<S9>/p,q,r '
  //   Integrator: '<S9>/ub,vb,wb'

  rtb_sincos_o1_idx_0 = USV_X.ubvbwb_CSTATE[1] * USV_X.pqr_CSTATE[2];

  // Product: '<S49>/k x j' incorporates:
  //   Integrator: '<S9>/p,q,r '
  //   Integrator: '<S9>/ub,vb,wb'

  rtb_q2dot = USV_X.pqr_CSTATE[1] * USV_X.ubvbwb_CSTATE[2];

  // DataTypeConversion: '<S5>/Data Type Conversion' incorporates:
  //   Integrator: '<S9>/p,q,r '
  //   Integrator: '<S9>/ub,vb,wb'
  //   Product: '<S48>/i x j'
  //   Product: '<S48>/k x i'
  //   Product: '<S49>/i x k'
  //   Product: '<S49>/j x i'
  //   Sum: '<S13>/Sum'

  rtb_DataTypeConversion[0] = rtb_sincos_o1_idx_0 - rtb_q2dot;
  rtb_DataTypeConversion[1] = USV_X.pqr_CSTATE[0] * USV_X.ubvbwb_CSTATE[2] -
    USV_X.ubvbwb_CSTATE[0] * USV_X.pqr_CSTATE[2];
  rtb_DataTypeConversion[2] = USV_X.ubvbwb_CSTATE[0] * USV_X.pqr_CSTATE[1] -
    USV_X.pqr_CSTATE[0] * USV_X.ubvbwb_CSTATE[1];

  // Outport: '<Root>/MavVehile3DInfo' incorporates:
  //   BusCreator generated from: '<Root>/MavVehile3DInfo'
  //   Clock: '<S8>/Clock1'

  USV_Y.MavVehile3DInfo.copterID = USV_B.copterID;
  USV_Y.MavVehile3DInfo.vehicleType = USV_B.vehicleType;
  USV_Y.MavVehile3DInfo.runnedTime = rtb_Clock1_tmp;

  // Sum: '<S9>/Sum'
  USV_B.Sum[0] = rtb_DataTypeConversion2[0] + rtb_DataTypeConversion[0];

  // Outport: '<Root>/MavVehile3DInfo' incorporates:
  //   DataTypeConversion: '<S8>/Data Type Conversion4'
  //   DataTypeConversion: '<S8>/Data Type Conversion5'
  //   Integrator: '<S9>/xe,ye,ze'

  USV_Y.MavVehile3DInfo.VelE[0] = static_cast<real32_T>(USV_B.Product_f[0]);
  USV_Y.MavVehile3DInfo.PosE[0] = static_cast<real32_T>(USV_X.xeyeze_CSTATE[0]);

  // Sum: '<S9>/Sum'
  USV_B.Sum[1] = rtb_DataTypeConversion2[1] + rtb_DataTypeConversion[1];

  // Outport: '<Root>/MavVehile3DInfo' incorporates:
  //   DataTypeConversion: '<S8>/Data Type Conversion4'
  //   DataTypeConversion: '<S8>/Data Type Conversion5'
  //   Integrator: '<S9>/xe,ye,ze'

  USV_Y.MavVehile3DInfo.VelE[1] = static_cast<real32_T>(USV_B.Product_f[1]);
  USV_Y.MavVehile3DInfo.PosE[1] = static_cast<real32_T>(USV_X.xeyeze_CSTATE[1]);

  // Sum: '<S9>/Sum'
  USV_B.Sum[2] = rtb_Switch1_i + rtb_DataTypeConversion[2];

  // Outport: '<Root>/MavVehile3DInfo' incorporates:
  //   BusCreator generated from: '<Root>/MavVehile3DInfo'
  //   DataTypeConversion: '<S8>/Data Type Conversion10'
  //   DataTypeConversion: '<S8>/Data Type Conversion4'
  //   DataTypeConversion: '<S8>/Data Type Conversion5'
  //   DataTypeConversion: '<S8>/Data Type Conversion6'
  //   DataTypeConversion: '<S8>/Data Type Conversion7'
  //   DataTypeConversion: '<S8>/Data Type Conversion9'
  //   Integrator: '<S9>/p,q,r '
  //   Integrator: '<S9>/xe,ye,ze'

  USV_Y.MavVehile3DInfo.VelE[2] = static_cast<real32_T>(USV_B.Product_f[2]);
  USV_Y.MavVehile3DInfo.PosE[2] = static_cast<real32_T>(rtb_Switch1_a);
  USV_Y.MavVehile3DInfo.AngEuler[0] = static_cast<real32_T>
    (rtb_VectorConcatenate[2]);
  USV_Y.MavVehile3DInfo.AngEuler[1] = static_cast<real32_T>
    (rtb_VectorConcatenate[1]);
  USV_Y.MavVehile3DInfo.AngEuler[2] = static_cast<real32_T>
    (rtb_VectorConcatenate[0]);
  USV_Y.MavVehile3DInfo.AngQuatern[0] = static_cast<real32_T>(USV_B.Merge[0]);
  USV_Y.MavVehile3DInfo.AngQuatern[1] = static_cast<real32_T>(USV_B.Merge[1]);
  USV_Y.MavVehile3DInfo.AngQuatern[2] = static_cast<real32_T>(USV_B.Merge[2]);
  USV_Y.MavVehile3DInfo.AngQuatern[3] = static_cast<real32_T>(USV_B.Merge[3]);
  for (i = 0; i < 8; i++) {
    USV_Y.MavVehile3DInfo.MotorRPMS[i] = USV_B.MotorRPMS[i];
  }

  USV_Y.MavVehile3DInfo.AccB[0] = static_cast<real32_T>(USV_B.Sum[0]);
  USV_Y.MavVehile3DInfo.RateB[0] = static_cast<real32_T>(USV_X.pqr_CSTATE[0]);
  USV_Y.MavVehile3DInfo.PosGPS[0] = USV_X.xeyeze_CSTATE[0];
  USV_Y.MavVehile3DInfo.AccB[1] = static_cast<real32_T>(USV_B.Sum[1]);
  USV_Y.MavVehile3DInfo.RateB[1] = static_cast<real32_T>(USV_X.pqr_CSTATE[1]);
  USV_Y.MavVehile3DInfo.PosGPS[1] = USV_X.xeyeze_CSTATE[1];
  USV_Y.MavVehile3DInfo.AccB[2] = static_cast<real32_T>(USV_B.Sum[2]);
  USV_Y.MavVehile3DInfo.RateB[2] = static_cast<real32_T>(USV_X.pqr_CSTATE[2]);
  USV_Y.MavVehile3DInfo.PosGPS[2] = rtb_Switch1_a;

  // TransferFcn: '<S52>/Transfer Fcn2'
  rtb_sincos_o1_idx_0 = USV_P.TransferFcn2_C_e * USV_X.TransferFcn2_CSTATE_b;

  // Gain: '<S52>/Gain3' incorporates:
  //   TransferFcn: '<S52>/Transfer Fcn3'

  rtb_Sum1_dx = USV_P.TransferFcn3_C * USV_X.TransferFcn3_CSTATE *
    USV_P.Gain3_Gain_o;

  // Outport: '<Root>/ExtToUE4PX4' incorporates:
  //   Constant: '<Root>/ExtToPX4'
  //   Constant: '<S52>/Constant2'
  //   DataTypeConversion: '<Root>/Data Type Conversion'
  //   Gain: '<S52>/Gain1'
  //   Gain: '<S52>/Gain2'
  //   TransferFcn: '<S52>/Transfer Fcn1'

  USV_Y.ExtToUE4PX4[0] = static_cast<real32_T>(USV_P.Gain1_Gain_nx *
    rtb_sincos_o1_idx_0);
  USV_Y.ExtToUE4PX4[1] = static_cast<real32_T>(USV_P.TransferFcn1_C_c *
    USV_X.TransferFcn1_CSTATE_l * USV_P.Gain2_Gain_k);
  USV_Y.ExtToUE4PX4[2] = static_cast<real32_T>(rtb_Sum1_dx);
  USV_Y.ExtToUE4PX4[3] = static_cast<real32_T>(rtb_Sum1_dx);
  for (i = 0; i < 12; i++) {
    USV_Y.ExtToUE4PX4[i + 4] = static_cast<real32_T>(USV_P.Constant2_Value_o[i]);
  }

  for (i = 0; i < 16; i++) {
    USV_Y.ExtToUE4PX4[i + 16] = static_cast<real32_T>(USV_P.ExtToPX4_Value[i]);
  }

  // End of Outport: '<Root>/ExtToUE4PX4'

  // DataTypeConversion: '<S5>/Data Type Conversion' incorporates:
  //   DataTypeConversion: '<S8>/Data Type Conversion9'

  rtb_DataTypeConversion[0] = static_cast<real32_T>(USV_B.Sum[0]);
  rtb_DataTypeConversion[1] = static_cast<real32_T>(USV_B.Sum[1]);
  rtb_DataTypeConversion[2] = static_cast<real32_T>(USV_B.Sum[2]);
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    for (i = 0; i < 8; i++) {
      // DataTypeConversion: '<S5>/Data Type Conversion3'
      USV_B.DataTypeConversion3[i] = USV_B.MotorRPMS[i];
    }
  }

  // Outport: '<Root>/outCopterData' incorporates:
  //   Constant: '<S5>/Constant'
  //   DataTypeConversion: '<S8>/Data Type Conversion10'
  //   DataTypeConversion: '<S8>/Data Type Conversion4'
  //   Integrator: '<S9>/p,q,r '

  USV_Y.outCopterData[0] = rtb_DataTypeConversion[0];
  USV_Y.outCopterData[3] = static_cast<real32_T>(USV_X.pqr_CSTATE[0]);
  USV_Y.outCopterData[6] = static_cast<real32_T>(USV_B.Product_f[0]);
  USV_Y.outCopterData[1] = rtb_DataTypeConversion[1];
  USV_Y.outCopterData[4] = static_cast<real32_T>(USV_X.pqr_CSTATE[1]);
  USV_Y.outCopterData[7] = static_cast<real32_T>(USV_B.Product_f[1]);
  USV_Y.outCopterData[2] = rtb_DataTypeConversion[2];
  USV_Y.outCopterData[5] = static_cast<real32_T>(USV_X.pqr_CSTATE[2]);
  USV_Y.outCopterData[8] = static_cast<real32_T>(USV_B.Product_f[2]);
  std::memcpy(&USV_Y.outCopterData[9], &USV_B.DataTypeConversion3[0], sizeof
              (real_T) << 3U);
  std::memcpy(&USV_Y.outCopterData[17], &USV_P.Constant_Value_el[0], 15U *
              sizeof(real_T));

  // Gain: '<S21>/High Gain Quaternion Normalization' incorporates:
  //   Constant: '<S21>/Constant'
  //   DotProduct: '<S21>/Dot Product'
  //   Integrator: '<S10>/q0 q1 q2 q3'
  //   Sum: '<S21>/Sum'

  rtb_sincos_o1_idx_0 = (USV_P.Constant_Value_g1 - (((USV_X.q0q1q2q3_CSTATE[0] *
    USV_X.q0q1q2q3_CSTATE[0] + USV_X.q0q1q2q3_CSTATE[1] * USV_X.q0q1q2q3_CSTATE
    [1]) + USV_X.q0q1q2q3_CSTATE[2] * USV_X.q0q1q2q3_CSTATE[2]) +
    USV_X.q0q1q2q3_CSTATE[3] * USV_X.q0q1q2q3_CSTATE[3])) *
    USV_P.CustomVariableMass6DOFQuaternio;

  // SignalConversion generated from: '<S10>/q0 q1 q2 q3' incorporates:
  //   Fcn: '<S21>/q0dot'
  //   Fcn: '<S21>/q1dot'
  //   Fcn: '<S21>/q2dot'
  //   Fcn: '<S21>/q3dot'
  //   Integrator: '<S10>/q0 q1 q2 q3'
  //   Integrator: '<S9>/p,q,r '

  USV_B.TmpSignalConversionAtq0q1q2q3_c[2] = ((USV_X.q0q1q2q3_CSTATE[0] *
    USV_X.pqr_CSTATE[1] + USV_X.pqr_CSTATE[0] * USV_X.q0q1q2q3_CSTATE[3]) -
    USV_X.q0q1q2q3_CSTATE[1] * USV_X.pqr_CSTATE[2]) * 0.5 + rtb_sincos_o1_idx_0 *
    USV_X.q0q1q2q3_CSTATE[2];
  USV_B.TmpSignalConversionAtq0q1q2q3_c[0] = ((USV_X.pqr_CSTATE[0] *
    USV_X.q0q1q2q3_CSTATE[1] + USV_X.pqr_CSTATE[1] * USV_X.q0q1q2q3_CSTATE[2]) +
    USV_X.pqr_CSTATE[2] * USV_X.q0q1q2q3_CSTATE[3]) * -0.5 + rtb_sincos_o1_idx_0
    * USV_X.q0q1q2q3_CSTATE[0];
  USV_B.TmpSignalConversionAtq0q1q2q3_c[1] = ((USV_X.q0q1q2q3_CSTATE[0] *
    USV_X.pqr_CSTATE[0] + USV_X.q0q1q2q3_CSTATE[2] * USV_X.pqr_CSTATE[2]) -
    USV_X.pqr_CSTATE[1] * USV_X.q0q1q2q3_CSTATE[3]) * 0.5 + rtb_sincos_o1_idx_0 *
    USV_X.q0q1q2q3_CSTATE[1];
  USV_B.TmpSignalConversionAtq0q1q2q3_c[3] = ((USV_X.q0q1q2q3_CSTATE[0] *
    USV_X.pqr_CSTATE[2] + USV_X.q0q1q2q3_CSTATE[1] * USV_X.pqr_CSTATE[1]) -
    USV_X.pqr_CSTATE[0] * USV_X.q0q1q2q3_CSTATE[2]) * 0.5 + rtb_sincos_o1_idx_0 *
    USV_X.q0q1q2q3_CSTATE[3];
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // UnitConversion: '<S115>/Unit Conversion' incorporates:
    //   Constant: '<S100>/Wingspan'

    // Unit Conversion - from: m to: ft
    // Expression: output = (3.28084*input) + (0)
    USV_B.UnitConversion_nn = 3.280839895013123 *
      USV_P.DrydenWindTurbulenceModelDisc_l;
  }

  // Outputs for Enabled SubSystem: '<S112>/Hpgw'
  // Constant: '<S112>/Constant1'
  USV_Hpgw(USV_P.DrydenWindTurbulenceModelDisc_a, frac_0, USV_B.sigma_wg_e,
           rtb_Switch1_m2, USV_B.Product_j[3], USV_B.UnitConversion_nn,
           &USV_B.Hpgw, &USV_DW.Hpgw, &USV_P.Hpgw);

  // End of Outputs for SubSystem: '<S112>/Hpgw'

  // Outputs for Enabled SubSystem: '<S112>/Hqgw'
  // Constant: '<S112>/Constant2'
  USV_Hqgw(USV_P.DrydenWindTurbulenceModelDisc_a, USV_B.UnitConversion_n,
           USV_B.Hwgwz.Sum, USV_B.UnitConversion_nn, &USV_B.Hqgw, &USV_DW.Hqgw,
           &USV_P.Hqgw);

  // End of Outputs for SubSystem: '<S112>/Hqgw'

  // Outputs for Enabled SubSystem: '<S112>/Hrgw'
  // Constant: '<S112>/Constant3'
  USV_Hrgw(USV_P.DrydenWindTurbulenceModelDisc_a, USV_B.UnitConversion_n,
           USV_B.Hvgwz.Sum, USV_B.UnitConversion_nn, &USV_B.Hrgw, &USV_DW.Hrgw,
           &USV_P.Hrgw);

  // End of Outputs for SubSystem: '<S112>/Hrgw'

  // If: '<S117>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' incorporates:
  //   Constant: '<S73>/Constant_DCM'

  if (rtsiIsModeUpdateTimeStep(&(&USV_M)->solverInfo)) {
    if (rtb_Switch1 <= 1000.0) {
      rtAction = 0;
    } else if (rtb_Switch1 >= 2000.0) {
      rtAction = 1;
    } else {
      rtAction = 2;
    }

    USV_DW.ifHeightMaxlowaltitudeelseifH_g = rtAction;
  } else {
    rtAction = USV_DW.ifHeightMaxlowaltitudeelseifH_g;
  }

  switch (rtAction) {
   case 0:
    // Outputs for IfAction SubSystem: '<S117>/Low altitude  rates' incorporates:
    //   ActionPort: '<S132>/Action Port'

    USV_Lowaltituderates(USV_P.Constant_DCM_Value, USV_B.Hpgw.Sum,
                         USV_B.Hqgw.Sum1, USV_B.Hrgw.Sum1,
                         USV_B.UnitConversion_o, rtb_VectorConcatenate);

    // End of Outputs for SubSystem: '<S117>/Low altitude  rates'
    break;

   case 1:
    break;

   case 2:
    // Outputs for IfAction SubSystem: '<S117>/Interpolate  rates' incorporates:
    //   ActionPort: '<S131>/Action Port'

    USV_Interpolaterates(USV_B.Hpgw.Sum, USV_B.Hqgw.Sum1, USV_B.Hrgw.Sum1,
                         USV_P.Constant_DCM_Value, USV_B.UnitConversion_o,
                         rtb_Switch1, rtb_VectorConcatenate,
                         &USV_P.Interpolaterates);

    // End of Outputs for SubSystem: '<S117>/Interpolate  rates'
    break;
  }

  // End of If: '<S117>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // UnitConversion: '<S154>/Unit Conversion' incorporates:
    //   Constant: '<S101>/Wingspan'

    // Unit Conversion - from: m to: ft
    // Expression: output = (3.28084*input) + (0)
    USV_B.UnitConversion_id = 3.280839895013123 *
      USV_P.DrydenWindTurbulenceModelDis_dk;
  }

  // Outputs for Enabled SubSystem: '<S151>/Hpgw'
  // Constant: '<S151>/Constant1'
  USV_Hpgw(USV_P.DrydenWindTurbulenceModelDisc_f, rtb_Sum_f4, USV_B.sigma_wg,
           rtb_Switch1_bi, USV_B.Product[3], USV_B.UnitConversion_id,
           &USV_B.Hpgw_f, &USV_DW.Hpgw_f, &USV_P.Hpgw_f);

  // End of Outputs for SubSystem: '<S151>/Hpgw'

  // Outputs for Enabled SubSystem: '<S151>/Hqgw'
  // Constant: '<S151>/Constant2'
  USV_Hqgw(USV_P.DrydenWindTurbulenceModelDisc_f, USV_B.UnitConversion,
           USV_B.Hwgwz_h.Sum, USV_B.UnitConversion_id, &USV_B.Hqgw_j,
           &USV_DW.Hqgw_j, &USV_P.Hqgw_j);

  // End of Outputs for SubSystem: '<S151>/Hqgw'

  // Outputs for Enabled SubSystem: '<S151>/Hrgw'
  // Constant: '<S151>/Constant3'
  USV_Hrgw(USV_P.DrydenWindTurbulenceModelDisc_f, USV_B.UnitConversion,
           USV_B.Hvgwz_m.Sum, USV_B.UnitConversion_id, &USV_B.Hrgw_l,
           &USV_DW.Hrgw_l, &USV_P.Hrgw_l);

  // End of Outputs for SubSystem: '<S151>/Hrgw'

  // If: '<S156>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' incorporates:
  //   Constant: '<S73>/Constant_DCM'
  //   UnitConversion: '<S153>/Unit Conversion'

  if (rtsiIsModeUpdateTimeStep(&(&USV_M)->solverInfo)) {
    if (rtb_Switch1 <= 1000.0) {
      rtAction = 0;
    } else if (rtb_Switch1 >= 2000.0) {
      rtAction = 1;
    } else {
      rtAction = 2;
    }

    USV_DW.ifHeightMaxlowaltitudeelseifH_h = rtAction;
  } else {
    rtAction = USV_DW.ifHeightMaxlowaltitudeelseifH_h;
  }

  switch (rtAction) {
   case 0:
    // Outputs for IfAction SubSystem: '<S156>/Low altitude  rates' incorporates:
    //   ActionPort: '<S171>/Action Port'

    USV_Lowaltituderates(USV_P.Constant_DCM_Value, USV_B.Hpgw_f.Sum,
                         USV_B.Hqgw_j.Sum1, USV_B.Hrgw_l.Sum1,
                         USV_B.UnitConversion_p, rtb_VectorConcatenate);

    // End of Outputs for SubSystem: '<S156>/Low altitude  rates'
    break;

   case 1:
    break;

   case 2:
    // Outputs for IfAction SubSystem: '<S156>/Interpolate  rates' incorporates:
    //   ActionPort: '<S170>/Action Port'

    USV_Interpolaterates(USV_B.Hpgw_f.Sum, USV_B.Hqgw_j.Sum1, USV_B.Hrgw_l.Sum1,
                         USV_P.Constant_DCM_Value, USV_B.UnitConversion_p,
                         rtb_Switch1, rtb_VectorConcatenate,
                         &USV_P.Interpolaterates_b);

    // End of Outputs for SubSystem: '<S156>/Interpolate  rates'
    break;
  }

  // End of If: '<S156>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // If: '<S337>/If1' incorporates:
    //   Constant: '<S337>/Constant'

    rtAction = -1;
    if (rtsiIsModeUpdateTimeStep(&(&USV_M)->solverInfo)) {
      if (USV_P.DirectionCosineMatrixtoQuaterni != 1.0) {
        rtAction = 0;
      }

      USV_DW.If1_ActiveSubsystem = rtAction;
    } else {
      rtAction = USV_DW.If1_ActiveSubsystem;
    }

    if (rtAction == 0) {
      // Outputs for IfAction SubSystem: '<S337>/If Warning//Error' incorporates:
      //   ActionPort: '<S361>/if'

      // Bias: '<S364>/Bias1' incorporates:
      //   Concatenate: '<S31>/Vector Concatenate'
      //   Math: '<S364>/Math Function'
      //   Product: '<S364>/Product'

      for (i = 0; i < 3; i++) {
        for (roll_sign = 0; roll_sign < 3; roll_sign++) {
          Product_f_tmp_tmp = 3 * i + roll_sign;
          Product_f_tmp_0[Product_f_tmp_tmp] = ((VectorConcatenate[3 * i + 1] *
            Product_f_tmp[roll_sign + 3] + VectorConcatenate[3 * i] *
            Product_f_tmp[roll_sign]) + VectorConcatenate[3 * i + 2] *
            Product_f_tmp[roll_sign + 6]) + USV_P.Bias1_Bias_p[Product_f_tmp_tmp];
        }
      }

      // End of Bias: '<S364>/Bias1'

      // RelationalOperator: '<S370>/Compare' incorporates:
      //   Abs: '<S364>/Abs2'
      //   Constant: '<S370>/Constant'

      for (i = 0; i < 9; i++) {
        rtb_Compare_af[i] = (std::abs(Product_f_tmp_0[i]) >
                             USV_P.DirectionCosineMatrixtoQuater_d);
      }

      // End of RelationalOperator: '<S370>/Compare'

      // Logic: '<S364>/Logical Operator1' incorporates:
      //   RelationalOperator: '<S370>/Compare'

      rtb_Compare_f = rtb_Compare_af[0];
      for (pitch_sign = 0; pitch_sign < 8; pitch_sign++) {
        rtb_Compare_f = (rtb_Compare_f || rtb_Compare_af[pitch_sign + 1]);
      }

      // If: '<S361>/If' incorporates:
      //   Abs: '<S365>/Abs1'
      //   Bias: '<S365>/Bias'
      //   Concatenate: '<S31>/Vector Concatenate'
      //   Constant: '<S372>/Constant'
      //   Logic: '<S364>/Logical Operator1'
      //   Product: '<S371>/Product'
      //   Product: '<S371>/Product1'
      //   Product: '<S371>/Product2'
      //   Product: '<S371>/Product3'
      //   Product: '<S371>/Product4'
      //   Product: '<S371>/Product5'
      //   RelationalOperator: '<S372>/Compare'
      //   Reshape: '<S371>/Reshape'
      //   Sum: '<S371>/Sum'

      if (std::abs((((((VectorConcatenate[0] * VectorConcatenate[4] *
                        VectorConcatenate[8] - VectorConcatenate[0] *
                        VectorConcatenate[5] * VectorConcatenate[7]) -
                       VectorConcatenate[1] * VectorConcatenate[3] *
                       VectorConcatenate[8]) + VectorConcatenate[2] *
                      VectorConcatenate[3] * VectorConcatenate[7]) +
                     VectorConcatenate[1] * VectorConcatenate[5] *
                     VectorConcatenate[6]) - VectorConcatenate[2] *
                    VectorConcatenate[4] * VectorConcatenate[6]) +
                   USV_P.Bias_Bias_k) > USV_P.DirectionCosineMatrixtoQuater_d) {
        // Outputs for IfAction SubSystem: '<S361>/If Not Proper' incorporates:
        //   ActionPort: '<S363>/Action Port'

        // If: '<S363>/If' incorporates:
        //   Constant: '<S363>/Constant'

        if (USV_P.DirectionCosineMatrixtoQuaterni == 2.0) {
          // Outputs for IfAction SubSystem: '<S363>/Warning' incorporates:
          //   ActionPort: '<S369>/Action Port'

          // Assertion: '<S369>/Assertion' incorporates:
          //   Constant: '<S363>/Constant1'

          utAssert(USV_P.Constant1_Value_jy != 0.0);

          // End of Outputs for SubSystem: '<S363>/Warning'
        } else if (USV_P.DirectionCosineMatrixtoQuaterni == 3.0) {
          // Outputs for IfAction SubSystem: '<S363>/Error' incorporates:
          //   ActionPort: '<S368>/Action Port'

          // Assertion: '<S368>/Assertion' incorporates:
          //   Constant: '<S363>/Constant1'

          utAssert(USV_P.Constant1_Value_jy != 0.0);

          // End of Outputs for SubSystem: '<S363>/Error'
        }

        // End of If: '<S363>/If'
        // End of Outputs for SubSystem: '<S361>/If Not Proper'
      } else if (rtb_Compare_f) {
        // Outputs for IfAction SubSystem: '<S361>/Else If Not Orthogonal' incorporates:
        //   ActionPort: '<S362>/Action Port'

        // If: '<S362>/If' incorporates:
        //   Constant: '<S362>/Constant'

        if (USV_P.DirectionCosineMatrixtoQuaterni == 2.0) {
          // Outputs for IfAction SubSystem: '<S362>/Warning' incorporates:
          //   ActionPort: '<S367>/Action Port'

          // Assertion: '<S367>/Assertion' incorporates:
          //   Constant: '<S362>/Constant1'

          utAssert(USV_P.Constant1_Value_fo != 0.0);

          // End of Outputs for SubSystem: '<S362>/Warning'
        } else if (USV_P.DirectionCosineMatrixtoQuaterni == 3.0) {
          // Outputs for IfAction SubSystem: '<S362>/Error' incorporates:
          //   ActionPort: '<S366>/Action Port'

          // Assertion: '<S366>/Assertion' incorporates:
          //   Constant: '<S362>/Constant1'

          utAssert(USV_P.Constant1_Value_fo != 0.0);

          // End of Outputs for SubSystem: '<S362>/Error'
        }

        // End of If: '<S362>/If'
        // End of Outputs for SubSystem: '<S361>/Else If Not Orthogonal'
      }

      // End of If: '<S361>/If'
      // End of Outputs for SubSystem: '<S337>/If Warning//Error'
    }
  }

  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[6] == 0) {
    // Gain: '<S331>/BiasGain1' incorporates:
    //   UniformRandomNumber: '<S331>/Uniform Random Number4'

    USV_B.BiasGain1[0] = USV_P.BiasGain1_Gain *
      USV_DW.UniformRandomNumber4_NextOutp_c[0];
    USV_B.BiasGain1[1] = USV_P.BiasGain1_Gain *
      USV_DW.UniformRandomNumber4_NextOutp_c[1];
    USV_B.BiasGain1[2] = USV_P.BiasGain1_Gain *
      USV_DW.UniformRandomNumber4_NextOutp_c[2];
  }

  // Gain: '<S432>/2*zeta * wn'
  rtb_Switch1_m2 = 2.0 * USV_P.FaultParamAPI.FaultInParams[9] *
    USV_P.ThreeaxisInertialMeasurementU_a;

  // Gain: '<S432>/wn^2'
  rtb_Clock1_tmp = USV_P.ThreeaxisInertialMeasurementU_a *
    USV_P.ThreeaxisInertialMeasurementU_a;

  // Sum: '<S432>/Sum2' incorporates:
  //   Gain: '<S432>/2*zeta * wn'
  //   Gain: '<S432>/wn^2'
  //   SecondOrderIntegrator: '<S432>/Integrator, Second-Order Limited'
  //   Sum: '<S432>/Sum3'

  USV_B.Sum2[0] = (rtb_sincos_o2_k[0] - USV_X.IntegratorSecondOrderLimited_CS[0])
    * rtb_Clock1_tmp - rtb_Switch1_m2 * USV_X.IntegratorSecondOrderLimited_CS[3];
  USV_B.Sum2[1] = (rtb_sincos_o2_k[1] - USV_X.IntegratorSecondOrderLimited_CS[1])
    * rtb_Clock1_tmp - rtb_Switch1_m2 * USV_X.IntegratorSecondOrderLimited_CS[4];
  USV_B.Sum2[2] = (rtb_sincos_o2_k[2] - USV_X.IntegratorSecondOrderLimited_CS[2])
    * rtb_Clock1_tmp - rtb_Switch1_m2 * USV_X.IntegratorSecondOrderLimited_CS[5];

  // Gain: '<S443>/2*zeta * wn'
  rtb_Switch1_m2 = 2.0 * USV_P.FaultParamAPI.FaultInParams[13] *
    USV_P.ThreeaxisInertialMeasurement_jf;

  // Gain: '<S443>/wn^2'
  rtb_Clock1_tmp = USV_P.ThreeaxisInertialMeasurement_jf *
    USV_P.ThreeaxisInertialMeasurement_jf;

  // Sum: '<S443>/Sum2' incorporates:
  //   Gain: '<S443>/2*zeta * wn'
  //   Gain: '<S443>/wn^2'
  //   Sum: '<S443>/Sum3'

  USV_B.Sum2_b[0] = (rtb_fuPos[0] - rtb_sincos_o1_h[0]) * rtb_Clock1_tmp -
    rtb_Switch1_m2 * rtb_IntegratorSecondOrderLimi_e[0];
  USV_B.Sum2_b[1] = (rtb_fuPos[1] - rtb_sincos_o1_h[1]) * rtb_Clock1_tmp -
    rtb_Switch1_m2 * rtb_IntegratorSecondOrderLimi_e[1];
  USV_B.Sum2_b[2] = (rtb_fuPos[2] - rtb_sincos_o1_h[2]) * rtb_Clock1_tmp -
    rtb_Switch1_m2 * rtb_IntegratorSecondOrderLimi_e[2];
  if (rtmIsMajorTimeStep((&USV_M)) &&
      (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
    // Assertion: '<S444>/Assertion' incorporates:
    //   Constant: '<S444>/max_val'
    //   Constant: '<S444>/min_val'
    //   Logic: '<S444>/conjunction'
    //   RelationalOperator: '<S444>/max_relop'
    //   RelationalOperator: '<S444>/min_relop'

    utAssert((USV_P.CheckAltitude_min <= rtb_Saturation_1) && (rtb_Saturation_1 <=
              USV_P.CheckAltitude_max));

    // Assertion: '<S445>/Assertion' incorporates:
    //   Constant: '<S445>/max_val'
    //   Constant: '<S445>/min_val'
    //   Logic: '<S445>/conjunction'
    //   RelationalOperator: '<S445>/max_relop'
    //   RelationalOperator: '<S445>/min_relop'

    utAssert((USV_P.CheckLatitude_min <= rtb_Switch_bvp) && (rtb_Switch_bvp <=
              USV_P.CheckLatitude_max));

    // Assertion: '<S446>/Assertion' incorporates:
    //   Constant: '<S446>/max_val'
    //   Constant: '<S446>/min_val'
    //   Logic: '<S446>/conjunction'
    //   RelationalOperator: '<S446>/max_relop'
    //   RelationalOperator: '<S446>/min_relop'

    utAssert((USV_P.CheckLongitude_min <= rtb_Abs1) && (rtb_Abs1 <=
              USV_P.CheckLongitude_max));

    // Assertion: '<S448>/Assertion' incorporates:
    //   Constant: '<S448>/max_val'
    //   Constant: '<S448>/min_val'
    //   Logic: '<S448>/conjunction'
    //   RelationalOperator: '<S448>/max_relop'
    //   RelationalOperator: '<S448>/min_relop'

    utAssert((USV_P.Istimewithinmodellimits_min <= rtb_Sum_hp) && (rtb_Sum_hp <=
              USV_P.Istimewithinmodellimits_max));

    // MATLAB Function 'SensorModel/HILSensorMavModel1/Subsystem/AccelNoiseGainFunction': '<S403>:1' 
    // '<S403>:1:3' if theta>0.1
    // MATLAB Function 'SensorModel/HILSensorMavModel1/Subsystem/GyroNoiseGainFunction': '<S404>:1' 
    // '<S404>:1:3' if theta>0.1
    // MATLAB Function 'SensorModel/HILSensorMavModel1/Subsystem/MagNoiseGainFunction': '<S405>:1' 
    // '<S405>:1:3' if theta>0.1
  }

  if (rtmIsMajorTimeStep((&USV_M))) {
    // Update for Integrator: '<S10>/q0 q1 q2 q3'
    USV_DW.q0q1q2q3_IWORK = 0;
    if (rtmIsMajorTimeStep((&USV_M)) &&
        (&USV_M)->Timing.TaskCounters.TID[5] == 0) {
      // Update for RandomNumber: '<S53>/White Noise'
      USV_DW.NextOutput = rt_nrand_Upu32_Yd_f_pw_snf(&USV_DW.RandSeed) *
        USV_P.WhiteNoise_StdDev + USV_P.WhiteNoise_Mean;
    }

    if (rtmIsMajorTimeStep((&USV_M)) &&
        (&USV_M)->Timing.TaskCounters.TID[3] == 0) {
      // Update for RandomNumber: '<S161>/White Noise'
      USV_DW.NextOutput_g[0] = rt_nrand_Upu32_Yd_f_pw_snf(&USV_DW.RandSeed_a[0])
        * USV_P.WhiteNoise_StdDev_e + USV_P.WhiteNoise_Mean_k;
      USV_DW.NextOutput_g[1] = rt_nrand_Upu32_Yd_f_pw_snf(&USV_DW.RandSeed_a[1])
        * USV_P.WhiteNoise_StdDev_e + USV_P.WhiteNoise_Mean_k;
      USV_DW.NextOutput_g[2] = rt_nrand_Upu32_Yd_f_pw_snf(&USV_DW.RandSeed_a[2])
        * USV_P.WhiteNoise_StdDev_e + USV_P.WhiteNoise_Mean_k;
      USV_DW.NextOutput_g[3] = rt_nrand_Upu32_Yd_f_pw_snf(&USV_DW.RandSeed_a[3])
        * USV_P.WhiteNoise_StdDev_e + USV_P.WhiteNoise_Mean_k;
    }

    // Update for Enabled SubSystem: '<S152>/Hugw(z)'
    USV_Hugwz_Update(&USV_B.Hugwz_e, &USV_DW.Hugwz_e);

    // End of Update for SubSystem: '<S152>/Hugw(z)'

    // Update for Enabled SubSystem: '<S152>/Hvgw(z)'
    USV_Hvgwz_Update(&USV_B.Hvgwz_m, &USV_DW.Hvgwz_m);

    // End of Update for SubSystem: '<S152>/Hvgw(z)'

    // Update for Enabled SubSystem: '<S152>/Hwgw(z)'
    USV_Hwgwz_Update(&USV_B.Hwgwz_h, &USV_DW.Hwgwz_h);

    // End of Update for SubSystem: '<S152>/Hwgw(z)'
    if (rtmIsMajorTimeStep((&USV_M)) &&
        (&USV_M)->Timing.TaskCounters.TID[3] == 0) {
      // Update for RandomNumber: '<S122>/White Noise'
      USV_DW.NextOutput_l[0] = rt_nrand_Upu32_Yd_f_pw_snf(&USV_DW.RandSeed_l[0])
        * USV_P.WhiteNoise_StdDev_k + USV_P.WhiteNoise_Mean_l;
      USV_DW.NextOutput_l[1] = rt_nrand_Upu32_Yd_f_pw_snf(&USV_DW.RandSeed_l[1])
        * USV_P.WhiteNoise_StdDev_k + USV_P.WhiteNoise_Mean_l;
      USV_DW.NextOutput_l[2] = rt_nrand_Upu32_Yd_f_pw_snf(&USV_DW.RandSeed_l[2])
        * USV_P.WhiteNoise_StdDev_k + USV_P.WhiteNoise_Mean_l;
      USV_DW.NextOutput_l[3] = rt_nrand_Upu32_Yd_f_pw_snf(&USV_DW.RandSeed_l[3])
        * USV_P.WhiteNoise_StdDev_k + USV_P.WhiteNoise_Mean_l;
    }

    // Update for Enabled SubSystem: '<S113>/Hugw(z)'
    USV_Hugwz_Update(&USV_B.Hugwz, &USV_DW.Hugwz);

    // End of Update for SubSystem: '<S113>/Hugw(z)'

    // Update for Enabled SubSystem: '<S113>/Hvgw(z)'
    USV_Hvgwz_Update(&USV_B.Hvgwz, &USV_DW.Hvgwz);

    // End of Update for SubSystem: '<S113>/Hvgw(z)'

    // Update for Enabled SubSystem: '<S113>/Hwgw(z)'
    USV_Hwgwz_Update(&USV_B.Hwgwz, &USV_DW.Hwgwz);

    // End of Update for SubSystem: '<S113>/Hwgw(z)'
    if (rtmIsMajorTimeStep((&USV_M)) &&
        (&USV_M)->Timing.TaskCounters.TID[2] == 0) {
      // Update for UniformRandomNumber: '<S406>/Uniform Random Number5'
      USV_DW.UniformRandomNumber5_NextOutput[0] =
        (USV_P.UniformRandomNumber5_Maximum[0] -
         USV_P.UniformRandomNumber5_Minimum[0]) * rt_urand_Upu32_Yd_f_pw_snf
        (&USV_DW.RandSeed_m[0]) + USV_P.UniformRandomNumber5_Minimum[0];

      // Update for UniformRandomNumber: '<S406>/Uniform Random Number1'
      USV_DW.UniformRandomNumber1_NextOutput[0] =
        (USV_P.UniformRandomNumber1_Maximum[0] -
         USV_P.UniformRandomNumber1_Minimum[0]) * rt_urand_Upu32_Yd_f_pw_snf
        (&USV_DW.RandSeed_k[0]) + USV_P.UniformRandomNumber1_Minimum[0];

      // Update for UniformRandomNumber: '<S406>/Uniform Random Number5'
      USV_DW.UniformRandomNumber5_NextOutput[1] =
        (USV_P.UniformRandomNumber5_Maximum[1] -
         USV_P.UniformRandomNumber5_Minimum[1]) * rt_urand_Upu32_Yd_f_pw_snf
        (&USV_DW.RandSeed_m[1]) + USV_P.UniformRandomNumber5_Minimum[1];

      // Update for UniformRandomNumber: '<S406>/Uniform Random Number1'
      USV_DW.UniformRandomNumber1_NextOutput[1] =
        (USV_P.UniformRandomNumber1_Maximum[1] -
         USV_P.UniformRandomNumber1_Minimum[1]) * rt_urand_Upu32_Yd_f_pw_snf
        (&USV_DW.RandSeed_k[1]) + USV_P.UniformRandomNumber1_Minimum[1];

      // Update for UniformRandomNumber: '<S406>/Uniform Random Number5'
      USV_DW.UniformRandomNumber5_NextOutput[2] =
        (USV_P.UniformRandomNumber5_Maximum[2] -
         USV_P.UniformRandomNumber5_Minimum[2]) * rt_urand_Upu32_Yd_f_pw_snf
        (&USV_DW.RandSeed_m[2]) + USV_P.UniformRandomNumber5_Minimum[2];

      // Update for UniformRandomNumber: '<S406>/Uniform Random Number1'
      USV_DW.UniformRandomNumber1_NextOutput[2] =
        (USV_P.UniformRandomNumber1_Maximum[2] -
         USV_P.UniformRandomNumber1_Minimum[2]) * rt_urand_Upu32_Yd_f_pw_snf
        (&USV_DW.RandSeed_k[2]) + USV_P.UniformRandomNumber1_Minimum[2];

      // Update for UniformRandomNumber: '<S406>/Uniform Random Number7'
      USV_DW.UniformRandomNumber7_NextOutput[0] =
        (USV_P.UniformRandomNumber7_Maximum[0] -
         USV_P.UniformRandomNumber7_Minimum[0]) * rt_urand_Upu32_Yd_f_pw_snf
        (&USV_DW.RandSeed_p[0]) + USV_P.UniformRandomNumber7_Minimum[0];
      USV_DW.UniformRandomNumber7_NextOutput[1] =
        (USV_P.UniformRandomNumber7_Maximum[1] -
         USV_P.UniformRandomNumber7_Minimum[1]) * rt_urand_Upu32_Yd_f_pw_snf
        (&USV_DW.RandSeed_p[1]) + USV_P.UniformRandomNumber7_Minimum[1];
      USV_DW.UniformRandomNumber7_NextOutput[2] =
        (USV_P.UniformRandomNumber7_Maximum[2] -
         USV_P.UniformRandomNumber7_Minimum[2]) * rt_urand_Upu32_Yd_f_pw_snf
        (&USV_DW.RandSeed_p[2]) + USV_P.UniformRandomNumber7_Minimum[2];
    }

    if (rtmIsMajorTimeStep((&USV_M)) &&
        (&USV_M)->Timing.TaskCounters.TID[1] == 0) {
      // Update for Memory: '<S467>/otime' incorporates:
      //   Constant: '<S419>/Decimal Year'

      USV_DW.otime_PreviousInput = USV_P.DecimalYear_Value;

      // Update for Memory: '<S466>/olon'
      USV_DW.olon_PreviousInput = USV_B.Switch_h;

      // Update for Memory: '<S465>/olat'
      USV_DW.olat_PreviousInput = USV_B.Switch_j;

      // Update for Memory: '<S465>/oalt'
      USV_DW.oalt_PreviousInput = USV_B.Gain_k;
    }

    if (rtmIsMajorTimeStep((&USV_M)) &&
        (&USV_M)->Timing.TaskCounters.TID[4] == 0) {
      // Update for UniformRandomNumber: '<S406>/Uniform Random Number'
      USV_DW.UniformRandomNumber_NextOutput = (USV_P.UniformRandomNumber_Maximum
        - USV_P.UniformRandomNumber_Minimum) * rt_urand_Upu32_Yd_f_pw_snf
        (&USV_DW.RandSeed_n) + USV_P.UniformRandomNumber_Minimum;
    }

    if (rtmIsMajorTimeStep((&USV_M)) &&
        (&USV_M)->Timing.TaskCounters.TID[3] == 0) {
      // Update for UniformRandomNumber: '<S406>/Uniform Random Number4'
      USV_DW.UniformRandomNumber4_NextOutput =
        (USV_P.UniformRandomNumber4_Maximum - USV_P.UniformRandomNumber4_Minimum)
        * rt_urand_Upu32_Yd_f_pw_snf(&USV_DW.RandSeed_kd) +
        USV_P.UniformRandomNumber4_Minimum;
    }

    if (rtmIsMajorTimeStep((&USV_M)) &&
        (&USV_M)->Timing.TaskCounters.TID[6] == 0) {
      // Update for UniformRandomNumber: '<S373>/Uniform Random Number5'
      USV_DW.UniformRandomNumber5_NextOutp_n[0] =
        (USV_P.UniformRandomNumber5_Maximum_a[0] -
         USV_P.UniformRandomNumber5_Minimum_l[0]) * rt_urand_Upu32_Yd_f_pw_snf
        (&USV_DW.RandSeed_as[0]) + USV_P.UniformRandomNumber5_Minimum_l[0];
      USV_DW.UniformRandomNumber5_NextOutp_n[1] =
        (USV_P.UniformRandomNumber5_Maximum_a[1] -
         USV_P.UniformRandomNumber5_Minimum_l[1]) * rt_urand_Upu32_Yd_f_pw_snf
        (&USV_DW.RandSeed_as[1]) + USV_P.UniformRandomNumber5_Minimum_l[1];
      USV_DW.UniformRandomNumber5_NextOutp_n[2] =
        (USV_P.UniformRandomNumber5_Maximum_a[2] -
         USV_P.UniformRandomNumber5_Minimum_l[2]) * rt_urand_Upu32_Yd_f_pw_snf
        (&USV_DW.RandSeed_as[2]) + USV_P.UniformRandomNumber5_Minimum_l[2];
    }

    // Update for Enabled SubSystem: '<S112>/Hpgw'
    USV_Hpgw_Update(&USV_B.Hpgw, &USV_DW.Hpgw);

    // End of Update for SubSystem: '<S112>/Hpgw'

    // Update for Enabled SubSystem: '<S112>/Hqgw'
    USV_Hqgw_Update(USV_B.Hwgwz.Sum, &USV_B.Hqgw, &USV_DW.Hqgw);

    // End of Update for SubSystem: '<S112>/Hqgw'

    // Update for Enabled SubSystem: '<S112>/Hrgw'
    USV_Hrgw_Update(USV_B.Hvgwz.Sum, &USV_B.Hrgw, &USV_DW.Hrgw);

    // End of Update for SubSystem: '<S112>/Hrgw'

    // Update for Enabled SubSystem: '<S151>/Hpgw'
    USV_Hpgw_Update(&USV_B.Hpgw_f, &USV_DW.Hpgw_f);

    // End of Update for SubSystem: '<S151>/Hpgw'

    // Update for Enabled SubSystem: '<S151>/Hqgw'
    USV_Hqgw_Update(USV_B.Hwgwz_h.Sum, &USV_B.Hqgw_j, &USV_DW.Hqgw_j);

    // End of Update for SubSystem: '<S151>/Hqgw'

    // Update for Enabled SubSystem: '<S151>/Hrgw'
    USV_Hrgw_Update(USV_B.Hvgwz_m.Sum, &USV_B.Hrgw_l, &USV_DW.Hrgw_l);

    // End of Update for SubSystem: '<S151>/Hrgw'
    if (rtmIsMajorTimeStep((&USV_M)) &&
        (&USV_M)->Timing.TaskCounters.TID[6] == 0) {
      // Update for UniformRandomNumber: '<S331>/Uniform Random Number4'
      USV_DW.UniformRandomNumber4_NextOutp_c[0] =
        (USV_P.UniformRandomNumber4_Maximum_j[0] -
         USV_P.UniformRandomNumber4_Minimum_g[0]) * rt_urand_Upu32_Yd_f_pw_snf
        (&USV_DW.RandSeed_lk[0]) + USV_P.UniformRandomNumber4_Minimum_g[0];
      USV_DW.UniformRandomNumber4_NextOutp_c[1] =
        (USV_P.UniformRandomNumber4_Maximum_j[1] -
         USV_P.UniformRandomNumber4_Minimum_g[1]) * rt_urand_Upu32_Yd_f_pw_snf
        (&USV_DW.RandSeed_lk[1]) + USV_P.UniformRandomNumber4_Minimum_g[1];
      USV_DW.UniformRandomNumber4_NextOutp_c[2] =
        (USV_P.UniformRandomNumber4_Maximum_j[2] -
         USV_P.UniformRandomNumber4_Minimum_g[2]) * rt_urand_Upu32_Yd_f_pw_snf
        (&USV_DW.RandSeed_lk[2]) + USV_P.UniformRandomNumber4_Minimum_g[2];
    }
  }                                    // end MajorTimeStep

  if (rtmIsMajorTimeStep((&USV_M))) {
    rt_ertODEUpdateContinuousStates(&(&USV_M)->solverInfo);

    // Update absolute time for base rate
    // The "clockTick0" counts the number of times the code of this task has
    //  been executed. The absolute time is the multiplication of "clockTick0"
    //  and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
    //  overflow during the application lifespan selected.

    ++(&USV_M)->Timing.clockTick0;
    (&USV_M)->Timing.t[0] = rtsiGetSolverStopTime(&(&USV_M)->solverInfo);

    {
      // Update absolute timer for sample time: [0.001s, 0.0s]
      // The "clockTick1" counts the number of times the code of this task has
      //  been executed. The resolution of this integer timer is 0.001, which is the step size
      //  of the task. Size of "clockTick1" ensures timer will not overflow during the
      //  application lifespan selected.

      (&USV_M)->Timing.clockTick1++;
    }

    rate_scheduler((&USV_M));
  }                                    // end MajorTimeStep
}

// Derivatives for root system: '<Root>'
void MulticopterModelClass::USV_derivatives()
{
  XDot_USV_T *_rtXdot;
  _rtXdot = ((XDot_USV_T *) (&USV_M)->derivs);

  // Derivatives for SecondOrderIntegrator: '<S432>/Integrator, Second-Order Limited' 
  if (USV_DW.IntegratorSecondOrderLimited_MO[0] == 0) {
    _rtXdot->IntegratorSecondOrderLimited_CS[0] =
      USV_X.IntegratorSecondOrderLimited_CS[3];
    _rtXdot->IntegratorSecondOrderLimited_CS[3] = USV_B.Sum2[0];
  }

  if (USV_DW.IntegratorSecondOrderLimited_MO[1] == 0) {
    _rtXdot->IntegratorSecondOrderLimited_CS[1] =
      USV_X.IntegratorSecondOrderLimited_CS[4];
    _rtXdot->IntegratorSecondOrderLimited_CS[4] = USV_B.Sum2[1];
  }

  if (USV_DW.IntegratorSecondOrderLimited_MO[2] == 0) {
    _rtXdot->IntegratorSecondOrderLimited_CS[2] =
      USV_X.IntegratorSecondOrderLimited_CS[5];
    _rtXdot->IntegratorSecondOrderLimited_CS[5] = USV_B.Sum2[2];
  }

  // End of Derivatives for SecondOrderIntegrator: '<S432>/Integrator, Second-Order Limited' 

  // Derivatives for Integrator: '<S10>/q0 q1 q2 q3'
  _rtXdot->q0q1q2q3_CSTATE[0] = USV_B.TmpSignalConversionAtq0q1q2q3_c[0];
  _rtXdot->q0q1q2q3_CSTATE[1] = USV_B.TmpSignalConversionAtq0q1q2q3_c[1];
  _rtXdot->q0q1q2q3_CSTATE[2] = USV_B.TmpSignalConversionAtq0q1q2q3_c[2];
  _rtXdot->q0q1q2q3_CSTATE[3] = USV_B.TmpSignalConversionAtq0q1q2q3_c[3];

  // Derivatives for Integrator: '<S9>/xe,ye,ze'
  _rtXdot->xeyeze_CSTATE[0] = USV_B.Product_f[0];
  _rtXdot->xeyeze_CSTATE[1] = USV_B.Product_f[1];
  _rtXdot->xeyeze_CSTATE[2] = USV_B.Product_f[2];

  // Derivatives for Enabled SubSystem: '<S54>/Distance into gust (x)'
  if (USV_DW.Distanceintogustx_MODE) {
    boolean_T lsat;
    boolean_T usat;

    // Derivatives for Integrator: '<S57>/Distance into Gust (x) (Limited to gust length d)' incorporates:
    //   Constant: '<S50>/Constant'

    lsat = (USV_X.DistanceintoGustxLimitedtogus_o <=
            USV_P.DistanceintoGustxLimitedtogus_h);

    // Derivatives for Enabled SubSystem: '<S54>/Distance into gust (x)'
    usat = (USV_X.DistanceintoGustxLimitedtogus_o >= USV_P.Distanceintogustx_d_m);

    // End of Derivatives for SubSystem: '<S54>/Distance into gust (x)'
    if (((!lsat) && (!usat)) || (lsat && (USV_P.FaultParamAPI.FaultInParams[1] >
          0.0)) || (usat && (USV_P.FaultParamAPI.FaultInParams[1] < 0.0))) {
      _rtXdot->DistanceintoGustxLimitedtogus_o =
        USV_P.FaultParamAPI.FaultInParams[1];
    } else {
      // in saturation
      _rtXdot->DistanceintoGustxLimitedtogus_o = 0.0;
    }

    // End of Derivatives for Integrator: '<S57>/Distance into Gust (x) (Limited to gust length d)' 
  } else {
    ((XDot_USV_T *) (&USV_M)->derivs)->DistanceintoGustxLimitedtogus_o = 0.0;
  }

  // End of Derivatives for SubSystem: '<S54>/Distance into gust (x)'

  // Derivatives for Enabled SubSystem: '<S54>/Distance into gust (y)'
  // Derivatives for Enabled SubSystem: '<S54>/Distance into gust (y)'
  // Constant: '<S50>/Constant'
  USV_Distanceintogusty_Deriv(USV_P.FaultParamAPI.FaultInParams[1],
    USV_P.Distanceintogusty_d_m, &USV_DW.Distanceintogusty,
    &USV_P.Distanceintogusty, &USV_X.Distanceintogusty,
    &_rtXdot->Distanceintogusty);

  // End of Derivatives for SubSystem: '<S54>/Distance into gust (y)'
  // End of Derivatives for SubSystem: '<S54>/Distance into gust (y)'

  // Derivatives for Enabled SubSystem: '<S54>/Distance into gust (z)'
  // Derivatives for Enabled SubSystem: '<S54>/Distance into gust (z)'
  USV_Distanceintogusty_Deriv(USV_P.FaultParamAPI.FaultInParams[1],
    USV_P.Distanceintogustz_d_m, &USV_DW.Distanceintogustz,
    &USV_P.Distanceintogustz, &USV_X.Distanceintogustz,
    &_rtXdot->Distanceintogustz);

  // End of Derivatives for SubSystem: '<S54>/Distance into gust (z)'
  // End of Derivatives for SubSystem: '<S54>/Distance into gust (z)'

  // Derivatives for Integrator: '<S9>/p,q,r '
  _rtXdot->pqr_CSTATE[0] = USV_B.Product2[0];

  // Derivatives for Integrator: '<S9>/ub,vb,wb'
  _rtXdot->ubvbwb_CSTATE[0] = USV_B.Sum[0];

  // Derivatives for SecondOrderIntegrator: '<S443>/Integrator, Second-Order Limited' 
  if (USV_DW.IntegratorSecondOrderLimited__p[0] == 0) {
    _rtXdot->IntegratorSecondOrderLimited__p[0] =
      USV_X.IntegratorSecondOrderLimited__p[3];
    _rtXdot->IntegratorSecondOrderLimited__p[3] = USV_B.Sum2_b[0];
  }

  // Derivatives for Integrator: '<S9>/p,q,r '
  _rtXdot->pqr_CSTATE[1] = USV_B.Product2[1];

  // Derivatives for Integrator: '<S9>/ub,vb,wb'
  _rtXdot->ubvbwb_CSTATE[1] = USV_B.Sum[1];

  // Derivatives for SecondOrderIntegrator: '<S443>/Integrator, Second-Order Limited' 
  if (USV_DW.IntegratorSecondOrderLimited__p[1] == 0) {
    _rtXdot->IntegratorSecondOrderLimited__p[1] =
      USV_X.IntegratorSecondOrderLimited__p[4];
    _rtXdot->IntegratorSecondOrderLimited__p[4] = USV_B.Sum2_b[1];
  }

  // Derivatives for Integrator: '<S9>/p,q,r '
  _rtXdot->pqr_CSTATE[2] = USV_B.Product2[2];

  // Derivatives for Integrator: '<S9>/ub,vb,wb'
  _rtXdot->ubvbwb_CSTATE[2] = USV_B.Sum[2];

  // Derivatives for SecondOrderIntegrator: '<S443>/Integrator, Second-Order Limited' 
  if (USV_DW.IntegratorSecondOrderLimited__p[2] == 0) {
    _rtXdot->IntegratorSecondOrderLimited__p[2] =
      USV_X.IntegratorSecondOrderLimited__p[5];
    _rtXdot->IntegratorSecondOrderLimited__p[5] = USV_B.Sum2_b[2];
  }

  // Derivatives for TransferFcn: '<S375>/Transfer Fcn4'
  _rtXdot->TransferFcn4_CSTATE = 0.0;
  _rtXdot->TransferFcn4_CSTATE += USV_P.TransferFcn4_A *
    USV_X.TransferFcn4_CSTATE;
  _rtXdot->TransferFcn4_CSTATE += USV_B.BiasGain1[0];

  // Derivatives for TransferFcn: '<S375>/Transfer Fcn1'
  _rtXdot->TransferFcn1_CSTATE = 0.0;
  _rtXdot->TransferFcn1_CSTATE += USV_P.TransferFcn1_A *
    USV_X.TransferFcn1_CSTATE;
  _rtXdot->TransferFcn1_CSTATE += USV_B.BiasGain1[1];

  // Derivatives for TransferFcn: '<S375>/Transfer Fcn2'
  _rtXdot->TransferFcn2_CSTATE = 0.0;
  _rtXdot->TransferFcn2_CSTATE += USV_P.TransferFcn2_A *
    USV_X.TransferFcn2_CSTATE;
  _rtXdot->TransferFcn2_CSTATE += USV_B.BiasGain1[2];

  // Derivatives for TransferFcn: '<S52>/Transfer Fcn2'
  _rtXdot->TransferFcn2_CSTATE_b = 0.0;
  _rtXdot->TransferFcn2_CSTATE_b += USV_P.TransferFcn2_A_e *
    USV_X.TransferFcn2_CSTATE_b;
  _rtXdot->TransferFcn2_CSTATE_b += USV_B.y_k[5];

  // Derivatives for TransferFcn: '<S52>/Transfer Fcn1'
  _rtXdot->TransferFcn1_CSTATE_l = 0.0;
  _rtXdot->TransferFcn1_CSTATE_l += USV_P.TransferFcn1_A_n *
    USV_X.TransferFcn1_CSTATE_l;
  _rtXdot->TransferFcn1_CSTATE_l += USV_B.y_k[6];

  // Derivatives for TransferFcn: '<S52>/Transfer Fcn3'
  _rtXdot->TransferFcn3_CSTATE = 0.0;
  _rtXdot->TransferFcn3_CSTATE += USV_P.TransferFcn3_A *
    USV_X.TransferFcn3_CSTATE;
  _rtXdot->TransferFcn3_CSTATE += USV_B.y_k[7];
}

// Model initialize function
void MulticopterModelClass::initialize()
{
  // Registration code

  // initialize non-finites
  rt_InitInfAndNaN(sizeof(real_T));

  // non-finite (run-time) assignments
  USV_P.uftinf_UpperSat = rtInf;

  {
    // Setup solver object
    rtsiSetSimTimeStepPtr(&(&USV_M)->solverInfo, &(&USV_M)->Timing.simTimeStep);
    rtsiSetTPtr(&(&USV_M)->solverInfo, &rtmGetTPtr((&USV_M)));
    rtsiSetStepSizePtr(&(&USV_M)->solverInfo, &(&USV_M)->Timing.stepSize0);
    rtsiSetdXPtr(&(&USV_M)->solverInfo, &(&USV_M)->derivs);
    rtsiSetContStatesPtr(&(&USV_M)->solverInfo, (real_T **) &(&USV_M)
                         ->contStates);
    rtsiSetNumContStatesPtr(&(&USV_M)->solverInfo, &(&USV_M)
      ->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&(&USV_M)->solverInfo, &(&USV_M)
      ->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&(&USV_M)->solverInfo, &(&USV_M)
      ->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&(&USV_M)->solverInfo, &(&USV_M)
      ->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&(&USV_M)->solverInfo, (&rtmGetErrorStatus((&USV_M))));
    rtsiSetRTModelPtr(&(&USV_M)->solverInfo, (&USV_M));
  }

  rtsiSetSimTimeStep(&(&USV_M)->solverInfo, MAJOR_TIME_STEP);
  (&USV_M)->intgData.y = (&USV_M)->odeY;
  (&USV_M)->intgData.f[0] = (&USV_M)->odeF[0];
  (&USV_M)->intgData.f[1] = (&USV_M)->odeF[1];
  (&USV_M)->intgData.f[2] = (&USV_M)->odeF[2];
  (&USV_M)->intgData.f[3] = (&USV_M)->odeF[3];
  (&USV_M)->contStates = ((X_USV_T *) &USV_X);
  rtsiSetSolverData(&(&USV_M)->solverInfo, static_cast<void *>(&(&USV_M)
    ->intgData));
  rtsiSetIsMinorTimeStepWithModeChange(&(&USV_M)->solverInfo, false);
  rtsiSetSolverName(&(&USV_M)->solverInfo,"ode4");
  rtmSetTPtr((&USV_M), &(&USV_M)->Timing.tArray[0]);
  (&USV_M)->Timing.stepSize0 = 0.001;
  rtmSetFirstInitCond((&USV_M), 1);

  {
    real_T tmp;
    int32_T i;
    int32_T t;
    uint32_T tseed;
    static const uint32_T tmp_0[625] = { 5489U, 1301868182U, 2938499221U,
      2950281878U, 1875628136U, 751856242U, 944701696U, 2243192071U, 694061057U,
      219885934U, 2066767472U, 3182869408U, 485472502U, 2336857883U, 1071588843U,
      3418470598U, 951210697U, 3693558366U, 2923482051U, 1793174584U,
      2982310801U, 1586906132U, 1951078751U, 1808158765U, 1733897588U,
      431328322U, 4202539044U, 530658942U, 1714810322U, 3025256284U, 3342585396U,
      1937033938U, 2640572511U, 1654299090U, 3692403553U, 4233871309U,
      3497650794U, 862629010U, 2943236032U, 2426458545U, 1603307207U,
      1133453895U, 3099196360U, 2208657629U, 2747653927U, 931059398U, 761573964U,
      3157853227U, 785880413U, 730313442U, 124945756U, 2937117055U, 3295982469U,
      1724353043U, 3021675344U, 3884886417U, 4010150098U, 4056961966U,
      699635835U, 2681338818U, 1339167484U, 720757518U, 2800161476U, 2376097373U,
      1532957371U, 3902664099U, 1238982754U, 3725394514U, 3449176889U,
      3570962471U, 4287636090U, 4087307012U, 3603343627U, 202242161U,
      2995682783U, 1620962684U, 3704723357U, 371613603U, 2814834333U,
      2111005706U, 624778151U, 2094172212U, 4284947003U, 1211977835U, 991917094U,
      1570449747U, 2962370480U, 1259410321U, 170182696U, 146300961U, 2836829791U,
      619452428U, 2723670296U, 1881399711U, 1161269684U, 1675188680U,
      4132175277U, 780088327U, 3409462821U, 1036518241U, 1834958505U,
      3048448173U, 161811569U, 618488316U, 44795092U, 3918322701U, 1924681712U,
      3239478144U, 383254043U, 4042306580U, 2146983041U, 3992780527U,
      3518029708U, 3545545436U, 3901231469U, 1896136409U, 2028528556U,
      2339662006U, 501326714U, 2060962201U, 2502746480U, 561575027U, 581893337U,
      3393774360U, 1778912547U, 3626131687U, 2175155826U, 319853231U, 986875531U,
      819755096U, 2915734330U, 2688355739U, 3482074849U, 2736559U, 2296975761U,
      1029741190U, 2876812646U, 690154749U, 579200347U, 4027461746U, 1285330465U,
      2701024045U, 4117700889U, 759495121U, 3332270341U, 2313004527U,
      2277067795U, 4131855432U, 2722057515U, 1264804546U, 3848622725U,
      2211267957U, 4100593547U, 959123777U, 2130745407U, 3194437393U, 486673947U,
      1377371204U, 17472727U, 352317554U, 3955548058U, 159652094U, 1232063192U,
      3835177280U, 49423123U, 3083993636U, 733092U, 2120519771U, 2573409834U,
      1112952433U, 3239502554U, 761045320U, 1087580692U, 2540165110U, 641058802U,
      1792435497U, 2261799288U, 1579184083U, 627146892U, 2165744623U,
      2200142389U, 2167590760U, 2381418376U, 1793358889U, 3081659520U,
      1663384067U, 2009658756U, 2689600308U, 739136266U, 2304581039U,
      3529067263U, 591360555U, 525209271U, 3131882996U, 294230224U, 2076220115U,
      3113580446U, 1245621585U, 1386885462U, 3203270426U, 123512128U, 12350217U,
      354956375U, 4282398238U, 3356876605U, 3888857667U, 157639694U, 2616064085U,
      1563068963U, 2762125883U, 4045394511U, 4180452559U, 3294769488U,
      1684529556U, 1002945951U, 3181438866U, 22506664U, 691783457U, 2685221343U,
      171579916U, 3878728600U, 2475806724U, 2030324028U, 3331164912U,
      1708711359U, 1970023127U, 2859691344U, 2588476477U, 2748146879U,
      136111222U, 2967685492U, 909517429U, 2835297809U, 3206906216U, 3186870716U,
      341264097U, 2542035121U, 3353277068U, 548223577U, 3170936588U, 1678403446U,
      297435620U, 2337555430U, 466603495U, 1132321815U, 1208589219U, 696392160U,
      894244439U, 2562678859U, 470224582U, 3306867480U, 201364898U, 2075966438U,
      1767227936U, 2929737987U, 3674877796U, 2654196643U, 3692734598U,
      3528895099U, 2796780123U, 3048728353U, 842329300U, 191554730U, 2922459673U,
      3489020079U, 3979110629U, 1022523848U, 2202932467U, 3583655201U,
      3565113719U, 587085778U, 4176046313U, 3013713762U, 950944241U, 396426791U,
      3784844662U, 3477431613U, 3594592395U, 2782043838U, 3392093507U,
      3106564952U, 2829419931U, 1358665591U, 2206918825U, 3170783123U, 31522386U,
      2988194168U, 1782249537U, 1105080928U, 843500134U, 1225290080U,
      1521001832U, 3605886097U, 2802786495U, 2728923319U, 3996284304U,
      903417639U, 1171249804U, 1020374987U, 2824535874U, 423621996U, 1988534473U,
      2493544470U, 1008604435U, 1756003503U, 1488867287U, 1386808992U,
      732088248U, 1780630732U, 2482101014U, 976561178U, 1543448953U, 2602866064U,
      2021139923U, 1952599828U, 2360242564U, 2117959962U, 2753061860U,
      2388623612U, 4138193781U, 2962920654U, 2284970429U, 766920861U,
      3457264692U, 2879611383U, 815055854U, 2332929068U, 1254853997U,
      3740375268U, 3799380844U, 4091048725U, 2006331129U, 1982546212U,
      686850534U, 1907447564U, 2682801776U, 2780821066U, 998290361U, 1342433871U,
      4195430425U, 607905174U, 3902331779U, 2454067926U, 1708133115U,
      1170874362U, 2008609376U, 3260320415U, 2211196135U, 433538229U,
      2728786374U, 2189520818U, 262554063U, 1182318347U, 3710237267U,
      1221022450U, 715966018U, 2417068910U, 2591870721U, 2870691989U,
      3418190842U, 4238214053U, 1540704231U, 1575580968U, 2095917976U,
      4078310857U, 2313532447U, 2110690783U, 4056346629U, 4061784526U,
      1123218514U, 551538993U, 597148360U, 4120175196U, 3581618160U, 3181170517U,
      422862282U, 3227524138U, 1713114790U, 662317149U, 1230418732U, 928171837U,
      1324564878U, 1928816105U, 1786535431U, 2878099422U, 3290185549U,
      539474248U, 1657512683U, 552370646U, 1671741683U, 3655312128U, 1552739510U,
      2605208763U, 1441755014U, 181878989U, 3124053868U, 1447103986U,
      3183906156U, 1728556020U, 3502241336U, 3055466967U, 1013272474U,
      818402132U, 1715099063U, 2900113506U, 397254517U, 4194863039U, 1009068739U,
      232864647U, 2540223708U, 2608288560U, 2415367765U, 478404847U, 3455100648U,
      3182600021U, 2115988978U, 434269567U, 4117179324U, 3461774077U, 887256537U,
      3545801025U, 286388911U, 3451742129U, 1981164769U, 786667016U, 3310123729U,
      3097811076U, 2224235657U, 2959658883U, 3370969234U, 2514770915U,
      3345656436U, 2677010851U, 2206236470U, 271648054U, 2342188545U,
      4292848611U, 3646533909U, 3754009956U, 3803931226U, 4160647125U,
      1477814055U, 4043852216U, 1876372354U, 3133294443U, 3871104810U,
      3177020907U, 2074304428U, 3479393793U, 759562891U, 164128153U, 1839069216U,
      2114162633U, 3989947309U, 3611054956U, 1333547922U, 835429831U, 494987340U,
      171987910U, 1252001001U, 370809172U, 3508925425U, 2535703112U, 1276855041U,
      1922855120U, 835673414U, 3030664304U, 613287117U, 171219893U, 3423096126U,
      3376881639U, 2287770315U, 1658692645U, 1262815245U, 3957234326U,
      1168096164U, 2968737525U, 2655813712U, 2132313144U, 3976047964U,
      326516571U, 353088456U, 3679188938U, 3205649712U, 2654036126U, 1249024881U,
      880166166U, 691800469U, 2229503665U, 1673458056U, 4032208375U, 1851778863U,
      2563757330U, 376742205U, 1794655231U, 340247333U, 1505873033U, 396524441U,
      879666767U, 3335579166U, 3260764261U, 3335999539U, 506221798U, 4214658741U,
      975887814U, 2080536343U, 3360539560U, 571586418U, 138896374U, 4234352651U,
      2737620262U, 3928362291U, 1516365296U, 38056726U, 3599462320U, 3585007266U,
      3850961033U, 471667319U, 1536883193U, 2310166751U, 1861637689U,
      2530999841U, 4139843801U, 2710569485U, 827578615U, 2012334720U,
      2907369459U, 3029312804U, 2820112398U, 1965028045U, 35518606U, 2478379033U,
      643747771U, 1924139484U, 4123405127U, 3811735531U, 3429660832U,
      3285177704U, 1948416081U, 1311525291U, 1183517742U, 1739192232U,
      3979815115U, 2567840007U, 4116821529U, 213304419U, 4125718577U,
      1473064925U, 2442436592U, 1893310111U, 4195361916U, 3747569474U,
      828465101U, 2991227658U, 750582866U, 1205170309U, 1409813056U, 678418130U,
      1171531016U, 3821236156U, 354504587U, 4202874632U, 3882511497U,
      1893248677U, 1903078632U, 26340130U, 2069166240U, 3657122492U, 3725758099U,
      831344905U, 811453383U, 3447711422U, 2434543565U, 4166886888U, 3358210805U,
      4142984013U, 2988152326U, 3527824853U, 982082992U, 2809155763U, 190157081U,
      3340214818U, 2365432395U, 2548636180U, 2894533366U, 3474657421U,
      2372634704U, 2845748389U, 43024175U, 2774226648U, 1987702864U, 3186502468U,
      453610222U, 4204736567U, 1392892630U, 2471323686U, 2470534280U,
      3541393095U, 4269885866U, 3909911300U, 759132955U, 1482612480U, 667715263U,
      1795580598U, 2337923983U, 3390586366U, 581426223U, 1515718634U, 476374295U,
      705213300U, 363062054U, 2084697697U, 2407503428U, 2292957699U, 2426213835U,
      2199989172U, 1987356470U, 4026755612U, 2147252133U, 270400031U,
      1367820199U, 2369854699U, 2844269403U, 79981964U, 624U };

    // Start for If: '<S37>/If'
    USV_DW.If_ActiveSubsystem = -1;

    // Start for Constant: '<S50>/FaultID'
    USV_B.FaultID = USV_P.FaultID_Value;

    // Start for If: '<S157>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 
    USV_DW.ifHeightMaxlowaltitudeelseifHei = -1;

    // Start for If: '<S118>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 
    USV_DW.ifHeightMaxlowaltitudeelseifH_b = -1;

    // Start for If: '<S330>/If'
    USV_DW.If_ActiveSubsystem_g = -1;

    // Start for If: '<S117>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 
    USV_DW.ifHeightMaxlowaltitudeelseifH_g = -1;

    // Start for If: '<S156>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 
    USV_DW.ifHeightMaxlowaltitudeelseifH_h = -1;

    // Start for If: '<S337>/If1'
    USV_DW.If1_ActiveSubsystem = -1;

    // InitializeConditions for SecondOrderIntegrator: '<S432>/Integrator, Second-Order Limited' 
    USV_X.IntegratorSecondOrderLimited_CS[0] =
      USV_P.IntegratorSecondOrderLimited_IC;
    USV_X.IntegratorSecondOrderLimited_CS[1] =
      USV_P.IntegratorSecondOrderLimited_IC;
    USV_X.IntegratorSecondOrderLimited_CS[2] =
      USV_P.IntegratorSecondOrderLimited_IC;
    USV_X.IntegratorSecondOrderLimited_CS[3] =
      USV_P.IntegratorSecondOrderLimited__e;
    USV_X.IntegratorSecondOrderLimited_CS[4] =
      USV_P.IntegratorSecondOrderLimited__e;
    USV_X.IntegratorSecondOrderLimited_CS[5] =
      USV_P.IntegratorSecondOrderLimited__e;

    // InitializeConditions for Integrator: '<S10>/q0 q1 q2 q3'
    if (rtmIsFirstInitCond((&USV_M))) {
      USV_X.q0q1q2q3_CSTATE[0] = 0.0;
      USV_X.q0q1q2q3_CSTATE[1] = 0.0;
      USV_X.q0q1q2q3_CSTATE[2] = 0.0;
      USV_X.q0q1q2q3_CSTATE[3] = 0.0;
    }

    USV_DW.q0q1q2q3_IWORK = 1;

    // End of InitializeConditions for Integrator: '<S10>/q0 q1 q2 q3'

    // InitializeConditions for Integrator: '<S9>/xe,ye,ze'
    USV_X.xeyeze_CSTATE[0] = USV_P.ModelInit_PosE[0];
    USV_X.xeyeze_CSTATE[1] = USV_P.ModelInit_PosE[1];
    USV_X.xeyeze_CSTATE[2] = USV_P.ModelInit_PosE[2];

    // InitializeConditions for RandomNumber: '<S53>/White Noise'
    tmp = std::floor(USV_P.BandLimitedWhiteNoise_seed);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    USV_DW.RandSeed = tseed;
    USV_DW.NextOutput = rt_nrand_Upu32_Yd_f_pw_snf(&USV_DW.RandSeed) *
      USV_P.WhiteNoise_StdDev + USV_P.WhiteNoise_Mean;

    // End of InitializeConditions for RandomNumber: '<S53>/White Noise'

    // InitializeConditions for Integrator: '<S9>/p,q,r '
    USV_X.pqr_CSTATE[0] = USV_P.ModelInit_RateB[0];

    // InitializeConditions for Integrator: '<S9>/ub,vb,wb'
    USV_X.ubvbwb_CSTATE[0] = USV_P.ModelInit_VelB[0];

    // InitializeConditions for Integrator: '<S9>/p,q,r '
    USV_X.pqr_CSTATE[1] = USV_P.ModelInit_RateB[1];

    // InitializeConditions for Integrator: '<S9>/ub,vb,wb'
    USV_X.ubvbwb_CSTATE[1] = USV_P.ModelInit_VelB[1];

    // InitializeConditions for Integrator: '<S9>/p,q,r '
    USV_X.pqr_CSTATE[2] = USV_P.ModelInit_RateB[2];

    // InitializeConditions for Integrator: '<S9>/ub,vb,wb'
    USV_X.ubvbwb_CSTATE[2] = USV_P.ModelInit_VelB[2];

    // InitializeConditions for RandomNumber: '<S161>/White Noise'
    tmp = std::floor(USV_P.DrydenWindTurbulenceModelDisc_g[0]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    USV_DW.RandSeed_a[0] = tseed;
    USV_DW.NextOutput_g[0] = rt_nrand_Upu32_Yd_f_pw_snf(&USV_DW.RandSeed_a[0]) *
      USV_P.WhiteNoise_StdDev_e + USV_P.WhiteNoise_Mean_k;

    // InitializeConditions for RandomNumber: '<S122>/White Noise'
    tmp = std::floor(USV_P.DrydenWindTurbulenceModelDisc_m[0]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>
      (static_cast<uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    USV_DW.RandSeed_l[0] = tseed;
    USV_DW.NextOutput_l[0] = rt_nrand_Upu32_Yd_f_pw_snf(&USV_DW.RandSeed_l[0]) *
      USV_P.WhiteNoise_StdDev_k + USV_P.WhiteNoise_Mean_l;

    // InitializeConditions for RandomNumber: '<S161>/White Noise'
    tmp = std::floor(USV_P.DrydenWindTurbulenceModelDisc_g[1]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>
      (static_cast<uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    USV_DW.RandSeed_a[1] = tseed;
    USV_DW.NextOutput_g[1] = rt_nrand_Upu32_Yd_f_pw_snf(&USV_DW.RandSeed_a[1]) *
      USV_P.WhiteNoise_StdDev_e + USV_P.WhiteNoise_Mean_k;

    // InitializeConditions for RandomNumber: '<S122>/White Noise'
    tmp = std::floor(USV_P.DrydenWindTurbulenceModelDisc_m[1]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>
      (static_cast<uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    USV_DW.RandSeed_l[1] = tseed;
    USV_DW.NextOutput_l[1] = rt_nrand_Upu32_Yd_f_pw_snf(&USV_DW.RandSeed_l[1]) *
      USV_P.WhiteNoise_StdDev_k + USV_P.WhiteNoise_Mean_l;

    // InitializeConditions for RandomNumber: '<S161>/White Noise'
    tmp = std::floor(USV_P.DrydenWindTurbulenceModelDisc_g[2]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>
      (static_cast<uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    USV_DW.RandSeed_a[2] = tseed;
    USV_DW.NextOutput_g[2] = rt_nrand_Upu32_Yd_f_pw_snf(&USV_DW.RandSeed_a[2]) *
      USV_P.WhiteNoise_StdDev_e + USV_P.WhiteNoise_Mean_k;

    // InitializeConditions for RandomNumber: '<S122>/White Noise'
    tmp = std::floor(USV_P.DrydenWindTurbulenceModelDisc_m[2]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>
      (static_cast<uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    USV_DW.RandSeed_l[2] = tseed;
    USV_DW.NextOutput_l[2] = rt_nrand_Upu32_Yd_f_pw_snf(&USV_DW.RandSeed_l[2]) *
      USV_P.WhiteNoise_StdDev_k + USV_P.WhiteNoise_Mean_l;

    // InitializeConditions for RandomNumber: '<S161>/White Noise'
    tmp = std::floor(USV_P.DrydenWindTurbulenceModelDisc_g[3]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>
      (static_cast<uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    USV_DW.RandSeed_a[3] = tseed;
    USV_DW.NextOutput_g[3] = rt_nrand_Upu32_Yd_f_pw_snf(&USV_DW.RandSeed_a[3]) *
      USV_P.WhiteNoise_StdDev_e + USV_P.WhiteNoise_Mean_k;

    // InitializeConditions for RandomNumber: '<S122>/White Noise'
    tmp = std::floor(USV_P.DrydenWindTurbulenceModelDisc_m[3]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>
      (static_cast<uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    USV_DW.RandSeed_l[3] = tseed;
    USV_DW.NextOutput_l[3] = rt_nrand_Upu32_Yd_f_pw_snf(&USV_DW.RandSeed_l[3]) *
      USV_P.WhiteNoise_StdDev_k + USV_P.WhiteNoise_Mean_l;

    // InitializeConditions for UniformRandomNumber: '<S406>/Uniform Random Number5' 
    tmp = std::floor(USV_P.UniformRandomNumber5_Seed[0]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>
      (static_cast<uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    USV_DW.RandSeed_m[0] = tseed;
    USV_DW.UniformRandomNumber5_NextOutput[0] =
      (USV_P.UniformRandomNumber5_Maximum[0] -
       USV_P.UniformRandomNumber5_Minimum[0]) * rt_urand_Upu32_Yd_f_pw_snf
      (&USV_DW.RandSeed_m[0]) + USV_P.UniformRandomNumber5_Minimum[0];

    // InitializeConditions for SecondOrderIntegrator: '<S443>/Integrator, Second-Order Limited' 
    USV_X.IntegratorSecondOrderLimited__p[0] =
      USV_P.IntegratorSecondOrderLimited__f;

    // InitializeConditions for UniformRandomNumber: '<S406>/Uniform Random Number5' 
    tmp = std::floor(USV_P.UniformRandomNumber5_Seed[1]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    USV_DW.RandSeed_m[1] = tseed;
    USV_DW.UniformRandomNumber5_NextOutput[1] =
      (USV_P.UniformRandomNumber5_Maximum[1] -
       USV_P.UniformRandomNumber5_Minimum[1]) * rt_urand_Upu32_Yd_f_pw_snf
      (&USV_DW.RandSeed_m[1]) + USV_P.UniformRandomNumber5_Minimum[1];

    // InitializeConditions for SecondOrderIntegrator: '<S443>/Integrator, Second-Order Limited' 
    USV_X.IntegratorSecondOrderLimited__p[1] =
      USV_P.IntegratorSecondOrderLimited__f;

    // InitializeConditions for UniformRandomNumber: '<S406>/Uniform Random Number5' 
    tmp = std::floor(USV_P.UniformRandomNumber5_Seed[2]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    USV_DW.RandSeed_m[2] = tseed;
    USV_DW.UniformRandomNumber5_NextOutput[2] =
      (USV_P.UniformRandomNumber5_Maximum[2] -
       USV_P.UniformRandomNumber5_Minimum[2]) * rt_urand_Upu32_Yd_f_pw_snf
      (&USV_DW.RandSeed_m[2]) + USV_P.UniformRandomNumber5_Minimum[2];

    // InitializeConditions for SecondOrderIntegrator: '<S443>/Integrator, Second-Order Limited' 
    USV_X.IntegratorSecondOrderLimited__p[2] =
      USV_P.IntegratorSecondOrderLimited__f;

    // InitializeConditions for Memory: '<S467>/otime'
    USV_DW.otime_PreviousInput = USV_P.otime_InitialCondition;

    // InitializeConditions for Memory: '<S466>/olon'
    USV_DW.olon_PreviousInput = USV_P.olon_InitialCondition;

    // InitializeConditions for Memory: '<S465>/olat'
    USV_DW.olat_PreviousInput = USV_P.olat_InitialCondition;

    // InitializeConditions for Memory: '<S465>/oalt'
    USV_DW.oalt_PreviousInput = USV_P.oalt_InitialCondition;

    // InitializeConditions for SecondOrderIntegrator: '<S443>/Integrator, Second-Order Limited' 
    USV_X.IntegratorSecondOrderLimited__p[3] =
      USV_P.IntegratorSecondOrderLimited__a;

    // InitializeConditions for UniformRandomNumber: '<S406>/Uniform Random Number1' 
    tmp = std::floor(USV_P.UniformRandomNumber1_Seed[0]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    USV_DW.RandSeed_k[0] = tseed;
    USV_DW.UniformRandomNumber1_NextOutput[0] =
      (USV_P.UniformRandomNumber1_Maximum[0] -
       USV_P.UniformRandomNumber1_Minimum[0]) * rt_urand_Upu32_Yd_f_pw_snf
      (&USV_DW.RandSeed_k[0]) + USV_P.UniformRandomNumber1_Minimum[0];

    // InitializeConditions for UniformRandomNumber: '<S406>/Uniform Random Number7' 
    tmp = std::floor(USV_P.UniformRandomNumber7_Seed[0]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    USV_DW.RandSeed_p[0] = tseed;
    USV_DW.UniformRandomNumber7_NextOutput[0] =
      (USV_P.UniformRandomNumber7_Maximum[0] -
       USV_P.UniformRandomNumber7_Minimum[0]) * rt_urand_Upu32_Yd_f_pw_snf
      (&USV_DW.RandSeed_p[0]) + USV_P.UniformRandomNumber7_Minimum[0];

    // InitializeConditions for SecondOrderIntegrator: '<S443>/Integrator, Second-Order Limited' 
    USV_X.IntegratorSecondOrderLimited__p[4] =
      USV_P.IntegratorSecondOrderLimited__a;

    // InitializeConditions for UniformRandomNumber: '<S406>/Uniform Random Number1' 
    tmp = std::floor(USV_P.UniformRandomNumber1_Seed[1]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    USV_DW.RandSeed_k[1] = tseed;
    USV_DW.UniformRandomNumber1_NextOutput[1] =
      (USV_P.UniformRandomNumber1_Maximum[1] -
       USV_P.UniformRandomNumber1_Minimum[1]) * rt_urand_Upu32_Yd_f_pw_snf
      (&USV_DW.RandSeed_k[1]) + USV_P.UniformRandomNumber1_Minimum[1];

    // InitializeConditions for UniformRandomNumber: '<S406>/Uniform Random Number7' 
    tmp = std::floor(USV_P.UniformRandomNumber7_Seed[1]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    USV_DW.RandSeed_p[1] = tseed;
    USV_DW.UniformRandomNumber7_NextOutput[1] =
      (USV_P.UniformRandomNumber7_Maximum[1] -
       USV_P.UniformRandomNumber7_Minimum[1]) * rt_urand_Upu32_Yd_f_pw_snf
      (&USV_DW.RandSeed_p[1]) + USV_P.UniformRandomNumber7_Minimum[1];

    // InitializeConditions for SecondOrderIntegrator: '<S443>/Integrator, Second-Order Limited' 
    USV_X.IntegratorSecondOrderLimited__p[5] =
      USV_P.IntegratorSecondOrderLimited__a;

    // InitializeConditions for UniformRandomNumber: '<S406>/Uniform Random Number1' 
    tmp = std::floor(USV_P.UniformRandomNumber1_Seed[2]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    USV_DW.RandSeed_k[2] = tseed;
    USV_DW.UniformRandomNumber1_NextOutput[2] =
      (USV_P.UniformRandomNumber1_Maximum[2] -
       USV_P.UniformRandomNumber1_Minimum[2]) * rt_urand_Upu32_Yd_f_pw_snf
      (&USV_DW.RandSeed_k[2]) + USV_P.UniformRandomNumber1_Minimum[2];

    // InitializeConditions for UniformRandomNumber: '<S406>/Uniform Random Number7' 
    tmp = std::floor(USV_P.UniformRandomNumber7_Seed[2]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    USV_DW.RandSeed_p[2] = tseed;
    USV_DW.UniformRandomNumber7_NextOutput[2] =
      (USV_P.UniformRandomNumber7_Maximum[2] -
       USV_P.UniformRandomNumber7_Minimum[2]) * rt_urand_Upu32_Yd_f_pw_snf
      (&USV_DW.RandSeed_p[2]) + USV_P.UniformRandomNumber7_Minimum[2];

    // InitializeConditions for UniformRandomNumber: '<S406>/Uniform Random Number' 
    tmp = std::floor(USV_P.UniformRandomNumber_Seed);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    USV_DW.RandSeed_n = tseed;
    USV_DW.UniformRandomNumber_NextOutput = (USV_P.UniformRandomNumber_Maximum -
      USV_P.UniformRandomNumber_Minimum) * rt_urand_Upu32_Yd_f_pw_snf
      (&USV_DW.RandSeed_n) + USV_P.UniformRandomNumber_Minimum;

    // End of InitializeConditions for UniformRandomNumber: '<S406>/Uniform Random Number' 

    // InitializeConditions for UniformRandomNumber: '<S406>/Uniform Random Number4' 
    tmp = std::floor(USV_P.UniformRandomNumber4_Seed);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>
      (static_cast<uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    USV_DW.RandSeed_kd = tseed;
    USV_DW.UniformRandomNumber4_NextOutput = (USV_P.UniformRandomNumber4_Maximum
      - USV_P.UniformRandomNumber4_Minimum) * rt_urand_Upu32_Yd_f_pw_snf
      (&USV_DW.RandSeed_kd) + USV_P.UniformRandomNumber4_Minimum;

    // End of InitializeConditions for UniformRandomNumber: '<S406>/Uniform Random Number4' 

    // InitializeConditions for UniformRandomNumber: '<S373>/Uniform Random Number5' 
    tmp = std::floor(USV_P.UniformRandomNumber5_Seed_a[0]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>
      (static_cast<uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    USV_DW.RandSeed_as[0] = tseed;
    USV_DW.UniformRandomNumber5_NextOutp_n[0] =
      (USV_P.UniformRandomNumber5_Maximum_a[0] -
       USV_P.UniformRandomNumber5_Minimum_l[0]) * rt_urand_Upu32_Yd_f_pw_snf
      (&USV_DW.RandSeed_as[0]) + USV_P.UniformRandomNumber5_Minimum_l[0];
    tmp = std::floor(USV_P.UniformRandomNumber5_Seed_a[1]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    USV_DW.RandSeed_as[1] = tseed;
    USV_DW.UniformRandomNumber5_NextOutp_n[1] =
      (USV_P.UniformRandomNumber5_Maximum_a[1] -
       USV_P.UniformRandomNumber5_Minimum_l[1]) * rt_urand_Upu32_Yd_f_pw_snf
      (&USV_DW.RandSeed_as[1]) + USV_P.UniformRandomNumber5_Minimum_l[1];
    tmp = std::floor(USV_P.UniformRandomNumber5_Seed_a[2]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    USV_DW.RandSeed_as[2] = tseed;
    USV_DW.UniformRandomNumber5_NextOutp_n[2] =
      (USV_P.UniformRandomNumber5_Maximum_a[2] -
       USV_P.UniformRandomNumber5_Minimum_l[2]) * rt_urand_Upu32_Yd_f_pw_snf
      (&USV_DW.RandSeed_as[2]) + USV_P.UniformRandomNumber5_Minimum_l[2];

    // End of InitializeConditions for UniformRandomNumber: '<S373>/Uniform Random Number5' 

    // InitializeConditions for TransferFcn: '<S375>/Transfer Fcn4'
    USV_X.TransferFcn4_CSTATE = 0.0;

    // InitializeConditions for TransferFcn: '<S375>/Transfer Fcn1'
    USV_X.TransferFcn1_CSTATE = 0.0;

    // InitializeConditions for TransferFcn: '<S375>/Transfer Fcn2'
    USV_X.TransferFcn2_CSTATE = 0.0;

    // InitializeConditions for TransferFcn: '<S52>/Transfer Fcn2'
    USV_X.TransferFcn2_CSTATE_b = 0.0;

    // InitializeConditions for TransferFcn: '<S52>/Transfer Fcn1'
    USV_X.TransferFcn1_CSTATE_l = 0.0;

    // InitializeConditions for TransferFcn: '<S52>/Transfer Fcn3'
    USV_X.TransferFcn3_CSTATE = 0.0;

    // InitializeConditions for UniformRandomNumber: '<S331>/Uniform Random Number4' 
    tmp = std::floor(USV_P.UniformRandomNumber4_Seed_e[0]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    USV_DW.RandSeed_lk[0] = tseed;
    USV_DW.UniformRandomNumber4_NextOutp_c[0] =
      (USV_P.UniformRandomNumber4_Maximum_j[0] -
       USV_P.UniformRandomNumber4_Minimum_g[0]) * rt_urand_Upu32_Yd_f_pw_snf
      (&USV_DW.RandSeed_lk[0]) + USV_P.UniformRandomNumber4_Minimum_g[0];
    tmp = std::floor(USV_P.UniformRandomNumber4_Seed_e[1]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    USV_DW.RandSeed_lk[1] = tseed;
    USV_DW.UniformRandomNumber4_NextOutp_c[1] =
      (USV_P.UniformRandomNumber4_Maximum_j[1] -
       USV_P.UniformRandomNumber4_Minimum_g[1]) * rt_urand_Upu32_Yd_f_pw_snf
      (&USV_DW.RandSeed_lk[1]) + USV_P.UniformRandomNumber4_Minimum_g[1];
    tmp = std::floor(USV_P.UniformRandomNumber4_Seed_e[2]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    USV_DW.RandSeed_lk[2] = tseed;
    USV_DW.UniformRandomNumber4_NextOutp_c[2] =
      (USV_P.UniformRandomNumber4_Maximum_j[2] -
       USV_P.UniformRandomNumber4_Minimum_g[2]) * rt_urand_Upu32_Yd_f_pw_snf
      (&USV_DW.RandSeed_lk[2]) + USV_P.UniformRandomNumber4_Minimum_g[2];

    // End of InitializeConditions for UniformRandomNumber: '<S331>/Uniform Random Number4' 

    // SystemInitialize for Enabled SubSystem: '<S54>/Distance into gust (x)'
    // InitializeConditions for Integrator: '<S57>/Distance into Gust (x) (Limited to gust length d)' 
    // '<S55>:1:6' hFault=false;
    // '<S55>:1:9' fParam=zeros(20,1);
    USV_X.DistanceintoGustxLimitedtogus_o =
      USV_P.DistanceintoGustxLimitedtogustl;

    // SystemInitialize for Integrator: '<S57>/Distance into Gust (x) (Limited to gust length d)' incorporates:
    //   Outport: '<S57>/x'

    USV_B.DistanceintoGustxLimitedtogustl = USV_P.x_Y0;

    // End of SystemInitialize for SubSystem: '<S54>/Distance into gust (x)'

    // SystemInitialize for Enabled SubSystem: '<S54>/Distance into gust (y)'
    USV_Distanceintogusty_Init(&USV_B.Distanceintogusty,
      &USV_P.Distanceintogusty, &USV_X.Distanceintogusty);

    // End of SystemInitialize for SubSystem: '<S54>/Distance into gust (y)'

    // SystemInitialize for Enabled SubSystem: '<S54>/Distance into gust (z)'
    USV_Distanceintogusty_Init(&USV_B.Distanceintogustz,
      &USV_P.Distanceintogustz, &USV_X.Distanceintogustz);

    // End of SystemInitialize for SubSystem: '<S54>/Distance into gust (z)'

    // SystemInitialize for Enabled SubSystem: '<S152>/Hugw(z)'
    // '<S102>:1:6' hFault=false;
    // '<S102>:1:9' fParam=zeros(20,1);
    // '<S103>:1:6' hFault=false;
    // '<S103>:1:9' fParam=zeros(20,1);
    // '<S104>:1:6' hFault=false;
    // '<S104>:1:9' fParam=zeros(20,1);
    // '<S105>:1:6' hFault=false;
    // '<S105>:1:9' fParam=zeros(20,1);
    USV_Hugwz_Init(&USV_B.Hugwz_e, &USV_DW.Hugwz_e, &USV_P.Hugwz_e);

    // End of SystemInitialize for SubSystem: '<S152>/Hugw(z)'

    // SystemInitialize for Enabled SubSystem: '<S152>/Hvgw(z)'
    USV_Hvgwz_Init(&USV_B.Hvgwz_m, &USV_DW.Hvgwz_m, &USV_P.Hvgwz_m);

    // End of SystemInitialize for SubSystem: '<S152>/Hvgw(z)'

    // SystemInitialize for Enabled SubSystem: '<S152>/Hwgw(z)'
    USV_Hwgwz_Init(&USV_B.Hwgwz_h, &USV_DW.Hwgwz_h, &USV_P.Hwgwz_h);

    // End of SystemInitialize for SubSystem: '<S152>/Hwgw(z)'

    // SystemInitialize for MATLAB Function: '<S73>/MATLAB Function'
    std::memcpy(&USV_DW.state_is[0], &tmp_0[0], 625U * sizeof(uint32_T));
    USV_DW.method = 7U;
    USV_DW.state = 1144108930U;
    USV_DW.state_i[0] = 362436069U;
    USV_DW.state_i[1] = 521288629U;

    // '<S106>:1:12' t0=0;
    // '<S106>:1:17' isInGust=0;
    // '<S106>:1:22' t1=2;
    USV_DW.t1 = 2.0;

    // '<S106>:1:27' a=0.5;
    USV_DW.a = 0.5;

    // '<S106>:1:32' ang=pi/2;
    USV_DW.ang = 1.5707963267948966;

    // SystemInitialize for Enabled SubSystem: '<S113>/Hugw(z)'
    USV_Hugwz_Init(&USV_B.Hugwz, &USV_DW.Hugwz, &USV_P.Hugwz);

    // End of SystemInitialize for SubSystem: '<S113>/Hugw(z)'

    // SystemInitialize for Enabled SubSystem: '<S113>/Hvgw(z)'
    USV_Hvgwz_Init(&USV_B.Hvgwz, &USV_DW.Hvgwz, &USV_P.Hvgwz);

    // End of SystemInitialize for SubSystem: '<S113>/Hvgw(z)'

    // SystemInitialize for Enabled SubSystem: '<S113>/Hwgw(z)'
    USV_Hwgwz_Init(&USV_B.Hwgwz, &USV_DW.Hwgwz, &USV_P.Hwgwz);

    // End of SystemInitialize for SubSystem: '<S113>/Hwgw(z)'

    // SystemInitialize for Enabled SubSystem: '<S453>/Convert from geodetic to  spherical coordinates ' 
    // SystemInitialize for Iterator SubSystem: '<S463>/For Iterator Subsystem'
    // InitializeConditions for UnitDelay: '<S510>/Unit Delay1'
    // '<S409>:1:6' hFault=false;
    // '<S409>:1:9' fParam=zeros(20,1);
    // '<S410>:1:6' hFault=false;
    // '<S410>:1:9' fParam=zeros(20,1);
    USV_DW.UnitDelay1_DSTATE[0] = USV_P.UnitDelay1_InitialCondition_c;
    USV_DW.UnitDelay1_DSTATE[1] = USV_P.UnitDelay1_InitialCondition_c;

    // End of SystemInitialize for SubSystem: '<S463>/For Iterator Subsystem'

    // SystemInitialize for SignalConversion generated from: '<S463>/sp[13]' incorporates:
    //   Outport: '<S463>/sp[13]'

    std::memcpy(&USV_B.OutportBufferForsp13[0], &USV_P.sp13_Y0[0], 13U * sizeof
                (real_T));

    // SystemInitialize for SignalConversion generated from: '<S463>/cp[13]' incorporates:
    //   Outport: '<S463>/cp[13]'

    std::memcpy(&USV_B.OutportBufferForcp13[0], &USV_P.cp13_Y0[0], 13U * sizeof
                (real_T));

    // End of SystemInitialize for SubSystem: '<S453>/Convert from geodetic to  spherical coordinates ' 

    // SystemInitialize for Enabled SubSystem: '<S453>/Convert from geodetic to  spherical coordinates' 
    // SystemInitialize for Sqrt: '<S462>/sqrt' incorporates:
    //   Outport: '<S462>/r'

    USV_B.sqrt_i = USV_P.r_Y0;

    // SystemInitialize for Product: '<S503>/Product4' incorporates:
    //   Outport: '<S462>/ct'

    USV_B.Product4_j = USV_P.ct_Y0;

    // SystemInitialize for Sqrt: '<S509>/sqrt' incorporates:
    //   Outport: '<S462>/st'

    USV_B.sqrt_ix = USV_P.st_Y0;

    // SystemInitialize for Product: '<S508>/Product12' incorporates:
    //   Outport: '<S462>/sa'

    USV_B.Product12 = USV_P.sa_Y0;

    // SystemInitialize for Product: '<S502>/Product11' incorporates:
    //   Outport: '<S462>/ca'

    USV_B.Product11 = USV_P.ca_Y0;

    // End of SystemInitialize for SubSystem: '<S453>/Convert from geodetic to  spherical coordinates' 

    // SystemInitialize for Iterator SubSystem: '<S453>/Compute magnetic vector in spherical coordinates' 
    // SystemInitialize for Iterator SubSystem: '<S461>/For Iterator Subsystem'
    // SystemInitialize for Enabled SubSystem: '<S469>/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations' 
    // SystemInitialize for Merge: '<S471>/Merge1'
    USV_B.Merge1_p = USV_P.Merge1_InitialOutput;

    // SystemInitialize for Merge: '<S471>/Merge'
    USV_B.Merge_c = USV_P.Merge_InitialOutput;

    // End of SystemInitialize for SubSystem: '<S469>/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations' 

    // SystemInitialize for Enabled SubSystem: '<S469>/Time adjust the gauss coefficients' 
    // InitializeConditions for UnitDelay: '<S472>/Unit Delay'
    std::memcpy(&USV_DW.UnitDelay_DSTATE_m[0],
                &USV_P.UnitDelay_InitialCondition_f[0], 169U * sizeof(real_T));

    // InitializeConditions for UnitDelay: '<S499>/Unit Delay'
    std::memcpy(&USV_DW.UnitDelay_DSTATE_d[0],
                &USV_P.UnitDelay_InitialCondition_k[0], 169U * sizeof(real_T));

    // SystemInitialize for Sum: '<S472>/Sum2' incorporates:
    //   Outport: '<S472>/tc[13][13]'

    std::memcpy(&USV_B.Sum2_a[0], &USV_P.tc1313_Y0[0], 169U * sizeof(real_T));

    // End of SystemInitialize for SubSystem: '<S469>/Time adjust the gauss coefficients' 

    // SystemInitialize for Enabled SubSystem: '<S469>/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations' 
    // InitializeConditions for UnitDelay: '<S471>/Unit Delay'
    std::memcpy(&USV_DW.UnitDelay_DSTATE_o[0],
                &USV_P.UnitDelay_InitialCondition[0], 169U * sizeof(real_T));

    // InitializeConditions for UnitDelay: '<S471>/Unit Delay1'
    std::memcpy(&USV_DW.UnitDelay1_DSTATE_m[0],
                &USV_P.UnitDelay1_InitialCondition_i[0], 169U * sizeof(real_T));

    // SystemInitialize for Assignment: '<S471>/Assignment' incorporates:
    //   Outport: '<S471>/dp[13][13]'

    std::memcpy(&USV_B.Assignment_c[0], &USV_P.dp1313_Y0[0], 169U * sizeof
                (real_T));

    // SystemInitialize for Assignment: '<S471>/Assignment_snorm' incorporates:
    //   Outport: '<S471>/snorm[169]'

    std::memcpy(&USV_B.Assignment_snorm[0], &USV_P.snorm169_Y0[0], 169U * sizeof
                (real_T));

    // End of SystemInitialize for SubSystem: '<S469>/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations' 

    // SystemInitialize for Enabled SubSystem: '<S470>/Special case - North//South Geographic Pole' 
    // InitializeConditions for UnitDelay: '<S473>/Unit Delay1'
    std::memcpy(&USV_DW.UnitDelay1_DSTATE_h[0],
                &USV_P.UnitDelay1_InitialCondition[0], 13U * sizeof(real_T));

    // SystemInitialize for IfAction SubSystem: '<S473>/If Action Subsystem1'
    // SystemInitialize for Assignment: '<S477>/Assignment2' incorporates:
    //   Outport: '<S477>/pp[13]'

    std::memcpy(&USV_B.Assignment2_a[0], &USV_P.pp13_Y0[0], 13U * sizeof(real_T));

    // End of SystemInitialize for SubSystem: '<S473>/If Action Subsystem1'

    // SystemInitialize for IfAction SubSystem: '<S473>/If Action Subsystem2'
    // SystemInitialize for Assignment: '<S478>/Assignment2' incorporates:
    //   Outport: '<S478>/pp[13]'

    std::memcpy(&USV_B.Assignment2_o[0], &USV_P.pp13_Y0_h[0], 13U * sizeof
                (real_T));

    // End of SystemInitialize for SubSystem: '<S473>/If Action Subsystem2'

    // SystemInitialize for Product: '<S473>/Product2' incorporates:
    //   Outport: '<S473>/bpp'

    USV_B.Product2_a = USV_P.bpp_Y0;

    // End of SystemInitialize for SubSystem: '<S470>/Special case - North//South Geographic Pole' 

    // SystemInitialize for Sum: '<S470>/Sum1' incorporates:
    //   Outport: '<S469>/bt'

    USV_B.Sum1_h = USV_P.bt_Y0;

    // SystemInitialize for Sum: '<S470>/Sum2' incorporates:
    //   Outport: '<S469>/bp'

    USV_B.Sum2_h = USV_P.bp_Y0;

    // SystemInitialize for Sum: '<S470>/Sum3' incorporates:
    //   Outport: '<S469>/br'

    USV_B.Sum3 = USV_P.br_Y0;

    // SystemInitialize for Sum: '<S470>/Sum5' incorporates:
    //   Outport: '<S469>/bpp'

    USV_B.Sum5 = USV_P.bpp_Y0_k;

    // End of SystemInitialize for SubSystem: '<S461>/For Iterator Subsystem'

    // SystemInitialize for Sum: '<S461>/Sum1' incorporates:
    //   Outport: '<S461>/bt,bp,br,bpp'

    USV_B.Sum1[0] = USV_P.btbpbrbpp_Y0[0];
    USV_B.Sum1[1] = USV_P.btbpbrbpp_Y0[1];
    USV_B.Sum1[2] = USV_P.btbpbrbpp_Y0[2];
    USV_B.Sum1[3] = USV_P.btbpbrbpp_Y0[3];

    // End of SystemInitialize for SubSystem: '<S453>/Compute magnetic vector in spherical coordinates' 

    // SystemInitialize for IfAction SubSystem: '<S330>/Negative Trace'
    // Start for If: '<S335>/Find Maximum Diagonal Value'
    // '<S411>:1:6' hFault=false;
    // '<S411>:1:9' fParam=zeros(20,1);
    // '<S412>:1:6' hFault=false;
    // '<S412>:1:9' fParam=zeros(20,1);
    // '<S377>:1:6' hFault=false;
    // '<S377>:1:9' fParam=zeros(20,1);
    USV_DW.FindMaximumDiagonalValue_Active = -1;

    // End of SystemInitialize for SubSystem: '<S330>/Negative Trace'

    // SystemInitialize for Merge: '<S330>/Merge'
    USV_B.Merge[0] = USV_P.Merge_InitialOutput_i[0];
    USV_B.Merge[1] = USV_P.Merge_InitialOutput_i[1];
    USV_B.Merge[2] = USV_P.Merge_InitialOutput_i[2];
    USV_B.Merge[3] = USV_P.Merge_InitialOutput_i[3];

    // SystemInitialize for Enabled SubSystem: '<S112>/Hpgw'
    USV_Hpgw_Init(&USV_B.Hpgw, &USV_DW.Hpgw, &USV_P.Hpgw);

    // End of SystemInitialize for SubSystem: '<S112>/Hpgw'

    // SystemInitialize for Enabled SubSystem: '<S112>/Hqgw'
    USV_Hqgw_Init(&USV_B.Hqgw, &USV_DW.Hqgw, &USV_P.Hqgw);

    // End of SystemInitialize for SubSystem: '<S112>/Hqgw'

    // SystemInitialize for Enabled SubSystem: '<S112>/Hrgw'
    USV_Hrgw_Init(&USV_B.Hrgw, &USV_DW.Hrgw, &USV_P.Hrgw);

    // End of SystemInitialize for SubSystem: '<S112>/Hrgw'

    // SystemInitialize for Enabled SubSystem: '<S151>/Hpgw'
    USV_Hpgw_Init(&USV_B.Hpgw_f, &USV_DW.Hpgw_f, &USV_P.Hpgw_f);

    // End of SystemInitialize for SubSystem: '<S151>/Hpgw'

    // SystemInitialize for Enabled SubSystem: '<S151>/Hqgw'
    USV_Hqgw_Init(&USV_B.Hqgw_j, &USV_DW.Hqgw_j, &USV_P.Hqgw_j);

    // End of SystemInitialize for SubSystem: '<S151>/Hqgw'

    // SystemInitialize for Enabled SubSystem: '<S151>/Hrgw'
    USV_Hrgw_Init(&USV_B.Hrgw_l, &USV_DW.Hrgw_l, &USV_P.Hrgw_l);

    // End of SystemInitialize for SubSystem: '<S151>/Hrgw'
  }

  // set "at time zero" to false
  if (rtmIsFirstInitCond((&USV_M))) {
    rtmSetFirstInitCond((&USV_M), 0);
  }
}

// Model terminate function
void MulticopterModelClass::terminate()
{
  // (no terminate code required)
}

// Constructor
MulticopterModelClass::MulticopterModelClass() :
  USV_U(),
  USV_Y(),
  USV_B(),
  USV_DW(),
  USV_X(),
  USV_M()
{
  // Currently there is no constructor body generated.
}

// Destructor
MulticopterModelClass::~MulticopterModelClass()
{
  // Currently there is no destructor body generated.
}

// Real-Time Model get method
RT_MODEL_USV_T * MulticopterModelClass::getRTM()
{
  return (&USV_M);
}

//
// File trailer for generated code.
//
// [EOF]
//
