//
// File: USV.h
//
// Code generated for Simulink model 'USV'.
//
// Model version                  : 10.49
// Simulink Coder version         : 9.7 (R2022a) 13-Nov-2021
// C/C++ source code generated on : Thu Sep 22 23:56:13 2022
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_USV_h_
#define RTW_HEADER_USV_h_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include <cmath>
#include <cstring>
#include <stddef.h>

// Model Code Variants

// Macros for accessing real-time model data structure
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

// Forward declaration for rtModel
typedef struct tag_RTM_USV_T RT_MODEL_USV_T;

#ifndef DEFINED_TYPEDEF_FOR_MavVehileInfo_
#define DEFINED_TYPEDEF_FOR_MavVehileInfo_

struct MavVehileInfo
{
  int32_T copterID;
  int32_T vehicleType;
  real_T runnedTime;
  real32_T VelE[3];
  real32_T PosE[3];
  real32_T AngEuler[3];
  real32_T AngQuatern[4];
  real32_T MotorRPMS[8];
  real32_T AccB[3];
  real32_T RateB[3];
  real_T PosGPS[3];
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_MavLinkGPS_
#define DEFINED_TYPEDEF_FOR_MavLinkGPS_

struct MavLinkGPS
{
  uint32_T time_usec;
  int32_T lat;
  int32_T lon;
  int32_T alt;
  uint16_T eph;
  uint16_T epv;
  uint16_T vel;
  int16_T vn;
  int16_T ve;
  int16_T vd;
  uint16_T cog;
  uint8_T fix_type;
  uint8_T satellites_visible;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_MavLinkSensor_
#define DEFINED_TYPEDEF_FOR_MavLinkSensor_

struct MavLinkSensor
{
  uint32_T time_usec;
  real32_T xacc;
  real32_T yacc;
  real32_T zacc;
  real32_T xgyro;
  real32_T ygyro;
  real32_T zgyro;
  real32_T xmag;
  real32_T ymag;
  real32_T zmag;
  real32_T abs_pressure;
  real32_T diff_pressure;
  real32_T pressure_alt;
  real32_T temperature;
  uint32_T fields_updated;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_MavLinkStateQuat_
#define DEFINED_TYPEDEF_FOR_MavLinkStateQuat_

struct MavLinkStateQuat
{
  uint32_T time_usec;
  real32_T attitude_quaternion[4];
  real32_T rollspeed;
  real32_T pitchspeed;
  real32_T yawspeed;
  int32_T lat;
  int32_T lon;
  int32_T alt;
  int16_T vx;
  int16_T vy;
  int16_T vz;
  uint16_T ind_airspeed;
  uint16_T true_airspeed;
  int16_T xacc;
  int16_T yacc;
  int16_T zacc;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_zbeTIcD0TTpzykOQ6r3F5E_
#define DEFINED_TYPEDEF_FOR_struct_zbeTIcD0TTpzykOQ6r3F5E_

struct struct_zbeTIcD0TTpzykOQ6r3F5E
{
  real_T FaultID;
  int32_T ESCNum;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_cC8C5MZV75wwVdzQ00rR7E_
#define DEFINED_TYPEDEF_FOR_struct_cC8C5MZV75wwVdzQ00rR7E_

struct struct_cC8C5MZV75wwVdzQ00rR7E
{
  real_T FaultInParams[32];
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_UoMJMKTA16gMsevoePqapD_
#define DEFINED_TYPEDEF_FOR_struct_UoMJMKTA16gMsevoePqapD_

struct struct_UoMJMKTA16gMsevoePqapD
{
  boolean_T isEnable;
  real_T input_offset;
  real_T input_scaling;
  real_T zero_position_disarmed;
  real_T zero_position_armed;
  real_T joint_control_type;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_rHAf2Ncw266Lr5SdOUZ2fD_
#define DEFINED_TYPEDEF_FOR_struct_rHAf2Ncw266Lr5SdOUZ2fD_

struct struct_rHAf2Ncw266Lr5SdOUZ2fD
{
  real_T ConstWindFaultID;
  real_T GustWindFaultID;
  real_T TurbWindFaultID;
  real_T SheerWindFaultID;
  real_T NoiseWindFaultID;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_lSp6B25aGgej2qHFROHX1D_
#define DEFINED_TYPEDEF_FOR_struct_lSp6B25aGgej2qHFROHX1D_

struct struct_lSp6B25aGgej2qHFROHX1D
{
  boolean_T isEnable;
  real_T input_index;
  real_T pose[6];
  real_T reversible;
  real_T turningDirection;
  real_T timeConstantUp;
  real_T timeConstantDown;
  real_T maxRotVelocity;
  real_T motorConstant;
  real_T momentConstant;
  real_T rotorDragCoefficient;
  real_T rollingMomentCoefficient;
  real_T rotorVelocitySlowdownSim;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_Pgy9ii6hzkRIywShcsrSAG_
#define DEFINED_TYPEDEF_FOR_struct_Pgy9ii6hzkRIywShcsrSAG_

struct struct_Pgy9ii6hzkRIywShcsrSAG
{
  real_T AccNoiseFaultID;
  real_T GyroNoiseFaultID;
  real_T MagNoiseFaultID;
  real_T BaroNoiseFaultID;
  real_T GPSNoiseFaultID;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_Jn5r04kZ5qDvsDYCBoFEc_
#define DEFINED_TYPEDEF_FOR_struct_Jn5r04kZ5qDvsDYCBoFEc_

struct struct_Jn5r04kZ5qDvsDYCBoFEc
{
  real_T Pose_futong_left[3];
  real_T Pose_futong_right[3];
  real_T zw;
  real_T HullRadius;
  real_T z_cb;
  real_T BoatLength;
  real_T BoatWidth;
  real_T LengthN;
  real_T WaterDensity;
  real_T Ma[36];
  real_T Dmat[36];
};

#endif

// Block signals for system '<S54>/Distance into gust (y)'
struct B_Distanceintogusty_USV_T {
  real_T DistanceintoGustxLimitedtogustl;
                  // '<S58>/Distance into Gust (x) (Limited to gust length d) '
};

// Block states (default storage) for system '<S54>/Distance into gust (y)'
struct DW_Distanceintogusty_USV_T {
  boolean_T Distanceintogusty_MODE;    // '<S54>/Distance into gust (y)'
};

// Continuous states for system '<S54>/Distance into gust (y)'
struct X_Distanceintogusty_USV_T {
  real_T DistanceintoGustxLimitedtogustl;
                  // '<S58>/Distance into Gust (x) (Limited to gust length d) '
};

// State derivatives for system '<S54>/Distance into gust (y)'
struct XDot_Distanceintogusty_USV_T {
  real_T DistanceintoGustxLimitedtogustl;
                  // '<S58>/Distance into Gust (x) (Limited to gust length d) '
};

// State Disabled for system '<S54>/Distance into gust (y)'
struct XDis_Distanceintogusty_USV_T {
  boolean_T DistanceintoGustxLimitedtogustl;
                  // '<S58>/Distance into Gust (x) (Limited to gust length d) '
};

// Block signals for system '<S112>/Hpgw'
struct B_Hpgw_USV_T {
  real_T UnitDelay[2];                 // '<S123>/Unit Delay'
  real_T Sum[2];                       // '<S123>/Sum'
};

// Block states (default storage) for system '<S112>/Hpgw'
struct DW_Hpgw_USV_T {
  real_T UnitDelay_DSTATE[2];          // '<S123>/Unit Delay'
  boolean_T Hpgw_MODE;                 // '<S112>/Hpgw'
};

// Block signals for system '<S112>/Hqgw'
struct B_Hqgw_USV_T {
  real_T dt1;                          // '<S124>/dt1'
  real_T Sum2;                         // '<S124>/Sum2'
  real_T LugV2[2];                     // '<S124>/Lug//V2'
  real_T UnitDelay1[2];                // '<S124>/Unit Delay1'
  real_T Sum1[2];                      // '<S124>/Sum1'
};

// Block states (default storage) for system '<S112>/Hqgw'
struct DW_Hqgw_USV_T {
  real_T UnitDelay_DSTATE[2];          // '<S124>/Unit Delay'
  real_T UnitDelay1_DSTATE[2];         // '<S124>/Unit Delay1'
  boolean_T Hqgw_MODE;                 // '<S112>/Hqgw'
};

// Block signals for system '<S112>/Hrgw'
struct B_Hrgw_USV_T {
  real_T dt1;                          // '<S125>/dt1'
  real_T Sum2;                         // '<S125>/Sum2'
  real_T LugV2[2];                     // '<S125>/Lug//V2'
  real_T UnitDelay1[2];                // '<S125>/Unit Delay1'
  real_T Sum1[2];                      // '<S125>/Sum1'
};

// Block states (default storage) for system '<S112>/Hrgw'
struct DW_Hrgw_USV_T {
  real_T UnitDelay_DSTATE[2];          // '<S125>/Unit Delay'
  real_T UnitDelay1_DSTATE[2];         // '<S125>/Unit Delay1'
  boolean_T Hrgw_MODE;                 // '<S112>/Hrgw'
};

// Block signals for system '<S113>/Hugw(z)'
struct B_Hugwz_USV_T {
  real_T UnitDelay[2];                 // '<S126>/Unit Delay'
  real_T Sum[2];                       // '<S126>/Sum'
};

// Block states (default storage) for system '<S113>/Hugw(z)'
struct DW_Hugwz_USV_T {
  real_T UnitDelay_DSTATE[2];          // '<S126>/Unit Delay'
  boolean_T Hugwz_MODE;                // '<S113>/Hugw(z)'
};

// Block signals for system '<S113>/Hvgw(z)'
struct B_Hvgwz_USV_T {
  real_T UnitDelay[2];                 // '<S127>/Unit Delay'
  real_T Sum[2];                       // '<S127>/Sum'
};

// Block states (default storage) for system '<S113>/Hvgw(z)'
struct DW_Hvgwz_USV_T {
  real_T UnitDelay_DSTATE[2];          // '<S127>/Unit Delay'
  boolean_T Hvgwz_MODE;                // '<S113>/Hvgw(z)'
};

// Block signals for system '<S113>/Hwgw(z)'
struct B_Hwgwz_USV_T {
  real_T UnitDelay[2];                 // '<S128>/Unit Delay'
  real_T Sum[2];                       // '<S128>/Sum'
};

// Block states (default storage) for system '<S113>/Hwgw(z)'
struct DW_Hwgwz_USV_T {
  real_T UnitDelay_DSTATE[2];          // '<S128>/Unit Delay'
  boolean_T Hwgwz_MODE;                // '<S113>/Hwgw(z)'
};

// Block signals for system '<S198>/MATLAB Function1'
struct B_MATLABFunction1_USV_T {
  real_T outputState;                  // '<S198>/MATLAB Function1'
};

// Block states (default storage) for system '<S198>/MATLAB Function1'
struct DW_MATLABFunction1_USV_T {
  real_T previousState;                // '<S198>/MATLAB Function1'
  real_T lastTime;                     // '<S198>/MATLAB Function1'
};

// Block signals for system '<S198>/���ģ��'
struct B_u_USV_T {
  real_T Fb[3];                        // '<S198>/���ģ��'
  real_T Mb[3];                        // '<S198>/���ģ��'
};

// Block signals for system '<S407>/Acc NoiseFun'
struct B_AccNoiseFun_USV_T {
  real_T y[3];                         // '<S407>/Acc NoiseFun'
};

// Block signals (default storage)
struct B_USV_T {
  real_T q0;                           // '<S20>/q0'
  real_T q1;                           // '<S20>/q1'
  real_T q2;                           // '<S20>/q2'
  real_T q3;                           // '<S20>/q3'
  real_T SinCos_o1;                    // '<S76>/SinCos'
  real_T SinCos_o2;                    // '<S76>/SinCos'
  real_T Switch;                       // '<S84>/Switch'
  real_T TrigonometricFunction1;       // '<S90>/Trigonometric Function1'
  real_T TrigonometricFunction2;       // '<S90>/Trigonometric Function2'
  real_T Switch_i;                     // '<S85>/Switch'
  real_T MatrixConcatenate[3];         // '<S72>/Matrix Concatenate'
  real_T VectorConcatenate_j[9];       // '<S220>/Vector Concatenate'
  real_T DCM_bj[9];                    // '<S198>/Transpose'
  real_T Gain;                         // '<S50>/Gain'
  real_T Divide;                       // '<S198>/Divide'
  real_T UnitConversion;               // '<S159>/Unit Conversion'
  real_T UnitConversion_m;             // '<S188>/Unit Conversion'
  real_T sigma_wg;                     // '<S169>/sigma_wg '
  real_T PreLookUpIndexSearchprobofexcee;
                          // '<S168>/PreLook-Up Index Search  (prob of exceed)'
  real_T Product[4];                   // '<S161>/Product'
  real_T UnitConversion_p;             // '<S150>/Unit Conversion'
  real_T UnitConversion_n;             // '<S120>/Unit Conversion'
  real_T UnitConversion_mq;            // '<S149>/Unit Conversion'
  real_T sigma_wg_e;                   // '<S130>/sigma_wg '
  real_T PreLookUpIndexSearchprobofexc_b;
                          // '<S129>/PreLook-Up Index Search  (prob of exceed)'
  real_T Product_j[4];                 // '<S122>/Product'
  real_T UnitConversion_o;             // '<S111>/Unit Conversion'
  real_T lnref_heightz0;               // '<S110>/ln(ref_height//z0)'
  real_T Windspeedatreferenceheight[3];
                                     // '<S110>/Wind speed at reference height'
  real_T VectorConcatenate_p[9];       // '<S235>/Vector Concatenate'
  real_T DCM_bj_d[9];                  // '<S199>/Transpose'
  real_T Divide_a;                     // '<S199>/Divide'
  real_T VectorConcatenate_o[9];       // '<S250>/Vector Concatenate'
  real_T DCM_bj_b[9];                  // '<S200>/Transpose'
  real_T Divide_l;                     // '<S200>/Divide'
  real_T VectorConcatenate_k[9];       // '<S265>/Vector Concatenate'
  real_T DCM_bj_h[9];                  // '<S201>/Transpose'
  real_T Divide_h;                     // '<S201>/Divide'
  real_T VectorConcatenate_m[9];       // '<S280>/Vector Concatenate'
  real_T DCM_bj_d2[9];                 // '<S202>/Transpose'
  real_T Divide_p;                     // '<S202>/Divide'
  real_T VectorConcatenate_l[9];       // '<S295>/Vector Concatenate'
  real_T DCM_bj_a[9];                  // '<S203>/Transpose'
  real_T Divide_hs;                    // '<S203>/Divide'
  real_T VectorConcatenate_h[9];       // '<S310>/Vector Concatenate'
  real_T DCM_bj_i[9];                  // '<S204>/Transpose'
  real_T Divide_f;                     // '<S204>/Divide'
  real_T VectorConcatenate_m3[9];      // '<S325>/Vector Concatenate'
  real_T DCM_bj_c[9];                  // '<S205>/Transpose'
  real_T Divide_k;                     // '<S205>/Divide'
  real_T Gain_g[3];                    // '<S426>/Gain'
  real_T Selector1[9];                 // '<S11>/Selector1'
  real_T Selector[9];                  // '<S11>/Selector'
  real_T Selector2[9];                 // '<S11>/Selector2'
  real_T Product2[3];                  // '<S11>/Product2'
  real_T Gain10[3];                    // '<S406>/Gain10'
  real_T Gain6[3];                     // '<S406>/Gain6'
  real_T Switch_h;                     // '<S456>/Switch'
  real_T Switch_j;                     // '<S455>/Switch'
  real_T olat;                         // '<S465>/olat'
  real_T Gain_k;                       // '<S419>/Gain'
  real_T oalt;                         // '<S465>/oalt'
  real_T Gain11[3];                    // '<S406>/Gain11'
  real_T Product4;                     // '<S414>/Product4'
  real_T Product4_l;                   // '<S415>/Product4'
  real_T BiasGain2[3];                 // '<S373>/BiasGain2'
  real_T SinCos_o1_e;                  // '<S382>/SinCos'
  real_T SinCos_o2_g;                  // '<S382>/SinCos'
  real_T Switch_m;                     // '<S390>/Switch'
  real_T TrigonometricFunction1_c;     // '<S396>/Trigonometric Function1'
  real_T TrigonometricFunction2_k;     // '<S396>/Trigonometric Function2'
  real_T Switch_f;                     // '<S391>/Switch'
  real_T Product_f[3];                 // '<S17>/Product'
  real_T Merge[4];                     // '<S330>/Merge'
  real_T Sum[3];                       // '<S9>/Sum'
  real_T DataTypeConversion3[8];       // '<S5>/Data Type Conversion3'
  real_T TmpSignalConversionAtq0q1q2q3_c[4];// '<S10>/qdot'
  real_T UnitConversion_nn;            // '<S115>/Unit Conversion'
  real_T UnitConversion_id;            // '<S154>/Unit Conversion'
  real_T BiasGain1[3];                 // '<S331>/BiasGain1'
  real_T Sum2[3];                      // '<S432>/Sum2'
  real_T Sum2_b[3];                    // '<S443>/Sum2'
  real_T y;                            // '<S406>/baro NoiseFun'
  real_T Gain_g4[11];                  // '<S463>/Gain'
  real_T Gain1_l[11];                  // '<S463>/Gain1'
  real_T OutportBufferForcp13[13];
  real_T OutportBufferForsp13[13];
  real_T b2;                           // '<S462>/b2'
  real_T a2;                           // '<S462>/a2'
  real_T c2;                           // '<S505>/Sum1'
  real_T a4;                           // '<S507>/a4'
  real_T c4;                           // '<S507>/Sum9'
  real_T sqrt_i;                       // '<S462>/sqrt'
  real_T Product11;                    // '<S502>/Product11'
  real_T Product4_j;                   // '<S503>/Product4'
  real_T c2_j;                         // '<S508>/Sum1'
  real_T Product12;                    // '<S508>/Product12'
  real_T sqrt_ix;                      // '<S509>/sqrt'
  real_T Sum1[4];                      // '<S461>/Sum1'
  real_T Sum1_h;                       // '<S470>/Sum1'
  real_T Sum2_h;                       // '<S470>/Sum2'
  real_T Sum3;                         // '<S470>/Sum3'
  real_T Sum5;                         // '<S470>/Sum5'
  real_T Assignment[169];              // '<S472>/Assignment'
  real_T Sum2_a[169];                  // '<S472>/Sum2'
  real_T Assignment2[169];             // '<S500>/Assignment2'
  real_T Merge1_p;                     // '<S471>/Merge1'
  real_T Assignment_c[169];            // '<S471>/Assignment'
  real_T Merge_c;                      // '<S471>/Merge'
  real_T Assignment_snorm[169];        // '<S471>/Assignment_snorm'
  real_T Product2_a;                   // '<S473>/Product2'
  real_T Assignment2_o[13];            // '<S478>/Assignment2'
  real_T Assignment2_a[13];            // '<S477>/Assignment2'
  real_T yNoise[3];                    // '<S376>/Acc NoiseFun'
  real_T gWind[3];                     // '<S73>/MATLAB Function'
  real_T FaultParam[20];               // '<S73>/FaultParamsExtract3'
  real_T FaultParam_h[20];             // '<S73>/FaultParamsExtract2'
  real_T FaultParam_o[20];             // '<S73>/FaultParamsExtract1'
  real_T FaultParam_l[20];             // '<S73>/FaultParamsExtract'
  real_T y_k[8];                       // '<S50>/MotorFaultModel'
  real_T DistanceintoGustxLimitedtogustl;
                   // '<S57>/Distance into Gust (x) (Limited to gust length d)'
  real_T Merge_i;                      // '<S37>/Merge'
  uint32_T PreLookUpIndexSearchprobofexc_n;
                          // '<S168>/PreLook-Up Index Search  (prob of exceed)'
  uint32_T PreLookUpIndexSearchprobofexc_c;
                          // '<S129>/PreLook-Up Index Search  (prob of exceed)'
  uint32_T fields_updated;             // '<S402>/Data Type Conversion6'
  real32_T MotorRPMS[8];               // '<S8>/Data Type Conversion8'
  int32_T FaultID;                     // '<S50>/FaultID'
  int32_T copterID;                    // '<S8>/Data Type Conversion'
  int32_T vehicleType;                 // '<S8>/Data Type Conversion2'
  uint16_T eph;                        // '<S331>/Data Type Conversion8'
  uint16_T epv;                        // '<S331>/Data Type Conversion9'
  uint8_T fix_type;                    // '<S331>/Data Type Conversion10'
  uint8_T satellites_visible;          // '<S331>/Data Type Conversion11'
  boolean_T HiddenBuf_InsertedFor_Distanc_a;// '<S54>/Logical Operator1'
  boolean_T HiddenBuf_InsertedFor_Distanc_f;// '<S54>/Logical Operator3'
  boolean_T hasFault_SheerWind;        // '<S73>/FaultParamsExtract3'
  boolean_T hasFault_TurbWind;         // '<S73>/FaultParamsExtract2'
  boolean_T hasFault_GustWind;         // '<S73>/FaultParamsExtract1'
  boolean_T hasFault_ConstWind;        // '<S73>/FaultParamsExtract'
  B_AccNoiseFun_USV_T sf_AccNoiseFun_n;// '<S417>/Acc NoiseFun'
  B_AccNoiseFun_USV_T sf_AccNoiseFun_i;// '<S413>/Acc NoiseFun'
  B_AccNoiseFun_USV_T sf_AccNoiseFun_j;// '<S407>/Acc NoiseFun'
  B_u_USV_T sf__i;                     // '<S205>/���ģ��'
  B_MATLABFunction1_USV_T sf_MATLABFunction1_n;// '<S205>/MATLAB Function1'
  B_u_USV_T sf__c;                     // '<S204>/���ģ��'
  B_MATLABFunction1_USV_T sf_MATLABFunction1_i;// '<S204>/MATLAB Function1'
  B_u_USV_T sf__h;                     // '<S203>/���ģ��'
  B_MATLABFunction1_USV_T sf_MATLABFunction1_j;// '<S203>/MATLAB Function1'
  B_u_USV_T sf__d;                     // '<S202>/���ģ��'
  B_MATLABFunction1_USV_T sf_MATLABFunction1_ga;// '<S202>/MATLAB Function1'
  B_u_USV_T sf__j;                     // '<S201>/���ģ��'
  B_MATLABFunction1_USV_T sf_MATLABFunction1_k;// '<S201>/MATLAB Function1'
  B_u_USV_T sf__m;                     // '<S200>/���ģ��'
  B_MATLABFunction1_USV_T sf_MATLABFunction1_g;// '<S200>/MATLAB Function1'
  B_u_USV_T sf__f;                     // '<S199>/���ģ��'
  B_MATLABFunction1_USV_T sf_MATLABFunction1_o;// '<S199>/MATLAB Function1'
  B_u_USV_T sf_;                       // '<S198>/���ģ��'
  B_MATLABFunction1_USV_T sf_MATLABFunction1_f;// '<S198>/MATLAB Function1'
  B_Hwgwz_USV_T Hwgwz_h;               // '<S152>/Hwgw(z)'
  B_Hvgwz_USV_T Hvgwz_m;               // '<S152>/Hvgw(z)'
  B_Hugwz_USV_T Hugwz_e;               // '<S152>/Hugw(z)'
  B_Hrgw_USV_T Hrgw_l;                 // '<S151>/Hrgw'
  B_Hqgw_USV_T Hqgw_j;                 // '<S151>/Hqgw'
  B_Hpgw_USV_T Hpgw_f;                 // '<S151>/Hpgw'
  B_Hwgwz_USV_T Hwgwz;                 // '<S113>/Hwgw(z)'
  B_Hvgwz_USV_T Hvgwz;                 // '<S113>/Hvgw(z)'
  B_Hugwz_USV_T Hugwz;                 // '<S113>/Hugw(z)'
  B_Hrgw_USV_T Hrgw;                   // '<S112>/Hrgw'
  B_Hqgw_USV_T Hqgw;                   // '<S112>/Hqgw'
  B_Hpgw_USV_T Hpgw;                   // '<S112>/Hpgw'
  B_Distanceintogusty_USV_T Distanceintogustz;// '<S54>/Distance into gust (z)'
  B_Distanceintogusty_USV_T Distanceintogusty;// '<S54>/Distance into gust (y)'
};

// Block states (default storage) for system '<Root>'
struct DW_USV_T {
  real_T UnitDelay1_DSTATE[2];         // '<S510>/Unit Delay1'
  real_T UnitDelay_DSTATE_m[169];      // '<S472>/Unit Delay'
  real_T UnitDelay_DSTATE_d[169];      // '<S499>/Unit Delay'
  real_T UnitDelay_DSTATE_o[169];      // '<S471>/Unit Delay'
  real_T UnitDelay1_DSTATE_m[169];     // '<S471>/Unit Delay1'
  real_T UnitDelay1_DSTATE_h[13];      // '<S473>/Unit Delay1'
  real_T WGS84GravitySFunction_h;      // '<S72>/WGS84 Gravity S-Function'
  real_T WGS84GravitySFunction_phi;    // '<S72>/WGS84 Gravity S-Function'
  real_T WGS84GravitySFunction_lambda; // '<S72>/WGS84 Gravity S-Function'
  real_T WGS84GravitySFunction_gamma_h;// '<S72>/WGS84 Gravity S-Function'
  real_T WGS84GravitySFunction_gamma_phi;// '<S72>/WGS84 Gravity S-Function'
  real_T NextOutput;                   // '<S53>/White Noise'
  real_T NextOutput_g[4];              // '<S161>/White Noise'
  real_T NextOutput_l[4];              // '<S122>/White Noise'
  real_T Product2_DWORK4[9];           // '<S11>/Product2'
  real_T UniformRandomNumber5_NextOutput[3];// '<S406>/Uniform Random Number5'
  real_T UniformRandomNumber1_NextOutput[3];// '<S406>/Uniform Random Number1'
  real_T otime_PreviousInput;          // '<S467>/otime'
  real_T olon_PreviousInput;           // '<S466>/olon'
  real_T olat_PreviousInput;           // '<S465>/olat'
  real_T oalt_PreviousInput;           // '<S465>/oalt'
  real_T UniformRandomNumber7_NextOutput[3];// '<S406>/Uniform Random Number7'
  real_T UniformRandomNumber_NextOutput;// '<S406>/Uniform Random Number'
  real_T UniformRandomNumber4_NextOutput;// '<S406>/Uniform Random Number4'
  real_T UniformRandomNumber5_NextOutp_n[3];// '<S373>/Uniform Random Number5'
  real_T UniformRandomNumber4_NextOutp_c[3];// '<S331>/Uniform Random Number4'
  real_T fParam[20];                   // '<S406>/FaultParamsExtract3'
  real_T fParam_f[20];                 // '<S406>/FaultParamsExtract2'
  real_T fParam_e[20];                 // '<S406>/FaultParamsExtract1'
  real_T fParam_m[20];                 // '<S406>/FaultParamsExtract'
  real_T fParam_j[20];                 // '<S373>/FaultParamsExtract'
  real_T t0;                           // '<S73>/MATLAB Function'
  real_T isInGust;                     // '<S73>/MATLAB Function'
  real_T t1;                           // '<S73>/MATLAB Function'
  real_T a;                            // '<S73>/MATLAB Function'
  real_T ang;                          // '<S73>/MATLAB Function'
  real_T wlast;                        // '<S73>/MATLAB Function'
  real_T wNow;                         // '<S73>/MATLAB Function'
  real_T fParam_h[20];                 // '<S73>/FaultParamsExtract3'
  real_T fParam_fl[20];                // '<S73>/FaultParamsExtract2'
  real_T fParam_j3[20];                // '<S73>/FaultParamsExtract1'
  real_T fParam_a[20];                 // '<S73>/FaultParamsExtract'
  real_T fParam_b[20];                 // '<S50>/FaultParamsExtract'
  uint32_T RandSeed;                   // '<S53>/White Noise'
  uint32_T PreLookUpIndexSearchaltitude_DW;
                                // '<S168>/PreLook-Up Index Search  (altitude)'
  uint32_T PreLookUpIndexSearchprobofexcee;
                          // '<S168>/PreLook-Up Index Search  (prob of exceed)'
  uint32_T RandSeed_a[4];              // '<S161>/White Noise'
  uint32_T PreLookUpIndexSearchaltitude__e;
                                // '<S129>/PreLook-Up Index Search  (altitude)'
  uint32_T PreLookUpIndexSearchprobofexc_l;
                          // '<S129>/PreLook-Up Index Search  (prob of exceed)'
  uint32_T RandSeed_l[4];              // '<S122>/White Noise'
  uint32_T RandSeed_m[3];              // '<S406>/Uniform Random Number5'
  uint32_T RandSeed_k[3];              // '<S406>/Uniform Random Number1'
  uint32_T RandSeed_p[3];              // '<S406>/Uniform Random Number7'
  uint32_T RandSeed_n;                 // '<S406>/Uniform Random Number'
  uint32_T RandSeed_kd;                // '<S406>/Uniform Random Number4'
  uint32_T RandSeed_as[3];             // '<S373>/Uniform Random Number5'
  uint32_T RandSeed_lk[3];             // '<S331>/Uniform Random Number4'
  uint32_T method;                     // '<S73>/MATLAB Function'
  uint32_T state;                      // '<S73>/MATLAB Function'
  uint32_T state_i[2];                 // '<S73>/MATLAB Function'
  uint32_T state_is[625];              // '<S73>/MATLAB Function'
  int_T q0q1q2q3_IWORK;                // '<S10>/q0 q1 q2 q3'
  int_T IntegratorSecondOrderLimited_MO[3];
                                   // '<S432>/Integrator, Second-Order Limited'
  int_T IntegratorSecondOrderLimited__p[3];
                                   // '<S443>/Integrator, Second-Order Limited'
  int8_T If_ActiveSubsystem;           // '<S37>/If'
  int8_T ifHeightMaxlowaltitudeelseifHei;
  // '<S157>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 
  int8_T ifHeightMaxlowaltitudeelseifH_b;
  // '<S118>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 
  int8_T If_ActiveSubsystem_g;         // '<S330>/If'
  int8_T ifHeightMaxlowaltitudeelseifH_g;
  // '<S117>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 
  int8_T ifHeightMaxlowaltitudeelseifH_h;
  // '<S156>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 
  int8_T If1_ActiveSubsystem;          // '<S337>/If1'
  int8_T FindMaximumDiagonalValue_Active;// '<S335>/Find Maximum Diagonal Value' 
  boolean_T IntegratorSecondOrderLimited_DW;
                                   // '<S432>/Integrator, Second-Order Limited'
  boolean_T IntegratorSecondOrderLimited__n;
                                   // '<S443>/Integrator, Second-Order Limited'
  boolean_T hFault;                    // '<S406>/FaultParamsExtract3'
  boolean_T hFault_g;                  // '<S406>/FaultParamsExtract2'
  boolean_T hFault_f;                  // '<S406>/FaultParamsExtract1'
  boolean_T hFault_a;                  // '<S406>/FaultParamsExtract'
  boolean_T hFault_o;                  // '<S373>/FaultParamsExtract'
  boolean_T wlast_not_empty;           // '<S73>/MATLAB Function'
  boolean_T wNow_not_empty;            // '<S73>/MATLAB Function'
  boolean_T hFault_i;                  // '<S73>/FaultParamsExtract3'
  boolean_T hFault_p;                  // '<S73>/FaultParamsExtract2'
  boolean_T hFault_ik;                 // '<S73>/FaultParamsExtract1'
  boolean_T hFault_n;                  // '<S73>/FaultParamsExtract'
  boolean_T hFault_c;                  // '<S50>/FaultParamsExtract'
  boolean_T Convertfromgeodetictosphericalc;
                   // '<S453>/Convert from geodetic to  spherical coordinates '
  boolean_T Convertfromgeodetictospherica_d;
                    // '<S453>/Convert from geodetic to  spherical coordinates'
  boolean_T SpecialcaseNorthSouthGeographic;
                        // '<S470>/Special case - North//South Geographic Pole'
  boolean_T Distanceintogustx_MODE;    // '<S54>/Distance into gust (x)'
  DW_MATLABFunction1_USV_T sf_MATLABFunction1_n;// '<S205>/MATLAB Function1'
  DW_MATLABFunction1_USV_T sf_MATLABFunction1_i;// '<S204>/MATLAB Function1'
  DW_MATLABFunction1_USV_T sf_MATLABFunction1_j;// '<S203>/MATLAB Function1'
  DW_MATLABFunction1_USV_T sf_MATLABFunction1_ga;// '<S202>/MATLAB Function1'
  DW_MATLABFunction1_USV_T sf_MATLABFunction1_k;// '<S201>/MATLAB Function1'
  DW_MATLABFunction1_USV_T sf_MATLABFunction1_g;// '<S200>/MATLAB Function1'
  DW_MATLABFunction1_USV_T sf_MATLABFunction1_o;// '<S199>/MATLAB Function1'
  DW_MATLABFunction1_USV_T sf_MATLABFunction1_f;// '<S198>/MATLAB Function1'
  DW_Hwgwz_USV_T Hwgwz_h;              // '<S152>/Hwgw(z)'
  DW_Hvgwz_USV_T Hvgwz_m;              // '<S152>/Hvgw(z)'
  DW_Hugwz_USV_T Hugwz_e;              // '<S152>/Hugw(z)'
  DW_Hrgw_USV_T Hrgw_l;                // '<S151>/Hrgw'
  DW_Hqgw_USV_T Hqgw_j;                // '<S151>/Hqgw'
  DW_Hpgw_USV_T Hpgw_f;                // '<S151>/Hpgw'
  DW_Hwgwz_USV_T Hwgwz;                // '<S113>/Hwgw(z)'
  DW_Hvgwz_USV_T Hvgwz;                // '<S113>/Hvgw(z)'
  DW_Hugwz_USV_T Hugwz;                // '<S113>/Hugw(z)'
  DW_Hrgw_USV_T Hrgw;                  // '<S112>/Hrgw'
  DW_Hqgw_USV_T Hqgw;                  // '<S112>/Hqgw'
  DW_Hpgw_USV_T Hpgw;                  // '<S112>/Hpgw'
  DW_Distanceintogusty_USV_T Distanceintogustz;// '<S54>/Distance into gust (z)' 
  DW_Distanceintogusty_USV_T Distanceintogusty;// '<S54>/Distance into gust (y)' 
};

// Continuous states (default storage)
struct X_USV_T {
  real_T IntegratorSecondOrderLimited_CS[6];
                                   // '<S432>/Integrator, Second-Order Limited'
  real_T q0q1q2q3_CSTATE[4];           // '<S10>/q0 q1 q2 q3'
  real_T xeyeze_CSTATE[3];             // '<S9>/xe,ye,ze'
  real_T pqr_CSTATE[3];                // '<S9>/p,q,r '
  real_T ubvbwb_CSTATE[3];             // '<S9>/ub,vb,wb'
  real_T IntegratorSecondOrderLimited__p[6];
                                   // '<S443>/Integrator, Second-Order Limited'
  real_T TransferFcn4_CSTATE;          // '<S375>/Transfer Fcn4'
  real_T TransferFcn1_CSTATE;          // '<S375>/Transfer Fcn1'
  real_T TransferFcn2_CSTATE;          // '<S375>/Transfer Fcn2'
  real_T TransferFcn2_CSTATE_b;        // '<S52>/Transfer Fcn2'
  real_T TransferFcn1_CSTATE_l;        // '<S52>/Transfer Fcn1'
  real_T TransferFcn3_CSTATE;          // '<S52>/Transfer Fcn3'
  X_Distanceintogusty_USV_T Distanceintogustz;// '<S54>/Distance into gust (y)'
  X_Distanceintogusty_USV_T Distanceintogusty;// '<S54>/Distance into gust (y)'
  real_T DistanceintoGustxLimitedtogus_o;
                   // '<S57>/Distance into Gust (x) (Limited to gust length d)'
};

// State derivatives (default storage)
struct XDot_USV_T {
  real_T IntegratorSecondOrderLimited_CS[6];
                                   // '<S432>/Integrator, Second-Order Limited'
  real_T q0q1q2q3_CSTATE[4];           // '<S10>/q0 q1 q2 q3'
  real_T xeyeze_CSTATE[3];             // '<S9>/xe,ye,ze'
  real_T pqr_CSTATE[3];                // '<S9>/p,q,r '
  real_T ubvbwb_CSTATE[3];             // '<S9>/ub,vb,wb'
  real_T IntegratorSecondOrderLimited__p[6];
                                   // '<S443>/Integrator, Second-Order Limited'
  real_T TransferFcn4_CSTATE;          // '<S375>/Transfer Fcn4'
  real_T TransferFcn1_CSTATE;          // '<S375>/Transfer Fcn1'
  real_T TransferFcn2_CSTATE;          // '<S375>/Transfer Fcn2'
  real_T TransferFcn2_CSTATE_b;        // '<S52>/Transfer Fcn2'
  real_T TransferFcn1_CSTATE_l;        // '<S52>/Transfer Fcn1'
  real_T TransferFcn3_CSTATE;          // '<S52>/Transfer Fcn3'
  XDot_Distanceintogusty_USV_T Distanceintogustz;// '<S54>/Distance into gust (y)' 
  XDot_Distanceintogusty_USV_T Distanceintogusty;// '<S54>/Distance into gust (y)' 
  real_T DistanceintoGustxLimitedtogus_o;
                   // '<S57>/Distance into Gust (x) (Limited to gust length d)'
};

// State disabled
struct XDis_USV_T {
  boolean_T IntegratorSecondOrderLimited_CS[6];
                                   // '<S432>/Integrator, Second-Order Limited'
  boolean_T q0q1q2q3_CSTATE[4];        // '<S10>/q0 q1 q2 q3'
  boolean_T xeyeze_CSTATE[3];          // '<S9>/xe,ye,ze'
  boolean_T pqr_CSTATE[3];             // '<S9>/p,q,r '
  boolean_T ubvbwb_CSTATE[3];          // '<S9>/ub,vb,wb'
  boolean_T IntegratorSecondOrderLimited__p[6];
                                   // '<S443>/Integrator, Second-Order Limited'
  boolean_T TransferFcn4_CSTATE;       // '<S375>/Transfer Fcn4'
  boolean_T TransferFcn1_CSTATE;       // '<S375>/Transfer Fcn1'
  boolean_T TransferFcn2_CSTATE;       // '<S375>/Transfer Fcn2'
  boolean_T TransferFcn2_CSTATE_b;     // '<S52>/Transfer Fcn2'
  boolean_T TransferFcn1_CSTATE_l;     // '<S52>/Transfer Fcn1'
  boolean_T TransferFcn3_CSTATE;       // '<S52>/Transfer Fcn3'
  XDis_Distanceintogusty_USV_T Distanceintogustz;// '<S54>/Distance into gust (y)' 
  XDis_Distanceintogusty_USV_T Distanceintogusty;// '<S54>/Distance into gust (y)' 
  boolean_T DistanceintoGustxLimitedtogus_o;
                   // '<S57>/Distance into Gust (x) (Limited to gust length d)'
};

#ifndef ODE4_INTG
#define ODE4_INTG

// ODE4 Integration Data
struct ODE4_IntgData {
  real_T *y;                           // output
  real_T *f[4];                        // derivatives
};

#endif

// External inputs (root inport signals with default storage)
struct ExtU_USV_T {
  real_T TerrainZ;                     // '<Root>/TerrainZ'
  real_T inPWMs[16];                   // '<Root>/inPWMs'
  int32_T inSILInts[8];                // '<Root>/inSILInts'
  real32_T inSILFloats[20];            // '<Root>/inSILFloats'
};

// External outputs (root outports fed by signals with default storage)
struct ExtY_USV_T {
  MavLinkSensor MavHILSensor;          // '<Root>/MavHILSensor'
  MavLinkGPS MavHILGPS;                // '<Root>/MavHILGPS'
  MavVehileInfo MavVehile3DInfo;       // '<Root>/MavVehile3DInfo'
  real32_T ExtToUE4PX4[32];            // '<Root>/ExtToUE4PX4'
  real_T outCopterData[32];            // '<Root>/outCopterData'
};

// Parameters for system: '<S54>/Distance into gust (y)'
struct P_Distanceintogusty_USV_T_ {
  real_T x_Y0;                         // Expression: [0]
                                          //  Referenced by: '<S58>/x'

  real_T DistanceintoGustxLimitedtogustl;// Expression: 0
                                            //  Referenced by: '<S58>/Distance into Gust (x) (Limited to gust length d) '

  real_T DistanceintoGustxLimitedtogus_b;// Expression: 0
                                            //  Referenced by: '<S58>/Distance into Gust (x) (Limited to gust length d) '

};

// Parameters for system: '<S54>/Distance into gust (y)'
typedef struct P_Distanceintogusty_USV_T_ P_Distanceintogusty_USV_T;

// Parameters for system: '<S112>/Hpgw'
struct P_Hpgw_USV_T_ {
  real_T pgw_Y0;                       // Expression: 0
                                          //  Referenced by: '<S123>/pgw'

  real_T Constant2_Value;              // Expression: 2.6
                                          //  Referenced by: '<S123>/Constant2'

  real_T u_Gain;                       // Expression: 2*dt
                                          //  Referenced by: '<S123>/2'

  real_T Constant_Value;               // Expression: 1
                                          //  Referenced by: '<S123>/Constant'

  real_T Constant1_Value;              // Expression: 0.95
                                          //  Referenced by: '<S123>/Constant1'

  real_T Constant3_Value;              // Expression: 1/3
                                          //  Referenced by: '<S123>/Constant3'

  real_T dt_Gain;                      // Expression: dt
                                          //  Referenced by: '<S123>/dt'

  real_T UnitDelay_InitialCondition;   // Expression: 0
                                          //  Referenced by: '<S123>/Unit Delay'

};

// Parameters for system: '<S112>/Hpgw'
typedef struct P_Hpgw_USV_T_ P_Hpgw_USV_T;

// Parameters for system: '<S112>/Hqgw'
struct P_Hqgw_USV_T_ {
  real_T qgw_Y0;                       // Expression: 0
                                          //  Referenced by: '<S124>/qgw'

  real_T Constant_Value;               // Expression: 1
                                          //  Referenced by: '<S124>/Constant'

  real_T dt1_Gain;                     // Expression: 4/pi
                                          //  Referenced by: '<S124>/dt1'

  real_T dt_Gain;                      // Expression: dt
                                          //  Referenced by: '<S124>/dt'

  real_T UnitDelay_InitialCondition;   // Expression: 0
                                          //  Referenced by: '<S124>/Unit Delay'

  real_T UnitDelay1_InitialCondition;  // Expression: 0
                                          //  Referenced by: '<S124>/Unit Delay1'

};

// Parameters for system: '<S112>/Hqgw'
typedef struct P_Hqgw_USV_T_ P_Hqgw_USV_T;

// Parameters for system: '<S112>/Hrgw'
struct P_Hrgw_USV_T_ {
  real_T rgw_Y0;                       // Expression: 0
                                          //  Referenced by: '<S125>/rgw'

  real_T Constant_Value;               // Expression: 1
                                          //  Referenced by: '<S125>/Constant'

  real_T dt1_Gain;                     // Expression: 3/pi
                                          //  Referenced by: '<S125>/dt1'

  real_T dt_Gain;                      // Expression: dt
                                          //  Referenced by: '<S125>/dt'

  real_T UnitDelay_InitialCondition;   // Expression: 0
                                          //  Referenced by: '<S125>/Unit Delay'

  real_T UnitDelay1_InitialCondition;  // Expression: 0
                                          //  Referenced by: '<S125>/Unit Delay1'

};

// Parameters for system: '<S112>/Hrgw'
typedef struct P_Hrgw_USV_T_ P_Hrgw_USV_T;

// Parameters for system: '<S113>/Hugw(z)'
struct P_Hugwz_USV_T_ {
  real_T ugw_Y0;                       // Expression: 0
                                          //  Referenced by: '<S126>/ugw'

  real_T u_Gain;                       // Expression: 2*dt
                                          //  Referenced by: '<S126>/2'

  real_T Constant_Value;               // Expression: 1
                                          //  Referenced by: '<S126>/Constant'

  real_T dt_Gain;                      // Expression: dt
                                          //  Referenced by: '<S126>/dt'

  real_T UnitDelay_InitialCondition;   // Expression: 0
                                          //  Referenced by: '<S126>/Unit Delay'

};

// Parameters for system: '<S113>/Hugw(z)'
typedef struct P_Hugwz_USV_T_ P_Hugwz_USV_T;

// Parameters for system: '<S113>/Hvgw(z)'
struct P_Hvgwz_USV_T_ {
  real_T vgw_Y0;                       // Expression: 0
                                          //  Referenced by: '<S127>/vgw'

  real_T u_Gain;                       // Expression: 2*dt
                                          //  Referenced by: '<S127>/2'

  real_T Constant_Value;               // Expression: 1
                                          //  Referenced by: '<S127>/Constant'

  real_T dt_Gain;                      // Expression: dt
                                          //  Referenced by: '<S127>/dt'

  real_T UnitDelay_InitialCondition;   // Expression: 0
                                          //  Referenced by: '<S127>/Unit Delay'

};

// Parameters for system: '<S113>/Hvgw(z)'
typedef struct P_Hvgwz_USV_T_ P_Hvgwz_USV_T;

// Parameters for system: '<S113>/Hwgw(z)'
struct P_Hwgwz_USV_T_ {
  real_T wgw_Y0;                       // Expression: 0
                                          //  Referenced by: '<S128>/wgw'

  real_T u_Gain;                       // Expression: 2*dt
                                          //  Referenced by: '<S128>/2'

  real_T Constant_Value;               // Expression: 1
                                          //  Referenced by: '<S128>/Constant'

  real_T dt_Gain;                      // Expression: dt
                                          //  Referenced by: '<S128>/dt'

  real_T UnitDelay_InitialCondition;   // Expression: 0
                                          //  Referenced by: '<S128>/Unit Delay'

};

// Parameters for system: '<S113>/Hwgw(z)'
typedef struct P_Hwgwz_USV_T_ P_Hwgwz_USV_T;

// Parameters for system: '<S117>/Interpolate  rates'
struct P_Interpolaterates_USV_T_ {
  real_T max_height_low_Value;         // Expression: max_height_low
                                          //  Referenced by: '<S131>/max_height_low'

  real_T min_height_high_Value;        // Expression: min_height_high
                                          //  Referenced by: '<S131>/min_height_high'

};

// Parameters for system: '<S117>/Interpolate  rates'
typedef struct P_Interpolaterates_USV_T_ P_Interpolaterates_USV_T;

// Parameters for system: '<S118>/Interpolate  velocities'
struct P_Interpolatevelocities_USV_T_ {
  real_T max_height_low_Value;         // Expression: max_height_low
                                          //  Referenced by: '<S139>/max_height_low'

  real_T min_height_high_Value;        // Expression: min_height_high
                                          //  Referenced by: '<S139>/min_height_high'

};

// Parameters for system: '<S118>/Interpolate  velocities'
typedef struct P_Interpolatevelocities_USV_T_ P_Interpolatevelocities_USV_T;

// Parameters (default storage)
struct P_USV_T_ {
  struct_Jn5r04kZ5qDvsDYCBoFEc USVPara;// Variable: USVPara
                                          //  Referenced by: '<S192>/USVPara_Dmat'

  struct_cC8C5MZV75wwVdzQ00rR7E FaultParamAPI;// Variable: FaultParamAPI
                                                 //  Referenced by:
                                                 //    '<S50>/Constant'
                                                 //    '<S50>/Gain'
                                                 //    '<S54>/Gust start time'
                                                 //    '<S100>/Wind direction'
                                                 //    '<S100>/Windspeed at 20ft (6m)'
                                                 //    '<S101>/Wind direction'
                                                 //    '<S101>/Windspeed at 20ft (6m)'
                                                 //    '<S110>/Wind Direction'
                                                 //    '<S110>/Wind speed at reference height'
                                                 //    '<S432>/2*zeta * wn'
                                                 //    '<S443>/2*zeta * wn'

  struct_zbeTIcD0TTpzykOQ6r3F5E ESCFault;// Variable: ESCFault
                                            //  Referenced by: '<S50>/MotorNum'

  real_T BoatParam_cf;                 // Variable: BoatParam_cf
                                          //  Referenced by: '<S194>/BoatParam_cf'

  real_T BoatParam_cg;                 // Variable: BoatParam_cg
                                          //  Referenced by: '<S4>/Constant1'

  real_T BoatParam_len;                // Variable: BoatParam_len
                                          //  Referenced by: '<S194>/BoatParam_len'

  real_T BoatParam_lenSlope;           // Variable: BoatParam_lenSlope
                                          //  Referenced by: '<S194>/BoatParam_lenSlope'

  real_T BoatParam_waterDensity;       // Variable: BoatParam_waterDensity
                                          //  Referenced by: '<S194>/BoatParam_waterDensity'

  real_T BoatParam_widSlope;           // Variable: BoatParam_widSlope
                                          //  Referenced by: '<S194>/BoatParam_widSlope'

  real_T BoatParam_width;              // Variable: BoatParam_width
                                          //  Referenced by: '<S194>/BoatParam_width'

  real_T ModelInit_AngEuler[3];        // Variable: ModelInit_AngEuler
                                          //  Referenced by: '<S10>/Initial Euler Angles'

  real_T ModelInit_PosE[3];            // Variable: ModelInit_PosE
                                          //  Referenced by: '<S9>/xe,ye,ze'

  real_T ModelInit_RateB[3];           // Variable: ModelInit_RateB
                                          //  Referenced by: '<S9>/p,q,r '

  real_T ModelInit_VelB[3];            // Variable: ModelInit_VelB
                                          //  Referenced by: '<S9>/ub,vb,wb'

  real_T ModelParam_GPSEphFinal;       // Variable: ModelParam_GPSEphFinal
                                          //  Referenced by: '<S331>/ModelParam.GPSEphFinal'

  real_T ModelParam_GPSEpvFinal;       // Variable: ModelParam_GPSEpvFinal
                                          //  Referenced by: '<S331>/ModelParam.GPSEpvFinal'

  real_T ModelParam_GPSLatLong[2];     // Variable: ModelParam_GPSLatLong
                                          //  Referenced by:
                                          //    '<S69>/ref_position'
                                          //    '<S378>/ref_position'

  real_T ModelParam_envAltitude;       // Variable: ModelParam_envAltitude
                                          //  Referenced by:
                                          //    '<S3>/ModelParam.envAltitude'
                                          //    '<S373>/ModelParam.envAltitude'

  real_T ModelParam_noisePowerOffGainAccel;
                                  // Variable: ModelParam_noisePowerOffGainAccel
                                     //  Referenced by: '<S402>/AccelNoiseGainFunction'

  real_T ModelParam_noisePowerOffGainAccelZ;
                                 // Variable: ModelParam_noisePowerOffGainAccelZ
                                    //  Referenced by: '<S402>/AccelNoiseGainFunction'

  real_T ModelParam_noisePowerOffGainGyro;
                                   // Variable: ModelParam_noisePowerOffGainGyro
                                      //  Referenced by: '<S402>/GyroNoiseGainFunction'

  real_T ModelParam_noisePowerOffGainGyroZ;
                                  // Variable: ModelParam_noisePowerOffGainGyroZ
                                     //  Referenced by: '<S402>/GyroNoiseGainFunction'

  real_T ModelParam_noisePowerOffGainMag;
                                    // Variable: ModelParam_noisePowerOffGainMag
                                       //  Referenced by: '<S402>/MagNoiseGainFunction'

  real_T ModelParam_noisePowerOffGainMagZ;
                                   // Variable: ModelParam_noisePowerOffGainMagZ
                                      //  Referenced by: '<S402>/MagNoiseGainFunction'

  real_T ModelParam_noisePowerOnGainAccel;
                                   // Variable: ModelParam_noisePowerOnGainAccel
                                      //  Referenced by: '<S402>/AccelNoiseGainFunction'

  real_T ModelParam_noisePowerOnGainAccelZ;
                                  // Variable: ModelParam_noisePowerOnGainAccelZ
                                     //  Referenced by: '<S402>/AccelNoiseGainFunction'

  real_T ModelParam_noisePowerOnGainGyro;
                                    // Variable: ModelParam_noisePowerOnGainGyro
                                       //  Referenced by: '<S402>/GyroNoiseGainFunction'

  real_T ModelParam_noisePowerOnGainGyroZ;
                                   // Variable: ModelParam_noisePowerOnGainGyroZ
                                      //  Referenced by: '<S402>/GyroNoiseGainFunction'

  real_T ModelParam_noisePowerOnGainMag;
                                     // Variable: ModelParam_noisePowerOnGainMag
                                        //  Referenced by: '<S402>/MagNoiseGainFunction'

  real_T ModelParam_noisePowerOnGainMagZ;
                                    // Variable: ModelParam_noisePowerOnGainMagZ
                                       //  Referenced by: '<S402>/MagNoiseGainFunction'

  real_T ModelParam_uavCCm[3];         // Variable: ModelParam_uavCCm
                                          //  Referenced by: '<S192>/ModelParam.uavCCm'

  real_T ModelParam_uavCd[3];          // Variable: ModelParam_uavCd
                                          //  Referenced by: '<S192>/ModelParam.uavCd'

  real_T ModelParam_uavJ[9];           // Variable: ModelParam_uavJ
                                          //  Referenced by: '<S12>/Constant1'

  real_T ModelParam_uavMass;           // Variable: ModelParam_uavMass
                                          //  Referenced by:
                                          //    '<S4>/ModelParam.uavMass'
                                          //    '<S8>/ModelParam.uavMass'
                                          //    '<S194>/ModelParam.uavMass'
                                          //    '<S12>/Constant'

  int16_T ModelParam_uavType;          // Variable: ModelParam_uavType
                                          //  Referenced by: '<S8>/UAVType'

  struct_lSp6B25aGgej2qHFROHX1D Motor1_MotorPara;// Mask Parameter: Motor1_MotorPara
                                                    //  Referenced by:
                                                    //    '<S198>/isEnable'
                                                    //    '<S198>/maxRotVelocity'
                                                    //    '<S198>/momentConstant'
                                                    //    '<S198>/motorConstant'
                                                    //    '<S198>/pose'
                                                    //    '<S198>/pose: 1 * 6'
                                                    //    '<S198>/reversible'
                                                    //    '<S198>/rollingMomentCoefficient'
                                                    //    '<S198>/rotorDragCoefficient'
                                                    //    '<S198>/rotorVelocitySlowdownSim'
                                                    //    '<S198>/rotorVelocitySlowdownSim1'
                                                    //    '<S198>/timeConstantDown'
                                                    //    '<S198>/timeConstantUp'
                                                    //    '<S198>/turningDirection'
                                                    //    '<S198>/turningDirection1'

  struct_lSp6B25aGgej2qHFROHX1D Motor2_MotorPara;// Mask Parameter: Motor2_MotorPara
                                                    //  Referenced by:
                                                    //    '<S199>/isEnable'
                                                    //    '<S199>/maxRotVelocity'
                                                    //    '<S199>/momentConstant'
                                                    //    '<S199>/motorConstant'
                                                    //    '<S199>/pose'
                                                    //    '<S199>/pose: 1 * 6'
                                                    //    '<S199>/reversible'
                                                    //    '<S199>/rollingMomentCoefficient'
                                                    //    '<S199>/rotorDragCoefficient'
                                                    //    '<S199>/rotorVelocitySlowdownSim'
                                                    //    '<S199>/rotorVelocitySlowdownSim1'
                                                    //    '<S199>/timeConstantDown'
                                                    //    '<S199>/timeConstantUp'
                                                    //    '<S199>/turningDirection'
                                                    //    '<S199>/turningDirection1'

  struct_lSp6B25aGgej2qHFROHX1D Motor3_MotorPara;// Mask Parameter: Motor3_MotorPara
                                                    //  Referenced by:
                                                    //    '<S200>/isEnable'
                                                    //    '<S200>/maxRotVelocity'
                                                    //    '<S200>/momentConstant'
                                                    //    '<S200>/motorConstant'
                                                    //    '<S200>/pose'
                                                    //    '<S200>/pose: 1 * 6'
                                                    //    '<S200>/reversible'
                                                    //    '<S200>/rollingMomentCoefficient'
                                                    //    '<S200>/rotorDragCoefficient'
                                                    //    '<S200>/rotorVelocitySlowdownSim'
                                                    //    '<S200>/rotorVelocitySlowdownSim1'
                                                    //    '<S200>/timeConstantDown'
                                                    //    '<S200>/timeConstantUp'
                                                    //    '<S200>/turningDirection'
                                                    //    '<S200>/turningDirection1'

  struct_lSp6B25aGgej2qHFROHX1D Motor4_MotorPara;// Mask Parameter: Motor4_MotorPara
                                                    //  Referenced by:
                                                    //    '<S201>/isEnable'
                                                    //    '<S201>/maxRotVelocity'
                                                    //    '<S201>/momentConstant'
                                                    //    '<S201>/motorConstant'
                                                    //    '<S201>/pose'
                                                    //    '<S201>/pose: 1 * 6'
                                                    //    '<S201>/reversible'
                                                    //    '<S201>/rollingMomentCoefficient'
                                                    //    '<S201>/rotorDragCoefficient'
                                                    //    '<S201>/rotorVelocitySlowdownSim'
                                                    //    '<S201>/rotorVelocitySlowdownSim1'
                                                    //    '<S201>/timeConstantDown'
                                                    //    '<S201>/timeConstantUp'
                                                    //    '<S201>/turningDirection'
                                                    //    '<S201>/turningDirection1'

  struct_lSp6B25aGgej2qHFROHX1D Motor5_MotorPara;// Mask Parameter: Motor5_MotorPara
                                                    //  Referenced by:
                                                    //    '<S202>/isEnable'
                                                    //    '<S202>/maxRotVelocity'
                                                    //    '<S202>/momentConstant'
                                                    //    '<S202>/motorConstant'
                                                    //    '<S202>/pose'
                                                    //    '<S202>/pose: 1 * 6'
                                                    //    '<S202>/reversible'
                                                    //    '<S202>/rollingMomentCoefficient'
                                                    //    '<S202>/rotorDragCoefficient'
                                                    //    '<S202>/rotorVelocitySlowdownSim'
                                                    //    '<S202>/rotorVelocitySlowdownSim1'
                                                    //    '<S202>/timeConstantDown'
                                                    //    '<S202>/timeConstantUp'
                                                    //    '<S202>/turningDirection'
                                                    //    '<S202>/turningDirection1'

  struct_lSp6B25aGgej2qHFROHX1D Motor6_MotorPara;// Mask Parameter: Motor6_MotorPara
                                                    //  Referenced by:
                                                    //    '<S203>/isEnable'
                                                    //    '<S203>/maxRotVelocity'
                                                    //    '<S203>/momentConstant'
                                                    //    '<S203>/motorConstant'
                                                    //    '<S203>/pose'
                                                    //    '<S203>/pose: 1 * 6'
                                                    //    '<S203>/reversible'
                                                    //    '<S203>/rollingMomentCoefficient'
                                                    //    '<S203>/rotorDragCoefficient'
                                                    //    '<S203>/rotorVelocitySlowdownSim'
                                                    //    '<S203>/rotorVelocitySlowdownSim1'
                                                    //    '<S203>/timeConstantDown'
                                                    //    '<S203>/timeConstantUp'
                                                    //    '<S203>/turningDirection'
                                                    //    '<S203>/turningDirection1'

  struct_lSp6B25aGgej2qHFROHX1D Motor7_MotorPara;// Mask Parameter: Motor7_MotorPara
                                                    //  Referenced by:
                                                    //    '<S204>/isEnable'
                                                    //    '<S204>/maxRotVelocity'
                                                    //    '<S204>/momentConstant'
                                                    //    '<S204>/motorConstant'
                                                    //    '<S204>/pose'
                                                    //    '<S204>/pose: 1 * 6'
                                                    //    '<S204>/reversible'
                                                    //    '<S204>/rollingMomentCoefficient'
                                                    //    '<S204>/rotorDragCoefficient'
                                                    //    '<S204>/rotorVelocitySlowdownSim'
                                                    //    '<S204>/rotorVelocitySlowdownSim1'
                                                    //    '<S204>/timeConstantDown'
                                                    //    '<S204>/timeConstantUp'
                                                    //    '<S204>/turningDirection'
                                                    //    '<S204>/turningDirection1'

  struct_lSp6B25aGgej2qHFROHX1D Motor8_MotorPara;// Mask Parameter: Motor8_MotorPara
                                                    //  Referenced by:
                                                    //    '<S205>/isEnable'
                                                    //    '<S205>/maxRotVelocity'
                                                    //    '<S205>/momentConstant'
                                                    //    '<S205>/motorConstant'
                                                    //    '<S205>/pose'
                                                    //    '<S205>/pose: 1 * 6'
                                                    //    '<S205>/reversible'
                                                    //    '<S205>/rollingMomentCoefficient'
                                                    //    '<S205>/rotorDragCoefficient'
                                                    //    '<S205>/rotorVelocitySlowdownSim'
                                                    //    '<S205>/rotorVelocitySlowdownSim1'
                                                    //    '<S205>/timeConstantDown'
                                                    //    '<S205>/timeConstantUp'
                                                    //    '<S205>/turningDirection'
                                                    //    '<S205>/turningDirection1'

  struct_UoMJMKTA16gMsevoePqapD ESC1_MotorPara;// Mask Parameter: ESC1_MotorPara
                                                  //  Referenced by:
                                                  //    '<S61>/input_offset'
                                                  //    '<S61>/input_scaling'
                                                  //    '<S61>/isEnable'
                                                  //    '<S61>/zero_position_armed'
                                                  //    '<S61>/zero_position_disarmed'

  struct_UoMJMKTA16gMsevoePqapD ESC2_MotorPara;// Mask Parameter: ESC2_MotorPara
                                                  //  Referenced by:
                                                  //    '<S62>/input_offset'
                                                  //    '<S62>/input_scaling'
                                                  //    '<S62>/isEnable'
                                                  //    '<S62>/zero_position_armed'
                                                  //    '<S62>/zero_position_disarmed'

  struct_UoMJMKTA16gMsevoePqapD ESC3_MotorPara;// Mask Parameter: ESC3_MotorPara
                                                  //  Referenced by:
                                                  //    '<S63>/input_offset'
                                                  //    '<S63>/input_scaling'
                                                  //    '<S63>/isEnable'
                                                  //    '<S63>/zero_position_armed'
                                                  //    '<S63>/zero_position_disarmed'

  struct_UoMJMKTA16gMsevoePqapD ESC4_MotorPara;// Mask Parameter: ESC4_MotorPara
                                                  //  Referenced by:
                                                  //    '<S64>/input_offset'
                                                  //    '<S64>/input_scaling'
                                                  //    '<S64>/isEnable'
                                                  //    '<S64>/zero_position_armed'
                                                  //    '<S64>/zero_position_disarmed'

  struct_UoMJMKTA16gMsevoePqapD ESC5_MotorPara;// Mask Parameter: ESC5_MotorPara
                                                  //  Referenced by:
                                                  //    '<S65>/input_offset'
                                                  //    '<S65>/input_scaling'
                                                  //    '<S65>/isEnable'
                                                  //    '<S65>/zero_position_armed'
                                                  //    '<S65>/zero_position_disarmed'

  struct_UoMJMKTA16gMsevoePqapD ESC6_MotorPara;// Mask Parameter: ESC6_MotorPara
                                                  //  Referenced by:
                                                  //    '<S66>/input_offset'
                                                  //    '<S66>/input_scaling'
                                                  //    '<S66>/isEnable'
                                                  //    '<S66>/zero_position_armed'
                                                  //    '<S66>/zero_position_disarmed'

  struct_UoMJMKTA16gMsevoePqapD ESC7_MotorPara;// Mask Parameter: ESC7_MotorPara
                                                  //  Referenced by:
                                                  //    '<S67>/input_offset'
                                                  //    '<S67>/input_scaling'
                                                  //    '<S67>/isEnable'
                                                  //    '<S67>/zero_position_armed'
                                                  //    '<S67>/zero_position_disarmed'

  struct_UoMJMKTA16gMsevoePqapD ESC8_MotorPara;// Mask Parameter: ESC8_MotorPara
                                                  //  Referenced by:
                                                  //    '<S68>/input_offset'
                                                  //    '<S68>/input_scaling'
                                                  //    '<S68>/isEnable'
                                                  //    '<S68>/zero_position_armed'
                                                  //    '<S68>/zero_position_disarmed'

  real_T BandLimitedWhiteNoise_Cov; // Mask Parameter: BandLimitedWhiteNoise_Cov
                                       //  Referenced by: '<S53>/Output'

  real_T DrydenWindTurbulenceModelDiscre;
                              // Mask Parameter: DrydenWindTurbulenceModelDiscre
                                 //  Referenced by: '<S187>/Medium//High Altitude'

  real_T DrydenWindTurbulenceModelDisc_i;
                              // Mask Parameter: DrydenWindTurbulenceModelDisc_i
                                 //  Referenced by: '<S148>/Medium//High Altitude'

  real_T DrydenWindTurbulenceModelDisc_g[4];
                              // Mask Parameter: DrydenWindTurbulenceModelDisc_g
                                 //  Referenced by: '<S161>/White Noise'

  real_T DrydenWindTurbulenceModelDisc_m[4];
                              // Mask Parameter: DrydenWindTurbulenceModelDisc_m
                                 //  Referenced by: '<S122>/White Noise'

  real_T DrydenWindTurbulenceModelDisc_f;
                              // Mask Parameter: DrydenWindTurbulenceModelDisc_f
                                 //  Referenced by:
                                 //    '<S151>/Constant1'
                                 //    '<S151>/Constant2'
                                 //    '<S151>/Constant3'
                                 //    '<S152>/Constant3'

  real_T DrydenWindTurbulenceModelDisc_a;
                              // Mask Parameter: DrydenWindTurbulenceModelDisc_a
                                 //  Referenced by:
                                 //    '<S112>/Constant1'
                                 //    '<S112>/Constant2'
                                 //    '<S112>/Constant3'
                                 //    '<S113>/Constant3'

  real_T WhiteNoise_Ts;                // Mask Parameter: WhiteNoise_Ts
                                          //  Referenced by: '<S161>/Constant1'

  real_T WhiteNoise_Ts_b;              // Mask Parameter: WhiteNoise_Ts_b
                                          //  Referenced by: '<S122>/Constant1'

  real_T DrydenWindTurbulenceModelDisc_n;
                              // Mask Parameter: DrydenWindTurbulenceModelDisc_n
                                 //  Referenced by: '<S168>/Probability of  Exceedance'

  real_T DrydenWindTurbulenceModelDisc_d;
                              // Mask Parameter: DrydenWindTurbulenceModelDisc_d
                                 //  Referenced by: '<S129>/Probability of  Exceedance'

  real_T DrydenWindTurbulenceModelDisc_l;
                              // Mask Parameter: DrydenWindTurbulenceModelDisc_l
                                 //  Referenced by: '<S100>/Wingspan'

  real_T DrydenWindTurbulenceModelDis_dk;
                              // Mask Parameter: DrydenWindTurbulenceModelDis_dk
                                 //  Referenced by: '<S101>/Wingspan'

  real_T ThreeaxisInertialMeasurementUni[3];
                              // Mask Parameter: ThreeaxisInertialMeasurementUni
                                 //  Referenced by: '<S426>/Measurement bias'

  real_T ThreeaxisInertialMeasurementU_n[9];
                              // Mask Parameter: ThreeaxisInertialMeasurementU_n
                                 //  Referenced by: '<S426>/Scale factors & Cross-coupling  errors'

  real_T DirectionCosineMatrixtoQuaterni;
                              // Mask Parameter: DirectionCosineMatrixtoQuaterni
                                 //  Referenced by:
                                 //    '<S337>/Constant'
                                 //    '<S362>/Constant'
                                 //    '<S363>/Constant'

  real_T CompareToConstant_const;     // Mask Parameter: CompareToConstant_const
                                         //  Referenced by: '<S88>/Constant'

  real_T CompareToConstant_const_j; // Mask Parameter: CompareToConstant_const_j
                                       //  Referenced by: '<S86>/Constant'

  real_T CompareToConstant_const_b; // Mask Parameter: CompareToConstant_const_b
                                       //  Referenced by: '<S89>/Constant'

  real_T CompareToConstant_const_n; // Mask Parameter: CompareToConstant_const_n
                                       //  Referenced by: '<S82>/Constant'

  real_T CompareToConstant_const_i; // Mask Parameter: CompareToConstant_const_i
                                       //  Referenced by: '<S80>/Constant'

  real_T CompareToConstant_const_e; // Mask Parameter: CompareToConstant_const_e
                                       //  Referenced by: '<S83>/Constant'

  real_T CompareToConstant_const_h; // Mask Parameter: CompareToConstant_const_h
                                       //  Referenced by: '<S459>/Constant'

  real_T CompareToConstant_const_k; // Mask Parameter: CompareToConstant_const_k
                                       //  Referenced by: '<S457>/Constant'

  real_T CompareToConstant_const_ee;
                                   // Mask Parameter: CompareToConstant_const_ee
                                      //  Referenced by: '<S460>/Constant'

  real_T CompareToConstant_const_a; // Mask Parameter: CompareToConstant_const_a
                                       //  Referenced by: '<S394>/Constant'

  real_T CompareToConstant_const_a2;
                                   // Mask Parameter: CompareToConstant_const_a2
                                      //  Referenced by: '<S392>/Constant'

  real_T CompareToConstant_const_d; // Mask Parameter: CompareToConstant_const_d
                                       //  Referenced by: '<S395>/Constant'

  real_T CompareToConstant_const_ew;
                                   // Mask Parameter: CompareToConstant_const_ew
                                      //  Referenced by: '<S388>/Constant'

  real_T CompareToConstant_const_l; // Mask Parameter: CompareToConstant_const_l
                                       //  Referenced by: '<S386>/Constant'

  real_T CompareToConstant_const_an;
                                   // Mask Parameter: CompareToConstant_const_an
                                      //  Referenced by: '<S389>/Constant'

  real_T Distanceintogustx_d_m;        // Mask Parameter: Distanceintogustx_d_m
                                          //  Referenced by: '<S57>/Distance into Gust (x) (Limited to gust length d)'

  real_T Distanceintogusty_d_m;        // Mask Parameter: Distanceintogusty_d_m
                                          //  Referenced by: '<S54>/Distance into gust (y)'

  real_T Distanceintogustz_d_m;        // Mask Parameter: Distanceintogustz_d_m
                                          //  Referenced by: '<S54>/Distance into gust (z)'

  real_T DiscreteWindGustModel_d_m[3];
                                    // Mask Parameter: DiscreteWindGustModel_d_m
                                       //  Referenced by: '<S54>/pi//Gust length'

  real_T ThreeaxisInertialMeasurementU_b[3];
                              // Mask Parameter: ThreeaxisInertialMeasurementU_b
                                 //  Referenced by: '<S427>/Measurement bias'

  real_T ThreeaxisInertialMeasurementU_o[3];
                              // Mask Parameter: ThreeaxisInertialMeasurementU_o
                                 //  Referenced by: '<S427>/g-sensitive bias'

  real_T ThreeaxisInertialMeasurementU_f[9];
                              // Mask Parameter: ThreeaxisInertialMeasurementU_f
                                 //  Referenced by: '<S427>/Scale factors & Cross-coupling  errors '

  real_T ThreeaxisInertialMeasurementU_j[3];
                              // Mask Parameter: ThreeaxisInertialMeasurementU_j
                                 //  Referenced by: '<S426>/wl_ins'

  real_T CustomVariableMass6DOFQuaternio;
                              // Mask Parameter: CustomVariableMass6DOFQuaternio
                                 //  Referenced by: '<S21>/High Gain Quaternion Normalization'

  real_T CheckAltitude_max;            // Mask Parameter: CheckAltitude_max
                                          //  Referenced by: '<S444>/max_val'

  real_T CheckLatitude_max;            // Mask Parameter: CheckLatitude_max
                                          //  Referenced by: '<S445>/max_val'

  real_T CheckLongitude_max;           // Mask Parameter: CheckLongitude_max
                                          //  Referenced by: '<S446>/max_val'

  real_T Istimewithinmodellimits_max;
                                  // Mask Parameter: Istimewithinmodellimits_max
                                     //  Referenced by: '<S448>/max_val'

  real_T CheckAltitude_min;            // Mask Parameter: CheckAltitude_min
                                          //  Referenced by: '<S444>/min_val'

  real_T CheckLatitude_min;            // Mask Parameter: CheckLatitude_min
                                          //  Referenced by: '<S445>/min_val'

  real_T CheckLongitude_min;           // Mask Parameter: CheckLongitude_min
                                          //  Referenced by: '<S446>/min_val'

  real_T Istimewithinmodellimits_min;
                                  // Mask Parameter: Istimewithinmodellimits_min
                                     //  Referenced by: '<S448>/min_val'

  real_T FlatEarthtoLLA_psi;           // Mask Parameter: FlatEarthtoLLA_psi
                                          //  Referenced by: '<S69>/ref_rotation'

  real_T FlatEarthtoLLA_psi_h;         // Mask Parameter: FlatEarthtoLLA_psi_h
                                          //  Referenced by: '<S378>/ref_rotation'

  real_T WhiteNoise_pwr[4];            // Mask Parameter: WhiteNoise_pwr
                                          //  Referenced by: '<S161>/Constant'

  real_T WhiteNoise_pwr_m[4];          // Mask Parameter: WhiteNoise_pwr_m
                                          //  Referenced by: '<S122>/Constant'

  real_T BandLimitedWhiteNoise_seed;
                                   // Mask Parameter: BandLimitedWhiteNoise_seed
                                      //  Referenced by: '<S53>/White Noise'

  real_T DirectionCosineMatrixtoQuater_d;
                              // Mask Parameter: DirectionCosineMatrixtoQuater_d
                                 //  Referenced by:
                                 //    '<S370>/Constant'
                                 //    '<S372>/Constant'

  real_T DiscreteWindGustModel_v_m[3];
                                    // Mask Parameter: DiscreteWindGustModel_v_m
                                       //  Referenced by: '<S54>/Gust magnitude//2.0'

  real_T ThreeaxisInertialMeasurementU_a;
                              // Mask Parameter: ThreeaxisInertialMeasurementU_a
                                 //  Referenced by:
                                 //    '<S432>/2*zeta * wn'
                                 //    '<S432>/wn^2'

  real_T ThreeaxisInertialMeasurement_jf;
                              // Mask Parameter: ThreeaxisInertialMeasurement_jf
                                 //  Referenced by:
                                 //    '<S443>/2*zeta * wn'
                                 //    '<S443>/wn^2'

  boolean_T DiscreteWindGustModel_Gx;// Mask Parameter: DiscreteWindGustModel_Gx
                                        //  Referenced by: '<S54>/Constant'

  boolean_T DiscreteWindGustModel_Gy;// Mask Parameter: DiscreteWindGustModel_Gy
                                        //  Referenced by: '<S54>/Constant1'

  boolean_T DiscreteWindGustModel_Gz;// Mask Parameter: DiscreteWindGustModel_Gz
                                        //  Referenced by: '<S54>/Constant2'

  real_T Constant_Value;               // Expression: 1
                                          //  Referenced by: '<S38>/Constant'

  real_T Constant_Value_f;             // Expression: 1
                                          //  Referenced by: '<S39>/Constant'

  real_T x_Y0;                         // Expression: [0]
                                          //  Referenced by: '<S57>/x'

  real_T DistanceintoGustxLimitedtogustl;// Expression: 0
                                            //  Referenced by: '<S57>/Distance into Gust (x) (Limited to gust length d)'

  real_T DistanceintoGustxLimitedtogus_h;// Expression: 0
                                            //  Referenced by: '<S57>/Distance into Gust (x) (Limited to gust length d)'

  real_T Constant_Value_j;             // Expression: 0
                                          //  Referenced by: '<S61>/Constant'

  real_T Switch2_Threshold;            // Expression: 0
                                          //  Referenced by: '<S61>/Switch2'

  real_T Constant1_Value;              // Expression: 0
                                          //  Referenced by: '<S61>/Constant1'

  real_T Constant_Value_o;             // Expression: 0
                                          //  Referenced by: '<S62>/Constant'

  real_T Switch2_Threshold_b;          // Expression: 0
                                          //  Referenced by: '<S62>/Switch2'

  real_T Constant1_Value_f;            // Expression: 0
                                          //  Referenced by: '<S62>/Constant1'

  real_T Constant_Value_d;             // Expression: 0
                                          //  Referenced by: '<S63>/Constant'

  real_T Switch2_Threshold_g;          // Expression: 0
                                          //  Referenced by: '<S63>/Switch2'

  real_T Constant1_Value_k;            // Expression: 0
                                          //  Referenced by: '<S63>/Constant1'

  real_T Constant_Value_jh;            // Expression: 0
                                          //  Referenced by: '<S64>/Constant'

  real_T Switch2_Threshold_l;          // Expression: 0
                                          //  Referenced by: '<S64>/Switch2'

  real_T Constant1_Value_k1;           // Expression: 0
                                          //  Referenced by: '<S64>/Constant1'

  real_T Constant_Value_h;             // Expression: 0
                                          //  Referenced by: '<S65>/Constant'

  real_T Switch2_Threshold_o;          // Expression: 0
                                          //  Referenced by: '<S65>/Switch2'

  real_T Constant1_Value_n;            // Expression: 0
                                          //  Referenced by: '<S65>/Constant1'

  real_T Constant_Value_n;             // Expression: 0
                                          //  Referenced by: '<S66>/Constant'

  real_T Switch2_Threshold_f;          // Expression: 0
                                          //  Referenced by: '<S66>/Switch2'

  real_T Constant1_Value_g;            // Expression: 0
                                          //  Referenced by: '<S66>/Constant1'

  real_T Constant_Value_p;             // Expression: 0
                                          //  Referenced by: '<S67>/Constant'

  real_T Switch2_Threshold_fn;         // Expression: 0
                                          //  Referenced by: '<S67>/Switch2'

  real_T Constant1_Value_e;            // Expression: 0
                                          //  Referenced by: '<S67>/Constant1'

  real_T Constant_Value_ff;            // Expression: 0
                                          //  Referenced by: '<S68>/Constant'

  real_T Switch2_Threshold_b0;         // Expression: 0
                                          //  Referenced by: '<S68>/Switch2'

  real_T Constant1_Value_ev;           // Expression: 0
                                          //  Referenced by: '<S68>/Constant1'

  real_T Bias_Bias;                    // Expression: -90
                                          //  Referenced by: '<S78>/Bias'

  real_T Gain_Gain;                    // Expression: -1
                                          //  Referenced by: '<S78>/Gain'

  real_T Bias1_Bias;                   // Expression: +90
                                          //  Referenced by: '<S78>/Bias1'

  real_T Bias_Bias_c;                  // Expression: 180
                                          //  Referenced by: '<S81>/Bias'

  real_T Bias1_Bias_k;                 // Expression: -180
                                          //  Referenced by: '<S81>/Bias1'

  real_T Bias_Bias_g;                  // Expression: 180
                                          //  Referenced by: '<S79>/Bias'

  real_T Bias1_Bias_kq;                // Expression: -180
                                          //  Referenced by: '<S79>/Bias1'

  real_T Bias_Bias_a;                  // Expression: -90
                                          //  Referenced by: '<S84>/Bias'

  real_T Gain_Gain_a;                  // Expression: -1
                                          //  Referenced by: '<S84>/Gain'

  real_T Bias1_Bias_d;                 // Expression: +90
                                          //  Referenced by: '<S84>/Bias1'

  real_T Constant2_Value;              // Expression: 360
                                          //  Referenced by: '<S87>/Constant2'

  real_T Bias_Bias_p;                  // Expression: 180
                                          //  Referenced by: '<S87>/Bias'

  real_T Bias1_Bias_a;                 // Expression: -180
                                          //  Referenced by: '<S87>/Bias1'

  real_T Constant_Value_p0;            // Expression: 180
                                          //  Referenced by: '<S75>/Constant'

  real_T Constant1_Value_i;            // Expression: 0
                                          //  Referenced by: '<S75>/Constant1'

  real_T Constant2_Value_a;            // Expression: 360
                                          //  Referenced by: '<S85>/Constant2'

  real_T Bias_Bias_i;                  // Expression: 180
                                          //  Referenced by: '<S85>/Bias'

  real_T Bias1_Bias_m;                 // Expression: -180
                                          //  Referenced by: '<S85>/Bias1'

  real_T Gain_Gain_i;                  // Expression: 1
                                          //  Referenced by: '<S133>/Gain'

  real_T Gain_Gain_k;                  // Expression: 1
                                          //  Referenced by: '<S141>/Gain'

  real_T Gain_Gain_p;                  // Expression: 1
                                          //  Referenced by: '<S172>/Gain'

  real_T Gain_Gain_d;                  // Expression: 1
                                          //  Referenced by: '<S180>/Gain'

  real_T Constant_Value_m;             // Expression: 0
                                          //  Referenced by: '<S198>/Constant'

  real_T Constant_Value_od;            // Expression: 0
                                          //  Referenced by: '<S199>/Constant'

  real_T Constant_Value_o3;            // Expression: 0
                                          //  Referenced by: '<S200>/Constant'

  real_T Constant_Value_fl;            // Expression: 0
                                          //  Referenced by: '<S201>/Constant'

  real_T Constant_Value_l;             // Expression: 0
                                          //  Referenced by: '<S202>/Constant'

  real_T Constant_Value_jw;            // Expression: 0
                                          //  Referenced by: '<S203>/Constant'

  real_T Constant_Value_d1;            // Expression: 0
                                          //  Referenced by: '<S204>/Constant'

  real_T Constant_Value_c;             // Expression: 0
                                          //  Referenced by: '<S205>/Constant'

  real_T Constant_Value_e;             // Expression: 1
                                          //  Referenced by: '<S336>/Constant'

  real_T Gain_Gain_b;                  // Expression: 0.5
                                          //  Referenced by: '<S336>/Gain'

  real_T Gain1_Gain;                   // Expression: 2
                                          //  Referenced by: '<S336>/Gain1'

  real_T Constant_Value_dn;            // Expression: 1
                                          //  Referenced by: '<S352>/Constant'

  real_T Gain_Gain_iq;                 // Expression: 0.5
                                          //  Referenced by: '<S340>/Gain'

  real_T Constant1_Value_j;            // Expression: 0.5
                                          //  Referenced by: '<S351>/Constant1'

  real_T Constant2_Value_p[2];         // Expression: [0 1]
                                          //  Referenced by: '<S351>/Constant2'

  real_T Gain1_Gain_p;                 // Expression: 1
                                          //  Referenced by: '<S340>/Gain1'

  real_T Gain3_Gain;                   // Expression: 1
                                          //  Referenced by: '<S340>/Gain3'

  real_T Gain4_Gain;                   // Expression: 1
                                          //  Referenced by: '<S340>/Gain4'

  real_T Constant_Value_g;             // Expression: 1
                                          //  Referenced by: '<S357>/Constant'

  real_T Gain_Gain_f;                  // Expression: 0.5
                                          //  Referenced by: '<S341>/Gain'

  real_T Constant1_Value_jw;           // Expression: 0.5
                                          //  Referenced by: '<S356>/Constant1'

  real_T Constant2_Value_h[2];         // Expression: [0 1]
                                          //  Referenced by: '<S356>/Constant2'

  real_T Gain1_Gain_a;                 // Expression: 1
                                          //  Referenced by: '<S341>/Gain1'

  real_T Gain2_Gain;                   // Expression: 1
                                          //  Referenced by: '<S341>/Gain2'

  real_T Gain3_Gain_e;                 // Expression: 1
                                          //  Referenced by: '<S341>/Gain3'

  real_T Constant_Value_eb;            // Expression: 1
                                          //  Referenced by: '<S347>/Constant'

  real_T Gain_Gain_am;                 // Expression: 0.5
                                          //  Referenced by: '<S339>/Gain'

  real_T Constant1_Value_h;            // Expression: 0.5
                                          //  Referenced by: '<S346>/Constant1'

  real_T Constant2_Value_f[2];         // Expression: [0 1]
                                          //  Referenced by: '<S346>/Constant2'

  real_T Gain1_Gain_n;                 // Expression: 1
                                          //  Referenced by: '<S339>/Gain1'

  real_T Gain2_Gain_i;                 // Expression: 1
                                          //  Referenced by: '<S339>/Gain2'

  real_T Gain3_Gain_d;                 // Expression: 1
                                          //  Referenced by: '<S339>/Gain3'

  real_T Constant1_Value_jy;           // Expression: 0
                                          //  Referenced by: '<S363>/Constant1'

  real_T Constant1_Value_fo;           // Expression: 0
                                          //  Referenced by: '<S362>/Constant1'

  real_T Bias_Bias_k;                  // Expression: -1
                                          //  Referenced by: '<S365>/Bias'

  real_T Bias1_Bias_p[9];              // Expression: -eye(3)
                                          //  Referenced by: '<S364>/Bias1'

  real_T Bias_Bias_h;                  // Expression: -90
                                          //  Referenced by: '<S384>/Bias'

  real_T Gain_Gain_n;                  // Expression: -1
                                          //  Referenced by: '<S384>/Gain'

  real_T Bias1_Bias_e;                 // Expression: +90
                                          //  Referenced by: '<S384>/Bias1'

  real_T Bias_Bias_ap;                 // Expression: 180
                                          //  Referenced by: '<S387>/Bias'

  real_T Bias1_Bias_kg;                // Expression: -180
                                          //  Referenced by: '<S387>/Bias1'

  real_T Bias_Bias_j;                  // Expression: 180
                                          //  Referenced by: '<S385>/Bias'

  real_T Bias1_Bias_d4;                // Expression: -180
                                          //  Referenced by: '<S385>/Bias1'

  real_T Bias_Bias_ah;                 // Expression: -90
                                          //  Referenced by: '<S390>/Bias'

  real_T Gain_Gain_fe;                 // Expression: -1
                                          //  Referenced by: '<S390>/Gain'

  real_T Bias1_Bias_ao;                // Expression: +90
                                          //  Referenced by: '<S390>/Bias1'

  real_T Constant2_Value_j;            // Expression: 360
                                          //  Referenced by: '<S393>/Constant2'

  real_T Bias_Bias_ao;                 // Expression: 180
                                          //  Referenced by: '<S393>/Bias'

  real_T Bias1_Bias_n;                 // Expression: -180
                                          //  Referenced by: '<S393>/Bias1'

  real_T Constant_Value_ma;            // Expression: 180
                                          //  Referenced by: '<S381>/Constant'

  real_T Constant1_Value_m;            // Expression: 0
                                          //  Referenced by: '<S381>/Constant1'

  real_T Constant2_Value_hc;           // Expression: 360
                                          //  Referenced by: '<S391>/Constant2'

  real_T Bias_Bias_ck;                 // Expression: 180
                                          //  Referenced by: '<S391>/Bias'

  real_T Bias1_Bias_mx;                // Expression: -180
                                          //  Referenced by: '<S391>/Bias1'

  real_T Bias_Bias_l;                  // Expression: -90
                                          //  Referenced by: '<S455>/Bias'

  real_T Gain_Gain_kv;                 // Expression: -1
                                          //  Referenced by: '<S455>/Gain'

  real_T Bias1_Bias_ax;                // Expression: +90
                                          //  Referenced by: '<S455>/Bias1'

  real_T Bias_Bias_gv;                 // Expression: 180
                                          //  Referenced by: '<S458>/Bias'

  real_T Bias1_Bias_kz;                // Expression: -180
                                          //  Referenced by: '<S458>/Bias1'

  real_T Bias_Bias_m;                  // Expression: 180
                                          //  Referenced by: '<S456>/Bias'

  real_T Bias1_Bias_eu;                // Expression: -180
                                          //  Referenced by: '<S456>/Bias1'

  real_T pp13_Y0[13];                  // Expression: ones(1,maxdef+1)
                                          //  Referenced by: '<S477>/pp[13]'

  real_T Constant_Value_cs;            // Expression: 1
                                          //  Referenced by: '<S477>/Constant'

  real_T pp13_Y0_h[13];                // Expression: ones(1,maxdef+1)
                                          //  Referenced by: '<S478>/pp[13]'

  real_T k1313_Value[169];             // Expression: k
                                          //  Referenced by: '<S478>/k[13][13]'

  real_T bpp_Y0;                       // Expression: 0
                                          //  Referenced by: '<S473>/bpp'

  real_T Constant_Value_i;             // Expression: fm(2)
                                          //  Referenced by: '<S473>/Constant'

  real_T Constant1_Value_c;            // Expression: 1
                                          //  Referenced by: '<S473>/Constant1'

  real_T UnitDelay1_InitialCondition[13];// Expression: ones(1,maxdef+1)
                                            //  Referenced by: '<S473>/Unit Delay1'

  real_T Constant_Value_a;             // Expression: 1
                                          //  Referenced by: '<S481>/Constant'

  real_T Gain1_Gain_m;                 // Expression: 1
                                          //  Referenced by: '<S481>/Gain1'

  real_T Gain2_Gain_ia;                // Expression: 1
                                          //  Referenced by: '<S481>/Gain2'

  real_T Constant_Value_iw;            // Expression: 1
                                          //  Referenced by: '<S483>/Constant'

  real_T Constant_Value_m4;            // Expression: 1
                                          //  Referenced by: '<S484>/Constant'

  real_T Constant1_Value_ha;           // Expression: 0
                                          //  Referenced by: '<S487>/Constant1'

  real_T Constant_Value_af;            // Expression: 0
                                          //  Referenced by: '<S487>/Constant'

  real_T k1313_Value_g[169];           // Expression: k
                                          //  Referenced by: '<S487>/k[13][13]'

  real_T dp1313_Y0[169];               // Expression: zeros(maxdef+1,maxdef+1)
                                          //  Referenced by: '<S471>/dp[13][13]'

  real_T snorm169_Y0[169];             // Expression: snorm
                                          //  Referenced by: '<S471>/snorm[169]'

  real_T UnitDelay_InitialCondition[169];// Expression: zeros(maxdef+1,maxdef+1)
                                            //  Referenced by: '<S471>/Unit Delay'

  real_T UnitDelay1_InitialCondition_i[169];// Expression: snorm
                                               //  Referenced by: '<S471>/Unit Delay1'

  real_T Merge1_InitialOutput;         // Expression: 0
                                          //  Referenced by: '<S471>/Merge1'

  real_T Merge_InitialOutput;          // Expression: 0
                                          //  Referenced by: '<S471>/Merge'

  real_T Gain_Gain_e;                  // Expression: 1
                                          //  Referenced by: '<S500>/Gain'

  real_T zerosmaxdef1maxdef1_Value[169];// Expression: zeros(maxdef+1,maxdef+1)
                                           //  Referenced by: '<S499>/zeros(maxdef+1,maxdef+1)'

  real_T tc1313_Y0[169];               // Expression: zeros(maxdef+1,maxdef+1)
                                          //  Referenced by: '<S472>/tc[13][13]'

  real_T UnitDelay_InitialCondition_f[169];// Expression: zeros(maxdef+1,maxdef+1)
                                              //  Referenced by: '<S472>/Unit Delay'

  real_T cmaxdefmaxdef_Value[169];     // Expression: c
                                          //  Referenced by: '<S472>/c[maxdef][maxdef]'

  real_T cdmaxdefmaxdef_Value[169];    // Expression: cd
                                          //  Referenced by: '<S472>/cd[maxdef][maxdef]'

  real_T UnitDelay_InitialCondition_k[169];// Expression: zeros(maxdef+1,maxdef+1)
                                              //  Referenced by: '<S499>/Unit Delay'

  real_T bt_Y0;                        // Expression: 0
                                          //  Referenced by: '<S469>/bt'

  real_T bp_Y0;                        // Expression: 0
                                          //  Referenced by: '<S469>/bp'

  real_T br_Y0;                        // Expression: 0
                                          //  Referenced by: '<S469>/br'

  real_T bpp_Y0_k;                     // Expression: 0
                                          //  Referenced by: '<S469>/bpp'

  real_T Constant1_Value_o;            // Expression: 1
                                          //  Referenced by: '<S475>/Constant1'

  real_T Merge_InitialOutput_j;        // Expression: 0
                                          //  Referenced by: '<S475>/Merge'

  real_T fm_Value[13];                 // Expression: fm
                                          //  Referenced by: '<S470>/fm'

  real_T Merge1_InitialOutput_h;       // Expression: 0
                                          //  Referenced by: '<S475>/Merge1'

  real_T fn_Value[13];                 // Expression: fn
                                          //  Referenced by: '<S470>/fn'

  real_T Constant1_Value_ng;           // Expression: 0
                                          //  Referenced by: '<S476>/Constant1'

  real_T UnitDelay1_InitialCondition_e;// Expression: 0
                                          //  Referenced by: '<S470>/Unit Delay1'

  real_T UnitDelay3_InitialCondition;  // Expression: 0
                                          //  Referenced by: '<S470>/Unit Delay3'

  real_T UnitDelay2_InitialCondition;  // Expression: 0
                                          //  Referenced by: '<S470>/Unit Delay2'

  real_T UnitDelay4_InitialCondition;  // Expression: 0
                                          //  Referenced by: '<S470>/Unit Delay4'

  real_T btbpbrbpp_Y0[4];              // Expression: [0 0 0 0]
                                          //  Referenced by: '<S461>/bt,bp,br,bpp'

  real_T UnitDelay_InitialCondition_g; // Expression: 0
                                          //  Referenced by: '<S461>/Unit Delay'

  real_T UnitDelay2_InitialCondition_d[4];// Expression: [0 0 0 0]
                                             //  Referenced by: '<S461>/Unit Delay2'

  real_T r_Y0;                         // Expression: 6378.137
                                          //  Referenced by: '<S462>/r'

  real_T ct_Y0;                        // Expression: 1
                                          //  Referenced by: '<S462>/ct'

  real_T st_Y0;                        // Expression: 0
                                          //  Referenced by: '<S462>/st'

  real_T sa_Y0;                        // Expression: 0
                                          //  Referenced by: '<S462>/sa'

  real_T ca_Y0;                        // Expression: 0
                                          //  Referenced by: '<S462>/ca'

  real_T b_Value;                      // Expression: 6356.7523142
                                          //  Referenced by: '<S462>/b'

  real_T a_Value;                      // Expression: 6378.137
                                          //  Referenced by: '<S462>/a'

  real_T Gain_Gain_h;                  // Expression: 2
                                          //  Referenced by: '<S507>/Gain'

  real_T Constant_Value_pt;            // Expression: 1
                                          //  Referenced by: '<S509>/Constant'

  real_T sp11_Y0[11];                  // Expression: (1:(maxdef-1))
                                          //  Referenced by: '<S510>/sp[11]'

  real_T cp11_Y0[11];                  // Expression: (1:(maxdef-1))
                                          //  Referenced by: '<S510>/cp[11]'

  real_T ForIterator_IterationLimit;   // Expression: maxdef-1
                                          //  Referenced by: '<S510>/For Iterator'

  real_T Constant_Value_p3[11];        // Expression: [1:maxdef-1]
                                          //  Referenced by: '<S510>/Constant'

  real_T UnitDelay1_InitialCondition_c;// Expression: 0
                                          //  Referenced by: '<S510>/Unit Delay1'

  real_T cpm1spm1_Threshold;           // Expression: 1
                                          //  Referenced by: '<S510>/cp[m-1] sp[m-1]'

  real_T Constant1_Value_mb[11];       // Expression: [1:maxdef-1]
                                          //  Referenced by: '<S510>/Constant1'

  real_T sp13_Y0[13];                  // Expression: [0 0 (1:(maxdef-1))]
                                          //  Referenced by: '<S463>/sp[13]'

  real_T cp13_Y0[13];                  // Expression: [1 1 (1:(maxdef-1))]
                                          //  Referenced by: '<S463>/cp[13]'

  real_T Gain_Gain_o;                  // Expression: 1
                                          //  Referenced by: '<S463>/Gain'

  real_T Gain1_Gain_pk;                // Expression: 1
                                          //  Referenced by: '<S463>/Gain1'

  real_T cp1_Value;                    // Expression: 1
                                          //  Referenced by: '<S463>/cp[1]'

  real_T sp1_Value;                    // Expression: 0
                                          //  Referenced by: '<S463>/sp[1]'

  real_T Gain_clock_Gain;              // Expression: 1E6
                                          //  Referenced by: '<S8>/Gain_clock'

  real_T IntegratorSecondOrderLimited_IC;// Expression: 0
                                            //  Referenced by: '<S432>/Integrator, Second-Order Limited'

  real_T IntegratorSecondOrderLimited__e;// Expression: 0
                                            //  Referenced by: '<S432>/Integrator, Second-Order Limited'

  real_T Constant_Value_a2;            // Expression: dtype_a
                                          //  Referenced by: '<S428>/Constant'

  real_T u2_Gain;                      // Expression: 0.5
                                          //  Referenced by: '<S20>/1//2'

  real_T Gain_Gain_kj;                 // Expression: 2
                                          //  Referenced by: '<S25>/Gain'

  real_T Gain_Gain_nt;                 // Expression: 2
                                          //  Referenced by: '<S28>/Gain'

  real_T Gain_Gain_b3;                 // Expression: 2
                                          //  Referenced by: '<S23>/Gain'

  real_T Gain_Gain_ky;                 // Expression: 2
                                          //  Referenced by: '<S29>/Gain'

  real_T Gain_Gain_oe;                 // Expression: 2
                                          //  Referenced by: '<S24>/Gain'

  real_T Gain_Gain_ev;                 // Expression: 2
                                          //  Referenced by: '<S27>/Gain'

  real_T Constant2_Value_pu;           // Expression: 1
                                          //  Referenced by: '<S90>/Constant2'

  real_T Constant1_Value_ex;           // Expression: R
                                          //  Referenced by: '<S90>/Constant1'

  real_T Constant_Value_ja;            // Expression: 1
                                          //  Referenced by: '<S93>/Constant'

  real_T Constant_Value_ov;            // Expression: 1
                                          //  Referenced by: '<S95>/Constant'

  real_T Constant_Value_eo;            // Expression: F
                                          //  Referenced by: '<S94>/Constant'

  real_T f_Value;                      // Expression: 1
                                          //  Referenced by: '<S94>/f'

  real_T Constant_Value_k;             // Expression: 1
                                          //  Referenced by: '<S90>/Constant'

  real_T Constant3_Value;              // Expression: 1
                                          //  Referenced by: '<S90>/Constant3'

  real_T Constant2_Value_e;            // Expression: 360
                                          //  Referenced by: '<S81>/Constant2'

  real_T Constant_Value_nj;            // Expression: 180
                                          //  Referenced by: '<S74>/Constant'

  real_T Constant1_Value_kn;           // Expression: 0
                                          //  Referenced by: '<S74>/Constant1'

  real_T Constant2_Value_a4;           // Expression: 360
                                          //  Referenced by: '<S79>/Constant2'

  real_T Saturation_1_UpperSat;        // Expression: 100000
                                          //  Referenced by: '<S3>/Saturation_1'

  real_T Saturation_1_LowerSat;        // Expression: 0
                                          //  Referenced by: '<S3>/Saturation_1'

  real_T JulianDate_Value;             // Expression: juliandate(year,month,day)
                                          //  Referenced by: '<S72>/Julian Date'

  real_T Gain_Gain_c;                  // Expression: -1
                                          //  Referenced by: '<S194>/Gain'

  real_T Gain1_Gain_j;                 // Expression: -1
                                          //  Referenced by: '<S194>/Gain1'

  real_T armState_Value;               // Expression: 1
                                          //  Referenced by: '<Root>/armState'

  real_T WhiteNoise_Mean;              // Expression: 0
                                          //  Referenced by: '<S53>/White Noise'

  real_T WhiteNoise_StdDev;            // Computed Parameter: WhiteNoise_StdDev
                                          //  Referenced by: '<S53>/White Noise'

  real_T u_Value;                      // Expression: 1.0
                                          //  Referenced by: '<S54>/2'

  real_T Gain1_Gain_k;                 // Expression: 0
                                          //  Referenced by: '<S50>/Gain1'

  real_T Constant3_Value_c[3];         // Expression: [1 -1 -1]
                                          //  Referenced by: '<S198>/Constant3'

  real_T Gain_1_Gain;                  // Expression: -1
                                          //  Referenced by: '<S73>/Gain_-1'

  real_T Saturation_2_UpperSat;        // Expression: 10000
                                          //  Referenced by: '<S73>/Saturation_2'

  real_T Saturation_2_LowerSat;        // Expression: 0
                                          //  Referenced by: '<S73>/Saturation_2'

  real_T Constant_V_Value;             // Expression: 5
                                          //  Referenced by: '<S73>/Constant_V'

  real_T LimitFunction10ftto1000ft_Upper;// Expression: max_height_low
                                            //  Referenced by: '<S186>/Limit Function 10ft to 1000ft'

  real_T LimitFunction10ftto1000ft_Lower;// Expression: 10
                                            //  Referenced by: '<S186>/Limit Function 10ft to 1000ft'

  real_T LimitHeighth1000ft_UpperSat;  // Expression: max_height_low
                                          //  Referenced by: '<S169>/Limit Height h<1000ft'

  real_T LimitHeighth1000ft_LowerSat;  // Expression: 0
                                          //  Referenced by: '<S169>/Limit Height h<1000ft'

  real_T sigma_wg_Gain;                // Expression: 0.1
                                          //  Referenced by: '<S169>/sigma_wg '

  real_T PreLookUpIndexSearchaltitude_Br[12];// Expression: h_vec
                                                //  Referenced by: '<S168>/PreLook-Up Index Search  (altitude)'

  real_T PreLookUpIndexSearchprobofexcee[7];// Expression: [1:7]
                                               //  Referenced by: '<S168>/PreLook-Up Index Search  (prob of exceed)'

  real_T MediumHighAltitudeIntensity_Tab[84];// Expression: sigma_vec'
                                                //  Referenced by: '<S168>/Medium//High Altitude Intensity'

  real_T WhiteNoise_Mean_k;            // Expression: 0
                                          //  Referenced by: '<S161>/White Noise'

  real_T WhiteNoise_StdDev_e;         // Computed Parameter: WhiteNoise_StdDev_e
                                         //  Referenced by: '<S161>/White Noise'

  real_T Lv_Gain;                      // Expression: 1
                                          //  Referenced by: '<S158>/Lv'

  real_T Lw_Gain;                      // Expression: 1
                                          //  Referenced by: '<S158>/Lw'

  real_T Constant_DCM_Value[9];        // Expression: eye(3)
                                          //  Referenced by: '<S73>/Constant_DCM'

  real_T LimitFunction10ftto1000ft_Upp_m;// Expression: max_height_low
                                            //  Referenced by: '<S147>/Limit Function 10ft to 1000ft'

  real_T LimitFunction10ftto1000ft_Low_m;// Expression: 10
                                            //  Referenced by: '<S147>/Limit Function 10ft to 1000ft'

  real_T LimitHeighth1000ft_UpperSat_b;// Expression: max_height_low
                                          //  Referenced by: '<S130>/Limit Height h<1000ft'

  real_T LimitHeighth1000ft_LowerSat_b;// Expression: 0
                                          //  Referenced by: '<S130>/Limit Height h<1000ft'

  real_T sigma_wg_Gain_n;              // Expression: 0.1
                                          //  Referenced by: '<S130>/sigma_wg '

  real_T PreLookUpIndexSearchaltitude__f[12];// Expression: h_vec
                                                //  Referenced by: '<S129>/PreLook-Up Index Search  (altitude)'

  real_T PreLookUpIndexSearchprobofexc_m[7];// Expression: [1:7]
                                               //  Referenced by: '<S129>/PreLook-Up Index Search  (prob of exceed)'

  real_T MediumHighAltitudeIntensity_T_b[84];// Expression: sigma_vec'
                                                //  Referenced by: '<S129>/Medium//High Altitude Intensity'

  real_T WhiteNoise_Mean_l;            // Expression: 0
                                          //  Referenced by: '<S122>/White Noise'

  real_T WhiteNoise_StdDev_k;         // Computed Parameter: WhiteNoise_StdDev_k
                                         //  Referenced by: '<S122>/White Noise'

  real_T Lv_Gain_e;                    // Expression: 1
                                          //  Referenced by: '<S119>/Lv'

  real_T Lw_Gain_a;                    // Expression: 1
                                          //  Referenced by: '<S119>/Lw'

  real_T uftinf_UpperSat;              // Expression: inf
                                          //  Referenced by: '<S110>/3ft-->inf'

  real_T uftinf_LowerSat;              // Expression: 3
                                          //  Referenced by: '<S110>/3ft-->inf'

  real_T hz0_Gain;                     // Expression: 1/z0
                                          //  Referenced by: '<S110>/h//z0'

  real_T ref_heightz0_Value;           // Expression: 20/z0
                                          //  Referenced by: '<S110>/ref_height//z0'

  real_T Wdeg1_Value;                  // Expression: 0
                                          //  Referenced by: '<S110>/Wdeg1'

  real_T Constant2_Value_g[3];         // Expression: [1 -1 -1]
                                          //  Referenced by: '<S198>/Constant2'

  real_T Constant1_Value_hj[6];        // Expression: [0;0;0;0;0;0]
                                          //  Referenced by: '<S198>/Constant1'

  real_T Constant3_Value_p[3];         // Expression: [1 -1 -1]
                                          //  Referenced by: '<S199>/Constant3'

  real_T Constant2_Value_k[3];         // Expression: [1 -1 -1]
                                          //  Referenced by: '<S199>/Constant2'

  real_T Constant1_Value_ku[6];        // Expression: [0;0;0;0;0;0]
                                          //  Referenced by: '<S199>/Constant1'

  real_T Constant3_Value_i[3];         // Expression: [1 -1 -1]
                                          //  Referenced by: '<S200>/Constant3'

  real_T Constant2_Value_p0[3];        // Expression: [1 -1 -1]
                                          //  Referenced by: '<S200>/Constant2'

  real_T Constant1_Value_l[6];         // Expression: [0;0;0;0;0;0]
                                          //  Referenced by: '<S200>/Constant1'

  real_T Constant3_Value_e[3];         // Expression: [1 -1 -1]
                                          //  Referenced by: '<S201>/Constant3'

  real_T Constant2_Value_p5[3];        // Expression: [1 -1 -1]
                                          //  Referenced by: '<S201>/Constant2'

  real_T Constant1_Value_ns[6];        // Expression: [0;0;0;0;0;0]
                                          //  Referenced by: '<S201>/Constant1'

  real_T Constant3_Value_cy[3];        // Expression: [1 -1 -1]
                                          //  Referenced by: '<S202>/Constant3'

  real_T Constant2_Value_az[3];        // Expression: [1 -1 -1]
                                          //  Referenced by: '<S202>/Constant2'

  real_T Constant1_Value_my[6];        // Expression: [0;0;0;0;0;0]
                                          //  Referenced by: '<S202>/Constant1'

  real_T Constant3_Value_p2[3];        // Expression: [1 -1 -1]
                                          //  Referenced by: '<S203>/Constant3'

  real_T Constant2_Value_hcw[3];       // Expression: [1 -1 -1]
                                          //  Referenced by: '<S203>/Constant2'

  real_T Constant1_Value_hx[6];        // Expression: [0;0;0;0;0;0]
                                          //  Referenced by: '<S203>/Constant1'

  real_T Constant3_Value_k[3];         // Expression: [1 -1 -1]
                                          //  Referenced by: '<S204>/Constant3'

  real_T Constant2_Value_ad[3];        // Expression: [1 -1 -1]
                                          //  Referenced by: '<S204>/Constant2'

  real_T Constant1_Value_a[6];         // Expression: [0;0;0;0;0;0]
                                          //  Referenced by: '<S204>/Constant1'

  real_T Constant3_Value_f[3];         // Expression: [1 -1 -1]
                                          //  Referenced by: '<S205>/Constant3'

  real_T Constant2_Value_l[3];         // Expression: [1 -1 -1]
                                          //  Referenced by: '<S205>/Constant2'

  real_T Constant1_Value_oc[6];        // Expression: [0;0;0;0;0;0]
                                          //  Referenced by: '<S205>/Constant1'

  real_T ZeroOrderHold1_Gain;          // Expression: 1
                                          //  Referenced by: '<S426>/Zero-Order Hold1'

  real_T ZeroOrderHold2_Gain;          // Expression: 1
                                          //  Referenced by: '<S426>/Zero-Order Hold2'

  real_T ZeroOrderHold_Gain;           // Expression: 1
                                          //  Referenced by: '<S426>/Zero-Order Hold'

  real_T centerofgravity_Value[3];     // Expression: [0 0 0]
                                          //  Referenced by: '<S406>/center of gravity'

  real_T ZeroOrderHold4_Gain;          // Expression: 1
                                          //  Referenced by: '<S426>/Zero-Order Hold4'

  real_T Gain_Gain_ka[3];              // Expression: [1 -1 1]
                                          //  Referenced by: '<S426>/Gain'

  real_T Constant_Value_ed[2];         // Expression: [0,0]
                                          //  Referenced by: '<S4>/Constant'

  real_T Constant2_Value_m[9];         // Expression: zeros(3)
                                          //  Referenced by: '<S12>/Constant2'

  real_T ZeroOrderHold3_Gain;          // Expression: 1
                                          //  Referenced by: '<S426>/Zero-Order Hold3'

  real_T Switch_Threshold;             // Expression: 0.5
                                          //  Referenced by: '<S428>/Switch'

  real_T Saturation_UpperSat[3];       // Expression: a_sath
                                          //  Referenced by: '<S426>/Saturation'

  real_T Saturation_LowerSat[3];       // Expression: a_satl
                                          //  Referenced by: '<S426>/Saturation'

  real_T UniformRandomNumber5_Minimum[3];// Expression: -[0.1,0.1,0.2]
                                            //  Referenced by: '<S406>/Uniform Random Number5'

  real_T UniformRandomNumber5_Maximum[3];// Expression: [0.1,0.1,0.2]
                                            //  Referenced by: '<S406>/Uniform Random Number5'

  real_T UniformRandomNumber5_Seed[3]; // Expression: [12233,645554,678766]
                                          //  Referenced by: '<S406>/Uniform Random Number5'

  real_T Gain10_Gain;                  // Expression: 5
                                          //  Referenced by: '<S406>/Gain10'

  real_T IntegratorSecondOrderLimited__f;// Expression: 0
                                            //  Referenced by: '<S443>/Integrator, Second-Order Limited'

  real_T IntegratorSecondOrderLimited__a;// Expression: 0
                                            //  Referenced by: '<S443>/Integrator, Second-Order Limited'

  real_T Constant_Value_au;            // Expression: dtype_g
                                          //  Referenced by: '<S441>/Constant'

  real_T ZeroOrderHold_Gain_m;         // Expression: 1
                                          //  Referenced by: '<S427>/Zero-Order Hold'

  real_T ZeroOrderHold1_Gain_l;        // Expression: 1
                                          //  Referenced by: '<S427>/Zero-Order Hold1'

  real_T Switch_Threshold_j;           // Expression: 0.5
                                          //  Referenced by: '<S441>/Switch'

  real_T Saturation_UpperSat_n[3];     // Expression: g_sath
                                          //  Referenced by: '<S427>/Saturation'

  real_T Saturation_LowerSat_f[3];     // Expression: g_satl
                                          //  Referenced by: '<S427>/Saturation'

  real_T UniformRandomNumber1_Minimum[3];// Expression: -[0.01,0.01,0.01]
                                            //  Referenced by: '<S406>/Uniform Random Number1'

  real_T UniformRandomNumber1_Maximum[3];// Expression: [0.01,0.01,0.01]
                                            //  Referenced by: '<S406>/Uniform Random Number1'

  real_T UniformRandomNumber1_Seed[3]; // Expression: [3243,44556,2334343]
                                          //  Referenced by: '<S406>/Uniform Random Number1'

  real_T Gain6_Gain;                   // Expression: 5
                                          //  Referenced by: '<S406>/Gain6'

  real_T epoch_Value;                  // Expression: epoch
                                          //  Referenced by: '<S453>/epoch'

  real_T DecimalYear_Value;            // Expression: dyear
                                          //  Referenced by: '<S419>/Decimal Year'

  real_T otime_InitialCondition;       // Expression: -1000
                                          //  Referenced by: '<S467>/otime'

  real_T Constant_Value_fly;           // Expression: 180
                                          //  Referenced by: '<S449>/Constant'

  real_T Saturation2_UpperSat;         // Expression: 100000
                                          //  Referenced by: '<S406>/Saturation2'

  real_T Saturation2_LowerSat;         // Expression: 0
                                          //  Referenced by: '<S406>/Saturation2'

  real_T Constant2_Value_b;            // Expression: 360
                                          //  Referenced by: '<S458>/Constant2'

  real_T Constant1_Value_nz;           // Expression: 0
                                          //  Referenced by: '<S449>/Constant1'

  real_T Constant2_Value_d;            // Expression: 360
                                          //  Referenced by: '<S456>/Constant2'

  real_T olon_InitialCondition;        // Expression: -1000
                                          //  Referenced by: '<S466>/olon'

  real_T olat_InitialCondition;        // Expression: -1000
                                          //  Referenced by: '<S465>/olat'

  real_T Gain_Gain_o3;                 // Expression: 0.001
                                          //  Referenced by: '<S419>/Gain'

  real_T oalt_InitialCondition;        // Expression: -1000
                                          //  Referenced by: '<S465>/oalt'

  real_T re_Value;                     // Expression: 6371.2
                                          //  Referenced by: '<S453>/re'

  real_T Gain_Mag_Gain;                // Expression: 1
                                          //  Referenced by: '<S406>/Gain_Mag'

  real_T nT2Gauss_Gain;                // Expression: 1E-5
                                          //  Referenced by: '<S406>/nT2Gauss'

  real_T UniformRandomNumber7_Minimum[3];// Expression: -[0.01,0.01,0.01]
                                            //  Referenced by: '<S406>/Uniform Random Number7'

  real_T UniformRandomNumber7_Maximum[3];// Expression: [0.01,0.01,0.01]
                                            //  Referenced by: '<S406>/Uniform Random Number7'

  real_T UniformRandomNumber7_Seed[3]; // Expression: [45465,454534,1234232]
                                          //  Referenced by: '<S406>/Uniform Random Number7'

  real_T Gain11_Gain;                  // Expression: 2
                                          //  Referenced by: '<S406>/Gain11'

  real_T SeaLevelTemperature_Value;    // Expression: T0
                                          //  Referenced by: '<S416>/Sea Level  Temperature'

  real_T SeaLevelTemperature_Value_j;  // Expression: T0
                                          //  Referenced by: '<S70>/Sea Level  Temperature'

  real_T Limitaltitudetotroposhere_Upper;// Expression: h_trop
                                            //  Referenced by: '<S70>/Limit  altitude  to troposhere'

  real_T Limitaltitudetotroposhere_Lower;// Expression: h0
                                            //  Referenced by: '<S70>/Limit  altitude  to troposhere'

  real_T LapseRate_Gain;               // Expression: L
                                          //  Referenced by: '<S70>/Lapse Rate'

  real_T uT0_Gain;                     // Expression: 1/T0
                                          //  Referenced by: '<S70>/1//T0'

  real_T Constant_Value_g3;            // Expression: g/(L*R)
                                          //  Referenced by: '<S70>/Constant'

  real_T rho0_Gain;                    // Expression: rho0
                                          //  Referenced by: '<S70>/rho0'

  real_T AltitudeofTroposphere_Value;  // Expression: h_trop
                                          //  Referenced by: '<S70>/Altitude of Troposphere'

  real_T LimitaltitudetoStratosphere_Upp;// Expression: 0
                                            //  Referenced by: '<S70>/Limit  altitude  to Stratosphere'

  real_T LimitaltitudetoStratosphere_Low;// Expression: h_trop-h_strat
                                            //  Referenced by: '<S70>/Limit  altitude  to Stratosphere'

  real_T gR_Gain;                      // Expression: g/R
                                          //  Referenced by: '<S70>/g//R'

  real_T u2rhoV2_Gain;                 // Expression: 1/2
                                          //  Referenced by: '<S408>/1//2rhoV^2'

  real_T UniformRandomNumber_Minimum;  // Expression: -2
                                          //  Referenced by: '<S406>/Uniform Random Number'

  real_T UniformRandomNumber_Maximum;  // Expression: 2
                                          //  Referenced by: '<S406>/Uniform Random Number'

  real_T UniformRandomNumber_Seed;     // Expression: 15634
                                          //  Referenced by: '<S406>/Uniform Random Number'

  real_T Gain5_Gain;                   // Expression: 0.2
                                          //  Referenced by: '<S406>/Gain5'

  real_T Constant2_Value_le;           // Expression: 0.3
                                          //  Referenced by: '<S414>/Constant2'

  real_T Saturation1_UpperSat;         // Expression: 100000
                                          //  Referenced by: '<S406>/Saturation1'

  real_T Saturation1_LowerSat;         // Expression: 0
                                          //  Referenced by: '<S406>/Saturation1'

  real_T Limitaltitudetotroposhere_Upp_n;// Expression: h_trop
                                            //  Referenced by: '<S416>/Limit  altitude  to troposhere'

  real_T Limitaltitudetotroposhere_Low_o;// Expression: h0
                                            //  Referenced by: '<S416>/Limit  altitude  to troposhere'

  real_T LapseRate_Gain_b;             // Expression: L
                                          //  Referenced by: '<S416>/Lapse Rate'

  real_T uT0_Gain_j;                   // Expression: 1/T0
                                          //  Referenced by: '<S416>/1//T0'

  real_T Constant_Value_d3;            // Expression: g/(L*R)
                                          //  Referenced by: '<S416>/Constant'

  real_T P0_Gain;                      // Expression: P0
                                          //  Referenced by: '<S416>/P0'

  real_T AltitudeofTroposphere_Value_p;// Expression: h_trop
                                          //  Referenced by: '<S416>/Altitude of Troposphere'

  real_T LimitaltitudetoStratosphere_U_n;// Expression: 0
                                            //  Referenced by: '<S416>/Limit  altitude  to Stratosphere'

  real_T LimitaltitudetoStratosphere_L_n;// Expression: h_trop-h_strat
                                            //  Referenced by: '<S416>/Limit  altitude  to Stratosphere'

  real_T gR_Gain_a;                    // Expression: g/R
                                          //  Referenced by: '<S416>/g//R'

  real_T Gain_Gain_d4;                 // Expression: 0.01
                                          //  Referenced by: '<S406>/Gain'

  real_T UniformRandomNumber4_Minimum; // Expression: -1
                                          //  Referenced by: '<S406>/Uniform Random Number4'

  real_T UniformRandomNumber4_Maximum; // Expression: 1
                                          //  Referenced by: '<S406>/Uniform Random Number4'

  real_T UniformRandomNumber4_Seed;    // Expression: 25634
                                          //  Referenced by: '<S406>/Uniform Random Number4'

  real_T Gain9_Gain;                   // Expression: 0.0005
                                          //  Referenced by: '<S406>/Gain9'

  real_T Constant_Value_nz;            // Expression: 0.5
                                          //  Referenced by: '<S415>/Constant'

  real_T Gain2_Gain_j;                 // Expression: 0.7
                                          //  Referenced by: '<S415>/Gain2'

  real_T Constant2_Value_ed;           // Expression: 0.3
                                          //  Referenced by: '<S415>/Constant2'

  real_T Gain1_Gain_e;                 // Expression: 0.01
                                          //  Referenced by: '<S406>/Gain1'

  real_T TemperatureConstant_Value;    // Expression: 25
                                          //  Referenced by: '<S3>/TemperatureConstant'

  real_T Constant_Value_da;            // Expression: 8191
                                          //  Referenced by: '<S402>/Constant'

  real_T UniformRandomNumber5_Minimum_l[3];// Expression: [-1,-1,-2]
                                              //  Referenced by: '<S373>/Uniform Random Number5'

  real_T UniformRandomNumber5_Maximum_a[3];// Expression: [1,1,2]
                                              //  Referenced by: '<S373>/Uniform Random Number5'

  real_T UniformRandomNumber5_Seed_a[3];// Expression: [1452,787,69]
                                           //  Referenced by: '<S373>/Uniform Random Number5'

  real_T BiasGain2_Gain;               // Expression: 0.5
                                          //  Referenced by: '<S373>/BiasGain2'

  real_T Constant2_Value_e4;           // Expression: 1
                                          //  Referenced by: '<S396>/Constant2'

  real_T Constant1_Value_jyn;          // Expression: R
                                          //  Referenced by: '<S396>/Constant1'

  real_T Constant_Value_jam;           // Expression: 1
                                          //  Referenced by: '<S399>/Constant'

  real_T Constant_Value_jd;            // Expression: 1
                                          //  Referenced by: '<S401>/Constant'

  real_T Constant_Value_odh;           // Expression: F
                                          //  Referenced by: '<S400>/Constant'

  real_T f_Value_n;                    // Expression: 1
                                          //  Referenced by: '<S400>/f'

  real_T Constant_Value_d1y;           // Expression: 1
                                          //  Referenced by: '<S396>/Constant'

  real_T Constant3_Value_l;            // Expression: 1
                                          //  Referenced by: '<S396>/Constant3'

  real_T Constant2_Value_aj;           // Expression: 360
                                          //  Referenced by: '<S387>/Constant2'

  real_T latScale_Gain;                // Expression: 1E7
                                          //  Referenced by: '<S331>/latScale'

  real_T Constant_Value_ph;            // Expression: 180
                                          //  Referenced by: '<S380>/Constant'

  real_T Constant1_Value_d;            // Expression: 0
                                          //  Referenced by: '<S380>/Constant1'

  real_T Constant2_Value_jc;           // Expression: 360
                                          //  Referenced by: '<S385>/Constant2'

  real_T lonScale_Gain;                // Expression: 1E7
                                          //  Referenced by: '<S331>/lonScale'

  real_T Saturation_UpperSat_e;        // Expression: 100000
                                          //  Referenced by: '<S373>/Saturation'

  real_T Saturation_LowerSat_a;        // Expression: 0
                                          //  Referenced by: '<S373>/Saturation'

  real_T altScale_Gain;                // Expression: 1E3
                                          //  Referenced by: '<S331>/altScale'

  real_T Gain6_Gain_o;                 // Expression: 100
                                          //  Referenced by: '<S331>/Gain6'

  real_T Gain8_Gain;                   // Expression: 100
                                          //  Referenced by: '<S331>/Gain8'

  real_T TransferFcn4_A;               // Computed Parameter: TransferFcn4_A
                                          //  Referenced by: '<S375>/Transfer Fcn4'

  real_T TransferFcn4_C;               // Computed Parameter: TransferFcn4_C
                                          //  Referenced by: '<S375>/Transfer Fcn4'

  real_T TransferFcn1_A;               // Computed Parameter: TransferFcn1_A
                                          //  Referenced by: '<S375>/Transfer Fcn1'

  real_T TransferFcn1_C;               // Computed Parameter: TransferFcn1_C
                                          //  Referenced by: '<S375>/Transfer Fcn1'

  real_T TransferFcn2_A;               // Computed Parameter: TransferFcn2_A
                                          //  Referenced by: '<S375>/Transfer Fcn2'

  real_T TransferFcn2_C;               // Computed Parameter: TransferFcn2_C
                                          //  Referenced by: '<S375>/Transfer Fcn2'

  real_T VelScale_Gain;                // Expression: 1E2
                                          //  Referenced by: '<S331>/VelScale'

  real_T VeScale_Gain;                 // Expression: 1E2
                                          //  Referenced by: '<S331>/VeScale'

  real_T AngleScale_Gain;              // Expression: 1E2
                                          //  Referenced by: '<S331>/AngleScale'

  real_T CopterID_Value;               // Expression: 1
                                          //  Referenced by: '<S8>/CopterID'

  real_T Merge_InitialOutput_i[4];     // Expression: [1 0 0 0]
                                          //  Referenced by: '<S330>/Merge'

  real_T Constant1_Value_l2;           // Expression: 0
                                          //  Referenced by: '<S52>/Constant1'

  real_T Gain_Gain_da;                 // Expression: 60/2/pi
                                          //  Referenced by: '<S8>/Gain'

  real_T TransferFcn2_A_e;             // Computed Parameter: TransferFcn2_A_e
                                          //  Referenced by: '<S52>/Transfer Fcn2'

  real_T TransferFcn2_C_e;             // Computed Parameter: TransferFcn2_C_e
                                          //  Referenced by: '<S52>/Transfer Fcn2'

  real_T Gain1_Gain_nx;                // Expression: 180/pi
                                          //  Referenced by: '<S52>/Gain1'

  real_T TransferFcn1_A_n;             // Computed Parameter: TransferFcn1_A_n
                                          //  Referenced by: '<S52>/Transfer Fcn1'

  real_T TransferFcn1_C_c;             // Computed Parameter: TransferFcn1_C_c
                                          //  Referenced by: '<S52>/Transfer Fcn1'

  real_T Gain2_Gain_k;                 // Expression: 180/pi
                                          //  Referenced by: '<S52>/Gain2'

  real_T TransferFcn3_A;               // Computed Parameter: TransferFcn3_A
                                          //  Referenced by: '<S52>/Transfer Fcn3'

  real_T TransferFcn3_C;               // Computed Parameter: TransferFcn3_C
                                          //  Referenced by: '<S52>/Transfer Fcn3'

  real_T Gain3_Gain_o;                 // Expression: 180/pi
                                          //  Referenced by: '<S52>/Gain3'

  real_T Constant2_Value_o[12];        // Expression: zeros(12,1)
                                          //  Referenced by: '<S52>/Constant2'

  real_T ExtToPX4_Value[16];           // Expression: 17:32
                                          //  Referenced by: '<Root>/ExtToPX4'

  real_T Constant_Value_el[15];   // Expression: [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
                                     //  Referenced by: '<S5>/Constant'

  real_T Constant_Value_g1;            // Expression: 1
                                          //  Referenced by: '<S21>/Constant'

  real_T UniformRandomNumber4_Minimum_g[3];// Expression: [-1,-1,-2]
                                              //  Referenced by: '<S331>/Uniform Random Number4'

  real_T UniformRandomNumber4_Maximum_j[3];// Expression: [1,1,2]
                                              //  Referenced by: '<S331>/Uniform Random Number4'

  real_T UniformRandomNumber4_Seed_e[3];// Expression: [5445,45433,33433]
                                           //  Referenced by: '<S331>/Uniform Random Number4'

  real_T BiasGain1_Gain;               // Expression: 0.1
                                          //  Referenced by: '<S331>/BiasGain1'

  int32_T Constant1_Value_h3;          // Computed Parameter: Constant1_Value_h3
                                          //  Referenced by: '<S479>/Constant1'

  int32_T Constant_Value_pi;           // Computed Parameter: Constant_Value_pi
                                          //  Referenced by: '<S480>/Constant'

  int32_T Constant_Value_b;            // Computed Parameter: Constant_Value_b
                                          //  Referenced by: '<S478>/Constant'

  int32_T Constant_Value_jv;           // Computed Parameter: Constant_Value_jv
                                          //  Referenced by: '<S489>/Constant'

  int32_T Gain_Gain_aq;                // Computed Parameter: Gain_Gain_aq
                                          //  Referenced by: '<S489>/Gain'

  int32_T Constant_Value_ld;           // Computed Parameter: Constant_Value_ld
                                          //  Referenced by: '<S492>/Constant'

  int32_T Gain_Gain_l;                 // Computed Parameter: Gain_Gain_l
                                          //  Referenced by: '<S491>/Gain'

  int32_T Constant_Value_al;           // Computed Parameter: Constant_Value_al
                                          //  Referenced by: '<S495>/Constant'

  int32_T Constant1_Value_dk;          // Computed Parameter: Constant1_Value_dk
                                          //  Referenced by: '<S495>/Constant1'

  int32_T Constant1_Value_b;           // Computed Parameter: Constant1_Value_b
                                          //  Referenced by: '<S496>/Constant1'

  int32_T Constant_Value_cw;           // Computed Parameter: Constant_Value_cw
                                          //  Referenced by: '<S494>/Constant'

  int32_T Constant1_Value_js;          // Computed Parameter: Constant1_Value_js
                                          //  Referenced by: '<S493>/Constant1'

  int32_T Gain_Gain_cl;                // Computed Parameter: Gain_Gain_cl
                                          //  Referenced by: '<S493>/Gain'

  int32_T Constant1_Value_iz;          // Computed Parameter: Constant1_Value_iz
                                          //  Referenced by: '<S497>/Constant1'

  int32_T Constant_Value_ds;           // Computed Parameter: Constant_Value_ds
                                          //  Referenced by: '<S471>/Constant'

  int32_T Constant_Value_hb;           // Computed Parameter: Constant_Value_hb
                                          //  Referenced by: '<S488>/Constant'

  int32_T Gain_Gain_cx;                // Computed Parameter: Gain_Gain_cx
                                          //  Referenced by: '<S488>/Gain'

  int32_T Constant_Value_bl;           // Computed Parameter: Constant_Value_bl
                                          //  Referenced by: '<S498>/Constant'

  int32_T Constant1_Value_me;          // Computed Parameter: Constant1_Value_me
                                          //  Referenced by: '<S498>/Constant1'

  int32_T Constant_Value_op;           // Computed Parameter: Constant_Value_op
                                          //  Referenced by: '<S500>/Constant'

  int32_T tc_old_Threshold;            // Computed Parameter: tc_old_Threshold
                                          //  Referenced by: '<S499>/tc_old'

  int32_T Constant_Value_d3e;          // Computed Parameter: Constant_Value_d3e
                                          //  Referenced by: '<S470>/Constant'

  int32_T Constant1_Value_lk;          // Computed Parameter: Constant1_Value_lk
                                          //  Referenced by: '<S470>/Constant1'

  int32_T Constant_Value_gj;           // Computed Parameter: Constant_Value_gj
                                          //  Referenced by: '<S469>/Constant'

  int32_T Constant_Value_mg;           // Computed Parameter: Constant_Value_mg
                                          //  Referenced by: '<S474>/Constant'

  int32_T Gain_Gain_kp;                // Computed Parameter: Gain_Gain_kp
                                          //  Referenced by: '<S474>/Gain'

  int32_T Constant_Value_jq;           // Computed Parameter: Constant_Value_jq
                                          //  Referenced by: '<S476>/Constant'

  int32_T ForIterator_IterationLimit_f;
                             // Computed Parameter: ForIterator_IterationLimit_f
                                //  Referenced by: '<S461>/For Iterator'

  int32_T Constant_Value_mk;           // Computed Parameter: Constant_Value_mk
                                          //  Referenced by: '<S461>/Constant'

  int32_T arn_Threshold;               // Computed Parameter: arn_Threshold
                                          //  Referenced by: '<S461>/ar(n)'

  int32_T FaultID_Value;               // Expression: FaultParamStruct.FaultID
                                          //  Referenced by: '<S50>/FaultID'

  int32_T FaultID_Value_a;      // Expression: FaultParamStruct.ConstWindFaultID
                                   //  Referenced by: '<S73>/FaultID'

  int32_T FaultID1_Value;        // Expression: FaultParamStruct.GustWindFaultID
                                    //  Referenced by: '<S73>/FaultID1'

  int32_T FaultID2_Value;        // Expression: FaultParamStruct.TurbWindFaultID
                                    //  Referenced by: '<S73>/FaultID2'

  int32_T FaultID3_Value;       // Expression: FaultParamStruct.SheerWindFaultID
                                   //  Referenced by: '<S73>/FaultID3'

  int32_T FaultID_Value_e;             // Computed Parameter: FaultID_Value_e
                                          //  Referenced by: '<S406>/FaultID'

  int32_T FaultID1_Value_a;            // Computed Parameter: FaultID1_Value_a
                                          //  Referenced by: '<S406>/FaultID1'

  int32_T FaultID2_Value_l;            // Computed Parameter: FaultID2_Value_l
                                          //  Referenced by: '<S406>/FaultID2'

  int32_T FaultID3_Value_n;            // Computed Parameter: FaultID3_Value_n
                                          //  Referenced by: '<S406>/FaultID3'

  int32_T FaultID_Value_p;       // Expression: FaultParamStruct.GPSNoiseFaultID
                                    //  Referenced by: '<S373>/FaultID'

  uint32_T MediumHighAltitudeIntensity_max[2];
                          // Computed Parameter: MediumHighAltitudeIntensity_max
                             //  Referenced by: '<S168>/Medium//High Altitude Intensity'

  uint32_T MediumHighAltitudeIntensity_m_g[2];
                          // Computed Parameter: MediumHighAltitudeIntensity_m_g
                             //  Referenced by: '<S129>/Medium//High Altitude Intensity'

  P_Interpolatevelocities_USV_T Interpolatevelocities_k;// '<S157>/Interpolate  velocities' 
  P_Interpolaterates_USV_T Interpolaterates_b;// '<S156>/Interpolate  rates'
  P_Hwgwz_USV_T Hwgwz_h;               // '<S152>/Hwgw(z)'
  P_Hvgwz_USV_T Hvgwz_m;               // '<S152>/Hvgw(z)'
  P_Hugwz_USV_T Hugwz_e;               // '<S152>/Hugw(z)'
  P_Hrgw_USV_T Hrgw_l;                 // '<S151>/Hrgw'
  P_Hqgw_USV_T Hqgw_j;                 // '<S151>/Hqgw'
  P_Hpgw_USV_T Hpgw_f;                 // '<S151>/Hpgw'
  P_Interpolatevelocities_USV_T Interpolatevelocities;// '<S118>/Interpolate  velocities' 
  P_Interpolaterates_USV_T Interpolaterates;// '<S117>/Interpolate  rates'
  P_Hwgwz_USV_T Hwgwz;                 // '<S113>/Hwgw(z)'
  P_Hvgwz_USV_T Hvgwz;                 // '<S113>/Hvgw(z)'
  P_Hugwz_USV_T Hugwz;                 // '<S113>/Hugw(z)'
  P_Hrgw_USV_T Hrgw;                   // '<S112>/Hrgw'
  P_Hqgw_USV_T Hqgw;                   // '<S112>/Hqgw'
  P_Hpgw_USV_T Hpgw;                   // '<S112>/Hpgw'
  P_Distanceintogusty_USV_T Distanceintogustz;// '<S54>/Distance into gust (z)'
  P_Distanceintogusty_USV_T Distanceintogusty;// '<S54>/Distance into gust (y)'
};

// Parameters (default storage)
typedef struct P_USV_T_ P_USV_T;

// Real-time Model Data Structure
struct tag_RTM_USV_T {
  const char_T *errorStatus;
  RTWSolverInfo solverInfo;
  X_USV_T *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  boolean_T *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;
  real_T odeY[34];
  real_T odeF[4][34];
  ODE4_IntgData intgData;

  //
  //  Sizes:
  //  The following substructure contains sizes information
  //  for many of the model attributes such as inputs, outputs,
  //  dwork, sample times, etc.

  struct {
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numSampTimes;
  } Sizes;

  //
  //  Timing:
  //  The following substructure contains information regarding
  //  the timing information for the model.

  struct {
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    boolean_T firstInitCondFlag;
    struct {
      uint16_T TID[7];
    } TaskCounters;

    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[7];
  } Timing;
};

extern "C" {
  static real_T rtGetInf(void);
  static real32_T rtGetInfF(void);
  static real_T rtGetMinusInf(void);
  static real32_T rtGetMinusInfF(void);
}                                      // extern "C"
  extern "C"
{
  static real_T rtGetNaN(void);
  static real32_T rtGetNaNF(void);
}                                      // extern "C"

extern "C" {
  extern real_T rtInf;
  extern real_T rtMinusInf;
  extern real_T rtNaN;
  extern real32_T rtInfF;
  extern real32_T rtMinusInfF;
  extern real32_T rtNaNF;
  static void rt_InitInfAndNaN(size_t realSize);
  static boolean_T rtIsInf(real_T value);
  static boolean_T rtIsInfF(real32_T value);
  static boolean_T rtIsNaN(real_T value);
  static boolean_T rtIsNaNF(real32_T value);
  struct BigEndianIEEEDouble {
    struct {
      uint32_T wordH;
      uint32_T wordL;
    } words;
  };

  struct LittleEndianIEEEDouble {
    struct {
      uint32_T wordL;
      uint32_T wordH;
    } words;
  };

  struct IEEESingle {
    union {
      real32_T wordLreal;
      uint32_T wordLuint;
    } wordL;
  };
}                                      // extern "C"
  // Class declaration for model USV
  class MulticopterModelClass
{
  // public data and function members
 public:
  // Real-Time Model get method
  RT_MODEL_USV_T * getRTM();

  // External inputs
  ExtU_USV_T USV_U;

  // External outputs
  ExtY_USV_T USV_Y;

  // Tunable parameters
  static P_USV_T USV_P;

  // model initialize function
  void initialize();

  // model step function
  void step();

  // model terminate function
  static void terminate();

  // Constructor
  MulticopterModelClass();

  // Destructor
  ~MulticopterModelClass();

  // private data and function members
 private:
  // Block signals
  B_USV_T USV_B;

  // Block states
  DW_USV_T USV_DW;

  // Block continuous states
  X_USV_T USV_X;

  // private member function(s) for subsystem '<S54>/Distance into gust (y)'
  static void USV_Distanceintogusty_Init(B_Distanceintogusty_USV_T *localB,
    P_Distanceintogusty_USV_T *localP, X_Distanceintogusty_USV_T *localX);
  static void USV_Distanceintogusty_Reset(P_Distanceintogusty_USV_T *localP,
    X_Distanceintogusty_USV_T *localX);
  void USV_Distanceintogusty_Deriv(real_T rtu_V, real_T rtp_d_m,
    DW_Distanceintogusty_USV_T *localDW, P_Distanceintogusty_USV_T *localP,
    X_Distanceintogusty_USV_T *localX, XDot_Distanceintogusty_USV_T *localXdot);
  static void USV_Distanceintogusty_Disable(DW_Distanceintogusty_USV_T *localDW);
  void USV_Distanceintogusty(boolean_T rtu_Enable, real_T rtp_d_m,
    B_Distanceintogusty_USV_T *localB, DW_Distanceintogusty_USV_T *localDW,
    P_Distanceintogusty_USV_T *localP, X_Distanceintogusty_USV_T *localX);

  // private member function(s) for subsystem '<S112>/Hpgw'
  static void USV_Hpgw_Init(B_Hpgw_USV_T *localB, DW_Hpgw_USV_T *localDW,
    P_Hpgw_USV_T *localP);
  static void USV_Hpgw_Reset(DW_Hpgw_USV_T *localDW, P_Hpgw_USV_T *localP);
  static void USV_Hpgw_Disable(B_Hpgw_USV_T *localB, DW_Hpgw_USV_T *localDW,
    P_Hpgw_USV_T *localP);
  void USV_Hpgw_Update(B_Hpgw_USV_T *localB, DW_Hpgw_USV_T *localDW);
  void USV_Hpgw(real_T rtu_Enable, const real_T rtu_L_wg[2], real_T rtu_sigma_wg,
                real_T rtu_sigma_wg_e, real_T rtu_Noise, real_T rtu_wingspan,
                B_Hpgw_USV_T *localB, DW_Hpgw_USV_T *localDW, P_Hpgw_USV_T
                *localP);

  // private member function(s) for subsystem '<S112>/Hqgw'
  static void USV_Hqgw_Init(B_Hqgw_USV_T *localB, DW_Hqgw_USV_T *localDW,
    P_Hqgw_USV_T *localP);
  static void USV_Hqgw_Reset(DW_Hqgw_USV_T *localDW, P_Hqgw_USV_T *localP);
  static void USV_Hqgw_Disable(B_Hqgw_USV_T *localB, DW_Hqgw_USV_T *localDW,
    P_Hqgw_USV_T *localP);
  void USV_Hqgw_Update(const real_T rtu_wg[2], B_Hqgw_USV_T *localB,
                       DW_Hqgw_USV_T *localDW);
  void USV_Hqgw(real_T rtu_Enable, real_T rtu_V, const real_T rtu_wg[2], real_T
                rtu_wingspan, B_Hqgw_USV_T *localB, DW_Hqgw_USV_T *localDW,
                P_Hqgw_USV_T *localP);

  // private member function(s) for subsystem '<S112>/Hrgw'
  static void USV_Hrgw_Init(B_Hrgw_USV_T *localB, DW_Hrgw_USV_T *localDW,
    P_Hrgw_USV_T *localP);
  static void USV_Hrgw_Reset(DW_Hrgw_USV_T *localDW, P_Hrgw_USV_T *localP);
  static void USV_Hrgw_Disable(B_Hrgw_USV_T *localB, DW_Hrgw_USV_T *localDW,
    P_Hrgw_USV_T *localP);
  void USV_Hrgw_Update(const real_T rtu_vg[2], B_Hrgw_USV_T *localB,
                       DW_Hrgw_USV_T *localDW);
  void USV_Hrgw(real_T rtu_Enable, real_T rtu_V, const real_T rtu_vg[2], real_T
                rtu_wingspan, B_Hrgw_USV_T *localB, DW_Hrgw_USV_T *localDW,
                P_Hrgw_USV_T *localP);

  // private member function(s) for subsystem '<S113>/Hugw(z)'
  static void USV_Hugwz_Init(B_Hugwz_USV_T *localB, DW_Hugwz_USV_T *localDW,
    P_Hugwz_USV_T *localP);
  static void USV_Hugwz_Reset(DW_Hugwz_USV_T *localDW, P_Hugwz_USV_T *localP);
  static void USV_Hugwz_Disable(B_Hugwz_USV_T *localB, DW_Hugwz_USV_T *localDW,
    P_Hugwz_USV_T *localP);
  void USV_Hugwz_Update(B_Hugwz_USV_T *localB, DW_Hugwz_USV_T *localDW);
  void USV_Hugwz(real_T rtu_Enable, real_T rtu_V, real_T rtu_L_ug, real_T
                 rtu_L_ug_n, real_T rtu_sigma_ug, real_T rtu_sigma_ug_f, real_T
                 rtu_Noise, B_Hugwz_USV_T *localB, DW_Hugwz_USV_T *localDW,
                 P_Hugwz_USV_T *localP);

  // private member function(s) for subsystem '<S113>/Hvgw(z)'
  static void USV_Hvgwz_Init(B_Hvgwz_USV_T *localB, DW_Hvgwz_USV_T *localDW,
    P_Hvgwz_USV_T *localP);
  static void USV_Hvgwz_Reset(DW_Hvgwz_USV_T *localDW, P_Hvgwz_USV_T *localP);
  static void USV_Hvgwz_Disable(B_Hvgwz_USV_T *localB, DW_Hvgwz_USV_T *localDW,
    P_Hvgwz_USV_T *localP);
  void USV_Hvgwz_Update(B_Hvgwz_USV_T *localB, DW_Hvgwz_USV_T *localDW);
  void USV_Hvgwz(real_T rtu_Enable, real_T rtu_sigma_vg, real_T rtu_sigma_vg_j,
                 const real_T rtu_L_vg[2], real_T rtu_V, real_T rtu_Noise,
                 B_Hvgwz_USV_T *localB, DW_Hvgwz_USV_T *localDW, P_Hvgwz_USV_T
                 *localP);

  // private member function(s) for subsystem '<S113>/Hwgw(z)'
  static void USV_Hwgwz_Init(B_Hwgwz_USV_T *localB, DW_Hwgwz_USV_T *localDW,
    P_Hwgwz_USV_T *localP);
  static void USV_Hwgwz_Reset(DW_Hwgwz_USV_T *localDW, P_Hwgwz_USV_T *localP);
  static void USV_Hwgwz_Disable(B_Hwgwz_USV_T *localB, DW_Hwgwz_USV_T *localDW,
    P_Hwgwz_USV_T *localP);
  void USV_Hwgwz_Update(B_Hwgwz_USV_T *localB, DW_Hwgwz_USV_T *localDW);
  void USV_Hwgwz(real_T rtu_Enable, real_T rtu_V, const real_T rtu_L_wg[2],
                 real_T rtu_sigma_wg, real_T rtu_sigma_wg_j, real_T rtu_Noise,
                 B_Hwgwz_USV_T *localB, DW_Hwgwz_USV_T *localDW, P_Hwgwz_USV_T
                 *localP);

  // private member function(s) for subsystem '<S117>/Low altitude  rates'
  static void USV_Lowaltituderates(const real_T rtu_DCM[9], const real_T
    rtu_pgw_hl[2], const real_T rtu_qgw_hl[2], const real_T rtu_rgw_hl[2],
    real_T rtu_Winddirection, real_T rty_pgwqgwrgw[3]);

  // private member function(s) for subsystem '<S117>/Interpolate  rates'
  static void USV_Interpolaterates(const real_T rtu_pgw_hl[2], const real_T
    rtu_qgw_hl[2], const real_T rtu_rgw_hl[2], const real_T rtu_DCM[9], real_T
    rtu_Winddirection, real_T rtu_Altitude, real_T rty_pgwqgwrgw[3],
    P_Interpolaterates_USV_T *localP);

  // private member function(s) for subsystem '<S118>/Low altitude  velocities'
  static void USV_Lowaltitudevelocities(const real_T rtu_DCM[9], const real_T
    rtu_ugw_hl[2], const real_T rtu_vgw_hl[2], const real_T rtu_wgw_hl[2],
    real_T rtu_Winddirection, real_T rty_ugwvgwwgw[3]);

  // private member function(s) for subsystem '<S118>/Interpolate  velocities'
  static void USV_Interpolatevelocities(const real_T rtu_ugw_hl[2], const real_T
    rtu_vgw_hl[2], const real_T rtu_wgw_hl[2], const real_T rtu_DCM[9], real_T
    rtu_Winddirection, real_T rtu_Altitude, real_T rty_ugwvgwwgw[3],
    P_Interpolatevelocities_USV_T *localP);

  // private member function(s) for subsystem '<S198>/MATLAB Function1'
  static void USV_MATLABFunction1(real_T rtu_timeConstantUp, real_T
    rtu_timeConstantDown, real_T rtu_inputState, real_T rtu_time,
    B_MATLABFunction1_USV_T *localB, DW_MATLABFunction1_USV_T *localDW);

  // private member function(s) for subsystem '<S198>/���ģ��'
  static void USV_u(real_T rtu_motor_rot_vel_, const real_T
                    rtu_relative_wind_velocity[3], real_T rtu_MotorDir, real_T
                    rtu_rotorVelocitySlowdownSim, real_T rtu_motorConstant,
                    real_T rtu_momentConstant, real_T rtu_rotorDragCoefficient,
                    real_T rtu_rollingMomentCoefficient, real_T rtu_reversible,
                    B_u_USV_T *localB);

  // private member function(s) for subsystem '<S407>/Acc NoiseFun'
  static void USV_AccNoiseFun(const real_T rtu_u[3], boolean_T rtu_isAccFault,
    const real_T rtu_AccFaultParams[20], B_AccNoiseFun_USV_T *localB);

  // private member function(s) for subsystem '<Root>'
  real_T USV_rand(void);

  // Continuous states update member function
  void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si );

  // Derivatives member function
  void USV_derivatives();

  // Real-Time Model
  RT_MODEL_USV_T USV_M;
}

;

//-
//  These blocks were eliminated from the model due to optimizations:
//
//  Block '<S16>/Unit Conversion' : Unused code path elimination
//  Block '<Root>/Constant1' : Unused code path elimination
//  Block '<S50>/Data Type Conversion1' : Unused code path elimination
//  Block '<S69>/Data Type Duplicate' : Unused code path elimination
//  Block '<S70>/P0' : Unused code path elimination
//  Block '<S70>/Product2' : Unused code path elimination
//  Block '<S70>/a' : Unused code path elimination
//  Block '<S70>/gamma*R' : Unused code path elimination
//  Block '<S71>/Unit Conversion' : Unused code path elimination
//  Block '<S100>/Cast' : Unused code path elimination
//  Block '<S101>/Cast' : Unused code path elimination
//  Block '<S192>/Display1' : Unused code path elimination
//  Block '<S192>/Display2' : Unused code path elimination
//  Block '<S192>/Display3' : Unused code path elimination
//  Block '<S192>/Display4' : Unused code path elimination
//  Block '<S192>/Display5' : Unused code path elimination
//  Block '<S4>/Display10' : Unused code path elimination
//  Block '<S4>/Display11' : Unused code path elimination
//  Block '<S4>/Display12' : Unused code path elimination
//  Block '<S4>/Display3' : Unused code path elimination
//  Block '<S4>/Display4' : Unused code path elimination
//  Block '<S4>/Display5' : Unused code path elimination
//  Block '<S4>/Display6' : Unused code path elimination
//  Block '<S4>/Display7' : Unused code path elimination
//  Block '<S4>/Display8' : Unused code path elimination
//  Block '<S4>/ModelParam.uavDearo' : Unused code path elimination
//  Block '<S194>/BoatParam_lenSlope1' : Unused code path elimination
//  Block '<S194>/Display' : Unused code path elimination
//  Block '<S194>/Display2' : Unused code path elimination
//  Block '<S194>/Gain2' : Unused code path elimination
//  Block '<S194>/Gain3' : Unused code path elimination
//  Block '<S378>/Data Type Duplicate' : Unused code path elimination
//  Block '<S406>/Data Type Conversion1' : Unused code path elimination
//  Block '<S416>/Product' : Unused code path elimination
//  Block '<S416>/Product3' : Unused code path elimination
//  Block '<S416>/a' : Unused code path elimination
//  Block '<S416>/gamma*R' : Unused code path elimination
//  Block '<S416>/rho0' : Unused code path elimination
//  Block '<S451>/Unit Conversion' : Unused code path elimination
//  Block '<S452>/Unit Conversion' : Unused code path elimination
//  Block '<S406>/magDecGain' : Unused code path elimination
//  Block '<S333>/Airspeed1' : Unused code path elimination
//  Block '<S333>/Bus Creator' : Unused code path elimination
//  Block '<S333>/Data Type Conversion1' : Unused code path elimination
//  Block '<S333>/Data Type Conversion2' : Unused code path elimination
//  Block '<S333>/Data Type Conversion3' : Unused code path elimination
//  Block '<S333>/Data Type Conversion4' : Unused code path elimination
//  Block '<S333>/Data Type Conversion5' : Unused code path elimination
//  Block '<S333>/Data Type Conversion7' : Unused code path elimination
//  Block '<S333>/Data Type Conversion8' : Unused code path elimination
//  Block '<S333>/Data Type Conversion9' : Unused code path elimination
//  Block '<S518>/1//2rhoV^2' : Unused code path elimination
//  Block '<S518>/Product2' : Unused code path elimination
//  Block '<S520>/Product' : Unused code path elimination
//  Block '<S520>/Product1' : Unused code path elimination
//  Block '<S520>/Product2' : Unused code path elimination
//  Block '<S520>/Sum' : Unused code path elimination
//  Block '<S333>/Gain' : Unused code path elimination
//  Block '<S333>/Gain1' : Unused code path elimination
//  Block '<S333>/Gain2' : Unused code path elimination
//  Block '<S333>/Gain3' : Unused code path elimination
//  Block '<S333>/Gain4' : Unused code path elimination
//  Block '<S333>/Gain5' : Unused code path elimination
//  Block '<S333>/Gain7' : Unused code path elimination
//  Block '<S333>/Sqrt1' : Unused code path elimination
//  Block '<S519>/Product' : Unused code path elimination
//  Block '<S519>/Product1' : Unused code path elimination
//  Block '<S519>/Product2' : Unused code path elimination
//  Block '<S519>/Sum' : Unused code path elimination
//  Block '<S31>/Reshape (9) to [3x3] column-major' : Reshape block reduction
//  Block '<S44>/Reshape1' : Reshape block reduction
//  Block '<S44>/Reshape2' : Reshape block reduction
//  Block '<S45>/Reshape1' : Reshape block reduction
//  Block '<S45>/Reshape2' : Reshape block reduction
//  Block '<S11>/Reshape' : Reshape block reduction
//  Block '<S11>/Reshape1' : Reshape block reduction
//  Block '<S14>/Unit Conversion' : Eliminated nontunable gain of 1
//  Block '<S15>/Unit Conversion' : Eliminated nontunable gain of 1
//  Block '<S17>/Reshape1' : Reshape block reduction
//  Block '<S17>/Reshape2' : Reshape block reduction
//  Block '<Root>/Data Type Conversion3' : Eliminate redundant data type conversion
//  Block '<S54>/Cast' : Eliminate redundant data type conversion
//  Block '<S54>/Cast To Double' : Eliminate redundant data type conversion
//  Block '<S60>/Unit Conversion' : Eliminated nontunable gain of 1
//  Block '<S3>/Reshape' : Reshape block reduction
//  Block '<S96>/Unit Conversion' : Eliminated nontunable gain of 1
//  Block '<S98>/Unit Conversion' : Eliminated nontunable gain of 1
//  Block '<S100>/Cast To Double' : Eliminate redundant data type conversion
//  Block '<S100>/Cast To Double1' : Eliminate redundant data type conversion
//  Block '<S100>/Cast To Double2' : Eliminate redundant data type conversion
//  Block '<S100>/Cast To Double3' : Eliminate redundant data type conversion
//  Block '<S100>/Cast To Double4' : Eliminate redundant data type conversion
//  Block '<S135>/Reshape' : Reshape block reduction
//  Block '<S135>/Reshape1' : Reshape block reduction
//  Block '<S137>/Reshape' : Reshape block reduction
//  Block '<S143>/Reshape' : Reshape block reduction
//  Block '<S143>/Reshape1' : Reshape block reduction
//  Block '<S145>/Reshape' : Reshape block reduction
//  Block '<S101>/Cast To Double' : Eliminate redundant data type conversion
//  Block '<S101>/Cast To Double1' : Eliminate redundant data type conversion
//  Block '<S101>/Cast To Double2' : Eliminate redundant data type conversion
//  Block '<S101>/Cast To Double3' : Eliminate redundant data type conversion
//  Block '<S101>/Cast To Double4' : Eliminate redundant data type conversion
//  Block '<S174>/Reshape' : Reshape block reduction
//  Block '<S174>/Reshape1' : Reshape block reduction
//  Block '<S176>/Reshape' : Reshape block reduction
//  Block '<S182>/Reshape' : Reshape block reduction
//  Block '<S182>/Reshape1' : Reshape block reduction
//  Block '<S184>/Reshape' : Reshape block reduction
//  Block '<S110>/Cast To Double' : Eliminate redundant data type conversion
//  Block '<S110>/Reshape' : Reshape block reduction
//  Block '<S110>/Reshape1' : Reshape block reduction
//  Block '<S220>/Reshape (9) to [3x3] column-major' : Reshape block reduction
//  Block '<S235>/Reshape (9) to [3x3] column-major' : Reshape block reduction
//  Block '<S250>/Reshape (9) to [3x3] column-major' : Reshape block reduction
//  Block '<S265>/Reshape (9) to [3x3] column-major' : Reshape block reduction
//  Block '<S280>/Reshape (9) to [3x3] column-major' : Reshape block reduction
//  Block '<S295>/Reshape (9) to [3x3] column-major' : Reshape block reduction
//  Block '<S310>/Reshape (9) to [3x3] column-major' : Reshape block reduction
//  Block '<S325>/Reshape (9) to [3x3] column-major' : Reshape block reduction
//  Block '<S8>/Data Type Conversion11' : Eliminate redundant data type conversion
//  Block '<S8>/Data Type Conversion3' : Eliminate redundant data type conversion
//  Block '<S330>/Reshape 3x3 -> 9' : Reshape block reduction
//  Block '<S364>/Reshape' : Reshape block reduction
//  Block '<S426>/Reshape1' : Reshape block reduction
//  Block '<S448>/maxtype' : Eliminate redundant data type conversion
//  Block '<S448>/mintype' : Eliminate redundant data type conversion
//  Block '<S450>/Unit Conversion' : Eliminated nontunable gain of 1
//  Block '<S419>/Unit Conversion2' : Eliminated nontunable gain of 1
//  Block '<S478>/Reshape' : Reshape block reduction
//  Block '<S485>/Reshape' : Reshape block reduction
//  Block '<S486>/Reshape' : Reshape block reduction
//  Block '<S487>/Reshape' : Reshape block reduction
//  Block '<S487>/Reshape1' : Reshape block reduction


//-
//  The generated code includes comments that allow you to trace directly
//  back to the appropriate location in the model.  The basic format
//  is <system>/block_name, where system is the system number (uniquely
//  assigned by Simulink) and block_name is the name of the block.
//
//  Use the MATLAB hilite_system command to trace the generated code back
//  to the model.  For example,
//
//  hilite_system('<S3>')    - opens system 3
//  hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
//
//  Here is the system hierarchy for this model
//
//  '<Root>' : 'USV'
//  '<S1>'   : 'USV/6DOF'
//  '<S2>'   : 'USV/ESCModel'
//  '<S3>'   : 'USV/Environment Model'
//  '<S4>'   : 'USV/Force and Moment Model'
//  '<S5>'   : 'USV/LogSelectModel'
//  '<S6>'   : 'USV/Model Info'
//  '<S7>'   : 'USV/OutputSignals'
//  '<S8>'   : 'USV/SensorModel'
//  '<S9>'   : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)'
//  '<S10>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate DCM & Euler Angles'
//  '<S11>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate omega_dot'
//  '<S12>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Determine Force,  Mass & Inertia'
//  '<S13>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Vbxw'
//  '<S14>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Velocity Conversion'
//  '<S15>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Velocity Conversion1'
//  '<S16>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Velocity Conversion2'
//  '<S17>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/transform to Inertial axes '
//  '<S18>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate DCM & Euler Angles/Quaternions to  Direction Cosine Matrix'
//  '<S19>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate DCM & Euler Angles/Quaternions to Rotation Angles'
//  '<S20>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate DCM & Euler Angles/Rotation Angles to Quaternions'
//  '<S21>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate DCM & Euler Angles/qdot'
//  '<S22>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate DCM & Euler Angles/Quaternions to  Direction Cosine Matrix/A11'
//  '<S23>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate DCM & Euler Angles/Quaternions to  Direction Cosine Matrix/A12'
//  '<S24>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate DCM & Euler Angles/Quaternions to  Direction Cosine Matrix/A13'
//  '<S25>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate DCM & Euler Angles/Quaternions to  Direction Cosine Matrix/A21'
//  '<S26>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate DCM & Euler Angles/Quaternions to  Direction Cosine Matrix/A22'
//  '<S27>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate DCM & Euler Angles/Quaternions to  Direction Cosine Matrix/A23'
//  '<S28>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate DCM & Euler Angles/Quaternions to  Direction Cosine Matrix/A31'
//  '<S29>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate DCM & Euler Angles/Quaternions to  Direction Cosine Matrix/A32'
//  '<S30>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate DCM & Euler Angles/Quaternions to  Direction Cosine Matrix/A33'
//  '<S31>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate DCM & Euler Angles/Quaternions to  Direction Cosine Matrix/Create 3x3 Matrix'
//  '<S32>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate DCM & Euler Angles/Quaternions to  Direction Cosine Matrix/Quaternion Normalize'
//  '<S33>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate DCM & Euler Angles/Quaternions to  Direction Cosine Matrix/Quaternion Normalize/Quaternion Modulus'
//  '<S34>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate DCM & Euler Angles/Quaternions to  Direction Cosine Matrix/Quaternion Normalize/Quaternion Modulus/Quaternion Norm'
//  '<S35>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate DCM & Euler Angles/Quaternions to Rotation Angles/Angle Calculation'
//  '<S36>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate DCM & Euler Angles/Quaternions to Rotation Angles/Quaternion Normalize'
//  '<S37>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate DCM & Euler Angles/Quaternions to Rotation Angles/Angle Calculation/Protect asincos input'
//  '<S38>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate DCM & Euler Angles/Quaternions to Rotation Angles/Angle Calculation/Protect asincos input/If Action Subsystem'
//  '<S39>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate DCM & Euler Angles/Quaternions to Rotation Angles/Angle Calculation/Protect asincos input/If Action Subsystem1'
//  '<S40>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate DCM & Euler Angles/Quaternions to Rotation Angles/Angle Calculation/Protect asincos input/If Action Subsystem2'
//  '<S41>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate DCM & Euler Angles/Quaternions to Rotation Angles/Quaternion Normalize/Quaternion Modulus'
//  '<S42>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate DCM & Euler Angles/Quaternions to Rotation Angles/Quaternion Normalize/Quaternion Modulus/Quaternion Norm'
//  '<S43>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate omega_dot/3x3 Cross Product'
//  '<S44>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate omega_dot/I x w'
//  '<S45>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate omega_dot/I x w1'
//  '<S46>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate omega_dot/3x3 Cross Product/Subsystem'
//  '<S47>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Calculate omega_dot/3x3 Cross Product/Subsystem1'
//  '<S48>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Vbxw/Subsystem'
//  '<S49>'  : 'USV/6DOF/Custom Variable Mass 6DOF (Quaternion)/Vbxw/Subsystem1'
//  '<S50>'  : 'USV/ESCModel/ESC Fault'
//  '<S51>'  : 'USV/ESCModel/ESC_All1'
//  '<S52>'  : 'USV/ESCModel/ToUEActuators'
//  '<S53>'  : 'USV/ESCModel/ESC Fault/Band-Limited White Noise'
//  '<S54>'  : 'USV/ESCModel/ESC Fault/Discrete Wind Gust Model'
//  '<S55>'  : 'USV/ESCModel/ESC Fault/FaultParamsExtract'
//  '<S56>'  : 'USV/ESCModel/ESC Fault/MotorFaultModel'
//  '<S57>'  : 'USV/ESCModel/ESC Fault/Discrete Wind Gust Model/Distance into gust (x)'
//  '<S58>'  : 'USV/ESCModel/ESC Fault/Discrete Wind Gust Model/Distance into gust (y)'
//  '<S59>'  : 'USV/ESCModel/ESC Fault/Discrete Wind Gust Model/Distance into gust (z)'
//  '<S60>'  : 'USV/ESCModel/ESC Fault/Discrete Wind Gust Model/Velocity Conversion'
//  '<S61>'  : 'USV/ESCModel/ESC_All1/ESC1'
//  '<S62>'  : 'USV/ESCModel/ESC_All1/ESC2'
//  '<S63>'  : 'USV/ESCModel/ESC_All1/ESC3'
//  '<S64>'  : 'USV/ESCModel/ESC_All1/ESC4'
//  '<S65>'  : 'USV/ESCModel/ESC_All1/ESC5'
//  '<S66>'  : 'USV/ESCModel/ESC_All1/ESC6'
//  '<S67>'  : 'USV/ESCModel/ESC_All1/ESC7'
//  '<S68>'  : 'USV/ESCModel/ESC_All1/ESC8'
//  '<S69>'  : 'USV/Environment Model/Flat Earth to LLA'
//  '<S70>'  : 'USV/Environment Model/ISA Atmosphere Model'
//  '<S71>'  : 'USV/Environment Model/Temperature Conversion'
//  '<S72>'  : 'USV/Environment Model/WGS84 Gravity Model '
//  '<S73>'  : 'USV/Environment Model/WindFault'
//  '<S74>'  : 'USV/Environment Model/Flat Earth to LLA/LatLong wrap'
//  '<S75>'  : 'USV/Environment Model/Flat Earth to LLA/LatLong wrap1'
//  '<S76>'  : 'USV/Environment Model/Flat Earth to LLA/LongLat_offset'
//  '<S77>'  : 'USV/Environment Model/Flat Earth to LLA/pos_deg'
//  '<S78>'  : 'USV/Environment Model/Flat Earth to LLA/LatLong wrap/Latitude Wrap 90'
//  '<S79>'  : 'USV/Environment Model/Flat Earth to LLA/LatLong wrap/Wrap Longitude'
//  '<S80>'  : 'USV/Environment Model/Flat Earth to LLA/LatLong wrap/Latitude Wrap 90/Compare To Constant'
//  '<S81>'  : 'USV/Environment Model/Flat Earth to LLA/LatLong wrap/Latitude Wrap 90/Wrap Angle 180'
//  '<S82>'  : 'USV/Environment Model/Flat Earth to LLA/LatLong wrap/Latitude Wrap 90/Wrap Angle 180/Compare To Constant'
//  '<S83>'  : 'USV/Environment Model/Flat Earth to LLA/LatLong wrap/Wrap Longitude/Compare To Constant'
//  '<S84>'  : 'USV/Environment Model/Flat Earth to LLA/LatLong wrap1/Latitude Wrap 90'
//  '<S85>'  : 'USV/Environment Model/Flat Earth to LLA/LatLong wrap1/Wrap Longitude'
//  '<S86>'  : 'USV/Environment Model/Flat Earth to LLA/LatLong wrap1/Latitude Wrap 90/Compare To Constant'
//  '<S87>'  : 'USV/Environment Model/Flat Earth to LLA/LatLong wrap1/Latitude Wrap 90/Wrap Angle 180'
//  '<S88>'  : 'USV/Environment Model/Flat Earth to LLA/LatLong wrap1/Latitude Wrap 90/Wrap Angle 180/Compare To Constant'
//  '<S89>'  : 'USV/Environment Model/Flat Earth to LLA/LatLong wrap1/Wrap Longitude/Compare To Constant'
//  '<S90>'  : 'USV/Environment Model/Flat Earth to LLA/LongLat_offset/Find Radian//Distance'
//  '<S91>'  : 'USV/Environment Model/Flat Earth to LLA/LongLat_offset/rotation_rad'
//  '<S92>'  : 'USV/Environment Model/Flat Earth to LLA/LongLat_offset/Find Radian//Distance/Angle Conversion2'
//  '<S93>'  : 'USV/Environment Model/Flat Earth to LLA/LongLat_offset/Find Radian//Distance/denom'
//  '<S94>'  : 'USV/Environment Model/Flat Earth to LLA/LongLat_offset/Find Radian//Distance/e'
//  '<S95>'  : 'USV/Environment Model/Flat Earth to LLA/LongLat_offset/Find Radian//Distance/e^4'
//  '<S96>'  : 'USV/Environment Model/WGS84 Gravity Model /Acceleration Conversion'
//  '<S97>'  : 'USV/Environment Model/WGS84 Gravity Model /Angle Conversion'
//  '<S98>'  : 'USV/Environment Model/WGS84 Gravity Model /Length Conversion'
//  '<S99>'  : 'USV/Environment Model/WGS84 Gravity Model /Velocity Conversion2'
//  '<S100>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))'
//  '<S101>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1'
//  '<S102>' : 'USV/Environment Model/WindFault/FaultParamsExtract'
//  '<S103>' : 'USV/Environment Model/WindFault/FaultParamsExtract1'
//  '<S104>' : 'USV/Environment Model/WindFault/FaultParamsExtract2'
//  '<S105>' : 'USV/Environment Model/WindFault/FaultParamsExtract3'
//  '<S106>' : 'USV/Environment Model/WindFault/MATLAB Function'
//  '<S107>' : 'USV/Environment Model/WindFault/MATLAB Function1'
//  '<S108>' : 'USV/Environment Model/WindFault/SheerWindStrength_Dec_Switch'
//  '<S109>' : 'USV/Environment Model/WindFault/TurbWindStrength_Dec_Switch'
//  '<S110>' : 'USV/Environment Model/WindFault/Wind Shear Model'
//  '<S111>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Angle Conversion'
//  '<S112>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Filters on angular rates'
//  '<S113>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Filters on velocities'
//  '<S114>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Length Conversion'
//  '<S115>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Length Conversion1'
//  '<S116>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/RMS turbulence  intensities'
//  '<S117>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select angular rates'
//  '<S118>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select velocities'
//  '<S119>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Turbulence scale lengths'
//  '<S120>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Velocity Conversion'
//  '<S121>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Velocity Conversion2'
//  '<S122>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/White Noise'
//  '<S123>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Filters on angular rates/Hpgw'
//  '<S124>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Filters on angular rates/Hqgw'
//  '<S125>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Filters on angular rates/Hrgw'
//  '<S126>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Filters on velocities/Hugw(z)'
//  '<S127>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Filters on velocities/Hvgw(z)'
//  '<S128>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Filters on velocities/Hwgw(z)'
//  '<S129>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/RMS turbulence  intensities/High Altitude Intensity'
//  '<S130>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/RMS turbulence  intensities/Low Altitude Intensity'
//  '<S131>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select angular rates/Interpolate  rates'
//  '<S132>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select angular rates/Low altitude  rates'
//  '<S133>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select angular rates/Medium//High  altitude rates'
//  '<S134>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select angular rates/Merge Subsystems'
//  '<S135>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select angular rates/Interpolate  rates/wind to body transformation'
//  '<S136>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select angular rates/Interpolate  rates/wind to body transformation/convert to earth coords'
//  '<S137>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select angular rates/Low altitude  rates/wind to body transformation'
//  '<S138>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select angular rates/Low altitude  rates/wind to body transformation/convert to earth coords'
//  '<S139>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select velocities/Interpolate  velocities'
//  '<S140>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select velocities/Low altitude  velocities'
//  '<S141>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select velocities/Medium//High  altitude velocities'
//  '<S142>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select velocities/Merge Subsystems'
//  '<S143>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select velocities/Interpolate  velocities/wind to body transformation'
//  '<S144>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select velocities/Interpolate  velocities/wind to body transformation/convert to earth coords'
//  '<S145>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select velocities/Low altitude  velocities/wind to body transformation'
//  '<S146>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select velocities/Low altitude  velocities/wind to body transformation/convert to earth coords'
//  '<S147>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Turbulence scale lengths/Low altitude scale length'
//  '<S148>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Turbulence scale lengths/Medium//High altitude scale length'
//  '<S149>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Turbulence scale lengths/Medium//High altitude scale length/Length Conversion'
//  '<S150>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Angle Conversion'
//  '<S151>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Filters on angular rates'
//  '<S152>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Filters on velocities'
//  '<S153>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Length Conversion'
//  '<S154>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Length Conversion1'
//  '<S155>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/RMS turbulence  intensities'
//  '<S156>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select angular rates'
//  '<S157>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select velocities'
//  '<S158>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Turbulence scale lengths'
//  '<S159>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Velocity Conversion'
//  '<S160>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Velocity Conversion2'
//  '<S161>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/White Noise'
//  '<S162>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Filters on angular rates/Hpgw'
//  '<S163>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Filters on angular rates/Hqgw'
//  '<S164>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Filters on angular rates/Hrgw'
//  '<S165>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Filters on velocities/Hugw(z)'
//  '<S166>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Filters on velocities/Hvgw(z)'
//  '<S167>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Filters on velocities/Hwgw(z)'
//  '<S168>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/RMS turbulence  intensities/High Altitude Intensity'
//  '<S169>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/RMS turbulence  intensities/Low Altitude Intensity'
//  '<S170>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select angular rates/Interpolate  rates'
//  '<S171>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select angular rates/Low altitude  rates'
//  '<S172>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select angular rates/Medium//High  altitude rates'
//  '<S173>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select angular rates/Merge Subsystems'
//  '<S174>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select angular rates/Interpolate  rates/wind to body transformation'
//  '<S175>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select angular rates/Interpolate  rates/wind to body transformation/convert to earth coords'
//  '<S176>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select angular rates/Low altitude  rates/wind to body transformation'
//  '<S177>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select angular rates/Low altitude  rates/wind to body transformation/convert to earth coords'
//  '<S178>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select velocities/Interpolate  velocities'
//  '<S179>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select velocities/Low altitude  velocities'
//  '<S180>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select velocities/Medium//High  altitude velocities'
//  '<S181>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select velocities/Merge Subsystems'
//  '<S182>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select velocities/Interpolate  velocities/wind to body transformation'
//  '<S183>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select velocities/Interpolate  velocities/wind to body transformation/convert to earth coords'
//  '<S184>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select velocities/Low altitude  velocities/wind to body transformation'
//  '<S185>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select velocities/Low altitude  velocities/wind to body transformation/convert to earth coords'
//  '<S186>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Turbulence scale lengths/Low altitude scale length'
//  '<S187>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Turbulence scale lengths/Medium//High altitude scale length'
//  '<S188>' : 'USV/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Turbulence scale lengths/Medium//High altitude scale length/Length Conversion'
//  '<S189>' : 'USV/Environment Model/WindFault/Wind Shear Model/Angle Conversion'
//  '<S190>' : 'USV/Environment Model/WindFault/Wind Shear Model/Length Conversion'
//  '<S191>' : 'USV/Force and Moment Model/3x3 Cross Product'
//  '<S192>' : 'USV/Force and Moment Model/BoatWaterDrag'
//  '<S193>' : 'USV/Force and Moment Model/Motor_ALL'
//  '<S194>' : 'USV/Force and Moment Model/buoyancyModel'
//  '<S195>' : 'USV/Force and Moment Model/3x3 Cross Product/Subsystem'
//  '<S196>' : 'USV/Force and Moment Model/3x3 Cross Product/Subsystem1'
//  '<S197>' : 'USV/Force and Moment Model/BoatWaterDrag/Body AeroCenter'
//  '<S198>' : 'USV/Force and Moment Model/Motor_ALL/Motor1'
//  '<S199>' : 'USV/Force and Moment Model/Motor_ALL/Motor2'
//  '<S200>' : 'USV/Force and Moment Model/Motor_ALL/Motor3'
//  '<S201>' : 'USV/Force and Moment Model/Motor_ALL/Motor4'
//  '<S202>' : 'USV/Force and Moment Model/Motor_ALL/Motor5'
//  '<S203>' : 'USV/Force and Moment Model/Motor_ALL/Motor6'
//  '<S204>' : 'USV/Force and Moment Model/Motor_ALL/Motor7'
//  '<S205>' : 'USV/Force and Moment Model/Motor_ALL/Motor8'
//  '<S206>' : 'USV/Force and Moment Model/Motor_ALL/Motor1/Cross Product'
//  '<S207>' : 'USV/Force and Moment Model/Motor_ALL/Motor1/Cross Product1'
//  '<S208>' : 'USV/Force and Moment Model/Motor_ALL/Motor1/Euler to DCM'
//  '<S209>' : 'USV/Force and Moment Model/Motor_ALL/Motor1/MATLAB Function1'
//  '<S210>' : 'USV/Force and Moment Model/Motor_ALL/Motor1/���ģ��'
//  '<S211>' : 'USV/Force and Moment Model/Motor_ALL/Motor1/Euler to DCM/A11'
//  '<S212>' : 'USV/Force and Moment Model/Motor_ALL/Motor1/Euler to DCM/A12'
//  '<S213>' : 'USV/Force and Moment Model/Motor_ALL/Motor1/Euler to DCM/A13'
//  '<S214>' : 'USV/Force and Moment Model/Motor_ALL/Motor1/Euler to DCM/A21'
//  '<S215>' : 'USV/Force and Moment Model/Motor_ALL/Motor1/Euler to DCM/A22'
//  '<S216>' : 'USV/Force and Moment Model/Motor_ALL/Motor1/Euler to DCM/A23'
//  '<S217>' : 'USV/Force and Moment Model/Motor_ALL/Motor1/Euler to DCM/A31'
//  '<S218>' : 'USV/Force and Moment Model/Motor_ALL/Motor1/Euler to DCM/A32'
//  '<S219>' : 'USV/Force and Moment Model/Motor_ALL/Motor1/Euler to DCM/A33'
//  '<S220>' : 'USV/Force and Moment Model/Motor_ALL/Motor1/Euler to DCM/Create Transformation Matrix'
//  '<S221>' : 'USV/Force and Moment Model/Motor_ALL/Motor2/Cross Product'
//  '<S222>' : 'USV/Force and Moment Model/Motor_ALL/Motor2/Cross Product1'
//  '<S223>' : 'USV/Force and Moment Model/Motor_ALL/Motor2/Euler to DCM'
//  '<S224>' : 'USV/Force and Moment Model/Motor_ALL/Motor2/MATLAB Function1'
//  '<S225>' : 'USV/Force and Moment Model/Motor_ALL/Motor2/���ģ��'
//  '<S226>' : 'USV/Force and Moment Model/Motor_ALL/Motor2/Euler to DCM/A11'
//  '<S227>' : 'USV/Force and Moment Model/Motor_ALL/Motor2/Euler to DCM/A12'
//  '<S228>' : 'USV/Force and Moment Model/Motor_ALL/Motor2/Euler to DCM/A13'
//  '<S229>' : 'USV/Force and Moment Model/Motor_ALL/Motor2/Euler to DCM/A21'
//  '<S230>' : 'USV/Force and Moment Model/Motor_ALL/Motor2/Euler to DCM/A22'
//  '<S231>' : 'USV/Force and Moment Model/Motor_ALL/Motor2/Euler to DCM/A23'
//  '<S232>' : 'USV/Force and Moment Model/Motor_ALL/Motor2/Euler to DCM/A31'
//  '<S233>' : 'USV/Force and Moment Model/Motor_ALL/Motor2/Euler to DCM/A32'
//  '<S234>' : 'USV/Force and Moment Model/Motor_ALL/Motor2/Euler to DCM/A33'
//  '<S235>' : 'USV/Force and Moment Model/Motor_ALL/Motor2/Euler to DCM/Create Transformation Matrix'
//  '<S236>' : 'USV/Force and Moment Model/Motor_ALL/Motor3/Cross Product'
//  '<S237>' : 'USV/Force and Moment Model/Motor_ALL/Motor3/Cross Product1'
//  '<S238>' : 'USV/Force and Moment Model/Motor_ALL/Motor3/Euler to DCM'
//  '<S239>' : 'USV/Force and Moment Model/Motor_ALL/Motor3/MATLAB Function1'
//  '<S240>' : 'USV/Force and Moment Model/Motor_ALL/Motor3/���ģ��'
//  '<S241>' : 'USV/Force and Moment Model/Motor_ALL/Motor3/Euler to DCM/A11'
//  '<S242>' : 'USV/Force and Moment Model/Motor_ALL/Motor3/Euler to DCM/A12'
//  '<S243>' : 'USV/Force and Moment Model/Motor_ALL/Motor3/Euler to DCM/A13'
//  '<S244>' : 'USV/Force and Moment Model/Motor_ALL/Motor3/Euler to DCM/A21'
//  '<S245>' : 'USV/Force and Moment Model/Motor_ALL/Motor3/Euler to DCM/A22'
//  '<S246>' : 'USV/Force and Moment Model/Motor_ALL/Motor3/Euler to DCM/A23'
//  '<S247>' : 'USV/Force and Moment Model/Motor_ALL/Motor3/Euler to DCM/A31'
//  '<S248>' : 'USV/Force and Moment Model/Motor_ALL/Motor3/Euler to DCM/A32'
//  '<S249>' : 'USV/Force and Moment Model/Motor_ALL/Motor3/Euler to DCM/A33'
//  '<S250>' : 'USV/Force and Moment Model/Motor_ALL/Motor3/Euler to DCM/Create Transformation Matrix'
//  '<S251>' : 'USV/Force and Moment Model/Motor_ALL/Motor4/Cross Product'
//  '<S252>' : 'USV/Force and Moment Model/Motor_ALL/Motor4/Cross Product1'
//  '<S253>' : 'USV/Force and Moment Model/Motor_ALL/Motor4/Euler to DCM'
//  '<S254>' : 'USV/Force and Moment Model/Motor_ALL/Motor4/MATLAB Function1'
//  '<S255>' : 'USV/Force and Moment Model/Motor_ALL/Motor4/���ģ��'
//  '<S256>' : 'USV/Force and Moment Model/Motor_ALL/Motor4/Euler to DCM/A11'
//  '<S257>' : 'USV/Force and Moment Model/Motor_ALL/Motor4/Euler to DCM/A12'
//  '<S258>' : 'USV/Force and Moment Model/Motor_ALL/Motor4/Euler to DCM/A13'
//  '<S259>' : 'USV/Force and Moment Model/Motor_ALL/Motor4/Euler to DCM/A21'
//  '<S260>' : 'USV/Force and Moment Model/Motor_ALL/Motor4/Euler to DCM/A22'
//  '<S261>' : 'USV/Force and Moment Model/Motor_ALL/Motor4/Euler to DCM/A23'
//  '<S262>' : 'USV/Force and Moment Model/Motor_ALL/Motor4/Euler to DCM/A31'
//  '<S263>' : 'USV/Force and Moment Model/Motor_ALL/Motor4/Euler to DCM/A32'
//  '<S264>' : 'USV/Force and Moment Model/Motor_ALL/Motor4/Euler to DCM/A33'
//  '<S265>' : 'USV/Force and Moment Model/Motor_ALL/Motor4/Euler to DCM/Create Transformation Matrix'
//  '<S266>' : 'USV/Force and Moment Model/Motor_ALL/Motor5/Cross Product'
//  '<S267>' : 'USV/Force and Moment Model/Motor_ALL/Motor5/Cross Product1'
//  '<S268>' : 'USV/Force and Moment Model/Motor_ALL/Motor5/Euler to DCM'
//  '<S269>' : 'USV/Force and Moment Model/Motor_ALL/Motor5/MATLAB Function1'
//  '<S270>' : 'USV/Force and Moment Model/Motor_ALL/Motor5/���ģ��'
//  '<S271>' : 'USV/Force and Moment Model/Motor_ALL/Motor5/Euler to DCM/A11'
//  '<S272>' : 'USV/Force and Moment Model/Motor_ALL/Motor5/Euler to DCM/A12'
//  '<S273>' : 'USV/Force and Moment Model/Motor_ALL/Motor5/Euler to DCM/A13'
//  '<S274>' : 'USV/Force and Moment Model/Motor_ALL/Motor5/Euler to DCM/A21'
//  '<S275>' : 'USV/Force and Moment Model/Motor_ALL/Motor5/Euler to DCM/A22'
//  '<S276>' : 'USV/Force and Moment Model/Motor_ALL/Motor5/Euler to DCM/A23'
//  '<S277>' : 'USV/Force and Moment Model/Motor_ALL/Motor5/Euler to DCM/A31'
//  '<S278>' : 'USV/Force and Moment Model/Motor_ALL/Motor5/Euler to DCM/A32'
//  '<S279>' : 'USV/Force and Moment Model/Motor_ALL/Motor5/Euler to DCM/A33'
//  '<S280>' : 'USV/Force and Moment Model/Motor_ALL/Motor5/Euler to DCM/Create Transformation Matrix'
//  '<S281>' : 'USV/Force and Moment Model/Motor_ALL/Motor6/Cross Product'
//  '<S282>' : 'USV/Force and Moment Model/Motor_ALL/Motor6/Cross Product1'
//  '<S283>' : 'USV/Force and Moment Model/Motor_ALL/Motor6/Euler to DCM'
//  '<S284>' : 'USV/Force and Moment Model/Motor_ALL/Motor6/MATLAB Function1'
//  '<S285>' : 'USV/Force and Moment Model/Motor_ALL/Motor6/���ģ��'
//  '<S286>' : 'USV/Force and Moment Model/Motor_ALL/Motor6/Euler to DCM/A11'
//  '<S287>' : 'USV/Force and Moment Model/Motor_ALL/Motor6/Euler to DCM/A12'
//  '<S288>' : 'USV/Force and Moment Model/Motor_ALL/Motor6/Euler to DCM/A13'
//  '<S289>' : 'USV/Force and Moment Model/Motor_ALL/Motor6/Euler to DCM/A21'
//  '<S290>' : 'USV/Force and Moment Model/Motor_ALL/Motor6/Euler to DCM/A22'
//  '<S291>' : 'USV/Force and Moment Model/Motor_ALL/Motor6/Euler to DCM/A23'
//  '<S292>' : 'USV/Force and Moment Model/Motor_ALL/Motor6/Euler to DCM/A31'
//  '<S293>' : 'USV/Force and Moment Model/Motor_ALL/Motor6/Euler to DCM/A32'
//  '<S294>' : 'USV/Force and Moment Model/Motor_ALL/Motor6/Euler to DCM/A33'
//  '<S295>' : 'USV/Force and Moment Model/Motor_ALL/Motor6/Euler to DCM/Create Transformation Matrix'
//  '<S296>' : 'USV/Force and Moment Model/Motor_ALL/Motor7/Cross Product'
//  '<S297>' : 'USV/Force and Moment Model/Motor_ALL/Motor7/Cross Product1'
//  '<S298>' : 'USV/Force and Moment Model/Motor_ALL/Motor7/Euler to DCM'
//  '<S299>' : 'USV/Force and Moment Model/Motor_ALL/Motor7/MATLAB Function1'
//  '<S300>' : 'USV/Force and Moment Model/Motor_ALL/Motor7/���ģ��'
//  '<S301>' : 'USV/Force and Moment Model/Motor_ALL/Motor7/Euler to DCM/A11'
//  '<S302>' : 'USV/Force and Moment Model/Motor_ALL/Motor7/Euler to DCM/A12'
//  '<S303>' : 'USV/Force and Moment Model/Motor_ALL/Motor7/Euler to DCM/A13'
//  '<S304>' : 'USV/Force and Moment Model/Motor_ALL/Motor7/Euler to DCM/A21'
//  '<S305>' : 'USV/Force and Moment Model/Motor_ALL/Motor7/Euler to DCM/A22'
//  '<S306>' : 'USV/Force and Moment Model/Motor_ALL/Motor7/Euler to DCM/A23'
//  '<S307>' : 'USV/Force and Moment Model/Motor_ALL/Motor7/Euler to DCM/A31'
//  '<S308>' : 'USV/Force and Moment Model/Motor_ALL/Motor7/Euler to DCM/A32'
//  '<S309>' : 'USV/Force and Moment Model/Motor_ALL/Motor7/Euler to DCM/A33'
//  '<S310>' : 'USV/Force and Moment Model/Motor_ALL/Motor7/Euler to DCM/Create Transformation Matrix'
//  '<S311>' : 'USV/Force and Moment Model/Motor_ALL/Motor8/Cross Product'
//  '<S312>' : 'USV/Force and Moment Model/Motor_ALL/Motor8/Cross Product1'
//  '<S313>' : 'USV/Force and Moment Model/Motor_ALL/Motor8/Euler to DCM'
//  '<S314>' : 'USV/Force and Moment Model/Motor_ALL/Motor8/MATLAB Function1'
//  '<S315>' : 'USV/Force and Moment Model/Motor_ALL/Motor8/���ģ��'
//  '<S316>' : 'USV/Force and Moment Model/Motor_ALL/Motor8/Euler to DCM/A11'
//  '<S317>' : 'USV/Force and Moment Model/Motor_ALL/Motor8/Euler to DCM/A12'
//  '<S318>' : 'USV/Force and Moment Model/Motor_ALL/Motor8/Euler to DCM/A13'
//  '<S319>' : 'USV/Force and Moment Model/Motor_ALL/Motor8/Euler to DCM/A21'
//  '<S320>' : 'USV/Force and Moment Model/Motor_ALL/Motor8/Euler to DCM/A22'
//  '<S321>' : 'USV/Force and Moment Model/Motor_ALL/Motor8/Euler to DCM/A23'
//  '<S322>' : 'USV/Force and Moment Model/Motor_ALL/Motor8/Euler to DCM/A31'
//  '<S323>' : 'USV/Force and Moment Model/Motor_ALL/Motor8/Euler to DCM/A32'
//  '<S324>' : 'USV/Force and Moment Model/Motor_ALL/Motor8/Euler to DCM/A33'
//  '<S325>' : 'USV/Force and Moment Model/Motor_ALL/Motor8/Euler to DCM/Create Transformation Matrix'
//  '<S326>' : 'USV/Force and Moment Model/buoyancyModel/3x3 Cross Product'
//  '<S327>' : 'USV/Force and Moment Model/buoyancyModel/MATLAB Function'
//  '<S328>' : 'USV/Force and Moment Model/buoyancyModel/3x3 Cross Product/Subsystem'
//  '<S329>' : 'USV/Force and Moment Model/buoyancyModel/3x3 Cross Product/Subsystem1'
//  '<S330>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions'
//  '<S331>' : 'USV/SensorModel/HILGPSModel'
//  '<S332>' : 'USV/SensorModel/HILSensorMavModel1'
//  '<S333>' : 'USV/SensorModel/HILStateMavModel'
//  '<S334>' : 'USV/SensorModel/ZLimit'
//  '<S335>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Negative Trace'
//  '<S336>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Positive Trace'
//  '<S337>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Validate DCM'
//  '<S338>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/trace(DCM)'
//  '<S339>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(1,1)'
//  '<S340>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(2,2)'
//  '<S341>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(3,3)'
//  '<S342>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Negative Trace/diag(DCM)'
//  '<S343>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(1,1)/cos(phi)sin(theta)cos(psi) + sin(phi)sin(psi) -sin(theta)'
//  '<S344>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(1,1)/cos(theta)sin(phi) - (cos(phi)sin(theta)sin(psi) - sin(phi)cos(psi))'
//  '<S345>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(1,1)/cos(theta)sin(psi) + (sin(phi)sin(theta)cos(psi) - cos(phi)sin(psi))'
//  '<S346>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(1,1)/if s~=0; s=0.5//s'
//  '<S347>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(1,1)/u(1) -(u(5)+u(9)) +1'
//  '<S348>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(2,2)/cos(phi)sin(theta)cos(psi) + sin(phi)sin(psi) +sin(theta)'
//  '<S349>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(2,2)/cos(theta)sin(phi) + (cos(phi)sin(theta)sin(psi) - sin(phi)cos(psi))'
//  '<S350>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(2,2)/cos(theta)sin(psi) + (sin(phi)sin(theta)cos(psi) - cos(phi)sin(psi))'
//  '<S351>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(2,2)/if s~=0; s=0.5//s'
//  '<S352>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(2,2)/u(5) -(u(1)+u(9)) +1'
//  '<S353>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(3,3)/cos(phi)sin(theta)cos(psi) + sin(phi)sin(psi) -sin(theta)'
//  '<S354>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(3,3)/cos(theta)sin(phi) + (cos(phi)sin(theta)sin(psi) - sin(phi)cos(psi))'
//  '<S355>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(3,3)/cos(theta)sin(psi) - (sin(phi)sin(theta)cos(psi) - cos(phi)sin(psi))'
//  '<S356>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(3,3)/if s~=0; s=0.5//s'
//  '<S357>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(3,3)/u(9) -(u(1)+u(5)) +1'
//  '<S358>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Positive Trace/cos(phi)sin(theta)cos(psi) + sin(phi)sin(psi) +sin(theta)'
//  '<S359>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Positive Trace/cos(theta)sin(phi) - (cos(phi)sin(theta)sin(psi) - sin(phi)cos(psi))'
//  '<S360>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Positive Trace/cos(theta)sin(psi) - (sin(phi)sin(theta)cos(psi) - cos(phi)sin(psi))'
//  '<S361>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error'
//  '<S362>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/Else If Not Orthogonal'
//  '<S363>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/If Not Proper'
//  '<S364>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/isNotOrthogonal'
//  '<S365>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/isNotProper'
//  '<S366>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/Else If Not Orthogonal/Error'
//  '<S367>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/Else If Not Orthogonal/Warning'
//  '<S368>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/If Not Proper/Error'
//  '<S369>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/If Not Proper/Warning'
//  '<S370>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/isNotOrthogonal/transpose*dcm ~= eye(3)'
//  '<S371>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/isNotProper/Determinant of 3x3 Matrix'
//  '<S372>' : 'USV/SensorModel/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/isNotProper/determinant does not equal 1'
//  '<S373>' : 'USV/SensorModel/HILGPSModel/GPSFault'
//  '<S374>' : 'USV/SensorModel/HILGPSModel/GenCogVel'
//  '<S375>' : 'USV/SensorModel/HILGPSModel/NoiseFilter1'
//  '<S376>' : 'USV/SensorModel/HILGPSModel/GPSFault/AccNoiseSwitch1'
//  '<S377>' : 'USV/SensorModel/HILGPSModel/GPSFault/FaultParamsExtract'
//  '<S378>' : 'USV/SensorModel/HILGPSModel/GPSFault/Flat Earth to LLA'
//  '<S379>' : 'USV/SensorModel/HILGPSModel/GPSFault/AccNoiseSwitch1/Acc NoiseFun'
//  '<S380>' : 'USV/SensorModel/HILGPSModel/GPSFault/Flat Earth to LLA/LatLong wrap'
//  '<S381>' : 'USV/SensorModel/HILGPSModel/GPSFault/Flat Earth to LLA/LatLong wrap1'
//  '<S382>' : 'USV/SensorModel/HILGPSModel/GPSFault/Flat Earth to LLA/LongLat_offset'
//  '<S383>' : 'USV/SensorModel/HILGPSModel/GPSFault/Flat Earth to LLA/pos_deg'
//  '<S384>' : 'USV/SensorModel/HILGPSModel/GPSFault/Flat Earth to LLA/LatLong wrap/Latitude Wrap 90'
//  '<S385>' : 'USV/SensorModel/HILGPSModel/GPSFault/Flat Earth to LLA/LatLong wrap/Wrap Longitude'
//  '<S386>' : 'USV/SensorModel/HILGPSModel/GPSFault/Flat Earth to LLA/LatLong wrap/Latitude Wrap 90/Compare To Constant'
//  '<S387>' : 'USV/SensorModel/HILGPSModel/GPSFault/Flat Earth to LLA/LatLong wrap/Latitude Wrap 90/Wrap Angle 180'
//  '<S388>' : 'USV/SensorModel/HILGPSModel/GPSFault/Flat Earth to LLA/LatLong wrap/Latitude Wrap 90/Wrap Angle 180/Compare To Constant'
//  '<S389>' : 'USV/SensorModel/HILGPSModel/GPSFault/Flat Earth to LLA/LatLong wrap/Wrap Longitude/Compare To Constant'
//  '<S390>' : 'USV/SensorModel/HILGPSModel/GPSFault/Flat Earth to LLA/LatLong wrap1/Latitude Wrap 90'
//  '<S391>' : 'USV/SensorModel/HILGPSModel/GPSFault/Flat Earth to LLA/LatLong wrap1/Wrap Longitude'
//  '<S392>' : 'USV/SensorModel/HILGPSModel/GPSFault/Flat Earth to LLA/LatLong wrap1/Latitude Wrap 90/Compare To Constant'
//  '<S393>' : 'USV/SensorModel/HILGPSModel/GPSFault/Flat Earth to LLA/LatLong wrap1/Latitude Wrap 90/Wrap Angle 180'
//  '<S394>' : 'USV/SensorModel/HILGPSModel/GPSFault/Flat Earth to LLA/LatLong wrap1/Latitude Wrap 90/Wrap Angle 180/Compare To Constant'
//  '<S395>' : 'USV/SensorModel/HILGPSModel/GPSFault/Flat Earth to LLA/LatLong wrap1/Wrap Longitude/Compare To Constant'
//  '<S396>' : 'USV/SensorModel/HILGPSModel/GPSFault/Flat Earth to LLA/LongLat_offset/Find Radian//Distance'
//  '<S397>' : 'USV/SensorModel/HILGPSModel/GPSFault/Flat Earth to LLA/LongLat_offset/rotation_rad'
//  '<S398>' : 'USV/SensorModel/HILGPSModel/GPSFault/Flat Earth to LLA/LongLat_offset/Find Radian//Distance/Angle Conversion2'
//  '<S399>' : 'USV/SensorModel/HILGPSModel/GPSFault/Flat Earth to LLA/LongLat_offset/Find Radian//Distance/denom'
//  '<S400>' : 'USV/SensorModel/HILGPSModel/GPSFault/Flat Earth to LLA/LongLat_offset/Find Radian//Distance/e'
//  '<S401>' : 'USV/SensorModel/HILGPSModel/GPSFault/Flat Earth to LLA/LongLat_offset/Find Radian//Distance/e^4'
//  '<S402>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem'
//  '<S403>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/AccelNoiseGainFunction'
//  '<S404>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/GyroNoiseGainFunction'
//  '<S405>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/MagNoiseGainFunction'
//  '<S406>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault'
//  '<S407>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/AccNoiseSwitch1'
//  '<S408>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/Dynamic Pressure'
//  '<S409>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/FaultParamsExtract'
//  '<S410>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/FaultParamsExtract1'
//  '<S411>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/FaultParamsExtract2'
//  '<S412>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/FaultParamsExtract3'
//  '<S413>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/GyroNoiseSwitch'
//  '<S414>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/GyroNoiseSwitch3'
//  '<S415>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/GyroNoiseSwitch4'
//  '<S416>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/ISA Atmosphere Model'
//  '<S417>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/MagNoiseSwitch'
//  '<S418>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/Three-axis Inertial Measurement Unit3'
//  '<S419>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015'
//  '<S420>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/baro NoiseFun'
//  '<S421>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/AccNoiseSwitch1/Acc NoiseFun'
//  '<S422>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/Dynamic Pressure/dot'
//  '<S423>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/GyroNoiseSwitch/Acc NoiseFun'
//  '<S424>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/MagNoiseSwitch/Acc NoiseFun'
//  '<S425>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/Three-axis Inertial Measurement Unit3/Acceleration Conversion'
//  '<S426>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Accelerometer'
//  '<S427>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Gyroscope'
//  '<S428>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Accelerometer/Dynamics'
//  '<S429>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Accelerometer/w x (w x d)'
//  '<S430>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Accelerometer/wdot x d'
//  '<S431>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Accelerometer/Dynamics/No Dynamics'
//  '<S432>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Accelerometer/Dynamics/Second-order Dynamics'
//  '<S433>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Accelerometer/w x (w x d)/w x (w x d)'
//  '<S434>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Accelerometer/w x (w x d)/w x d'
//  '<S435>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Accelerometer/w x (w x d)/w x (w x d)/Subsystem'
//  '<S436>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Accelerometer/w x (w x d)/w x (w x d)/Subsystem1'
//  '<S437>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Accelerometer/w x (w x d)/w x d/Subsystem'
//  '<S438>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Accelerometer/w x (w x d)/w x d/Subsystem1'
//  '<S439>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Accelerometer/wdot x d/Subsystem'
//  '<S440>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Accelerometer/wdot x d/Subsystem1'
//  '<S441>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Gyroscope/Dynamics'
//  '<S442>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Gyroscope/Dynamics/No Dynamics'
//  '<S443>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Gyroscope/Dynamics/Second-order Dynamics'
//  '<S444>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/Check Altitude'
//  '<S445>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/Check Latitude'
//  '<S446>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/Check Longitude'
//  '<S447>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/Compute x,y,z, and h components of magnetic field'
//  '<S448>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/Is time within model limits'
//  '<S449>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/LatLong wrap'
//  '<S450>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/Length Conversion'
//  '<S451>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/MagField Conversion'
//  '<S452>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/MagField Conversion1'
//  '<S453>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag'
//  '<S454>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/Compute x,y,z, and h components of magnetic field/Angle Conversion'
//  '<S455>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/LatLong wrap/Latitude Wrap 90'
//  '<S456>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/LatLong wrap/Wrap Longitude'
//  '<S457>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/LatLong wrap/Latitude Wrap 90/Compare To Constant'
//  '<S458>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/LatLong wrap/Latitude Wrap 90/Wrap Angle 180'
//  '<S459>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/LatLong wrap/Latitude Wrap 90/Wrap Angle 180/Compare To Constant'
//  '<S460>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/LatLong wrap/Wrap Longitude/Compare To Constant'
//  '<S461>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates'
//  '<S462>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Convert from geodetic to  spherical coordinates'
//  '<S463>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Convert from geodetic to  spherical coordinates '
//  '<S464>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Get Cosine and Sine  of Latitude and Longitude'
//  '<S465>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Has altitude or latitude changed'
//  '<S466>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Has longitude changed '
//  '<S467>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Has time changed'
//  '<S468>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Rotate magnetic vector components  to geodetic from spherical and  compute declination, inclination  and total intensity'
//  '<S469>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem'
//  '<S470>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Accumulate terms of the  spherical harmonic expansion'
//  '<S471>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations'
//  '<S472>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Time adjust the gauss coefficients'
//  '<S473>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Accumulate terms of the  spherical harmonic expansion/Special case - North//South Geographic Pole'
//  '<S474>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Accumulate terms of the  spherical harmonic expansion/calculate  index'
//  '<S475>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Accumulate terms of the  spherical harmonic expansion/calculate temp values'
//  '<S476>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Accumulate terms of the  spherical harmonic expansion/special case'
//  '<S477>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Accumulate terms of the  spherical harmonic expansion/Special case - North//South Geographic Pole/If Action Subsystem1'
//  '<S478>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Accumulate terms of the  spherical harmonic expansion/Special case - North//South Geographic Pole/If Action Subsystem2'
//  '<S479>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Accumulate terms of the  spherical harmonic expansion/Special case - North//South Geographic Pole/If Action Subsystem2/calculate  indices'
//  '<S480>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Accumulate terms of the  spherical harmonic expansion/Special case - North//South Geographic Pole/If Action Subsystem2/calculate  row and column'
//  '<S481>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Accumulate terms of the  spherical harmonic expansion/calculate temp values/If Action Subsystem'
//  '<S482>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Accumulate terms of the  spherical harmonic expansion/calculate temp values/If Action Subsystem1'
//  '<S483>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Accumulate terms of the  spherical harmonic expansion/calculate temp values/If Action Subsystem1/m,n'
//  '<S484>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Accumulate terms of the  spherical harmonic expansion/calculate temp values/If Action Subsystem1/n,m-1'
//  '<S485>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations/If Action Subsystem'
//  '<S486>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations/If Action Subsystem1'
//  '<S487>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations/If Action Subsystem2'
//  '<S488>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations/calculate  index'
//  '<S489>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations/If Action Subsystem/calculate  index'
//  '<S490>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations/If Action Subsystem/calculate  row and column'
//  '<S491>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations/If Action Subsystem1/calculate  index'
//  '<S492>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations/If Action Subsystem1/calculate  row and column'
//  '<S493>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations/If Action Subsystem2/calculate  indices'
//  '<S494>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations/If Action Subsystem2/calculate  row and column1'
//  '<S495>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations/If Action Subsystem2/calculate  row and column2'
//  '<S496>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations/If Action Subsystem2/m<n-2'
//  '<S497>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations/If Action Subsystem2/m<n-2 '
//  '<S498>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Time adjust the gauss coefficients/If Action Subsystem'
//  '<S499>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Time adjust the gauss coefficients/if (m~=0)'
//  '<S500>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Time adjust the gauss coefficients/if (m~=0)/If Action Subsystem1'
//  '<S501>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Time adjust the gauss coefficients/if (m~=0)/If Action Subsystem2'
//  '<S502>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Convert from geodetic to  spherical coordinates/calculate ca'
//  '<S503>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Convert from geodetic to  spherical coordinates/calculate ct'
//  '<S504>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Convert from geodetic to  spherical coordinates/calculate d'
//  '<S505>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Convert from geodetic to  spherical coordinates/calculate q'
//  '<S506>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Convert from geodetic to  spherical coordinates/calculate q2'
//  '<S507>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Convert from geodetic to  spherical coordinates/calculate r2'
//  '<S508>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Convert from geodetic to  spherical coordinates/calculate sa'
//  '<S509>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Convert from geodetic to  spherical coordinates/calculate st'
//  '<S510>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Convert from geodetic to  spherical coordinates /For Iterator Subsystem'
//  '<S511>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Get Cosine and Sine  of Latitude and Longitude/Angle Conversion2'
//  '<S512>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Rotate magnetic vector components  to geodetic from spherical and  compute declination, inclination  and total intensity/Calculate bx'
//  '<S513>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Rotate magnetic vector components  to geodetic from spherical and  compute declination, inclination  and total intensity/Calculate by'
//  '<S514>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Rotate magnetic vector components  to geodetic from spherical and  compute declination, inclination  and total intensity/Calculate bz'
//  '<S515>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Rotate magnetic vector components  to geodetic from spherical and  compute declination, inclination  and total intensity/Compute declination, inclination,  and total intensity'
//  '<S516>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Rotate magnetic vector components  to geodetic from spherical and  compute declination, inclination  and total intensity/Compute declination, inclination,  and total intensity/Angle Conversion'
//  '<S517>' : 'USV/SensorModel/HILSensorMavModel1/Subsystem/SensorFault/World Magnetic Model 2015/geomag/Rotate magnetic vector components  to geodetic from spherical and  compute declination, inclination  and total intensity/Compute declination, inclination,  and total intensity/Angle Conversion1'
//  '<S518>' : 'USV/SensorModel/HILStateMavModel/Dynamic Pressure'
//  '<S519>' : 'USV/SensorModel/HILStateMavModel/dot1'
//  '<S520>' : 'USV/SensorModel/HILStateMavModel/Dynamic Pressure/dot'

#endif                                 // RTW_HEADER_USV_h_

//
// File trailer for generated code.
//
// [EOF]
//
