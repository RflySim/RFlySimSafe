//
// File: FixedwingModel.h
//
// Code generated for Simulink model 'FixedwingModel'.
//
// Model version                  : 10.0
// Simulink Coder version         : 9.7 (R2022a) 13-Nov-2021
// C/C++ source code generated on : Tue Oct 18 15:33:03 2022
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_FixedwingModel_h_
#define RTW_HEADER_FixedwingModel_h_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include <cstring>
#include <cmath>
#include <stddef.h>

// Model Code Variants

// Macros for accessing real-time model data structure
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

// Forward declaration for rtModel
typedef struct tag_RTM_FixedwingModel_T RT_MODEL_FixedwingModel_T;

#ifndef DEFINED_TYPEDEF_FOR_MavVehileInfo_
#define DEFINED_TYPEDEF_FOR_MavVehileInfo_

struct MavVehileInfo
{
  int32_T copterID;
  int32_T vehicleType;
  real_T runnedTime;
  real32_T VelE[3];
  real32_T PosE[3];
  real32_T AngEuler[3];
  real32_T AngQuatern[4];
  real32_T MotorRPMS[8];
  real32_T AccB[3];
  real32_T RateB[3];
  real_T PosGPS[3];
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_MavLinkGPS_
#define DEFINED_TYPEDEF_FOR_MavLinkGPS_

struct MavLinkGPS
{
  uint32_T time_usec;
  int32_T lat;
  int32_T lon;
  int32_T alt;
  uint16_T eph;
  uint16_T epv;
  uint16_T vel;
  int16_T vn;
  int16_T ve;
  int16_T vd;
  uint16_T cog;
  uint8_T fix_type;
  uint8_T satellites_visible;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_HILGPS_
#define DEFINED_TYPEDEF_FOR_HILGPS_

struct HILGPS
{
  uint8_T fix_type;
  uint8_T satellites_visible;
  int32_T lat;
  int32_T lon;
  int32_T alt;
  uint32_T hAcc;
  uint32_T vAcc;
  int32_T velN;
  int32_T velE;
  int32_T velD;
  int32_T gSpeed;
  int32_T headMot;
  int32_T headVeh;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_MavLinkSensor_
#define DEFINED_TYPEDEF_FOR_MavLinkSensor_

struct MavLinkSensor
{
  uint32_T time_usec;
  real32_T xacc;
  real32_T yacc;
  real32_T zacc;
  real32_T xgyro;
  real32_T ygyro;
  real32_T zgyro;
  real32_T xmag;
  real32_T ymag;
  real32_T zmag;
  real32_T abs_pressure;
  real32_T diff_pressure;
  real32_T pressure_alt;
  real32_T temperature;
  uint32_T fields_updated;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_MavLinkStateQuat_
#define DEFINED_TYPEDEF_FOR_MavLinkStateQuat_

struct MavLinkStateQuat
{
  uint32_T time_usec;
  real32_T attitude_quaternion[4];
  real32_T rollspeed;
  real32_T pitchspeed;
  real32_T yawspeed;
  int32_T lat;
  int32_T lon;
  int32_T alt;
  int16_T vx;
  int16_T vy;
  int16_T vz;
  uint16_T ind_airspeed;
  uint16_T true_airspeed;
  int16_T xacc;
  int16_T yacc;
  int16_T zacc;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_pQS2n5LfNYssVkZ6clZuRD_
#define DEFINED_TYPEDEF_FOR_struct_pQS2n5LfNYssVkZ6clZuRD_

struct struct_pQS2n5LfNYssVkZ6clZuRD
{
  real_T FaultID;
  int32_T SteerNum;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_cC8C5MZV75wwVdzQ00rR7E_
#define DEFINED_TYPEDEF_FOR_struct_cC8C5MZV75wwVdzQ00rR7E_

struct struct_cC8C5MZV75wwVdzQ00rR7E
{
  real_T FaultInParams[32];
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_rHAf2Ncw266Lr5SdOUZ2fD_
#define DEFINED_TYPEDEF_FOR_struct_rHAf2Ncw266Lr5SdOUZ2fD_

struct struct_rHAf2Ncw266Lr5SdOUZ2fD
{
  real_T ConstWindFaultID;
  real_T GustWindFaultID;
  real_T TurbWindFaultID;
  real_T SheerWindFaultID;
  real_T NoiseWindFaultID;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_Pgy9ii6hzkRIywShcsrSAG_
#define DEFINED_TYPEDEF_FOR_struct_Pgy9ii6hzkRIywShcsrSAG_

struct struct_Pgy9ii6hzkRIywShcsrSAG
{
  real_T AccNoiseFaultID;
  real_T GyroNoiseFaultID;
  real_T MagNoiseFaultID;
  real_T BaroNoiseFaultID;
  real_T GPSNoiseFaultID;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_WviXPLxdKq6zu4cY2Dzal_
#define DEFINED_TYPEDEF_FOR_struct_WviXPLxdKq6zu4cY2Dzal_

struct struct_WviXPLxdKq6zu4cY2Dzal
{
  real_T span;
  real_T chord;
  real_T S;
  real_T elarm;
  real_T mass;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_4DpoEKxWTGrPnnQ0H36a0F_
#define DEFINED_TYPEDEF_FOR_struct_4DpoEKxWTGrPnnQ0H36a0F_

struct struct_4DpoEKxWTGrPnnQ0H36a0F
{
  real_T Ixx;
  real_T Iyy;
  real_T Izz;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_IVdt2OZSKf0hs7PThOqQKB_
#define DEFINED_TYPEDEF_FOR_struct_IVdt2OZSKf0hs7PThOqQKB_

struct struct_IVdt2OZSKf0hs7PThOqQKB
{
  real_T CL0;
  real_T CLa;
  real_T CLa_dot;
  real_T CLq;
  real_T CLDe;
  real_T CLDf;
  real_T CD0;
  real_T A1;
  real_T Apolar;
  real_T CYb;
  real_T CYDr;
  real_T Clb;
  real_T Clp;
  real_T Clr;
  real_T ClDa;
  real_T ClDr;
  real_T Cm0;
  real_T Cma;
  real_T Cma_dot;
  real_T Cmq;
  real_T CmDe;
  real_T CmDf;
  real_T Cnb;
  real_T Cnp;
  real_T Cnr;
  real_T CnDa;
  real_T CnDr;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_KipJoflCB6JCEUAdQsRLpC_
#define DEFINED_TYPEDEF_FOR_struct_KipJoflCB6JCEUAdQsRLpC_

struct struct_KipJoflCB6JCEUAdQsRLpC
{
  real_T MinThK;
  real_T ThK;
  real_T TFact;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_ki0Ew8I79ddW4bzORFl8sB_
#define DEFINED_TYPEDEF_FOR_struct_ki0Ew8I79ddW4bzORFl8sB_

struct struct_ki0Ew8I79ddW4bzORFl8sB
{
  real_T max;
  real_T min;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_Do5IOGuWVKTPIiQJKxeh1D_
#define DEFINED_TYPEDEF_FOR_struct_Do5IOGuWVKTPIiQJKxeh1D_

struct struct_Do5IOGuWVKTPIiQJKxeh1D
{
  real_T roll;
  real_T pitch;
  real_T yawrate;
  real_T tpercent;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_3PJJ4WLMHK1TvFiEKQocoD_
#define DEFINED_TYPEDEF_FOR_struct_3PJJ4WLMHK1TvFiEKQocoD_

struct struct_3PJJ4WLMHK1TvFiEKQocoD
{
  real_T Pos_0[3];
  real_T Euler_0[3];
  real_T Omega_0[3];
  real_T PQR_0[3];
  real_T Vb_0[3];
  real_T gsLL[2];
  real_T gsH;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_VNLjlAmEUjUhY2ZajRutz_
#define DEFINED_TYPEDEF_FOR_struct_VNLjlAmEUjUhY2ZajRutz_

struct struct_VNLjlAmEUjUhY2ZajRutz
{
  struct_WviXPLxdKq6zu4cY2Dzal geometry;
  struct_4DpoEKxWTGrPnnQ0H36a0F inertia;
  struct_IVdt2OZSKf0hs7PThOqQKB aero;
  struct_KipJoflCB6JCEUAdQsRLpC engine;
  struct_ki0Ew8I79ddW4bzORFl8sB elevator;
  struct_ki0Ew8I79ddW4bzORFl8sB aileron;
  struct_ki0Ew8I79ddW4bzORFl8sB rudder;
  struct_ki0Ew8I79ddW4bzORFl8sB flap;
  struct_ki0Ew8I79ddW4bzORFl8sB throttlepercent;
  struct_Do5IOGuWVKTPIiQJKxeh1D attitudectrlmax;
  struct_3PJJ4WLMHK1TvFiEKQocoD ic;
  real_T sampleTime;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_qYIpymaSbzHVkej1LIQGDH_
#define DEFINED_TYPEDEF_FOR_struct_qYIpymaSbzHVkej1LIQGDH_

struct struct_qYIpymaSbzHVkej1LIQGDH
{
  real_T ISA_lapse;
  real_T ISA_hmax;
  real_T ISA_R;
  real_T ISA_g;
  real_T ISA_rho0;
  real_T ISA_P0;
  real_T ISA_T0;
  real_T windBase;
  real_T windDirTurb;
  real_T windDirHor;
  real_T windOn;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_5j3ox25Rt05MdMcOAsLXzF_
#define DEFINED_TYPEDEF_FOR_struct_5j3ox25Rt05MdMcOAsLXzF_

struct struct_5j3ox25Rt05MdMcOAsLXzF
{
  real_T apSampleTime;
};

#endif

// Block signals for system '<S17>/Distance into gust (y)'
struct B_Distanceintogusty_Fixedwing_T {
  real_T DistanceintoGustxLimitedtogustl;
                  // '<S21>/Distance into Gust (x) (Limited to gust length d) '
};

// Block states (default storage) for system '<S17>/Distance into gust (y)'
struct DW_Distanceintogusty_Fixedwin_T {
  boolean_T Distanceintogusty_MODE;    // '<S17>/Distance into gust (y)'
};

// Continuous states for system '<S17>/Distance into gust (y)'
struct X_Distanceintogusty_Fixedwing_T {
  real_T DistanceintoGustxLimitedtogustl;
                  // '<S21>/Distance into Gust (x) (Limited to gust length d) '
};

// State derivatives for system '<S17>/Distance into gust (y)'
struct XDot_Distanceintogusty_Fixedw_T {
  real_T DistanceintoGustxLimitedtogustl;
                  // '<S21>/Distance into Gust (x) (Limited to gust length d) '
};

// State Disabled for system '<S17>/Distance into gust (y)'
struct XDis_Distanceintogusty_Fixedw_T {
  boolean_T DistanceintoGustxLimitedtogustl;
                  // '<S21>/Distance into Gust (x) (Limited to gust length d) '
};

// Block signals for system '<S15>/FaultParamsExtract'
struct B_FaultParamsExtract_Fixedwin_T {
  real_T FaultParam[20];               // '<S15>/FaultParamsExtract'
  boolean_T hasFault;                  // '<S15>/FaultParamsExtract'
};

// Block states (default storage) for system '<S15>/FaultParamsExtract'
struct DW_FaultParamsExtract_Fixedwi_T {
  real_T fParam[20];                   // '<S15>/FaultParamsExtract'
  boolean_T hFault;                    // '<S15>/FaultParamsExtract'
};

// Block signals for system '<S69>/Hpgw'
struct B_Hpgw_FixedwingModel_T {
  real_T UnitDelay[2];                 // '<S80>/Unit Delay'
  real_T Sum[2];                       // '<S80>/Sum'
};

// Block states (default storage) for system '<S69>/Hpgw'
struct DW_Hpgw_FixedwingModel_T {
  real_T UnitDelay_DSTATE[2];          // '<S80>/Unit Delay'
  boolean_T Hpgw_MODE;                 // '<S69>/Hpgw'
};

// Block signals for system '<S69>/Hqgw'
struct B_Hqgw_FixedwingModel_T {
  real_T dt1;                          // '<S81>/dt1'
  real_T Sum2;                         // '<S81>/Sum2'
  real_T LugV2[2];                     // '<S81>/Lug//V2'
  real_T UnitDelay1[2];                // '<S81>/Unit Delay1'
  real_T Sum1[2];                      // '<S81>/Sum1'
};

// Block states (default storage) for system '<S69>/Hqgw'
struct DW_Hqgw_FixedwingModel_T {
  real_T UnitDelay_DSTATE[2];          // '<S81>/Unit Delay'
  real_T UnitDelay1_DSTATE[2];         // '<S81>/Unit Delay1'
  boolean_T Hqgw_MODE;                 // '<S69>/Hqgw'
};

// Block signals for system '<S69>/Hrgw'
struct B_Hrgw_FixedwingModel_T {
  real_T dt1;                          // '<S82>/dt1'
  real_T Sum2;                         // '<S82>/Sum2'
  real_T LugV2[2];                     // '<S82>/Lug//V2'
  real_T UnitDelay1[2];                // '<S82>/Unit Delay1'
  real_T Sum1[2];                      // '<S82>/Sum1'
};

// Block states (default storage) for system '<S69>/Hrgw'
struct DW_Hrgw_FixedwingModel_T {
  real_T UnitDelay_DSTATE[2];          // '<S82>/Unit Delay'
  real_T UnitDelay1_DSTATE[2];         // '<S82>/Unit Delay1'
  boolean_T Hrgw_MODE;                 // '<S69>/Hrgw'
};

// Block signals for system '<S70>/Hugw(z)'
struct B_Hugwz_FixedwingModel_T {
  real_T UnitDelay[2];                 // '<S83>/Unit Delay'
  real_T Sum[2];                       // '<S83>/Sum'
};

// Block states (default storage) for system '<S70>/Hugw(z)'
struct DW_Hugwz_FixedwingModel_T {
  real_T UnitDelay_DSTATE[2];          // '<S83>/Unit Delay'
  boolean_T Hugwz_MODE;                // '<S70>/Hugw(z)'
};

// Block signals for system '<S70>/Hvgw(z)'
struct B_Hvgwz_FixedwingModel_T {
  real_T UnitDelay[2];                 // '<S84>/Unit Delay'
  real_T Sum[2];                       // '<S84>/Sum'
};

// Block states (default storage) for system '<S70>/Hvgw(z)'
struct DW_Hvgwz_FixedwingModel_T {
  real_T UnitDelay_DSTATE[2];          // '<S84>/Unit Delay'
  boolean_T Hvgwz_MODE;                // '<S70>/Hvgw(z)'
};

// Block signals for system '<S70>/Hwgw(z)'
struct B_Hwgwz_FixedwingModel_T {
  real_T UnitDelay[2];                 // '<S85>/Unit Delay'
  real_T Sum[2];                       // '<S85>/Sum'
};

// Block states (default storage) for system '<S70>/Hwgw(z)'
struct DW_Hwgwz_FixedwingModel_T {
  real_T UnitDelay_DSTATE[2];          // '<S85>/Unit Delay'
  boolean_T Hwgwz_MODE;                // '<S70>/Hwgw(z)'
};

// Block states (default storage) for system '<S151>/Negative Trace'
struct DW_NegativeTrace_FixedwingMod_T {
  int8_T FindMaximumDiagonalValue_Active;// '<S155>/Find Maximum Diagonal Value' 
};

// Block signals for system '<S227>/Acc NoiseFun'
struct B_AccNoiseFun_FixedwingModel_T {
  real_T y[3];                         // '<S227>/Acc NoiseFun'
};

// Block states (default storage) for system '<S369>/Negative Yaw'
struct DW_NegativeYaw_FixedwingModel_T {
  boolean_T NegativeYaw_MODE;          // '<S369>/Negative Yaw'
};

// Block states (default storage) for system '<S369>/Positive Yaw'
struct DW_PositiveYaw_FixedwingModel_T {
  boolean_T PositiveYaw_MODE;          // '<S369>/Positive Yaw'
};

// Block signals (default storage)
struct B_FixedwingModel_T {
  real_T MathFunction1;                // '<S149>/Math Function1'
  real_T Merge;                        // '<S369>/Merge'
  real_T Product[3];                   // '<S353>/Product'
  real_T Merge_c;                      // '<S525>/Merge'
  real_T xeyeze[3];                    // '<S341>/xe,ye,ze'
  real_T UnitConversion;               // '<S564>/Unit Conversion'
  real_T sigma_wg;                     // '<S545>/sigma_wg '
  real_T PreLookUpIndexSearchprobofexcee;
                          // '<S544>/PreLook-Up Index Search  (prob of exceed)'
  real_T Product_m[4];                 // '<S537>/Product'
  real_T UnitConversion_k;             // '<S526>/Unit Conversion'
  real_T Product1[3];                  // '<S523>/Product1'
  real_T Merge_l[4];                   // '<S410>/Merge'
  real_T Merge_lc[4];                  // '<S409>/Merge'
  real_T DataTypeConversion1[20];      // '<Root>/Data Type Conversion1'
  real_T SinCos_o1;                    // '<S31>/SinCos'
  real_T SinCos_o2;                    // '<S31>/SinCos'
  real_T Switch;                       // '<S39>/Switch'
  real_T TrigonometricFunction1;       // '<S45>/Trigonometric Function1'
  real_T TrigonometricFunction2;       // '<S45>/Trigonometric Function2'
  real_T Switch_d;                     // '<S40>/Switch'
  real_T MatrixConcatenate[3];         // '<S27>/Matrix Concatenate'
  real_T Gain[3];                      // '<S246>/Gain'
  real_T Selector1[9];                 // '<S347>/Selector1'
  real_T Selector[9];                  // '<S347>/Selector'
  real_T Selector2[9];                 // '<S347>/Selector2'
  real_T Product2[3];                  // '<S347>/Product2'
  real_T Gain10[3];                    // '<S226>/Gain10'
  real_T Gain6[3];                     // '<S226>/Gain6'
  real_T Switch_c;                     // '<S276>/Switch'
  real_T Switch_j;                     // '<S275>/Switch'
  real_T olat;                         // '<S285>/olat'
  real_T Gain_m;                       // '<S239>/Gain'
  real_T oalt;                         // '<S285>/oalt'
  real_T Gain11[3];                    // '<S226>/Gain11'
  real_T UniformRandomNumber[3];       // '<S28>/Uniform Random Number'
  real_T Sum1[3];                      // '<S28>/Sum1'
  real_T UnitConversion_g;             // '<S116>/Unit Conversion'
  real_T UnitConversion_d;             // '<S145>/Unit Conversion'
  real_T sigma_wg_o;                   // '<S126>/sigma_wg '
  real_T PreLookUpIndexSearchprobofexc_f;
                          // '<S125>/PreLook-Up Index Search  (prob of exceed)'
  real_T Product_p[4];                 // '<S118>/Product'
  real_T UnitConversion_kf;            // '<S107>/Unit Conversion'
  real_T UnitConversion_i;             // '<S77>/Unit Conversion'
  real_T UnitConversion_dt;            // '<S106>/Unit Conversion'
  real_T sigma_wg_e;                   // '<S87>/sigma_wg '
  real_T PreLookUpIndexSearchprobofexc_b;
                           // '<S86>/PreLook-Up Index Search  (prob of exceed)'
  real_T Product_a[4];                 // '<S79>/Product'
  real_T UnitConversion_c;             // '<S68>/Unit Conversion'
  real_T lnref_heightz0;               // '<S66>/ln(ref_height//z0)'
  real_T Windspeedatreferenceheight[3];
                                      // '<S66>/Wind speed at reference height'
  real_T Product4;                     // '<S234>/Product4'
  real_T Product4_l;                   // '<S235>/Product4'
  real_T BiasGain2[3];                 // '<S194>/BiasGain2'
  real_T SinCos_o1_o;                  // '<S202>/SinCos'
  real_T SinCos_o2_c;                  // '<S202>/SinCos'
  real_T Switch_l;                     // '<S210>/Switch'
  real_T TrigonometricFunction1_m;     // '<S216>/Trigonometric Function1'
  real_T TrigonometricFunction2_n;     // '<S216>/Trigonometric Function2'
  real_T Switch_h;                     // '<S211>/Switch'
  real_T Merge_m[4];                   // '<S151>/Merge'
  real_T Gain_l;                       // '<S15>/Gain'
  real_T Sum2;                         // '<S10>/Sum2'
  real_T Sum2_k;                       // '<S11>/Sum2'
  real_T Sum2_p;                       // '<S12>/Sum2'
  real_T Sum2_g;                       // '<S13>/Sum2'
  real_T Sum2_l;                       // '<S14>/Sum2'
  real_T UnitConversion_ck;            // '<S72>/Unit Conversion'
  real_T UnitConversion_m;             // '<S111>/Unit Conversion'
  real_T BiasGain1[3];                 // '<S152>/BiasGain1'
  real_T Sum2_o[3];                    // '<S252>/Sum2'
  real_T Sum2_pq[3];                   // '<S263>/Sum2'
  real_T TmpSignalConversionAtphithetaps[3];// '<S346>/phidot thetadot psidot'
  real_T Sum_c[3];                     // '<S341>/Sum'
  real_T ZeroOrderHold2;               // '<S345>/Zero-Order Hold2'
  real_T Gain_c[3];                    // '<S345>/Gain'
  real_T Sum2_j[3];                    // '<S512>/Sum2'
  real_T UnitConversion_i3;            // '<S530>/Unit Conversion'
  real_T w[2];                         // '<S543>/w'
  real_T sqrt_f;                       // '<S543>/sqrt'
  real_T LwgV1[2];                     // '<S543>/Lwg//V 1'
  real_T w_m[2];                       // '<S543>/w '
  real_T w_f[2];                       // '<S542>/w'
  real_T w_d[2];                       // '<S542>/w '
  real_T w1[2];                        // '<S542>/w 1'
  real_T w_a[2];                       // '<S541>/w'
  real_T w1_f[2];                      // '<S541>/w1'
  real_T w_b[2];                       // '<S540>/w'
  real_T UnaryMinus[2];                // '<S540>/Unary Minus'
  real_T w_d0[2];                      // '<S539>/w'
  real_T w4;                           // '<S538>/w4'
  real_T u16;                          // '<S538>/u^1//6'
  real_T sigma_w[2];                   // '<S538>/sigma_w'
  real_T w_e[2];                       // '<S538>/w'
  real_T F1[3];                        // '<S344>/Ground Model'
  real_T M1[3];                        // '<S344>/Ground Model'
  real_T Incidence;                    // '<S371>/Incidence'
  real_T y;                            // '<S226>/baro NoiseFun'
  real_T Gain_d[11];                   // '<S283>/Gain'
  real_T Gain1[11];                    // '<S283>/Gain1'
  real_T OutportBufferForcp13[13];
  real_T OutportBufferForsp13[13];
  real_T b2;                           // '<S282>/b2'
  real_T a2;                           // '<S282>/a2'
  real_T c2;                           // '<S325>/Sum1'
  real_T a4;                           // '<S327>/a4'
  real_T c4;                           // '<S327>/Sum9'
  real_T sqrt_d;                       // '<S282>/sqrt'
  real_T Product11;                    // '<S322>/Product11'
  real_T Product4_a;                   // '<S323>/Product4'
  real_T c2_n;                         // '<S328>/Sum1'
  real_T Product12;                    // '<S328>/Product12'
  real_T sqrt_j;                       // '<S329>/sqrt'
  real_T Sum1_k[4];                    // '<S281>/Sum1'
  real_T Sum1_m;                       // '<S290>/Sum1'
  real_T Sum2_h;                       // '<S290>/Sum2'
  real_T Sum3;                         // '<S290>/Sum3'
  real_T Sum5;                         // '<S290>/Sum5'
  real_T Assignment[169];              // '<S292>/Assignment'
  real_T Sum2_gf[169];                 // '<S292>/Sum2'
  real_T Assignment2[169];             // '<S320>/Assignment2'
  real_T Merge1_o;                     // '<S291>/Merge1'
  real_T Assignment_p[169];            // '<S291>/Assignment'
  real_T Merge_h;                      // '<S291>/Merge'
  real_T Assignment_snorm[169];        // '<S291>/Assignment_snorm'
  real_T Product2_h;                   // '<S293>/Product2'
  real_T Assignment2_g[13];            // '<S298>/Assignment2'
  real_T Assignment2_c[13];            // '<S297>/Assignment2'
  real_T yNoise[3];                    // '<S199>/MATLAB Function'
  real_T gWind[3];                     // '<S28>/MATLAB Function'
  real_T FaultParam[20];               // '<S28>/FaultParamsExtract3'
  real_T FaultParam_a[20];             // '<S28>/FaultParamsExtract2'
  real_T FaultParam_d[20];             // '<S28>/FaultParamsExtract1'
  real_T FaultParam_af[20];            // '<S28>/FaultParamsExtract'
  real_T fm[6];                        // '<Root>/CollisionDetection'
  real_T y_f[5];                       // '<S15>/SteerEngineFaultModel'
  real_T DistanceintoGustxLimitedtogustl;
                   // '<S20>/Distance into Gust (x) (Limited to gust length d)'
  uint32_T PreLookUpIndexSearchprobofexc_h;
                          // '<S544>/PreLook-Up Index Search  (prob of exceed)'
  uint32_T PreLookUpIndexSearchprobofex_ft;
                          // '<S125>/PreLook-Up Index Search  (prob of exceed)'
  uint32_T PreLookUpIndexSearchprobofex_f4;
                           // '<S86>/PreLook-Up Index Search  (prob of exceed)'
  uint32_T fields_updated;             // '<S153>/Data Type Conversion6'
  int32_T copterID;                    // '<S7>/Data Type Conversion'
  int32_T vehicleType;                 // '<S7>/Data Type Conversion2'
  uint16_T eph;                        // '<S152>/Data Type Conversion8'
  uint16_T epv;                        // '<S152>/Data Type Conversion9'
  uint8_T HiddenBuf_InsertedFor_PositiveY;// '<S369>/Compare To Zero'
  uint8_T HiddenBuf_InsertedFor_Positiv_n;// '<S525>/Compare To Zero'
  uint8_T fix_type;                    // '<S152>/Data Type Conversion10'
  uint8_T satellites_visible;          // '<S152>/Data Type Conversion11'
  boolean_T HiddenBuf_InsertedFor_NegativeY;// '<S369>/Logical Operator'
  boolean_T HiddenBuf_InsertedFor_Negativ_e;// '<S525>/Logical Operator'
  boolean_T HiddenBuf_InsertedFor_Distanc_b;// '<S17>/Logical Operator1'
  boolean_T HiddenBuf_InsertedFor_Distanc_a;// '<S17>/Logical Operator3'
  boolean_T hasFault_SheerWind;        // '<S28>/FaultParamsExtract3'
  boolean_T hasFault_TurbWind;         // '<S28>/FaultParamsExtract2'
  boolean_T hasFault_GustWind;         // '<S28>/FaultParamsExtract1'
  boolean_T hasFault_ConstWind;        // '<S28>/FaultParamsExtract'
  B_AccNoiseFun_FixedwingModel_T sf_AccNoiseFun_e;// '<S237>/Acc NoiseFun'
  B_AccNoiseFun_FixedwingModel_T sf_AccNoiseFun_p;// '<S233>/Acc NoiseFun'
  B_AccNoiseFun_FixedwingModel_T sf_AccNoiseFun;// '<S227>/Acc NoiseFun'
  B_FaultParamsExtract_Fixedwin_T sf_FaultParamsExtract_d;// '<S194>/FaultParamsExtract' 
  B_Hwgwz_FixedwingModel_T Hwgwz_j;    // '<S109>/Hwgw(z)'
  B_Hvgwz_FixedwingModel_T Hvgwz_o;    // '<S109>/Hvgw(z)'
  B_Hugwz_FixedwingModel_T Hugwz_l;    // '<S109>/Hugw(z)'
  B_Hrgw_FixedwingModel_T Hrgw_a;      // '<S108>/Hrgw'
  B_Hqgw_FixedwingModel_T Hqgw_p;      // '<S108>/Hqgw'
  B_Hpgw_FixedwingModel_T Hpgw_h;      // '<S108>/Hpgw'
  B_Hwgwz_FixedwingModel_T Hwgwz;      // '<S70>/Hwgw(z)'
  B_Hvgwz_FixedwingModel_T Hvgwz;      // '<S70>/Hvgw(z)'
  B_Hugwz_FixedwingModel_T Hugwz;      // '<S70>/Hugw(z)'
  B_Hrgw_FixedwingModel_T Hrgw;        // '<S69>/Hrgw'
  B_Hqgw_FixedwingModel_T Hqgw;        // '<S69>/Hqgw'
  B_Hpgw_FixedwingModel_T Hpgw;        // '<S69>/Hpgw'
  B_FaultParamsExtract_Fixedwin_T sf_FaultParamsExtract;// '<S15>/FaultParamsExtract' 
  B_Distanceintogusty_Fixedwing_T Distanceintogustz;// '<S17>/Distance into gust (z)' 
  B_Distanceintogusty_Fixedwing_T Distanceintogusty;// '<S17>/Distance into gust (y)' 
};

// Block states (default storage) for system '<Root>'
struct DW_FixedwingModel_T {
  real_T UnitDelay1_DSTATE[2];         // '<S330>/Unit Delay1'
  real_T UnitDelay_DSTATE_i[169];      // '<S292>/Unit Delay'
  real_T UnitDelay_DSTATE_k[169];      // '<S319>/Unit Delay'
  real_T UnitDelay_DSTATE_h[169];      // '<S291>/Unit Delay'
  real_T UnitDelay1_DSTATE_e[169];     // '<S291>/Unit Delay1'
  real_T UnitDelay1_DSTATE_h[13];      // '<S293>/Unit Delay1'
  real_T NextOutput[4];                // '<S537>/White Noise'
  real_T WGS84GravitySFunction_h;      // '<S27>/WGS84 Gravity S-Function'
  real_T WGS84GravitySFunction_phi;    // '<S27>/WGS84 Gravity S-Function'
  real_T WGS84GravitySFunction_lambda; // '<S27>/WGS84 Gravity S-Function'
  real_T WGS84GravitySFunction_gamma_h;// '<S27>/WGS84 Gravity S-Function'
  real_T WGS84GravitySFunction_gamma_phi;// '<S27>/WGS84 Gravity S-Function'
  real_T Product2_DWORK4[9];           // '<S347>/Product2'
  real_T UniformRandomNumber5_NextOutput[3];// '<S226>/Uniform Random Number5'
  real_T UniformRandomNumber1_NextOutput[3];// '<S226>/Uniform Random Number1'
  real_T otime_PreviousInput;          // '<S287>/otime'
  real_T olon_PreviousInput;           // '<S286>/olon'
  real_T olat_PreviousInput;           // '<S285>/olat'
  real_T oalt_PreviousInput;           // '<S285>/oalt'
  real_T UniformRandomNumber7_NextOutput[3];// '<S226>/Uniform Random Number7'
  real_T UniformRandomNumber_NextOutput[3];// '<S28>/Uniform Random Number'
  real_T NextOutput_c[4];              // '<S118>/White Noise'
  real_T NextOutput_b[4];              // '<S79>/White Noise'
  real_T UniformRandomNumber_NextOutpu_a;// '<S226>/Uniform Random Number'
  real_T UniformRandomNumber4_NextOutput;// '<S226>/Uniform Random Number4'
  real_T UniformRandomNumber5_NextOutp_j[3];// '<S194>/Uniform Random Number5'
  real_T NextOutput_p;                 // '<S16>/White Noise'
  real_T UniformRandomNumber4_NextOutp_l[3];// '<S152>/Uniform Random Number4'
  real_T fParam[20];                   // '<S226>/FaultParamsExtract3'
  real_T fParam_g[20];                 // '<S226>/FaultParamsExtract2'
  real_T fParam_e[20];                 // '<S226>/FaultParamsExtract1'
  real_T fParam_o[20];                 // '<S226>/FaultParamsExtract'
  real_T lastZ;                        // '<Root>/MATLAB Function'
  real_T t0;                           // '<S28>/MATLAB Function'
  real_T isInGust;                     // '<S28>/MATLAB Function'
  real_T t1;                           // '<S28>/MATLAB Function'
  real_T a;                            // '<S28>/MATLAB Function'
  real_T ang;                          // '<S28>/MATLAB Function'
  real_T wlast;                        // '<S28>/MATLAB Function'
  real_T wNow;                         // '<S28>/MATLAB Function'
  real_T fParam_p[20];                 // '<S28>/FaultParamsExtract4'
  real_T fParam_l[20];                 // '<S28>/FaultParamsExtract3'
  real_T fParam_p1[20];                // '<S28>/FaultParamsExtract2'
  real_T fParam_c[20];                 // '<S28>/FaultParamsExtract1'
  real_T fParam_ou[20];                // '<S28>/FaultParamsExtract'
  real_T fOut[6];                      // '<Root>/CollisionDetection'
  real_T mv0[3];                       // '<Root>/CollisionDetection'
  real_T tColi;                        // '<Root>/CollisionDetection'
  uint32_T PreLookUpIndexSearchaltitude_DW;
                                // '<S544>/PreLook-Up Index Search  (altitude)'
  uint32_T PreLookUpIndexSearchprobofexcee;
                          // '<S544>/PreLook-Up Index Search  (prob of exceed)'
  uint32_T RandSeed[4];                // '<S537>/White Noise'
  uint32_T RandSeed_a[3];              // '<S226>/Uniform Random Number5'
  uint32_T RandSeed_j[3];              // '<S226>/Uniform Random Number1'
  uint32_T RandSeed_p[3];              // '<S226>/Uniform Random Number7'
  uint32_T RandSeed_h[3];              // '<S28>/Uniform Random Number'
  uint32_T PreLookUpIndexSearchaltitude__m;
                                // '<S125>/PreLook-Up Index Search  (altitude)'
  uint32_T PreLookUpIndexSearchprobofexc_k;
                          // '<S125>/PreLook-Up Index Search  (prob of exceed)'
  uint32_T RandSeed_ab[4];             // '<S118>/White Noise'
  uint32_T PreLookUpIndexSearchaltitude__f;
                                 // '<S86>/PreLook-Up Index Search  (altitude)'
  uint32_T PreLookUpIndexSearchprobofexc_o;
                           // '<S86>/PreLook-Up Index Search  (prob of exceed)'
  uint32_T RandSeed_ah[4];             // '<S79>/White Noise'
  uint32_T RandSeed_c;                 // '<S226>/Uniform Random Number'
  uint32_T RandSeed_m;                 // '<S226>/Uniform Random Number4'
  uint32_T RandSeed_d[3];              // '<S194>/Uniform Random Number5'
  uint32_T RandSeed_ph;                // '<S16>/White Noise'
  uint32_T RandSeed_as[3];             // '<S152>/Uniform Random Number4'
  uint32_T method;                     // '<S28>/MATLAB Function'
  uint32_T state;                      // '<S28>/MATLAB Function'
  uint32_T state_b[2];                 // '<S28>/MATLAB Function'
  uint32_T state_a[625];               // '<S28>/MATLAB Function'
  uint32_T method_o;                   // '<Root>/CollisionDetection'
  uint32_T state_n;                    // '<Root>/CollisionDetection'
  uint32_T state_an[2];                // '<Root>/CollisionDetection'
  uint32_T state_k[625];               // '<Root>/CollisionDetection'
  int_T IntegratorSecondOrderLimited_MO[3];
                                   // '<S252>/Integrator, Second-Order Limited'
  int_T IntegratorSecondOrder_MODE;    // '<S10>/Integrator, Second-Order'
  int_T IntegratorSecondOrder_MODE_j;  // '<S14>/Integrator, Second-Order'
  int_T IntegratorSecondOrder_MODE_d;  // '<S11>/Integrator, Second-Order'
  int_T IntegratorSecondOrder_MODE_c;  // '<S12>/Integrator, Second-Order'
  int_T IntegratorSecondOrder_MODE_p;  // '<S13>/Integrator, Second-Order'
  int_T IntegratorSecondOrderLimited__o[3];
                                   // '<S263>/Integrator, Second-Order Limited'
  int_T IntegratorSecondOrderLimited__c[3];
                                   // '<S512>/Integrator, Second-Order Limited'
  int8_T ifHeightMaxlowaltitudeelseifHei;
  // '<S533>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 
  int8_T If_ActiveSubsystem;           // '<S410>/If'
  int8_T If_ActiveSubsystem_n;         // '<S409>/If'
  int8_T ifHeightMaxlowaltitudeelseifH_l;
  // '<S114>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 
  int8_T ifHeightMaxlowaltitudeelseifH_h;
  // '<S75>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 
  int8_T If_ActiveSubsystem_j;         // '<S151>/If'
  int8_T ifHeightMaxlowaltitudeelseifH_j;
  // '<S74>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 
  int8_T ifHeightMaxlowaltitudeelseifH_g;
  // '<S113>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 
  int8_T If1_ActiveSubsystem;          // '<S157>/If1'
  int8_T If1_ActiveSubsystem_o;        // '<S418>/If1'
  int8_T If1_ActiveSubsystem_oz;       // '<S456>/If1'
  int8_T ifHeightMaxlowaltitudeelseif_j4;
  // '<S532>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 
  int8_T takeoffFlag;                  // '<S344>/Ground Model'
  int8_T landFlag;                     // '<S344>/Ground Model'
  int8_T isCol;                        // '<Root>/CollisionDetection'
  boolean_T IntegratorSecondOrderLimited_DW;
                                   // '<S252>/Integrator, Second-Order Limited'
  boolean_T IntegratorSecondOrder_DWORK1;// '<S10>/Integrator, Second-Order'
  boolean_T IntegratorSecondOrder_DWORK1_f;// '<S14>/Integrator, Second-Order'
  boolean_T IntegratorSecondOrder_DWORK1_c;// '<S11>/Integrator, Second-Order'
  boolean_T IntegratorSecondOrder_DWORK1_e;// '<S12>/Integrator, Second-Order'
  boolean_T IntegratorSecondOrder_DWORK1_g;// '<S13>/Integrator, Second-Order'
  boolean_T IntegratorSecondOrderLimited__a;
                                   // '<S263>/Integrator, Second-Order Limited'
  boolean_T IntegratorSecondOrderLimited_oq;
                                   // '<S512>/Integrator, Second-Order Limited'
  boolean_T hFault;                    // '<S226>/FaultParamsExtract3'
  boolean_T hFault_j;                  // '<S226>/FaultParamsExtract2'
  boolean_T hFault_k;                  // '<S226>/FaultParamsExtract1'
  boolean_T hFault_a;                  // '<S226>/FaultParamsExtract'
  boolean_T wlast_not_empty;           // '<S28>/MATLAB Function'
  boolean_T wNow_not_empty;            // '<S28>/MATLAB Function'
  boolean_T hFault_d;                  // '<S28>/FaultParamsExtract4'
  boolean_T hFault_f;                  // '<S28>/FaultParamsExtract3'
  boolean_T hFault_kb;                 // '<S28>/FaultParamsExtract2'
  boolean_T hFault_m;                  // '<S28>/FaultParamsExtract1'
  boolean_T hFault_b;                  // '<S28>/FaultParamsExtract'
  boolean_T Hwgws_MODE;                // '<S528>/Hwgw(s)'
  boolean_T Hvgws_MODE;                // '<S528>/Hvgw(s)'
  boolean_T Hugws_MODE;                // '<S528>/Hugw(s)'
  boolean_T Hrgw_MODE;                 // '<S527>/Hrgw'
  boolean_T Hqgw_MODE;                 // '<S527>/Hqgw'
  boolean_T Hpgw_MODE;                 // '<S527>/Hpgw'
  boolean_T Convertfromgeodetictosphericalc;
                   // '<S273>/Convert from geodetic to  spherical coordinates '
  boolean_T Convertfromgeodetictospherica_f;
                    // '<S273>/Convert from geodetic to  spherical coordinates'
  boolean_T SpecialcaseNorthSouthGeographic;
                        // '<S290>/Special case - North//South Geographic Pole'
  boolean_T Distanceintogustx_MODE;    // '<S17>/Distance into gust (x)'
  DW_PositiveYaw_FixedwingModel_T PositiveYaw_i;// '<S525>/Positive Yaw'
  DW_NegativeYaw_FixedwingModel_T NegativeYaw_d;// '<S525>/Negative Yaw'
  DW_NegativeTrace_FixedwingMod_T NegativeTrace_a;// '<S410>/Negative Trace'
  DW_NegativeTrace_FixedwingMod_T NegativeTrace_j;// '<S409>/Negative Trace'
  DW_PositiveYaw_FixedwingModel_T PositiveYaw;// '<S369>/Positive Yaw'
  DW_NegativeYaw_FixedwingModel_T NegativeYaw;// '<S369>/Negative Yaw'
  DW_FaultParamsExtract_Fixedwi_T sf_FaultParamsExtract_d;// '<S194>/FaultParamsExtract' 
  DW_NegativeTrace_FixedwingMod_T NegativeTrace;// '<S151>/Negative Trace'
  DW_Hwgwz_FixedwingModel_T Hwgwz_j;   // '<S109>/Hwgw(z)'
  DW_Hvgwz_FixedwingModel_T Hvgwz_o;   // '<S109>/Hvgw(z)'
  DW_Hugwz_FixedwingModel_T Hugwz_l;   // '<S109>/Hugw(z)'
  DW_Hrgw_FixedwingModel_T Hrgw_a;     // '<S108>/Hrgw'
  DW_Hqgw_FixedwingModel_T Hqgw_p;     // '<S108>/Hqgw'
  DW_Hpgw_FixedwingModel_T Hpgw_h;     // '<S108>/Hpgw'
  DW_Hwgwz_FixedwingModel_T Hwgwz;     // '<S70>/Hwgw(z)'
  DW_Hvgwz_FixedwingModel_T Hvgwz;     // '<S70>/Hvgw(z)'
  DW_Hugwz_FixedwingModel_T Hugwz;     // '<S70>/Hugw(z)'
  DW_Hrgw_FixedwingModel_T Hrgw;       // '<S69>/Hrgw'
  DW_Hqgw_FixedwingModel_T Hqgw;       // '<S69>/Hqgw'
  DW_Hpgw_FixedwingModel_T Hpgw;       // '<S69>/Hpgw'
  DW_FaultParamsExtract_Fixedwi_T sf_FaultParamsExtract;// '<S15>/FaultParamsExtract' 
  DW_Distanceintogusty_Fixedwin_T Distanceintogustz;// '<S17>/Distance into gust (z)' 
  DW_Distanceintogusty_Fixedwin_T Distanceintogusty;// '<S17>/Distance into gust (y)' 
};

// Continuous states (default storage)
struct X_FixedwingModel_T {
  real_T IntegratorSecondOrderLimited_CS[6];
                                   // '<S252>/Integrator, Second-Order Limited'
  real_T IntegratorSecondOrder_CSTATE[2];// '<S10>/Integrator, Second-Order'
  real_T phithetapsi_CSTATE[3];        // '<S346>/phi theta psi'
  real_T ubvbwb_CSTATE[3];             // '<S341>/ub,vb,wb'
  real_T xeyeze_CSTATE[3];             // '<S341>/xe,ye,ze'
  real_T TransferFcn_CSTATE;           // '<S366>/Transfer Fcn'
  real_T TransferFcn_CSTATE_n;         // '<S384>/Transfer Fcn'
  real_T IntegratorSecondOrder_CSTATE_e[2];// '<S14>/Integrator, Second-Order'
  real_T IntegratorSecondOrder_CSTATE_k[2];// '<S11>/Integrator, Second-Order'
  real_T pqr_CSTATE[3];                // '<S341>/p,q,r '
  real_T IntegratorSecondOrder_CSTATE_a[2];// '<S12>/Integrator, Second-Order'
  real_T IntegratorSecondOrder_CSTATE_h[2];// '<S13>/Integrator, Second-Order'
  real_T IntegratorSecondOrderLimited__d[6];
                                   // '<S263>/Integrator, Second-Order Limited'
  real_T TransferFcn4_CSTATE;          // '<S196>/Transfer Fcn4'
  real_T TransferFcn1_CSTATE;          // '<S196>/Transfer Fcn1'
  real_T TransferFcn2_CSTATE;          // '<S196>/Transfer Fcn2'
  real_T IntegratorSecondOrderLimited__o[6];
                                   // '<S512>/Integrator, Second-Order Limited'
  real_T wg_p1_CSTATE[2];              // '<S543>/wg_p1'
  real_T wg_p2_CSTATE[2];              // '<S543>/wg_p2'
  real_T vg_p1_CSTATE[2];              // '<S542>/vg_p1'
  real_T vgw_p2_CSTATE[2];             // '<S542>/vgw_p2'
  real_T ug_p_CSTATE[2];               // '<S541>/ug_p'
  real_T rgw_p_CSTATE[2];              // '<S540>/rgw_p'
  real_T qgw_p_CSTATE[2];              // '<S539>/qgw_p'
  real_T pgw_p_CSTATE[2];              // '<S538>/pgw_p'
  X_Distanceintogusty_Fixedwing_T Distanceintogustz;// '<S17>/Distance into gust (y)' 
  X_Distanceintogusty_Fixedwing_T Distanceintogusty;// '<S17>/Distance into gust (y)' 
  real_T DistanceintoGustxLimitedtogus_i;
                   // '<S20>/Distance into Gust (x) (Limited to gust length d)'
};

// Periodic continuous state vector (global)
typedef int_T PeriodicIndX_FixedwingModel_T[3];
typedef real_T PeriodicRngX_FixedwingModel_T[6];

// State derivatives (default storage)
struct XDot_FixedwingModel_T {
  real_T IntegratorSecondOrderLimited_CS[6];
                                   // '<S252>/Integrator, Second-Order Limited'
  real_T IntegratorSecondOrder_CSTATE[2];// '<S10>/Integrator, Second-Order'
  real_T phithetapsi_CSTATE[3];        // '<S346>/phi theta psi'
  real_T ubvbwb_CSTATE[3];             // '<S341>/ub,vb,wb'
  real_T xeyeze_CSTATE[3];             // '<S341>/xe,ye,ze'
  real_T TransferFcn_CSTATE;           // '<S366>/Transfer Fcn'
  real_T TransferFcn_CSTATE_n;         // '<S384>/Transfer Fcn'
  real_T IntegratorSecondOrder_CSTATE_e[2];// '<S14>/Integrator, Second-Order'
  real_T IntegratorSecondOrder_CSTATE_k[2];// '<S11>/Integrator, Second-Order'
  real_T pqr_CSTATE[3];                // '<S341>/p,q,r '
  real_T IntegratorSecondOrder_CSTATE_a[2];// '<S12>/Integrator, Second-Order'
  real_T IntegratorSecondOrder_CSTATE_h[2];// '<S13>/Integrator, Second-Order'
  real_T IntegratorSecondOrderLimited__d[6];
                                   // '<S263>/Integrator, Second-Order Limited'
  real_T TransferFcn4_CSTATE;          // '<S196>/Transfer Fcn4'
  real_T TransferFcn1_CSTATE;          // '<S196>/Transfer Fcn1'
  real_T TransferFcn2_CSTATE;          // '<S196>/Transfer Fcn2'
  real_T IntegratorSecondOrderLimited__o[6];
                                   // '<S512>/Integrator, Second-Order Limited'
  real_T wg_p1_CSTATE[2];              // '<S543>/wg_p1'
  real_T wg_p2_CSTATE[2];              // '<S543>/wg_p2'
  real_T vg_p1_CSTATE[2];              // '<S542>/vg_p1'
  real_T vgw_p2_CSTATE[2];             // '<S542>/vgw_p2'
  real_T ug_p_CSTATE[2];               // '<S541>/ug_p'
  real_T rgw_p_CSTATE[2];              // '<S540>/rgw_p'
  real_T qgw_p_CSTATE[2];              // '<S539>/qgw_p'
  real_T pgw_p_CSTATE[2];              // '<S538>/pgw_p'
  XDot_Distanceintogusty_Fixedw_T Distanceintogustz;// '<S17>/Distance into gust (y)' 
  XDot_Distanceintogusty_Fixedw_T Distanceintogusty;// '<S17>/Distance into gust (y)' 
  real_T DistanceintoGustxLimitedtogus_i;
                   // '<S20>/Distance into Gust (x) (Limited to gust length d)'
};

// State disabled
struct XDis_FixedwingModel_T {
  boolean_T IntegratorSecondOrderLimited_CS[6];
                                   // '<S252>/Integrator, Second-Order Limited'
  boolean_T IntegratorSecondOrder_CSTATE[2];// '<S10>/Integrator, Second-Order'
  boolean_T phithetapsi_CSTATE[3];     // '<S346>/phi theta psi'
  boolean_T ubvbwb_CSTATE[3];          // '<S341>/ub,vb,wb'
  boolean_T xeyeze_CSTATE[3];          // '<S341>/xe,ye,ze'
  boolean_T TransferFcn_CSTATE;        // '<S366>/Transfer Fcn'
  boolean_T TransferFcn_CSTATE_n;      // '<S384>/Transfer Fcn'
  boolean_T IntegratorSecondOrder_CSTATE_e[2];// '<S14>/Integrator, Second-Order' 
  boolean_T IntegratorSecondOrder_CSTATE_k[2];// '<S11>/Integrator, Second-Order' 
  boolean_T pqr_CSTATE[3];             // '<S341>/p,q,r '
  boolean_T IntegratorSecondOrder_CSTATE_a[2];// '<S12>/Integrator, Second-Order' 
  boolean_T IntegratorSecondOrder_CSTATE_h[2];// '<S13>/Integrator, Second-Order' 
  boolean_T IntegratorSecondOrderLimited__d[6];
                                   // '<S263>/Integrator, Second-Order Limited'
  boolean_T TransferFcn4_CSTATE;       // '<S196>/Transfer Fcn4'
  boolean_T TransferFcn1_CSTATE;       // '<S196>/Transfer Fcn1'
  boolean_T TransferFcn2_CSTATE;       // '<S196>/Transfer Fcn2'
  boolean_T IntegratorSecondOrderLimited__o[6];
                                   // '<S512>/Integrator, Second-Order Limited'
  boolean_T wg_p1_CSTATE[2];           // '<S543>/wg_p1'
  boolean_T wg_p2_CSTATE[2];           // '<S543>/wg_p2'
  boolean_T vg_p1_CSTATE[2];           // '<S542>/vg_p1'
  boolean_T vgw_p2_CSTATE[2];          // '<S542>/vgw_p2'
  boolean_T ug_p_CSTATE[2];            // '<S541>/ug_p'
  boolean_T rgw_p_CSTATE[2];           // '<S540>/rgw_p'
  boolean_T qgw_p_CSTATE[2];           // '<S539>/qgw_p'
  boolean_T pgw_p_CSTATE[2];           // '<S538>/pgw_p'
  XDis_Distanceintogusty_Fixedw_T Distanceintogustz;// '<S17>/Distance into gust (y)' 
  XDis_Distanceintogusty_Fixedw_T Distanceintogusty;// '<S17>/Distance into gust (y)' 
  boolean_T DistanceintoGustxLimitedtogus_i;
                   // '<S20>/Distance into Gust (x) (Limited to gust length d)'
};

#ifndef ODE4_INTG
#define ODE4_INTG

// ODE4 Integration Data
struct ODE4_IntgData {
  real_T *y;                           // output
  real_T *f[4];                        // derivatives
};

#endif

// External inputs (root inport signals with default storage)
struct ExtU_FixedwingModel_T {
  real_T inPWMs[16];                   // '<Root>/inPWMs'
  real_T TerrainZ;                     // '<Root>/TerrainZ'
  real32_T inFloatsCollision[20];      // '<Root>/inFloatsCollision'
  int32_T inSILInts[8];                // '<Root>/inSILInts'
  real32_T inSILFloats[20];            // '<Root>/inSILFloats'
  real_T inCopterData[32];             // '<Root>/inCopterData'
};

// External outputs (root outports fed by signals with default storage)
struct ExtY_FixedwingModel_T {
  MavLinkSensor MavHILSensor;          // '<Root>/MavHILSensor'
  MavLinkGPS MavHILGPS;                // '<Root>/MavHILGPS'
  MavVehileInfo MavVehile3DInfo;       // '<Root>/MavVehile3DInfo'
  real_T outCopterData[32];            // '<Root>/outCopterData'
};

// Parameters for system: '<S17>/Distance into gust (y)'
struct P_Distanceintogusty_Fixedwing_T_ {
  real_T x_Y0;                         // Expression: [0]
                                          //  Referenced by: '<S21>/x'

  real_T DistanceintoGustxLimitedtogustl;// Expression: 0
                                            //  Referenced by: '<S21>/Distance into Gust (x) (Limited to gust length d) '

  real_T DistanceintoGustxLimitedtogus_a;// Expression: 0
                                            //  Referenced by: '<S21>/Distance into Gust (x) (Limited to gust length d) '

};

// Parameters for system: '<S17>/Distance into gust (y)'
typedef struct P_Distanceintogusty_Fixedwing_T_ P_Distanceintogusty_Fixedwing_T;

// Parameters for system: '<S69>/Hpgw'
struct P_Hpgw_FixedwingModel_T_ {
  real_T pgw_Y0;                       // Expression: 0
                                          //  Referenced by: '<S80>/pgw'

  real_T Constant2_Value;              // Expression: 2.6
                                          //  Referenced by: '<S80>/Constant2'

  real_T u_Gain;                       // Expression: 2*dt
                                          //  Referenced by: '<S80>/2'

  real_T Constant_Value;               // Expression: 1
                                          //  Referenced by: '<S80>/Constant'

  real_T Constant1_Value;              // Expression: 0.95
                                          //  Referenced by: '<S80>/Constant1'

  real_T Constant3_Value;              // Expression: 1/3
                                          //  Referenced by: '<S80>/Constant3'

  real_T dt_Gain;                      // Expression: dt
                                          //  Referenced by: '<S80>/dt'

  real_T UnitDelay_InitialCondition;   // Expression: 0
                                          //  Referenced by: '<S80>/Unit Delay'

};

// Parameters for system: '<S69>/Hpgw'
typedef struct P_Hpgw_FixedwingModel_T_ P_Hpgw_FixedwingModel_T;

// Parameters for system: '<S69>/Hqgw'
struct P_Hqgw_FixedwingModel_T_ {
  real_T qgw_Y0;                       // Expression: 0
                                          //  Referenced by: '<S81>/qgw'

  real_T Constant_Value;               // Expression: 1
                                          //  Referenced by: '<S81>/Constant'

  real_T dt1_Gain;                     // Expression: 4/pi
                                          //  Referenced by: '<S81>/dt1'

  real_T dt_Gain;                      // Expression: dt
                                          //  Referenced by: '<S81>/dt'

  real_T UnitDelay_InitialCondition;   // Expression: 0
                                          //  Referenced by: '<S81>/Unit Delay'

  real_T UnitDelay1_InitialCondition;  // Expression: 0
                                          //  Referenced by: '<S81>/Unit Delay1'

};

// Parameters for system: '<S69>/Hqgw'
typedef struct P_Hqgw_FixedwingModel_T_ P_Hqgw_FixedwingModel_T;

// Parameters for system: '<S69>/Hrgw'
struct P_Hrgw_FixedwingModel_T_ {
  real_T rgw_Y0;                       // Expression: 0
                                          //  Referenced by: '<S82>/rgw'

  real_T Constant_Value;               // Expression: 1
                                          //  Referenced by: '<S82>/Constant'

  real_T dt1_Gain;                     // Expression: 3/pi
                                          //  Referenced by: '<S82>/dt1'

  real_T dt_Gain;                      // Expression: dt
                                          //  Referenced by: '<S82>/dt'

  real_T UnitDelay_InitialCondition;   // Expression: 0
                                          //  Referenced by: '<S82>/Unit Delay'

  real_T UnitDelay1_InitialCondition;  // Expression: 0
                                          //  Referenced by: '<S82>/Unit Delay1'

};

// Parameters for system: '<S69>/Hrgw'
typedef struct P_Hrgw_FixedwingModel_T_ P_Hrgw_FixedwingModel_T;

// Parameters for system: '<S70>/Hugw(z)'
struct P_Hugwz_FixedwingModel_T_ {
  real_T ugw_Y0;                       // Expression: 0
                                          //  Referenced by: '<S83>/ugw'

  real_T u_Gain;                       // Expression: 2*dt
                                          //  Referenced by: '<S83>/2'

  real_T Constant_Value;               // Expression: 1
                                          //  Referenced by: '<S83>/Constant'

  real_T dt_Gain;                      // Expression: dt
                                          //  Referenced by: '<S83>/dt'

  real_T UnitDelay_InitialCondition;   // Expression: 0
                                          //  Referenced by: '<S83>/Unit Delay'

};

// Parameters for system: '<S70>/Hugw(z)'
typedef struct P_Hugwz_FixedwingModel_T_ P_Hugwz_FixedwingModel_T;

// Parameters for system: '<S70>/Hvgw(z)'
struct P_Hvgwz_FixedwingModel_T_ {
  real_T vgw_Y0;                       // Expression: 0
                                          //  Referenced by: '<S84>/vgw'

  real_T u_Gain;                       // Expression: 2*dt
                                          //  Referenced by: '<S84>/2'

  real_T Constant_Value;               // Expression: 1
                                          //  Referenced by: '<S84>/Constant'

  real_T dt_Gain;                      // Expression: dt
                                          //  Referenced by: '<S84>/dt'

  real_T UnitDelay_InitialCondition;   // Expression: 0
                                          //  Referenced by: '<S84>/Unit Delay'

};

// Parameters for system: '<S70>/Hvgw(z)'
typedef struct P_Hvgwz_FixedwingModel_T_ P_Hvgwz_FixedwingModel_T;

// Parameters for system: '<S70>/Hwgw(z)'
struct P_Hwgwz_FixedwingModel_T_ {
  real_T wgw_Y0;                       // Expression: 0
                                          //  Referenced by: '<S85>/wgw'

  real_T u_Gain;                       // Expression: 2*dt
                                          //  Referenced by: '<S85>/2'

  real_T Constant_Value;               // Expression: 1
                                          //  Referenced by: '<S85>/Constant'

  real_T dt_Gain;                      // Expression: dt
                                          //  Referenced by: '<S85>/dt'

  real_T UnitDelay_InitialCondition;   // Expression: 0
                                          //  Referenced by: '<S85>/Unit Delay'

};

// Parameters for system: '<S70>/Hwgw(z)'
typedef struct P_Hwgwz_FixedwingModel_T_ P_Hwgwz_FixedwingModel_T;

// Parameters for system: '<S74>/Interpolate  rates'
struct P_Interpolaterates_FixedwingM_T_ {
  real_T max_height_low_Value;         // Expression: max_height_low
                                          //  Referenced by: '<S88>/max_height_low'

  real_T min_height_high_Value;        // Expression: min_height_high
                                          //  Referenced by: '<S88>/min_height_high'

};

// Parameters for system: '<S74>/Interpolate  rates'
typedef struct P_Interpolaterates_FixedwingM_T_ P_Interpolaterates_FixedwingM_T;

// Parameters for system: '<S75>/Interpolate  velocities'
struct P_Interpolatevelocities_Fixed_T_ {
  real_T max_height_low_Value;         // Expression: max_height_low
                                          //  Referenced by: '<S96>/max_height_low'

  real_T min_height_high_Value;        // Expression: min_height_high
                                          //  Referenced by: '<S96>/min_height_high'

};

// Parameters for system: '<S75>/Interpolate  velocities'
typedef struct P_Interpolatevelocities_Fixed_T_ P_Interpolatevelocities_Fixed_T;

// Parameters for system: '<S151>/Positive Trace'
struct P_PositiveTrace_FixedwingMode_T_ {
  real_T Constant_Value;               // Expression: 1
                                          //  Referenced by: '<S156>/Constant'

  real_T Gain_Gain;                    // Expression: 0.5
                                          //  Referenced by: '<S156>/Gain'

  real_T Gain1_Gain;                   // Expression: 2
                                          //  Referenced by: '<S156>/Gain1'

};

// Parameters for system: '<S151>/Positive Trace'
typedef struct P_PositiveTrace_FixedwingMode_T_ P_PositiveTrace_FixedwingMode_T;

// Parameters for system: '<S151>/Negative Trace'
struct P_NegativeTrace_FixedwingMode_T_ {
  real_T Constant_Value;               // Expression: 1
                                          //  Referenced by: '<S172>/Constant'

  real_T Gain_Gain;                    // Expression: 0.5
                                          //  Referenced by: '<S160>/Gain'

  real_T Constant1_Value;              // Expression: 0.5
                                          //  Referenced by: '<S171>/Constant1'

  real_T Constant2_Value[2];           // Expression: [0 1]
                                          //  Referenced by: '<S171>/Constant2'

  real_T Gain1_Gain;                   // Expression: 1
                                          //  Referenced by: '<S160>/Gain1'

  real_T Gain3_Gain;                   // Expression: 1
                                          //  Referenced by: '<S160>/Gain3'

  real_T Gain4_Gain;                   // Expression: 1
                                          //  Referenced by: '<S160>/Gain4'

  real_T Constant_Value_c;             // Expression: 1
                                          //  Referenced by: '<S177>/Constant'

  real_T Gain_Gain_j;                  // Expression: 0.5
                                          //  Referenced by: '<S161>/Gain'

  real_T Constant1_Value_m;            // Expression: 0.5
                                          //  Referenced by: '<S176>/Constant1'

  real_T Constant2_Value_d[2];         // Expression: [0 1]
                                          //  Referenced by: '<S176>/Constant2'

  real_T Gain1_Gain_l;                 // Expression: 1
                                          //  Referenced by: '<S161>/Gain1'

  real_T Gain2_Gain;                   // Expression: 1
                                          //  Referenced by: '<S161>/Gain2'

  real_T Gain3_Gain_j;                 // Expression: 1
                                          //  Referenced by: '<S161>/Gain3'

  real_T Constant_Value_f;             // Expression: 1
                                          //  Referenced by: '<S167>/Constant'

  real_T Gain_Gain_e;                  // Expression: 0.5
                                          //  Referenced by: '<S159>/Gain'

  real_T Constant1_Value_a;            // Expression: 0.5
                                          //  Referenced by: '<S166>/Constant1'

  real_T Constant2_Value_a[2];         // Expression: [0 1]
                                          //  Referenced by: '<S166>/Constant2'

  real_T Gain1_Gain_h;                 // Expression: 1
                                          //  Referenced by: '<S159>/Gain1'

  real_T Gain2_Gain_b;                 // Expression: 1
                                          //  Referenced by: '<S159>/Gain2'

  real_T Gain3_Gain_n;                 // Expression: 1
                                          //  Referenced by: '<S159>/Gain3'

};

// Parameters for system: '<S151>/Negative Trace'
typedef struct P_NegativeTrace_FixedwingMode_T_ P_NegativeTrace_FixedwingMode_T;

// Parameters for system: '<S157>/If Warning//Error'
struct P_IfWarningError_FixedwingMod_T_ {
  real_T Constant1_Value;              // Expression: 0
                                          //  Referenced by: '<S183>/Constant1'

  real_T Constant1_Value_d;            // Expression: 0
                                          //  Referenced by: '<S182>/Constant1'

  real_T Bias_Bias;                    // Expression: -1
                                          //  Referenced by: '<S185>/Bias'

  real_T Bias1_Bias[9];                // Expression: -eye(3)
                                          //  Referenced by: '<S184>/Bias1'

};

// Parameters for system: '<S157>/If Warning//Error'
typedef struct P_IfWarningError_FixedwingMod_T_ P_IfWarningError_FixedwingMod_T;

// Parameters for system: '<S369>/Negative Yaw'
struct P_NegativeYaw_FixedwingModel_T_ {
  real_T Constant1_Value;              // Expression: 2*pi
                                          //  Referenced by: '<S407>/Constant1'

  real_T Constant2_Value;              // Expression: 2*pi
                                          //  Referenced by: '<S407>/Constant2'

};

// Parameters for system: '<S369>/Negative Yaw'
typedef struct P_NegativeYaw_FixedwingModel_T_ P_NegativeYaw_FixedwingModel_T;

// Parameters for system: '<S369>/Positive Yaw'
struct P_PositiveYaw_FixedwingModel_T_ {
  real_T Constant1_Value;              // Expression: 2*pi
                                          //  Referenced by: '<S408>/Constant1'

};

// Parameters for system: '<S369>/Positive Yaw'
typedef struct P_PositiveYaw_FixedwingModel_T_ P_PositiveYaw_FixedwingModel_T;

// Parameters (default storage)
struct P_FixedwingModel_T_ {
  struct_VNLjlAmEUjUhY2ZajRutz uav;    // Variable: uav
                                          //  Referenced by:
                                          //    '<Root>/ModelParam.uavMass'
                                          //    '<Root>/Gain'
                                          //    '<Root>/Gain1'
                                          //    '<Root>/Gain3'
                                          //    '<S8>/Constant1'
                                          //    '<S344>/ModelParam.uavMass'
                                          //    '<S522>/Wingspan'
                                          //    '<S149>/Min Th K'
                                          //    '<S149>/MaxRPM1'
                                          //    '<S149>/Th K'
                                          //    '<S348>/Constant'
                                          //    '<S382>/chord'
                                          //    '<S382>/span'
                                          //    '<S382>/span1'
                                          //    '<S382>/span2'
                                          //    '<S385>/CYDr'
                                          //    '<S385>/CYb'
                                          //    '<S386>/ClDa'
                                          //    '<S386>/ClDr'
                                          //    '<S386>/Clb'
                                          //    '<S387>/CnDa'
                                          //    '<S387>/CnDr'
                                          //    '<S387>/Cnb'
                                          //    '<S394>/Apolar'
                                          //    '<S394>/Apolar (A2)'
                                          //    '<S394>/CD0'
                                          //    '<S395>/CL0'
                                          //    '<S395>/CLDe'
                                          //    '<S395>/CLa'
                                          //    '<S395>/CLa_dot'
                                          //    '<S395>/CmDe1'
                                          //    '<S396>/Cm0'
                                          //    '<S396>/CmDe'
                                          //    '<S396>/CmDf'
                                          //    '<S396>/Cma'
                                          //    '<S396>/Cma1'
                                          //    '<S396>/chord'
                                          //    '<S396>/elarm'
                                          //    '<S388>/Constant'
                                          //    '<S388>/Constant1'
                                          //    '<S391>/Constant'
                                          //    '<S391>/Constant1'
                                          //    '<S397>/Constant'
                                          //    '<S389>/Cmq2'
                                          //    '<S390>/Cmq4'
                                          //    '<S392>/Cmq2'
                                          //    '<S393>/Cmq4'
                                          //    '<S398>/Cmq2'

  struct_cC8C5MZV75wwVdzQ00rR7E FaultParamAPI;// Variable: FaultParamAPI
                                                 //  Referenced by:
                                                 //    '<S55>/Wind direction'
                                                 //    '<S55>/Windspeed at 20ft (6m)'
                                                 //    '<S56>/Wind direction'
                                                 //    '<S56>/Windspeed at 20ft (6m)'
                                                 //    '<S66>/Wind Direction'
                                                 //    '<S66>/Wind speed at reference height'
                                                 //    '<S252>/2*zeta * wn'
                                                 //    '<S263>/2*zeta * wn'

  struct_qYIpymaSbzHVkej1LIQGDH env;   // Variable: env
                                          //  Referenced by:
                                          //    '<Root>/Constant3'
                                          //    '<S148>/kg2N'
                                          //    '<S522>/Wind direction'
                                          //    '<S522>/Windspeed at 20ft (6m)'
                                          //    '<S523>/Wind Direction'
                                          //    '<S523>/Wind Speed'
                                          //    '<S399>/Constant'
                                          //    '<S399>/Sea Level  Temperature'
                                          //    '<S399>/1//T0'
                                          //    '<S399>/Lapse Rate'
                                          //    '<S399>/g//R'
                                          //    '<S399>/rho0'

  struct_pQS2n5LfNYssVkZ6clZuRD SteerEngineFault;// Variable: SteerEngineFault
                                                    //  Referenced by: '<S15>/SteerNum'

  real_T ModelInit_AngEuler[3];        // Variable: ModelInit_AngEuler
                                          //  Referenced by: '<S346>/phi theta psi'

  real_T ModelInit_Inputs[16];         // Variable: ModelInit_Inputs
                                          //  Referenced by: '<Root>/InitinputNoArmed'

  real_T ModelInit_PosE[3];            // Variable: ModelInit_PosE
                                          //  Referenced by: '<S341>/xe,ye,ze'

  real_T ModelInit_RateB[3];           // Variable: ModelInit_RateB
                                          //  Referenced by: '<S341>/p,q,r '

  real_T ModelInit_VelB[3];            // Variable: ModelInit_VelB
                                          //  Referenced by: '<S341>/ub,vb,wb'

  real_T ModelParam_GPSEphFinal;       // Variable: ModelParam_GPSEphFinal
                                          //  Referenced by: '<S152>/ModelParam.GPSEphFinal'

  real_T ModelParam_GPSEpvFinal;       // Variable: ModelParam_GPSEpvFinal
                                          //  Referenced by: '<S152>/ModelParam.GPSEpvFinal'

  real_T ModelParam_GPSLatLong[2];     // Variable: ModelParam_GPSLatLong
                                          //  Referenced by:
                                          //    '<S24>/ref_position'
                                          //    '<S198>/ref_position'

  real_T ModelParam_envAltitude;       // Variable: ModelParam_envAltitude
                                          //  Referenced by:
                                          //    '<S3>/ModelParam.envAltitude'
                                          //    '<S194>/ModelParam.envAltitude'

  real_T ModelParam_noisePowerOffGainAccel;
                                  // Variable: ModelParam_noisePowerOffGainAccel
                                     //  Referenced by: '<S153>/AccelNoiseGainFunction'

  real_T ModelParam_noisePowerOffGainAccelZ;
                                 // Variable: ModelParam_noisePowerOffGainAccelZ
                                    //  Referenced by: '<S153>/AccelNoiseGainFunction'

  real_T ModelParam_noisePowerOffGainGyro;
                                   // Variable: ModelParam_noisePowerOffGainGyro
                                      //  Referenced by: '<S153>/GyroNoiseGainFunction'

  real_T ModelParam_noisePowerOffGainGyroZ;
                                  // Variable: ModelParam_noisePowerOffGainGyroZ
                                     //  Referenced by: '<S153>/GyroNoiseGainFunction'

  real_T ModelParam_noisePowerOffGainMag;
                                    // Variable: ModelParam_noisePowerOffGainMag
                                       //  Referenced by: '<S153>/MagNoiseGainFunction'

  real_T ModelParam_noisePowerOffGainMagZ;
                                   // Variable: ModelParam_noisePowerOffGainMagZ
                                      //  Referenced by: '<S153>/MagNoiseGainFunction'

  real_T ModelParam_noisePowerOnGainAccel;
                                   // Variable: ModelParam_noisePowerOnGainAccel
                                      //  Referenced by: '<S153>/AccelNoiseGainFunction'

  real_T ModelParam_noisePowerOnGainAccelZ;
                                  // Variable: ModelParam_noisePowerOnGainAccelZ
                                     //  Referenced by: '<S153>/AccelNoiseGainFunction'

  real_T ModelParam_noisePowerOnGainGyro;
                                    // Variable: ModelParam_noisePowerOnGainGyro
                                       //  Referenced by: '<S153>/GyroNoiseGainFunction'

  real_T ModelParam_noisePowerOnGainGyroZ;
                                   // Variable: ModelParam_noisePowerOnGainGyroZ
                                      //  Referenced by: '<S153>/GyroNoiseGainFunction'

  real_T ModelParam_noisePowerOnGainMag;
                                     // Variable: ModelParam_noisePowerOnGainMag
                                        //  Referenced by: '<S153>/MagNoiseGainFunction'

  real_T ModelParam_noisePowerOnGainMagZ;
                                    // Variable: ModelParam_noisePowerOnGainMagZ
                                       //  Referenced by: '<S153>/MagNoiseGainFunction'

  int8_T ModelParam_uavType;           // Variable: ModelParam_uavType
                                          //  Referenced by: '<S7>/UAVType'

  real_T BandLimitedWhiteNoise_Cov; // Mask Parameter: BandLimitedWhiteNoise_Cov
                                       //  Referenced by: '<S16>/Output'

  real_T DrydenWindTurbulenceModel_L_hig;
                              // Mask Parameter: DrydenWindTurbulenceModel_L_hig
                                 //  Referenced by: '<S563>/Medium//High Altitude'

  real_T DrydenWindTurbulenceModelDiscre;
                              // Mask Parameter: DrydenWindTurbulenceModelDiscre
                                 //  Referenced by: '<S144>/Medium//High Altitude'

  real_T DrydenWindTurbulenceModelDisc_h;
                              // Mask Parameter: DrydenWindTurbulenceModelDisc_h
                                 //  Referenced by: '<S105>/Medium//High Altitude'

  real_T DrydenWindTurbulenceModel_Seed[4];
                               // Mask Parameter: DrydenWindTurbulenceModel_Seed
                                  //  Referenced by: '<S537>/White Noise'

  real_T DrydenWindTurbulenceModelDisc_o[4];
                              // Mask Parameter: DrydenWindTurbulenceModelDisc_o
                                 //  Referenced by: '<S118>/White Noise'

  real_T DrydenWindTurbulenceModelDis_o3[4];
                              // Mask Parameter: DrydenWindTurbulenceModelDis_o3
                                 //  Referenced by: '<S79>/White Noise'

  real_T DrydenWindTurbulenceModel_T_on;
                               // Mask Parameter: DrydenWindTurbulenceModel_T_on
                                  //  Referenced by:
                                  //    '<S527>/Constant1'
                                  //    '<S527>/Constant2'
                                  //    '<S527>/Constant3'
                                  //    '<S528>/Constant'

  real_T DrydenWindTurbulenceModelDisc_f;
                              // Mask Parameter: DrydenWindTurbulenceModelDisc_f
                                 //  Referenced by:
                                 //    '<S108>/Constant1'
                                 //    '<S108>/Constant2'
                                 //    '<S108>/Constant3'
                                 //    '<S109>/Constant3'

  real_T DrydenWindTurbulenceModelDisc_e;
                              // Mask Parameter: DrydenWindTurbulenceModelDisc_e
                                 //  Referenced by:
                                 //    '<S69>/Constant1'
                                 //    '<S69>/Constant2'
                                 //    '<S69>/Constant3'
                                 //    '<S70>/Constant3'

  real_T WhiteNoise_Ts;                // Mask Parameter: WhiteNoise_Ts
                                          //  Referenced by: '<S537>/Constant1'

  real_T WhiteNoise_Ts_a;              // Mask Parameter: WhiteNoise_Ts_a
                                          //  Referenced by: '<S118>/Constant1'

  real_T WhiteNoise_Ts_h;              // Mask Parameter: WhiteNoise_Ts_h
                                          //  Referenced by: '<S79>/Constant1'

  real_T DrydenWindTurbulenceModel_TurbP;
                              // Mask Parameter: DrydenWindTurbulenceModel_TurbP
                                 //  Referenced by: '<S544>/Probability of  Exceedance'

  real_T DrydenWindTurbulenceModelDisc_m;
                              // Mask Parameter: DrydenWindTurbulenceModelDisc_m
                                 //  Referenced by: '<S125>/Probability of  Exceedance'

  real_T DrydenWindTurbulenceModelDisc_l;
                              // Mask Parameter: DrydenWindTurbulenceModelDisc_l
                                 //  Referenced by: '<S86>/Probability of  Exceedance'

  real_T DrydenWindTurbulenceModelDisc_b;
                              // Mask Parameter: DrydenWindTurbulenceModelDisc_b
                                 //  Referenced by: '<S55>/Wingspan'

  real_T DrydenWindTurbulenceModelDis_bc;
                              // Mask Parameter: DrydenWindTurbulenceModelDis_bc
                                 //  Referenced by: '<S56>/Wingspan'

  real_T ThreeaxisInertialMeasurementUni[3];
                              // Mask Parameter: ThreeaxisInertialMeasurementUni
                                 //  Referenced by: '<S246>/Measurement bias'

  real_T ThreeaxisAccelerometer_a_bias[3];
                                // Mask Parameter: ThreeaxisAccelerometer_a_bias
                                   //  Referenced by: '<S345>/Measurement bias'

  real_T ThreeaxisInertialMeasurementU_l[9];
                              // Mask Parameter: ThreeaxisInertialMeasurementU_l
                                 //  Referenced by: '<S246>/Scale factors & Cross-coupling  errors'

  real_T ThreeaxisAccelerometer_a_sf_cc[9];
                               // Mask Parameter: ThreeaxisAccelerometer_a_sf_cc
                                  //  Referenced by: '<S345>/Scale factors & Cross-coupling  errors'

  real_T ThreeaxisAccelerometer_acc[3];
                                   // Mask Parameter: ThreeaxisAccelerometer_acc
                                      //  Referenced by: '<S345>/wl_ins'

  real_T DirectionCosineMatrixtoQuaterni;
                              // Mask Parameter: DirectionCosineMatrixtoQuaterni
                                 //  Referenced by:
                                 //    '<S157>/If Warning//Error'
                                 //    '<S157>/Constant'

  real_T DirectionCosineMatrixtoQuater_o;
                              // Mask Parameter: DirectionCosineMatrixtoQuater_o
                                 //  Referenced by:
                                 //    '<S418>/If Warning//Error'
                                 //    '<S418>/Constant'

  real_T DirectionCosineMatrixtoQuater_c;
                              // Mask Parameter: DirectionCosineMatrixtoQuater_c
                                 //  Referenced by:
                                 //    '<S456>/If Warning//Error'
                                 //    '<S456>/Constant'

  real_T CompareToConstant_const;     // Mask Parameter: CompareToConstant_const
                                         //  Referenced by: '<S43>/Constant'

  real_T CompareToConstant_const_j; // Mask Parameter: CompareToConstant_const_j
                                       //  Referenced by: '<S41>/Constant'

  real_T CompareToConstant_const_jw;
                                   // Mask Parameter: CompareToConstant_const_jw
                                      //  Referenced by: '<S44>/Constant'

  real_T CompareToConstant_const_p; // Mask Parameter: CompareToConstant_const_p
                                       //  Referenced by: '<S37>/Constant'

  real_T CompareToConstant_const_d; // Mask Parameter: CompareToConstant_const_d
                                       //  Referenced by: '<S35>/Constant'

  real_T CompareToConstant_const_b; // Mask Parameter: CompareToConstant_const_b
                                       //  Referenced by: '<S38>/Constant'

  real_T CompareToConstant_const_e; // Mask Parameter: CompareToConstant_const_e
                                       //  Referenced by: '<S279>/Constant'

  real_T CompareToConstant_const_h; // Mask Parameter: CompareToConstant_const_h
                                       //  Referenced by: '<S277>/Constant'

  real_T CompareToConstant_const_n; // Mask Parameter: CompareToConstant_const_n
                                       //  Referenced by: '<S280>/Constant'

  real_T CompareToConstant_const_o; // Mask Parameter: CompareToConstant_const_o
                                       //  Referenced by: '<S214>/Constant'

  real_T CompareToConstant_const_c; // Mask Parameter: CompareToConstant_const_c
                                       //  Referenced by: '<S212>/Constant'

  real_T CompareToConstant_const_f; // Mask Parameter: CompareToConstant_const_f
                                       //  Referenced by: '<S215>/Constant'

  real_T CompareToConstant_const_l; // Mask Parameter: CompareToConstant_const_l
                                       //  Referenced by: '<S208>/Constant'

  real_T CompareToConstant_const_a; // Mask Parameter: CompareToConstant_const_a
                                       //  Referenced by: '<S206>/Constant'

  real_T CompareToConstant_const_k; // Mask Parameter: CompareToConstant_const_k
                                       //  Referenced by: '<S209>/Constant'

  real_T Distanceintogustx_d_m;        // Mask Parameter: Distanceintogustx_d_m
                                          //  Referenced by: '<S20>/Distance into Gust (x) (Limited to gust length d)'

  real_T Distanceintogusty_d_m;        // Mask Parameter: Distanceintogusty_d_m
                                          //  Referenced by: '<S17>/Distance into gust (y)'

  real_T Distanceintogustz_d_m;        // Mask Parameter: Distanceintogustz_d_m
                                          //  Referenced by: '<S17>/Distance into gust (z)'

  real_T DiscreteWindGustModel_d_m[3];
                                    // Mask Parameter: DiscreteWindGustModel_d_m
                                       //  Referenced by: '<S17>/pi//Gust length'

  real_T LinearSecondOrderActuators_fin_;
                              // Mask Parameter: LinearSecondOrderActuators_fin_
                                 //  Referenced by: '<S10>/Integrator, Second-Order'

  real_T LinearSecondOrderActuator4_fin_;
                              // Mask Parameter: LinearSecondOrderActuator4_fin_
                                 //  Referenced by: '<S14>/Integrator, Second-Order'

  real_T LinearSecondOrderActuator1_fin_;
                              // Mask Parameter: LinearSecondOrderActuator1_fin_
                                 //  Referenced by: '<S11>/Integrator, Second-Order'

  real_T LinearSecondOrderActuator2_fin_;
                              // Mask Parameter: LinearSecondOrderActuator2_fin_
                                 //  Referenced by: '<S12>/Integrator, Second-Order'

  real_T LinearSecondOrderActuator3_fin_;
                              // Mask Parameter: LinearSecondOrderActuator3_fin_
                                 //  Referenced by: '<S13>/Integrator, Second-Order'

  real_T LinearSecondOrderActuators_fi_e;
                              // Mask Parameter: LinearSecondOrderActuators_fi_e
                                 //  Referenced by: '<S10>/Integrator, Second-Order'

  real_T LinearSecondOrderActuator4_fi_c;
                              // Mask Parameter: LinearSecondOrderActuator4_fi_c
                                 //  Referenced by: '<S14>/Integrator, Second-Order'

  real_T LinearSecondOrderActuator1_fi_e;
                              // Mask Parameter: LinearSecondOrderActuator1_fi_e
                                 //  Referenced by: '<S11>/Integrator, Second-Order'

  real_T LinearSecondOrderActuator2_fi_c;
                              // Mask Parameter: LinearSecondOrderActuator2_fi_c
                                 //  Referenced by: '<S12>/Integrator, Second-Order'

  real_T LinearSecondOrderActuator3_fi_l;
                              // Mask Parameter: LinearSecondOrderActuator3_fi_l
                                 //  Referenced by: '<S13>/Integrator, Second-Order'

  real_T ThreeaxisInertialMeasurementU_b[3];
                              // Mask Parameter: ThreeaxisInertialMeasurementU_b
                                 //  Referenced by: '<S247>/Measurement bias'

  real_T ThreeaxisInertialMeasurement_b5[3];
                              // Mask Parameter: ThreeaxisInertialMeasurement_b5
                                 //  Referenced by: '<S247>/g-sensitive bias'

  real_T ThreeaxisInertialMeasurementU_m[9];
                              // Mask Parameter: ThreeaxisInertialMeasurementU_m
                                 //  Referenced by: '<S247>/Scale factors & Cross-coupling  errors '

  real_T ISAAtmosphereModel1_h0;       // Mask Parameter: ISAAtmosphereModel1_h0
                                          //  Referenced by: '<S399>/Limit  altitude  to troposhere'

  real_T ISAAtmosphereModel1_h_strat;
                                  // Mask Parameter: ISAAtmosphereModel1_h_strat
                                     //  Referenced by: '<S399>/Limit  altitude  to Stratosphere'

  real_T ISAAtmosphereModel1_h_trop;
                                   // Mask Parameter: ISAAtmosphereModel1_h_trop
                                      //  Referenced by:
                                      //    '<S399>/Altitude of Troposphere'
                                      //    '<S399>/Limit  altitude  to Stratosphere'
                                      //    '<S399>/Limit  altitude  to troposhere'

  real_T ThreeaxisInertialMeasurementU_p[3];
                              // Mask Parameter: ThreeaxisInertialMeasurementU_p
                                 //  Referenced by: '<S246>/wl_ins'

  real_T uDOFEulerAngles_inertia[9];  // Mask Parameter: uDOFEulerAngles_inertia
                                         //  Referenced by: '<S348>/Constant1'

  real_T CheckAltitude_max;            // Mask Parameter: CheckAltitude_max
                                          //  Referenced by: '<S264>/max_val'

  real_T CheckLatitude_max;            // Mask Parameter: CheckLatitude_max
                                          //  Referenced by: '<S265>/max_val'

  real_T CheckLongitude_max;           // Mask Parameter: CheckLongitude_max
                                          //  Referenced by: '<S266>/max_val'

  real_T Istimewithinmodellimits_max;
                                  // Mask Parameter: Istimewithinmodellimits_max
                                     //  Referenced by: '<S268>/max_val'

  real_T CheckAltitude_min;            // Mask Parameter: CheckAltitude_min
                                          //  Referenced by: '<S264>/min_val'

  real_T CheckLatitude_min;            // Mask Parameter: CheckLatitude_min
                                          //  Referenced by: '<S265>/min_val'

  real_T CheckLongitude_min;           // Mask Parameter: CheckLongitude_min
                                          //  Referenced by: '<S266>/min_val'

  real_T Istimewithinmodellimits_min;
                                  // Mask Parameter: Istimewithinmodellimits_min
                                     //  Referenced by: '<S268>/min_val'

  real_T FlatEarthtoLLA_psi;           // Mask Parameter: FlatEarthtoLLA_psi
                                          //  Referenced by: '<S24>/ref_rotation'

  real_T FlatEarthtoLLA_psi_i;         // Mask Parameter: FlatEarthtoLLA_psi_i
                                          //  Referenced by: '<S198>/ref_rotation'

  real_T WhiteNoise_pwr[4];            // Mask Parameter: WhiteNoise_pwr
                                          //  Referenced by: '<S537>/Constant'

  real_T WhiteNoise_pwr_f[4];          // Mask Parameter: WhiteNoise_pwr_f
                                          //  Referenced by: '<S118>/Constant'

  real_T WhiteNoise_pwr_a[4];          // Mask Parameter: WhiteNoise_pwr_a
                                          //  Referenced by: '<S79>/Constant'

  real_T BandLimitedWhiteNoise_seed;
                                   // Mask Parameter: BandLimitedWhiteNoise_seed
                                      //  Referenced by: '<S16>/White Noise'

  real_T DiscreteWindGustModel_t_0; // Mask Parameter: DiscreteWindGustModel_t_0
                                       //  Referenced by: '<S17>/Gust start time'

  real_T DirectionCosineMatrixtoQuate_o3;
                              // Mask Parameter: DirectionCosineMatrixtoQuate_o3
                                 //  Referenced by: '<S157>/If Warning//Error'

  real_T DirectionCosineMatrixtoQuater_p;
                              // Mask Parameter: DirectionCosineMatrixtoQuater_p
                                 //  Referenced by: '<S418>/If Warning//Error'

  real_T DirectionCosineMatrixtoQuater_k;
                              // Mask Parameter: DirectionCosineMatrixtoQuater_k
                                 //  Referenced by: '<S456>/If Warning//Error'

  real_T DiscreteWindGustModel_v_m[3];
                                    // Mask Parameter: DiscreteWindGustModel_v_m
                                       //  Referenced by: '<S17>/Gust magnitude//2.0'

  real_T ThreeaxisInertialMeasurement_mp;
                              // Mask Parameter: ThreeaxisInertialMeasurement_mp
                                 //  Referenced by:
                                 //    '<S252>/2*zeta * wn'
                                 //    '<S252>/wn^2'

  real_T ThreeaxisInertialMeasurementU_e;
                              // Mask Parameter: ThreeaxisInertialMeasurementU_e
                                 //  Referenced by:
                                 //    '<S263>/2*zeta * wn'
                                 //    '<S263>/wn^2'

  real_T SecondorderDynamics_wn;       // Mask Parameter: SecondorderDynamics_wn
                                          //  Referenced by:
                                          //    '<S512>/2*zeta * wn'
                                          //    '<S512>/wn^2'

  real_T LinearSecondOrderActuators_wn_f;
                              // Mask Parameter: LinearSecondOrderActuators_wn_f
                                 //  Referenced by:
                                 //    '<S10>/2*zeta * wn'
                                 //    '<S10>/wn^2'

  real_T LinearSecondOrderActuator1_wn_f;
                              // Mask Parameter: LinearSecondOrderActuator1_wn_f
                                 //  Referenced by:
                                 //    '<S11>/2*zeta * wn'
                                 //    '<S11>/wn^2'

  real_T LinearSecondOrderActuator2_wn_f;
                              // Mask Parameter: LinearSecondOrderActuator2_wn_f
                                 //  Referenced by:
                                 //    '<S12>/2*zeta * wn'
                                 //    '<S12>/wn^2'

  real_T LinearSecondOrderActuator3_wn_f;
                              // Mask Parameter: LinearSecondOrderActuator3_wn_f
                                 //  Referenced by:
                                 //    '<S13>/2*zeta * wn'
                                 //    '<S13>/wn^2'

  real_T LinearSecondOrderActuator4_wn_f;
                              // Mask Parameter: LinearSecondOrderActuator4_wn_f
                                 //  Referenced by:
                                 //    '<S14>/2*zeta * wn'
                                 //    '<S14>/wn^2'

  real_T LinearSecondOrderActuators_z_fi;
                              // Mask Parameter: LinearSecondOrderActuators_z_fi
                                 //  Referenced by: '<S10>/2*zeta * wn'

  real_T LinearSecondOrderActuator1_z_fi;
                              // Mask Parameter: LinearSecondOrderActuator1_z_fi
                                 //  Referenced by: '<S11>/2*zeta * wn'

  real_T LinearSecondOrderActuator2_z_fi;
                              // Mask Parameter: LinearSecondOrderActuator2_z_fi
                                 //  Referenced by: '<S12>/2*zeta * wn'

  real_T LinearSecondOrderActuator3_z_fi;
                              // Mask Parameter: LinearSecondOrderActuator3_z_fi
                                 //  Referenced by: '<S13>/2*zeta * wn'

  real_T LinearSecondOrderActuator4_z_fi;
                              // Mask Parameter: LinearSecondOrderActuator4_z_fi
                                 //  Referenced by: '<S14>/2*zeta * wn'

  real_T SecondorderDynamics_zn;       // Mask Parameter: SecondorderDynamics_zn
                                          //  Referenced by: '<S512>/2*zeta * wn'

  boolean_T DiscreteWindGustModel_Gx;// Mask Parameter: DiscreteWindGustModel_Gx
                                        //  Referenced by: '<S17>/Constant'

  boolean_T DiscreteWindGustModel_Gy;// Mask Parameter: DiscreteWindGustModel_Gy
                                        //  Referenced by: '<S17>/Constant1'

  boolean_T DiscreteWindGustModel_Gz;// Mask Parameter: DiscreteWindGustModel_Gz
                                        //  Referenced by: '<S17>/Constant2'

  real_T x_Y0;                         // Expression: [0]
                                          //  Referenced by: '<S20>/x'

  real_T DistanceintoGustxLimitedtogustl;// Expression: 0
                                            //  Referenced by: '<S20>/Distance into Gust (x) (Limited to gust length d)'

  real_T DistanceintoGustxLimitedtogus_g;// Expression: 0
                                            //  Referenced by: '<S20>/Distance into Gust (x) (Limited to gust length d)'

  real_T Bias_Bias;                    // Expression: -90
                                          //  Referenced by: '<S33>/Bias'

  real_T Gain_Gain;                    // Expression: -1
                                          //  Referenced by: '<S33>/Gain'

  real_T Bias1_Bias;                   // Expression: +90
                                          //  Referenced by: '<S33>/Bias1'

  real_T Bias_Bias_o;                  // Expression: 180
                                          //  Referenced by: '<S36>/Bias'

  real_T Bias1_Bias_b;                 // Expression: -180
                                          //  Referenced by: '<S36>/Bias1'

  real_T Bias_Bias_m;                  // Expression: 180
                                          //  Referenced by: '<S34>/Bias'

  real_T Bias1_Bias_l;                 // Expression: -180
                                          //  Referenced by: '<S34>/Bias1'

  real_T Bias_Bias_d;                  // Expression: -90
                                          //  Referenced by: '<S39>/Bias'

  real_T Gain_Gain_l;                  // Expression: -1
                                          //  Referenced by: '<S39>/Gain'

  real_T Bias1_Bias_i;                 // Expression: +90
                                          //  Referenced by: '<S39>/Bias1'

  real_T Constant2_Value;              // Expression: 360
                                          //  Referenced by: '<S42>/Constant2'

  real_T Bias_Bias_h;                  // Expression: 180
                                          //  Referenced by: '<S42>/Bias'

  real_T Bias1_Bias_ik;                // Expression: -180
                                          //  Referenced by: '<S42>/Bias1'

  real_T Constant_Value;               // Expression: 180
                                          //  Referenced by: '<S30>/Constant'

  real_T Constant1_Value;              // Expression: 0
                                          //  Referenced by: '<S30>/Constant1'

  real_T Constant2_Value_k;            // Expression: 360
                                          //  Referenced by: '<S40>/Constant2'

  real_T Bias_Bias_mo;                 // Expression: 180
                                          //  Referenced by: '<S40>/Bias'

  real_T Bias1_Bias_m;                 // Expression: -180
                                          //  Referenced by: '<S40>/Bias1'

  real_T Gain_Gain_i;                  // Expression: 1
                                          //  Referenced by: '<S90>/Gain'

  real_T Gain_Gain_j;                  // Expression: 1
                                          //  Referenced by: '<S98>/Gain'

  real_T Gain_Gain_e;                  // Expression: 1
                                          //  Referenced by: '<S129>/Gain'

  real_T Gain_Gain_a;                  // Expression: 1
                                          //  Referenced by: '<S137>/Gain'

  real_T Bias_Bias_c;                  // Expression: -90
                                          //  Referenced by: '<S204>/Bias'

  real_T Gain_Gain_m;                  // Expression: -1
                                          //  Referenced by: '<S204>/Gain'

  real_T Bias1_Bias_bq;                // Expression: +90
                                          //  Referenced by: '<S204>/Bias1'

  real_T Bias_Bias_l;                  // Expression: 180
                                          //  Referenced by: '<S207>/Bias'

  real_T Bias1_Bias_k;                 // Expression: -180
                                          //  Referenced by: '<S207>/Bias1'

  real_T Bias_Bias_os;                 // Expression: 180
                                          //  Referenced by: '<S205>/Bias'

  real_T Bias1_Bias_d;                 // Expression: -180
                                          //  Referenced by: '<S205>/Bias1'

  real_T Bias_Bias_j;                  // Expression: -90
                                          //  Referenced by: '<S210>/Bias'

  real_T Gain_Gain_o;                  // Expression: -1
                                          //  Referenced by: '<S210>/Gain'

  real_T Bias1_Bias_e;                 // Expression: +90
                                          //  Referenced by: '<S210>/Bias1'

  real_T Constant2_Value_k5;           // Expression: 360
                                          //  Referenced by: '<S213>/Constant2'

  real_T Bias_Bias_jv;                 // Expression: 180
                                          //  Referenced by: '<S213>/Bias'

  real_T Bias1_Bias_lz;                // Expression: -180
                                          //  Referenced by: '<S213>/Bias1'

  real_T Constant_Value_l;             // Expression: 180
                                          //  Referenced by: '<S201>/Constant'

  real_T Constant1_Value_o;            // Expression: 0
                                          //  Referenced by: '<S201>/Constant1'

  real_T Constant2_Value_p;            // Expression: 360
                                          //  Referenced by: '<S211>/Constant2'

  real_T Bias_Bias_i;                  // Expression: 180
                                          //  Referenced by: '<S211>/Bias'

  real_T Bias1_Bias_dh;                // Expression: -180
                                          //  Referenced by: '<S211>/Bias1'

  real_T Bias_Bias_b;                  // Expression: -90
                                          //  Referenced by: '<S275>/Bias'

  real_T Gain_Gain_en;                 // Expression: -1
                                          //  Referenced by: '<S275>/Gain'

  real_T Bias1_Bias_a;                 // Expression: +90
                                          //  Referenced by: '<S275>/Bias1'

  real_T Bias_Bias_je;                 // Expression: 180
                                          //  Referenced by: '<S278>/Bias'

  real_T Bias1_Bias_g;                 // Expression: -180
                                          //  Referenced by: '<S278>/Bias1'

  real_T Bias_Bias_g;                  // Expression: 180
                                          //  Referenced by: '<S276>/Bias'

  real_T Bias1_Bias_gb;                // Expression: -180
                                          //  Referenced by: '<S276>/Bias1'

  real_T pp13_Y0[13];                  // Expression: ones(1,maxdef+1)
                                          //  Referenced by: '<S297>/pp[13]'

  real_T Constant_Value_m;             // Expression: 1
                                          //  Referenced by: '<S297>/Constant'

  real_T pp13_Y0_j[13];                // Expression: ones(1,maxdef+1)
                                          //  Referenced by: '<S298>/pp[13]'

  real_T k1313_Value[169];             // Expression: k
                                          //  Referenced by: '<S298>/k[13][13]'

  real_T bpp_Y0;                       // Expression: 0
                                          //  Referenced by: '<S293>/bpp'

  real_T Constant_Value_n;             // Expression: fm(2)
                                          //  Referenced by: '<S293>/Constant'

  real_T Constant1_Value_f;            // Expression: 1
                                          //  Referenced by: '<S293>/Constant1'

  real_T UnitDelay1_InitialCondition[13];// Expression: ones(1,maxdef+1)
                                            //  Referenced by: '<S293>/Unit Delay1'

  real_T Constant_Value_nn;            // Expression: 1
                                          //  Referenced by: '<S301>/Constant'

  real_T Gain1_Gain;                   // Expression: 1
                                          //  Referenced by: '<S301>/Gain1'

  real_T Gain2_Gain;                   // Expression: 1
                                          //  Referenced by: '<S301>/Gain2'

  real_T Constant_Value_lc;            // Expression: 1
                                          //  Referenced by: '<S303>/Constant'

  real_T Constant_Value_j;             // Expression: 1
                                          //  Referenced by: '<S304>/Constant'

  real_T Constant1_Value_l;            // Expression: 0
                                          //  Referenced by: '<S307>/Constant1'

  real_T Constant_Value_i;             // Expression: 0
                                          //  Referenced by: '<S307>/Constant'

  real_T k1313_Value_c[169];           // Expression: k
                                          //  Referenced by: '<S307>/k[13][13]'

  real_T dp1313_Y0[169];               // Expression: zeros(maxdef+1,maxdef+1)
                                          //  Referenced by: '<S291>/dp[13][13]'

  real_T snorm169_Y0[169];             // Expression: snorm
                                          //  Referenced by: '<S291>/snorm[169]'

  real_T UnitDelay_InitialCondition[169];// Expression: zeros(maxdef+1,maxdef+1)
                                            //  Referenced by: '<S291>/Unit Delay'

  real_T UnitDelay1_InitialCondition_g[169];// Expression: snorm
                                               //  Referenced by: '<S291>/Unit Delay1'

  real_T Merge1_InitialOutput;         // Expression: 0
                                          //  Referenced by: '<S291>/Merge1'

  real_T Merge_InitialOutput;          // Expression: 0
                                          //  Referenced by: '<S291>/Merge'

  real_T Gain_Gain_f;                  // Expression: 1
                                          //  Referenced by: '<S320>/Gain'

  real_T zerosmaxdef1maxdef1_Value[169];// Expression: zeros(maxdef+1,maxdef+1)
                                           //  Referenced by: '<S319>/zeros(maxdef+1,maxdef+1)'

  real_T tc1313_Y0[169];               // Expression: zeros(maxdef+1,maxdef+1)
                                          //  Referenced by: '<S292>/tc[13][13]'

  real_T UnitDelay_InitialCondition_d[169];// Expression: zeros(maxdef+1,maxdef+1)
                                              //  Referenced by: '<S292>/Unit Delay'

  real_T cmaxdefmaxdef_Value[169];     // Expression: c
                                          //  Referenced by: '<S292>/c[maxdef][maxdef]'

  real_T cdmaxdefmaxdef_Value[169];    // Expression: cd
                                          //  Referenced by: '<S292>/cd[maxdef][maxdef]'

  real_T UnitDelay_InitialCondition_l[169];// Expression: zeros(maxdef+1,maxdef+1)
                                              //  Referenced by: '<S319>/Unit Delay'

  real_T bt_Y0;                        // Expression: 0
                                          //  Referenced by: '<S289>/bt'

  real_T bp_Y0;                        // Expression: 0
                                          //  Referenced by: '<S289>/bp'

  real_T br_Y0;                        // Expression: 0
                                          //  Referenced by: '<S289>/br'

  real_T bpp_Y0_g;                     // Expression: 0
                                          //  Referenced by: '<S289>/bpp'

  real_T Constant1_Value_m;            // Expression: 1
                                          //  Referenced by: '<S295>/Constant1'

  real_T Merge_InitialOutput_i;        // Expression: 0
                                          //  Referenced by: '<S295>/Merge'

  real_T fm_Value[13];                 // Expression: fm
                                          //  Referenced by: '<S290>/fm'

  real_T Merge1_InitialOutput_a;       // Expression: 0
                                          //  Referenced by: '<S295>/Merge1'

  real_T fn_Value[13];                 // Expression: fn
                                          //  Referenced by: '<S290>/fn'

  real_T Constant1_Value_b;            // Expression: 0
                                          //  Referenced by: '<S296>/Constant1'

  real_T UnitDelay1_InitialCondition_n;// Expression: 0
                                          //  Referenced by: '<S290>/Unit Delay1'

  real_T UnitDelay3_InitialCondition;  // Expression: 0
                                          //  Referenced by: '<S290>/Unit Delay3'

  real_T UnitDelay2_InitialCondition;  // Expression: 0
                                          //  Referenced by: '<S290>/Unit Delay2'

  real_T UnitDelay4_InitialCondition;  // Expression: 0
                                          //  Referenced by: '<S290>/Unit Delay4'

  real_T btbpbrbpp_Y0[4];              // Expression: [0 0 0 0]
                                          //  Referenced by: '<S281>/bt,bp,br,bpp'

  real_T UnitDelay_InitialCondition_n; // Expression: 0
                                          //  Referenced by: '<S281>/Unit Delay'

  real_T UnitDelay2_InitialCondition_e[4];// Expression: [0 0 0 0]
                                             //  Referenced by: '<S281>/Unit Delay2'

  real_T r_Y0;                         // Expression: 6378.137
                                          //  Referenced by: '<S282>/r'

  real_T ct_Y0;                        // Expression: 1
                                          //  Referenced by: '<S282>/ct'

  real_T st_Y0;                        // Expression: 0
                                          //  Referenced by: '<S282>/st'

  real_T sa_Y0;                        // Expression: 0
                                          //  Referenced by: '<S282>/sa'

  real_T ca_Y0;                        // Expression: 0
                                          //  Referenced by: '<S282>/ca'

  real_T b_Value;                      // Expression: 6356.7523142
                                          //  Referenced by: '<S282>/b'

  real_T a_Value;                      // Expression: 6378.137
                                          //  Referenced by: '<S282>/a'

  real_T Gain_Gain_p;                  // Expression: 2
                                          //  Referenced by: '<S327>/Gain'

  real_T Constant_Value_c;             // Expression: 1
                                          //  Referenced by: '<S329>/Constant'

  real_T sp11_Y0[11];                  // Expression: (1:(maxdef-1))
                                          //  Referenced by: '<S330>/sp[11]'

  real_T cp11_Y0[11];                  // Expression: (1:(maxdef-1))
                                          //  Referenced by: '<S330>/cp[11]'

  real_T ForIterator_IterationLimit;   // Expression: maxdef-1
                                          //  Referenced by: '<S330>/For Iterator'

  real_T Constant_Value_ny[11];        // Expression: [1:maxdef-1]
                                          //  Referenced by: '<S330>/Constant'

  real_T UnitDelay1_InitialCondition_e;// Expression: 0
                                          //  Referenced by: '<S330>/Unit Delay1'

  real_T cpm1spm1_Threshold;           // Expression: 1
                                          //  Referenced by: '<S330>/cp[m-1] sp[m-1]'

  real_T Constant1_Value_n[11];        // Expression: [1:maxdef-1]
                                          //  Referenced by: '<S330>/Constant1'

  real_T sp13_Y0[13];                  // Expression: [0 0 (1:(maxdef-1))]
                                          //  Referenced by: '<S283>/sp[13]'

  real_T cp13_Y0[13];                  // Expression: [1 1 (1:(maxdef-1))]
                                          //  Referenced by: '<S283>/cp[13]'

  real_T Gain_Gain_g;                  // Expression: 1
                                          //  Referenced by: '<S283>/Gain'

  real_T Gain1_Gain_n;                 // Expression: 1
                                          //  Referenced by: '<S283>/Gain1'

  real_T cp1_Value;                    // Expression: 1
                                          //  Referenced by: '<S283>/cp[1]'

  real_T sp1_Value;                    // Expression: 0
                                          //  Referenced by: '<S283>/sp[1]'

  real_T u2rhoV2_Gain;                 // Expression: 1/2
                                          //  Referenced by: '<S370>/1//2rhoV^2'

  real_T pgw_Y0;                       // Expression: 0
                                          //  Referenced by: '<S538>/pgw'

  real_T Constant1_Value_j;            // Expression: 1/3
                                          //  Referenced by: '<S538>/Constant1'

  real_T Constant2_Value_pn;           // Expression: 1/6
                                          //  Referenced by: '<S538>/Constant2'

  real_T Constant3_Value;              // Expression: pi/4
                                          //  Referenced by: '<S538>/Constant3'

  real_T pgw_p_IC;                     // Expression: 0
                                          //  Referenced by: '<S538>/pgw_p'

  real_T qgw_Y0;                       // Expression: 0
                                          //  Referenced by: '<S539>/qgw'

  real_T qgw_p_IC;                     // Expression: 0
                                          //  Referenced by: '<S539>/qgw_p'

  real_T pi4_Gain;                     // Expression: pi/4
                                          //  Referenced by: '<S539>/pi//4'

  real_T rgw_Y0;                       // Expression: 0
                                          //  Referenced by: '<S540>/rgw'

  real_T rgw_p_IC;                     // Expression: 0
                                          //  Referenced by: '<S540>/rgw_p'

  real_T pi3_Gain;                     // Expression: pi/3
                                          //  Referenced by: '<S540>/pi//3'

  real_T ugw_Y0;                       // Expression: 0
                                          //  Referenced by: '<S541>/ugw'

  real_T upi_Gain;                     // Expression: 2/pi
                                          //  Referenced by: '<S541>/(2//pi)'

  real_T ug_p_IC;                      // Expression: 0
                                          //  Referenced by: '<S541>/ug_p'

  real_T vgw_Y0;                       // Expression: 0
                                          //  Referenced by: '<S542>/vgw'

  real_T upi_Gain_d;                   // Expression: 1/pi
                                          //  Referenced by: '<S542>/(1//pi)'

  real_T vg_p1_IC;                     // Expression: 0
                                          //  Referenced by: '<S542>/vg_p1'

  real_T vgw_p2_IC;                    // Expression: 0
                                          //  Referenced by: '<S542>/vgw_p2'

  real_T sqrt3_Gain;                   // Expression: sqrt(3)
                                          //  Referenced by: '<S542>/sqrt(3)'

  real_T wgw_Y0;                       // Expression: 0
                                          //  Referenced by: '<S543>/wgw'

  real_T upi_Gain_o;                   // Expression: 1/pi
                                          //  Referenced by: '<S543>/1//pi'

  real_T Constant_Value_mt;            // Expression: 3
                                          //  Referenced by: '<S543>/Constant'

  real_T wg_p1_IC;                     // Expression: 0
                                          //  Referenced by: '<S543>/wg_p1'

  real_T wg_p2_IC;                     // Expression: 0
                                          //  Referenced by: '<S543>/wg_p2'

  real_T Gain_Gain_d;                  // Expression: 1
                                          //  Referenced by: '<S548>/Gain'

  real_T Gain_Gain_k;                  // Expression: 1
                                          //  Referenced by: '<S556>/Gain'

  real_T ReduceZWind_Gain[3];          // Expression: [1 1 0.1]
                                          //  Referenced by: '<S9>/Reduce Z Wind'

  real_T Constant_Value_e;             // Expression: 0
                                          //  Referenced by: '<S406>/Constant'

  real_T Constant_Value_f;             // Expression: 0
                                          //  Referenced by: '<S568>/Constant'

  real_T Gain_clock_Gain;              // Expression: 1E6
                                          //  Referenced by: '<S7>/Gain_clock'

  real_T IntegratorSecondOrderLimited_IC;// Expression: 0
                                            //  Referenced by: '<S252>/Integrator, Second-Order Limited'

  real_T IntegratorSecondOrderLimited__j;// Expression: 0
                                            //  Referenced by: '<S252>/Integrator, Second-Order Limited'

  real_T Constant_Value_b;             // Expression: dtype_a
                                          //  Referenced by: '<S248>/Constant'

  real_T Saturation_UpperSat;          // Expression: 1.0
                                          //  Referenced by: '<S149>/Saturation'

  real_T Saturation_LowerSat;          // Expression: 0
                                          //  Referenced by: '<S149>/Saturation'

  real_T MaxRPM_Gain;                  // Expression: 8000
                                          //  Referenced by: '<S149>/MaxRPM'

  real_T MinRPM_Value;                 // Expression: 0
                                          //  Referenced by: '<S149>/Min RPM'

  real_T PropDiameterin1_Value;        // Expression: 2
                                          //  Referenced by: '<S149>/Prop Diameter (in)1'

  real_T PropDiameterin_Value;         // Expression: 17
                                          //  Referenced by: '<S149>/Prop Diameter (in)'

  real_T PropDiameterin2_Value;        // Expression: 4
                                          //  Referenced by: '<S149>/Prop Diameter (in)2'

  real_T ToConstant_Value;             // Expression: 2.83e-12
                                          //  Referenced by: '<S149>/To Constant'

  real_T phithetapsi_WrappedStateUpperVa;// Expression: pi
                                            //  Referenced by: '<S346>/phi theta psi'

  real_T phithetapsi_WrappedStateLowerVa;// Expression: -pi
                                            //  Referenced by: '<S346>/phi theta psi'

  real_T Merge_InitialOutput_c;        // Expression: 0
                                          //  Referenced by: '<S369>/Merge'

  real_T Merge_InitialOutput_f;        // Expression: 0
                                          //  Referenced by: '<S525>/Merge'

  real_T Gain1_Gain_k;                 // Expression: -1
                                          //  Referenced by: '<S9>/Gain1'

  real_T ZeroBound_UpperSat;           // Expression: inf
                                          //  Referenced by: '<S521>/Zero Bound'

  real_T ZeroBound_LowerSat;           // Expression: 0.001
                                          //  Referenced by: '<S521>/Zero Bound'

  real_T LimitFunction10ftto1000ft_Upper;// Expression: max_height_low
                                            //  Referenced by: '<S562>/Limit Function 10ft to 1000ft'

  real_T LimitFunction10ftto1000ft_Lower;// Expression: 10
                                            //  Referenced by: '<S562>/Limit Function 10ft to 1000ft'

  real_T LimitHeighth1000ft_UpperSat;  // Expression: max_height_low
                                          //  Referenced by: '<S545>/Limit Height h<1000ft'

  real_T LimitHeighth1000ft_LowerSat;  // Expression: 0
                                          //  Referenced by: '<S545>/Limit Height h<1000ft'

  real_T sigma_wg_Gain;                // Expression: 0.1
                                          //  Referenced by: '<S545>/sigma_wg '

  real_T PreLookUpIndexSearchaltitude_Br[12];// Expression: h_vec
                                                //  Referenced by: '<S544>/PreLook-Up Index Search  (altitude)'

  real_T PreLookUpIndexSearchprobofexcee[7];// Expression: [1:7]
                                               //  Referenced by: '<S544>/PreLook-Up Index Search  (prob of exceed)'

  real_T MediumHighAltitudeIntensity_Tab[84];// Expression: sigma_vec'
                                                //  Referenced by: '<S544>/Medium//High Altitude Intensity'

  real_T WhiteNoise_Mean;              // Expression: 0
                                          //  Referenced by: '<S537>/White Noise'

  real_T WhiteNoise_StdDev;            // Computed Parameter: WhiteNoise_StdDev
                                          //  Referenced by: '<S537>/White Noise'

  real_T Lv_Gain;                      // Expression: 1
                                          //  Referenced by: '<S534>/Lv'

  real_T Lw_Gain;                      // Expression: 1
                                          //  Referenced by: '<S534>/Lw'

  real_T Wdeg1_Value;                  // Expression: 0
                                          //  Referenced by: '<S523>/Wdeg1'

  real_T _Gain;                        // Expression: -1
                                          //  Referenced by: '<S523>/ '

  real_T Constant_Value_a[3];          // Expression: [ 0 0 0]
                                          //  Referenced by: '<S9>/Constant'

  real_T Switch_Threshold;             // Expression: 0.3
                                          //  Referenced by: '<S9>/Switch'

  real_T TransferFcn_A;                // Computed Parameter: TransferFcn_A
                                          //  Referenced by: '<S366>/Transfer Fcn'

  real_T TransferFcn_C;                // Computed Parameter: TransferFcn_C
                                          //  Referenced by: '<S366>/Transfer Fcn'

  real_T Gain_Gain_ly;                 // Expression: -1
                                          //  Referenced by: '<S366>/Gain'

  real_T LimitaltitudetoStratosphere_Upp;// Expression: 0
                                            //  Referenced by: '<S399>/Limit  altitude  to Stratosphere'

  real_T Constant1_Value_k;            // Expression: 0
                                          //  Referenced by: '<S6>/Constant1'

  real_T Constant2_Value_c;            // Expression: 0
                                          //  Referenced by: '<S6>/Constant2'

  real_T Constant3_Value_o;            // Expression: 0
                                          //  Referenced by: '<S6>/Constant3'

  real_T Constant4_Value;              // Expression: 0
                                          //  Referenced by: '<S6>/Constant4'

  real_T Constant5_Value;              // Expression: 0
                                          //  Referenced by: '<S6>/Constant5'

  real_T Constant_Value_h[3];          // Expression: [ 0 0 0]
                                          //  Referenced by: '<S342>/Constant'

  real_T Constant1_Value_o3;           // Expression: 0
                                          //  Referenced by: '<S342>/Constant1'

  real_T TransferFcn_A_p;              // Computed Parameter: TransferFcn_A_p
                                          //  Referenced by: '<S384>/Transfer Fcn'

  real_T TransferFcn_C_m;              // Computed Parameter: TransferFcn_C_m
                                          //  Referenced by: '<S384>/Transfer Fcn'

  real_T TransferFcn_D;                // Computed Parameter: TransferFcn_D
                                          //  Referenced by: '<S384>/Transfer Fcn'

  real_T Saturation_UpperSat_a;        // Expression: inf
                                          //  Referenced by: '<S398>/Saturation'

  real_T Saturation_LowerSat_c;        // Expression: 0.1
                                          //  Referenced by: '<S398>/Saturation'

  real_T Gain_Gain_g1;                 // Expression: -1
                                          //  Referenced by: '<S394>/Gain'

  real_T Ydown_Gain;                   // Expression: -1
                                          //  Referenced by: '<S384>/Y-down'

  real_T Gain_Gain_kp;                 // Expression: -1
                                          //  Referenced by: '<S342>/Gain'

  real_T Saturation_UpperSat_g;        // Expression: 0
                                          //  Referenced by: '<S342>/Saturation'

  real_T Saturation_LowerSat_p;        // Expression: -inf
                                          //  Referenced by: '<S342>/Saturation'

  real_T GravitationalForce_Value[3];
                                // Expression: [0 0 uav.geometry.mass*env.ISA_g]
                                   //  Referenced by: '<S342>/Gravitational Force'

  real_T Cmq1_Value;                   // Expression: .5
                                          //  Referenced by: '<S389>/Cmq1'

  real_T Saturation_UpperSat_n;        // Expression: inf
                                          //  Referenced by: '<S389>/Saturation'

  real_T Saturation_LowerSat_h;        // Expression: 0.1
                                          //  Referenced by: '<S389>/Saturation'

  real_T Cmq3_Value;                   // Expression: .5
                                          //  Referenced by: '<S390>/Cmq3'

  real_T Saturation_UpperSat_b;        // Expression: inf
                                          //  Referenced by: '<S390>/Saturation'

  real_T Saturation_LowerSat_l;        // Expression: 0.1
                                          //  Referenced by: '<S390>/Saturation'

  real_T Cmq1_Value_b;                 // Expression: .5
                                          //  Referenced by: '<S392>/Cmq1'

  real_T Saturation_UpperSat_i;        // Expression: inf
                                          //  Referenced by: '<S392>/Saturation'

  real_T Saturation_LowerSat_cz;       // Expression: 0.1
                                          //  Referenced by: '<S392>/Saturation'

  real_T Cmq3_Value_c;                 // Expression: .5
                                          //  Referenced by: '<S393>/Cmq3'

  real_T Saturation_UpperSat_m;        // Expression: inf
                                          //  Referenced by: '<S393>/Saturation'

  real_T Saturation_LowerSat_b;        // Expression: 0.1
                                          //  Referenced by: '<S393>/Saturation'

  real_T Gain4_Gain;                   // Expression: 1
                                          //  Referenced by: '<S8>/Gain4'

  real_T Gain_Gain_n[3];               // Expression: [0 0 9.8]
                                          //  Referenced by: '<S344>/Gain'

  real_T Gain6_Gain;                   // Expression: 1
                                          //  Referenced by: '<S8>/Gain6'

  real_T Gain2_Gain_o;                 // Expression: 1
                                          //  Referenced by: '<S8>/Gain2'

  real_T Gain_Gain_oe;                 // Expression: 1
                                          //  Referenced by: '<S8>/Gain'

  real_T Gain3_Gain;                   // Expression: 1
                                          //  Referenced by: '<S8>/Gain3'

  real_T Merge_InitialOutput_fj[4];    // Expression: [1 0 0 0]
                                          //  Referenced by: '<S410>/Merge'

  real_T Merge_InitialOutput_p[4];     // Expression: [1 0 0 0]
                                          //  Referenced by: '<S409>/Merge'

  real_T Gain8_Gain;                   // Expression: 1
                                          //  Referenced by: '<S8>/Gain8'

  real_T ZeroOrderHold1_Gain;          // Expression: 1
                                          //  Referenced by: '<S246>/Zero-Order Hold1'

  real_T Constant2_Value_g;            // Expression: 1
                                          //  Referenced by: '<S45>/Constant2'

  real_T Constant1_Value_p;            // Expression: R
                                          //  Referenced by: '<S45>/Constant1'

  real_T Constant_Value_i2;            // Expression: 1
                                          //  Referenced by: '<S48>/Constant'

  real_T Constant_Value_d;             // Expression: 1
                                          //  Referenced by: '<S50>/Constant'

  real_T Constant_Value_mj;            // Expression: F
                                          //  Referenced by: '<S49>/Constant'

  real_T f_Value;                      // Expression: 1
                                          //  Referenced by: '<S49>/f'

  real_T Constant_Value_es;            // Expression: 1
                                          //  Referenced by: '<S45>/Constant'

  real_T Constant3_Value_e;            // Expression: 1
                                          //  Referenced by: '<S45>/Constant3'

  real_T Constant2_Value_b;            // Expression: 360
                                          //  Referenced by: '<S36>/Constant2'

  real_T Constant_Value_iz;            // Expression: 180
                                          //  Referenced by: '<S29>/Constant'

  real_T Constant1_Value_jz;           // Expression: 0
                                          //  Referenced by: '<S29>/Constant1'

  real_T Constant2_Value_k0;           // Expression: 360
                                          //  Referenced by: '<S34>/Constant2'

  real_T Saturation_1_UpperSat;        // Expression: 100000
                                          //  Referenced by: '<S3>/Saturation_1'

  real_T Saturation_1_LowerSat;        // Expression: 0
                                          //  Referenced by: '<S3>/Saturation_1'

  real_T JulianDate_Value;             // Expression: juliandate(year,month,day)
                                          //  Referenced by: '<S27>/Julian Date'

  real_T ZeroOrderHold2_Gain;          // Expression: 1
                                          //  Referenced by: '<S246>/Zero-Order Hold2'

  real_T ZeroOrderHold_Gain;           // Expression: 1
                                          //  Referenced by: '<S246>/Zero-Order Hold'

  real_T centerofgravity_Value[3];     // Expression: [0 0 0]
                                          //  Referenced by: '<S226>/center of gravity'

  real_T ZeroOrderHold4_Gain;          // Expression: 1
                                          //  Referenced by: '<S246>/Zero-Order Hold4'

  real_T Gain_Gain_i1[3];              // Expression: [1 -1 1]
                                          //  Referenced by: '<S246>/Gain'

  real_T Constant2_Value_cn[9];        // Expression: zeros(3)
                                          //  Referenced by: '<S348>/Constant2'

  real_T Gain7_Gain;                   // Expression: 1
                                          //  Referenced by: '<S8>/Gain7'

  real_T ZeroOrderHold3_Gain;          // Expression: 1
                                          //  Referenced by: '<S246>/Zero-Order Hold3'

  real_T Switch_Threshold_d;           // Expression: 0.5
                                          //  Referenced by: '<S248>/Switch'

  real_T Saturation_UpperSat_h[3];     // Expression: a_sath
                                          //  Referenced by: '<S246>/Saturation'

  real_T Saturation_LowerSat_cm[3];    // Expression: a_satl
                                          //  Referenced by: '<S246>/Saturation'

  real_T UniformRandomNumber5_Minimum[3];// Expression: -[0.1,0.1,0.2]
                                            //  Referenced by: '<S226>/Uniform Random Number5'

  real_T UniformRandomNumber5_Maximum[3];// Expression: [0.1,0.1,0.2]
                                            //  Referenced by: '<S226>/Uniform Random Number5'

  real_T UniformRandomNumber5_Seed[3]; // Expression: [12233,645554,678766]
                                          //  Referenced by: '<S226>/Uniform Random Number5'

  real_T Gain10_Gain;                  // Expression: 5
                                          //  Referenced by: '<S226>/Gain10'

  real_T IntegratorSecondOrderLimited__n;// Expression: 0
                                            //  Referenced by: '<S263>/Integrator, Second-Order Limited'

  real_T IntegratorSecondOrderLimited__l;// Expression: 0
                                            //  Referenced by: '<S263>/Integrator, Second-Order Limited'

  real_T Constant_Value_g;             // Expression: dtype_g
                                          //  Referenced by: '<S261>/Constant'

  real_T ZeroOrderHold_Gain_h;         // Expression: 1
                                          //  Referenced by: '<S247>/Zero-Order Hold'

  real_T ZeroOrderHold1_Gain_k;        // Expression: 1
                                          //  Referenced by: '<S247>/Zero-Order Hold1'

  real_T Switch_Threshold_p;           // Expression: 0.5
                                          //  Referenced by: '<S261>/Switch'

  real_T Saturation_UpperSat_gx[3];    // Expression: g_sath
                                          //  Referenced by: '<S247>/Saturation'

  real_T Saturation_LowerSat_a[3];     // Expression: g_satl
                                          //  Referenced by: '<S247>/Saturation'

  real_T UniformRandomNumber1_Minimum[3];// Expression: -[0.01,0.01,0.01]
                                            //  Referenced by: '<S226>/Uniform Random Number1'

  real_T UniformRandomNumber1_Maximum[3];// Expression: [0.01,0.01,0.01]
                                            //  Referenced by: '<S226>/Uniform Random Number1'

  real_T UniformRandomNumber1_Seed[3]; // Expression: [3243,44556,2334343]
                                          //  Referenced by: '<S226>/Uniform Random Number1'

  real_T Gain6_Gain_j;                 // Expression: 5
                                          //  Referenced by: '<S226>/Gain6'

  real_T epoch_Value;                  // Expression: epoch
                                          //  Referenced by: '<S273>/epoch'

  real_T DecimalYear_Value;            // Expression: dyear
                                          //  Referenced by: '<S239>/Decimal Year'

  real_T otime_InitialCondition;       // Expression: -1000
                                          //  Referenced by: '<S287>/otime'

  real_T Constant_Value_bw;            // Expression: 180
                                          //  Referenced by: '<S269>/Constant'

  real_T Constant2_Value_h;            // Expression: 360
                                          //  Referenced by: '<S278>/Constant2'

  real_T Constant1_Value_ni;           // Expression: 0
                                          //  Referenced by: '<S269>/Constant1'

  real_T Constant2_Value_n;            // Expression: 360
                                          //  Referenced by: '<S276>/Constant2'

  real_T olon_InitialCondition;        // Expression: -1000
                                          //  Referenced by: '<S286>/olon'

  real_T olat_InitialCondition;        // Expression: -1000
                                          //  Referenced by: '<S285>/olat'

  real_T Gain_Gain_if;                 // Expression: 0.001
                                          //  Referenced by: '<S239>/Gain'

  real_T oalt_InitialCondition;        // Expression: -1000
                                          //  Referenced by: '<S285>/oalt'

  real_T re_Value;                     // Expression: 6371.2
                                          //  Referenced by: '<S273>/re'

  real_T Gain_Mag_Gain;                // Expression: 1
                                          //  Referenced by: '<S226>/Gain_Mag'

  real_T nT2Gauss_Gain;                // Expression: 1E-5
                                          //  Referenced by: '<S226>/nT2Gauss'

  real_T UniformRandomNumber7_Minimum[3];// Expression: -[0.01,0.01,0.01]
                                            //  Referenced by: '<S226>/Uniform Random Number7'

  real_T UniformRandomNumber7_Maximum[3];// Expression: [0.01,0.01,0.01]
                                            //  Referenced by: '<S226>/Uniform Random Number7'

  real_T UniformRandomNumber7_Seed[3]; // Expression: [45465,454534,1234232]
                                          //  Referenced by: '<S226>/Uniform Random Number7'

  real_T Gain11_Gain;                  // Expression: 2
                                          //  Referenced by: '<S226>/Gain11'

  real_T SeaLevelTemperature_Value;    // Expression: T0
                                          //  Referenced by: '<S236>/Sea Level  Temperature'

  real_T Constant_111_Value[3];        // Expression: [1,1,1]
                                          //  Referenced by: '<S28>/Constant_[1 1 1]'

  real_T UniformRandomNumber_Minimum[3];// Expression: [-1,-1,-0.5]
                                           //  Referenced by: '<S28>/Uniform Random Number'

  real_T UniformRandomNumber_Maximum[3];// Expression: [1,1,0.5]
                                           //  Referenced by: '<S28>/Uniform Random Number'

  real_T UniformRandomNumber_Seed[3];  // Expression: [564565,6846798,46545]
                                          //  Referenced by: '<S28>/Uniform Random Number'

  real_T Gain5_Gain;                   // Expression: 1
                                          //  Referenced by: '<S8>/Gain5'

  real_T Gain_1_Gain;                  // Expression: -1
                                          //  Referenced by: '<S28>/Gain_-1'

  real_T Saturation_2_UpperSat;        // Expression: 10000
                                          //  Referenced by: '<S28>/Saturation_2'

  real_T Saturation_2_LowerSat;        // Expression: 0
                                          //  Referenced by: '<S28>/Saturation_2'

  real_T Constant_V_Value;             // Expression: 5
                                          //  Referenced by: '<S28>/Constant_V'

  real_T LimitFunction10ftto1000ft_Upp_d;// Expression: max_height_low
                                            //  Referenced by: '<S143>/Limit Function 10ft to 1000ft'

  real_T LimitFunction10ftto1000ft_Low_k;// Expression: 10
                                            //  Referenced by: '<S143>/Limit Function 10ft to 1000ft'

  real_T LimitHeighth1000ft_UpperSat_p;// Expression: max_height_low
                                          //  Referenced by: '<S126>/Limit Height h<1000ft'

  real_T LimitHeighth1000ft_LowerSat_f;// Expression: 0
                                          //  Referenced by: '<S126>/Limit Height h<1000ft'

  real_T sigma_wg_Gain_a;              // Expression: 0.1
                                          //  Referenced by: '<S126>/sigma_wg '

  real_T PreLookUpIndexSearchaltitude__i[12];// Expression: h_vec
                                                //  Referenced by: '<S125>/PreLook-Up Index Search  (altitude)'

  real_T PreLookUpIndexSearchprobofexc_c[7];// Expression: [1:7]
                                               //  Referenced by: '<S125>/PreLook-Up Index Search  (prob of exceed)'

  real_T MediumHighAltitudeIntensity_T_g[84];// Expression: sigma_vec'
                                                //  Referenced by: '<S125>/Medium//High Altitude Intensity'

  real_T WhiteNoise_Mean_l;            // Expression: 0
                                          //  Referenced by: '<S118>/White Noise'

  real_T WhiteNoise_StdDev_a;         // Computed Parameter: WhiteNoise_StdDev_a
                                         //  Referenced by: '<S118>/White Noise'

  real_T Lv_Gain_c;                    // Expression: 1
                                          //  Referenced by: '<S115>/Lv'

  real_T Lw_Gain_a;                    // Expression: 1
                                          //  Referenced by: '<S115>/Lw'

  real_T Constant_DCM_Value[9];        // Expression: eye(3)
                                          //  Referenced by: '<S28>/Constant_DCM'

  real_T LimitFunction10ftto1000ft_Upp_f;// Expression: max_height_low
                                            //  Referenced by: '<S104>/Limit Function 10ft to 1000ft'

  real_T LimitFunction10ftto1000ft_Low_d;// Expression: 10
                                            //  Referenced by: '<S104>/Limit Function 10ft to 1000ft'

  real_T LimitHeighth1000ft_UpperSat_n;// Expression: max_height_low
                                          //  Referenced by: '<S87>/Limit Height h<1000ft'

  real_T LimitHeighth1000ft_LowerSat_n;// Expression: 0
                                          //  Referenced by: '<S87>/Limit Height h<1000ft'

  real_T sigma_wg_Gain_d;              // Expression: 0.1
                                          //  Referenced by: '<S87>/sigma_wg '

  real_T PreLookUpIndexSearchaltitude__n[12];// Expression: h_vec
                                                //  Referenced by: '<S86>/PreLook-Up Index Search  (altitude)'

  real_T PreLookUpIndexSearchprobofexc_e[7];// Expression: [1:7]
                                               //  Referenced by: '<S86>/PreLook-Up Index Search  (prob of exceed)'

  real_T MediumHighAltitudeIntensity_T_n[84];// Expression: sigma_vec'
                                                //  Referenced by: '<S86>/Medium//High Altitude Intensity'

  real_T WhiteNoise_Mean_e;            // Expression: 0
                                          //  Referenced by: '<S79>/White Noise'

  real_T WhiteNoise_StdDev_h;         // Computed Parameter: WhiteNoise_StdDev_h
                                         //  Referenced by: '<S79>/White Noise'

  real_T Lv_Gain_i;                    // Expression: 1
                                          //  Referenced by: '<S76>/Lv'

  real_T Lw_Gain_m;                    // Expression: 1
                                          //  Referenced by: '<S76>/Lw'

  real_T uftinf_UpperSat;              // Expression: inf
                                          //  Referenced by: '<S66>/3ft-->inf'

  real_T uftinf_LowerSat;              // Expression: 3
                                          //  Referenced by: '<S66>/3ft-->inf'

  real_T hz0_Gain;                     // Expression: 1/z0
                                          //  Referenced by: '<S66>/h//z0'

  real_T ref_heightz0_Value;           // Expression: 20/z0
                                          //  Referenced by: '<S66>/ref_height//z0'

  real_T Wdeg1_Value_g;                // Expression: 0
                                          //  Referenced by: '<S66>/Wdeg1'

  real_T SeaLevelTemperature_Value_m;  // Expression: T0
                                          //  Referenced by: '<S25>/Sea Level  Temperature'

  real_T Limitaltitudetotroposhere_Upper;// Expression: h_trop
                                            //  Referenced by: '<S25>/Limit  altitude  to troposhere'

  real_T Limitaltitudetotroposhere_Lower;// Expression: h0
                                            //  Referenced by: '<S25>/Limit  altitude  to troposhere'

  real_T LapseRate_Gain;               // Expression: L
                                          //  Referenced by: '<S25>/Lapse Rate'

  real_T uT0_Gain;                     // Expression: 1/T0
                                          //  Referenced by: '<S25>/1//T0'

  real_T Constant_Value_o;             // Expression: g/(L*R)
                                          //  Referenced by: '<S25>/Constant'

  real_T rho0_Gain;                    // Expression: rho0
                                          //  Referenced by: '<S25>/rho0'

  real_T AltitudeofTroposphere_Value;  // Expression: h_trop
                                          //  Referenced by: '<S25>/Altitude of Troposphere'

  real_T LimitaltitudetoStratosphere_U_h;// Expression: 0
                                            //  Referenced by: '<S25>/Limit  altitude  to Stratosphere'

  real_T LimitaltitudetoStratosphere_Low;// Expression: h_trop-h_strat
                                            //  Referenced by: '<S25>/Limit  altitude  to Stratosphere'

  real_T gR_Gain;                      // Expression: g/R
                                          //  Referenced by: '<S25>/g//R'

  real_T u2rhoV2_Gain_o;               // Expression: 1/2
                                          //  Referenced by: '<S228>/1//2rhoV^2'

  real_T UniformRandomNumber_Minimum_m;// Expression: -2
                                          //  Referenced by: '<S226>/Uniform Random Number'

  real_T UniformRandomNumber_Maximum_n;// Expression: 2
                                          //  Referenced by: '<S226>/Uniform Random Number'

  real_T UniformRandomNumber_Seed_m;   // Expression: 15634
                                          //  Referenced by: '<S226>/Uniform Random Number'

  real_T Gain5_Gain_l;                 // Expression: 0.2
                                          //  Referenced by: '<S226>/Gain5'

  real_T Constant2_Value_h0;           // Expression: 0.3
                                          //  Referenced by: '<S234>/Constant2'

  real_T Limitaltitudetotroposhere_Upp_j;// Expression: h_trop
                                            //  Referenced by: '<S236>/Limit  altitude  to troposhere'

  real_T Limitaltitudetotroposhere_Low_g;// Expression: h0
                                            //  Referenced by: '<S236>/Limit  altitude  to troposhere'

  real_T LapseRate_Gain_m;             // Expression: L
                                          //  Referenced by: '<S236>/Lapse Rate'

  real_T uT0_Gain_g;                   // Expression: 1/T0
                                          //  Referenced by: '<S236>/1//T0'

  real_T Constant_Value_ij;            // Expression: g/(L*R)
                                          //  Referenced by: '<S236>/Constant'

  real_T P0_Gain;                      // Expression: P0
                                          //  Referenced by: '<S236>/P0'

  real_T AltitudeofTroposphere_Value_k;// Expression: h_trop
                                          //  Referenced by: '<S236>/Altitude of Troposphere'

  real_T LimitaltitudetoStratosphere_U_m;// Expression: 0
                                            //  Referenced by: '<S236>/Limit  altitude  to Stratosphere'

  real_T LimitaltitudetoStratosphere_L_o;// Expression: h_trop-h_strat
                                            //  Referenced by: '<S236>/Limit  altitude  to Stratosphere'

  real_T gR_Gain_k;                    // Expression: g/R
                                          //  Referenced by: '<S236>/g//R'

  real_T Gain_Gain_ku;                 // Expression: 0.01
                                          //  Referenced by: '<S226>/Gain'

  real_T UniformRandomNumber4_Minimum; // Expression: -1
                                          //  Referenced by: '<S226>/Uniform Random Number4'

  real_T UniformRandomNumber4_Maximum; // Expression: 1
                                          //  Referenced by: '<S226>/Uniform Random Number4'

  real_T UniformRandomNumber4_Seed;    // Expression: 25634
                                          //  Referenced by: '<S226>/Uniform Random Number4'

  real_T Gain9_Gain;                   // Expression: 0.01
                                          //  Referenced by: '<S226>/Gain9'

  real_T Constant_Value_oe;            // Expression: 0.5
                                          //  Referenced by: '<S235>/Constant'

  real_T Gain2_Gain_l;                 // Expression: 0.7
                                          //  Referenced by: '<S235>/Gain2'

  real_T Constant2_Value_d;            // Expression: 0.3
                                          //  Referenced by: '<S235>/Constant2'

  real_T Gain1_Gain_a;                 // Expression: 0.01
                                          //  Referenced by: '<S226>/Gain1'

  real_T Constant1_Value_c;            // Expression: 10
                                          //  Referenced by: '<S3>/Constant1'

  real_T Constant_Value_e0;            // Expression: 8191
                                          //  Referenced by: '<S153>/Constant'

  real_T UniformRandomNumber5_Minimum_n[3];// Expression: [-1,-1,-2]
                                              //  Referenced by: '<S194>/Uniform Random Number5'

  real_T UniformRandomNumber5_Maximum_f[3];// Expression: [1,1,2]
                                              //  Referenced by: '<S194>/Uniform Random Number5'

  real_T UniformRandomNumber5_Seed_e[3];// Expression: [1452,787,69]
                                           //  Referenced by: '<S194>/Uniform Random Number5'

  real_T BiasGain2_Gain;               // Expression: 0.5
                                          //  Referenced by: '<S194>/BiasGain2'

  real_T Constant2_Value_hi;           // Expression: 1
                                          //  Referenced by: '<S216>/Constant2'

  real_T Constant1_Value_cs;           // Expression: R
                                          //  Referenced by: '<S216>/Constant1'

  real_T Constant_Value_k;             // Expression: 1
                                          //  Referenced by: '<S219>/Constant'

  real_T Constant_Value_kh;            // Expression: 1
                                          //  Referenced by: '<S221>/Constant'

  real_T Constant_Value_eq;            // Expression: F
                                          //  Referenced by: '<S220>/Constant'

  real_T f_Value_b;                    // Expression: 1
                                          //  Referenced by: '<S220>/f'

  real_T Constant_Value_ea;            // Expression: 1
                                          //  Referenced by: '<S216>/Constant'

  real_T Constant3_Value_i;            // Expression: 1
                                          //  Referenced by: '<S216>/Constant3'

  real_T Constant2_Value_a;            // Expression: 360
                                          //  Referenced by: '<S207>/Constant2'

  real_T latScale_Gain;                // Expression: 1E7
                                          //  Referenced by: '<S152>/latScale'

  real_T Constant_Value_bh;            // Expression: 180
                                          //  Referenced by: '<S200>/Constant'

  real_T Constant1_Value_i;            // Expression: 0
                                          //  Referenced by: '<S200>/Constant1'

  real_T Constant2_Value_n2;           // Expression: 360
                                          //  Referenced by: '<S205>/Constant2'

  real_T lonScale_Gain;                // Expression: 1E7
                                          //  Referenced by: '<S152>/lonScale'

  real_T Saturation_UpperSat_k;        // Expression: 100000
                                          //  Referenced by: '<S194>/Saturation'

  real_T Saturation_LowerSat_bp;       // Expression: 0
                                          //  Referenced by: '<S194>/Saturation'

  real_T altScale_Gain;                // Expression: 1E3
                                          //  Referenced by: '<S152>/altScale'

  real_T Gain6_Gain_f;                 // Expression: 100
                                          //  Referenced by: '<S152>/Gain6'

  real_T Gain8_Gain_e;                 // Expression: 100
                                          //  Referenced by: '<S152>/Gain8'

  real_T TransferFcn4_A;               // Computed Parameter: TransferFcn4_A
                                          //  Referenced by: '<S196>/Transfer Fcn4'

  real_T TransferFcn4_C;               // Computed Parameter: TransferFcn4_C
                                          //  Referenced by: '<S196>/Transfer Fcn4'

  real_T TransferFcn1_A;               // Computed Parameter: TransferFcn1_A
                                          //  Referenced by: '<S196>/Transfer Fcn1'

  real_T TransferFcn1_C;               // Computed Parameter: TransferFcn1_C
                                          //  Referenced by: '<S196>/Transfer Fcn1'

  real_T TransferFcn2_A;               // Computed Parameter: TransferFcn2_A
                                          //  Referenced by: '<S196>/Transfer Fcn2'

  real_T TransferFcn2_C;               // Computed Parameter: TransferFcn2_C
                                          //  Referenced by: '<S196>/Transfer Fcn2'

  real_T VelScale_Gain;                // Expression: 1E2
                                          //  Referenced by: '<S152>/VelScale'

  real_T VeScale_Gain;                 // Expression: 1E2
                                          //  Referenced by: '<S152>/VeScale'

  real_T AngleScale_Gain;              // Expression: 1E2
                                          //  Referenced by: '<S152>/AngleScale'

  real_T CopterID_Value;               // Expression: 1
                                          //  Referenced by: '<S7>/CopterID'

  real_T Merge_InitialOutput_h[4];     // Expression: [1 0 0 0]
                                          //  Referenced by: '<S151>/Merge'

  real_T Gain_Gain_k2;                 // Expression: 1
                                          //  Referenced by: '<S1>/Gain'

  real_T Gain1_Gain_e;                 // Expression: 1000
                                          //  Referenced by: '<S1>/Gain1'

  real_T Gain2_Gain_lu;                // Expression: 1
                                          //  Referenced by: '<S1>/Gain2'

  real_T Gain6_Gain_jk;                // Expression: 180/pi
                                          //  Referenced by: '<S1>/Gain6'

  real_T Gain3_Gain_c;                 // Expression: 1
                                          //  Referenced by: '<S1>/Gain3'

  real_T Gain7_Gain_o;                 // Expression: 180/pi
                                          //  Referenced by: '<S1>/Gain7'

  real_T Gain10_Gain_g;                // Expression: -1
                                          //  Referenced by: '<S1>/Gain10'

  real_T Gain4_Gain_d;                 // Expression: 1
                                          //  Referenced by: '<S1>/Gain4'

  real_T Gain8_Gain_d;                 // Expression: 180/pi
                                          //  Referenced by: '<S1>/Gain8'

  real_T Gain5_Gain_n;                 // Expression: 1
                                          //  Referenced by: '<S1>/Gain5'

  real_T Gain9_Gain_b;                 // Expression: 180/pi
                                          //  Referenced by: '<S1>/Gain9'

  real_T Gain4_Gain_a;                 // Expression: -1
                                          //  Referenced by: '<Root>/Gain4'

  real_T flap_Value;                   // Expression: 0
                                          //  Referenced by: '<Root>/flap'

  real_T Constant1_Value_pt;           // Expression: 1
                                          //  Referenced by: '<Root>/Constant1'

  real_T Gain2_Gain_b;                 // Expression: 0.5
                                          //  Referenced by: '<Root>/Gain2'

  real_T WhiteNoise_Mean_f;            // Expression: 0
                                          //  Referenced by: '<S16>/White Noise'

  real_T WhiteNoise_StdDev_k;         // Computed Parameter: WhiteNoise_StdDev_k
                                         //  Referenced by: '<S16>/White Noise'

  real_T Gain_Gain_g0;                 // Expression: 1
                                          //  Referenced by: '<S15>/Gain'

  real_T u_Value;                      // Expression: 1.0
                                          //  Referenced by: '<S17>/2'

  real_T Constant_Value_ki[18];
                            // Expression: [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
                               //  Referenced by: '<S4>/Constant'

  real_T Constant_Value_lt;            // Expression: 2
                                          //  Referenced by: '<S15>/Constant'

  real_T UniformRandomNumber4_Minimum_o[3];// Expression: [-1,-1,-2]
                                              //  Referenced by: '<S152>/Uniform Random Number4'

  real_T UniformRandomNumber4_Maximum_a[3];// Expression: [1,1,2]
                                              //  Referenced by: '<S152>/Uniform Random Number4'

  real_T UniformRandomNumber4_Seed_g[3];// Expression: [5445,45433,33433]
                                           //  Referenced by: '<S152>/Uniform Random Number4'

  real_T BiasGain1_Gain;               // Expression: 0.1
                                          //  Referenced by: '<S152>/BiasGain1'

  real_T Constant_Value_nk[3];         // Expression: [0 0 0]
                                          //  Referenced by: '<S8>/Constant'

  real_T IntegratorSecondOrderLimited__g;// Expression: 0
                                            //  Referenced by: '<S512>/Integrator, Second-Order Limited'

  real_T IntegratorSecondOrderLimited__o;// Expression: 0
                                            //  Referenced by: '<S512>/Integrator, Second-Order Limited'

  real_T ZeroOrderHold1_Gain_f;        // Expression: 1
                                          //  Referenced by: '<S345>/Zero-Order Hold1'

  real_T ZeroOrderHold2_Gain_n;        // Expression: 1
                                          //  Referenced by: '<S345>/Zero-Order Hold2'

  real_T ZeroOrderHold_Gain_l;         // Expression: 1
                                          //  Referenced by: '<S345>/Zero-Order Hold'

  real_T ZeroOrderHold4_Gain_j;        // Expression: 1
                                          //  Referenced by: '<S345>/Zero-Order Hold4'

  real_T Gain_Gain_il[3];              // Expression: [1 -1 1]
                                          //  Referenced by: '<S345>/Gain'

  real_T ZeroOrderHold3_Gain_b;        // Expression: 1
                                          //  Referenced by: '<S345>/Zero-Order Hold3'

  int32_T Constant1_Value_kv;          // Computed Parameter: Constant1_Value_kv
                                          //  Referenced by: '<S299>/Constant1'

  int32_T Constant_Value_mb;           // Computed Parameter: Constant_Value_mb
                                          //  Referenced by: '<S300>/Constant'

  int32_T Constant_Value_ce;           // Computed Parameter: Constant_Value_ce
                                          //  Referenced by: '<S298>/Constant'

  int32_T Constant_Value_e3;           // Computed Parameter: Constant_Value_e3
                                          //  Referenced by: '<S309>/Constant'

  int32_T Gain_Gain_ow;                // Computed Parameter: Gain_Gain_ow
                                          //  Referenced by: '<S309>/Gain'

  int32_T Constant_Value_p;            // Computed Parameter: Constant_Value_p
                                          //  Referenced by: '<S312>/Constant'

  int32_T Gain_Gain_kt;                // Computed Parameter: Gain_Gain_kt
                                          //  Referenced by: '<S311>/Gain'

  int32_T Constant_Value_b4;           // Computed Parameter: Constant_Value_b4
                                          //  Referenced by: '<S315>/Constant'

  int32_T Constant1_Value_e;           // Computed Parameter: Constant1_Value_e
                                          //  Referenced by: '<S315>/Constant1'

  int32_T Constant1_Value_a;           // Computed Parameter: Constant1_Value_a
                                          //  Referenced by: '<S316>/Constant1'

  int32_T Constant_Value_kw;           // Computed Parameter: Constant_Value_kw
                                          //  Referenced by: '<S314>/Constant'

  int32_T Constant1_Value_oh;          // Computed Parameter: Constant1_Value_oh
                                          //  Referenced by: '<S313>/Constant1'

  int32_T Gain_Gain_ai;                // Computed Parameter: Gain_Gain_ai
                                          //  Referenced by: '<S313>/Gain'

  int32_T Constant1_Value_ck;          // Computed Parameter: Constant1_Value_ck
                                          //  Referenced by: '<S317>/Constant1'

  int32_T Constant_Value_o5;           // Computed Parameter: Constant_Value_o5
                                          //  Referenced by: '<S291>/Constant'

  int32_T Constant_Value_kn;           // Computed Parameter: Constant_Value_kn
                                          //  Referenced by: '<S308>/Constant'

  int32_T Gain_Gain_ag;                // Computed Parameter: Gain_Gain_ag
                                          //  Referenced by: '<S308>/Gain'

  int32_T Constant_Value_mq;           // Computed Parameter: Constant_Value_mq
                                          //  Referenced by: '<S318>/Constant'

  int32_T Constant1_Value_ab;          // Computed Parameter: Constant1_Value_ab
                                          //  Referenced by: '<S318>/Constant1'

  int32_T Constant_Value_khy;          // Computed Parameter: Constant_Value_khy
                                          //  Referenced by: '<S320>/Constant'

  int32_T tc_old_Threshold;            // Computed Parameter: tc_old_Threshold
                                          //  Referenced by: '<S319>/tc_old'

  int32_T Constant_Value_ct;           // Computed Parameter: Constant_Value_ct
                                          //  Referenced by: '<S290>/Constant'

  int32_T Constant1_Value_d;           // Computed Parameter: Constant1_Value_d
                                          //  Referenced by: '<S290>/Constant1'

  int32_T Constant_Value_lcx;          // Computed Parameter: Constant_Value_lcx
                                          //  Referenced by: '<S289>/Constant'

  int32_T Constant_Value_ba;           // Computed Parameter: Constant_Value_ba
                                          //  Referenced by: '<S294>/Constant'

  int32_T Gain_Gain_jb;                // Computed Parameter: Gain_Gain_jb
                                          //  Referenced by: '<S294>/Gain'

  int32_T Constant_Value_mw;           // Computed Parameter: Constant_Value_mw
                                          //  Referenced by: '<S296>/Constant'

  int32_T ForIterator_IterationLimit_c;
                             // Computed Parameter: ForIterator_IterationLimit_c
                                //  Referenced by: '<S281>/For Iterator'

  int32_T Constant_Value_b5;           // Computed Parameter: Constant_Value_b5
                                          //  Referenced by: '<S281>/Constant'

  int32_T arn_Threshold;               // Computed Parameter: arn_Threshold
                                          //  Referenced by: '<S281>/ar(n)'

  int32_T FaultID_Value;               // Computed Parameter: FaultID_Value
                                          //  Referenced by: '<S226>/FaultID'

  int32_T FaultID1_Value;              // Computed Parameter: FaultID1_Value
                                          //  Referenced by: '<S226>/FaultID1'

  int32_T FaultID2_Value;              // Computed Parameter: FaultID2_Value
                                          //  Referenced by: '<S226>/FaultID2'

  int32_T FaultID4_Value;       // Expression: FaultParamStruct.NoiseWindFaultID
                                   //  Referenced by: '<S28>/FaultID4'

  int32_T FaultID_Value_i;      // Expression: FaultParamStruct.ConstWindFaultID
                                   //  Referenced by: '<S28>/FaultID'

  int32_T FaultID1_Value_j;      // Expression: FaultParamStruct.GustWindFaultID
                                    //  Referenced by: '<S28>/FaultID1'

  int32_T FaultID2_Value_i;      // Expression: FaultParamStruct.TurbWindFaultID
                                    //  Referenced by: '<S28>/FaultID2'

  int32_T FaultID3_Value;       // Expression: FaultParamStruct.SheerWindFaultID
                                   //  Referenced by: '<S28>/FaultID3'

  int32_T FaultID3_Value_h;            // Computed Parameter: FaultID3_Value_h
                                          //  Referenced by: '<S226>/FaultID3'

  int32_T FaultID_Value_m;       // Expression: FaultParamStruct.GPSNoiseFaultID
                                    //  Referenced by: '<S194>/FaultID'

  int32_T FaultID_Value_b;             // Expression: FaultParamStruct.FaultID
                                          //  Referenced by: '<S15>/FaultID'

  uint32_T MediumHighAltitudeIntensity_max[2];
                          // Computed Parameter: MediumHighAltitudeIntensity_max
                             //  Referenced by: '<S544>/Medium//High Altitude Intensity'

  uint32_T MediumHighAltitudeIntensity_m_o[2];
                          // Computed Parameter: MediumHighAltitudeIntensity_m_o
                             //  Referenced by: '<S125>/Medium//High Altitude Intensity'

  uint32_T MediumHighAltitudeIntensity_m_h[2];
                          // Computed Parameter: MediumHighAltitudeIntensity_m_h
                             //  Referenced by: '<S86>/Medium//High Altitude Intensity'

  P_PositiveYaw_FixedwingModel_T PositiveYaw_i;// '<S525>/Positive Yaw'
  P_NegativeYaw_FixedwingModel_T NegativeYaw_d;// '<S525>/Negative Yaw'
  P_Interpolatevelocities_Fixed_T Interpolatevelocities_k;// '<S533>/Interpolate  velocities' 
  P_Interpolaterates_FixedwingM_T Interpolaterates_c;// '<S532>/Interpolate  rates' 
  P_IfWarningError_FixedwingMod_T IfWarningError_j;// '<S456>/If Warning//Error' 
  P_NegativeTrace_FixedwingMode_T NegativeTrace_a;// '<S410>/Negative Trace'
  P_PositiveTrace_FixedwingMode_T PositiveTrace_f;// '<S410>/Positive Trace'
  P_IfWarningError_FixedwingMod_T IfWarningError_g;// '<S418>/If Warning//Error' 
  P_NegativeTrace_FixedwingMode_T NegativeTrace_j;// '<S409>/Negative Trace'
  P_PositiveTrace_FixedwingMode_T PositiveTrace_l;// '<S409>/Positive Trace'
  P_PositiveYaw_FixedwingModel_T PositiveYaw;// '<S369>/Positive Yaw'
  P_NegativeYaw_FixedwingModel_T NegativeYaw;// '<S369>/Negative Yaw'
  P_IfWarningError_FixedwingMod_T IfWarningError;// '<S157>/If Warning//Error'
  P_NegativeTrace_FixedwingMode_T NegativeTrace;// '<S151>/Negative Trace'
  P_PositiveTrace_FixedwingMode_T PositiveTrace;// '<S151>/Positive Trace'
  P_Interpolatevelocities_Fixed_T Interpolatevelocities_n;// '<S114>/Interpolate  velocities' 
  P_Interpolaterates_FixedwingM_T Interpolaterates_a;// '<S113>/Interpolate  rates' 
  P_Hwgwz_FixedwingModel_T Hwgwz_j;    // '<S109>/Hwgw(z)'
  P_Hvgwz_FixedwingModel_T Hvgwz_o;    // '<S109>/Hvgw(z)'
  P_Hugwz_FixedwingModel_T Hugwz_l;    // '<S109>/Hugw(z)'
  P_Hrgw_FixedwingModel_T Hrgw_a;      // '<S108>/Hrgw'
  P_Hqgw_FixedwingModel_T Hqgw_p;      // '<S108>/Hqgw'
  P_Hpgw_FixedwingModel_T Hpgw_h;      // '<S108>/Hpgw'
  P_Interpolatevelocities_Fixed_T Interpolatevelocities;// '<S75>/Interpolate  velocities' 
  P_Interpolaterates_FixedwingM_T Interpolaterates;// '<S74>/Interpolate  rates' 
  P_Hwgwz_FixedwingModel_T Hwgwz;      // '<S70>/Hwgw(z)'
  P_Hvgwz_FixedwingModel_T Hvgwz;      // '<S70>/Hvgw(z)'
  P_Hugwz_FixedwingModel_T Hugwz;      // '<S70>/Hugw(z)'
  P_Hrgw_FixedwingModel_T Hrgw;        // '<S69>/Hrgw'
  P_Hqgw_FixedwingModel_T Hqgw;        // '<S69>/Hqgw'
  P_Hpgw_FixedwingModel_T Hpgw;        // '<S69>/Hpgw'
  P_Distanceintogusty_Fixedwing_T Distanceintogustz;// '<S17>/Distance into gust (z)' 
  P_Distanceintogusty_Fixedwing_T Distanceintogusty;// '<S17>/Distance into gust (y)' 
};

// Parameters (default storage)
typedef struct P_FixedwingModel_T_ P_FixedwingModel_T;

// Real-time Model Data Structure
struct tag_RTM_FixedwingModel_T {
  const char_T *errorStatus;
  RTWSolverInfo solverInfo;
  X_FixedwingModel_T *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  boolean_T *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;
  real_T odeY[64];
  real_T odeF[4][64];
  ODE4_IntgData intgData;

  //
  //  Sizes:
  //  The following substructure contains sizes information
  //  for many of the model attributes such as inputs, outputs,
  //  dwork, sample times, etc.

  struct {
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numSampTimes;
  } Sizes;

  //
  //  Timing:
  //  The following substructure contains information regarding
  //  the timing information for the model.

  struct {
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    struct {
      uint16_T TID[6];
    } TaskCounters;

    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[6];
  } Timing;
};

extern "C" {
  static real_T rtGetInf(void);
  static real32_T rtGetInfF(void);
  static real_T rtGetMinusInf(void);
  static real32_T rtGetMinusInfF(void);
}                                      // extern "C"
  extern "C"
{
  static real_T rtGetNaN(void);
  static real32_T rtGetNaNF(void);
}                                      // extern "C"

extern "C" {
  extern real_T rtInf;
  extern real_T rtMinusInf;
  extern real_T rtNaN;
  extern real32_T rtInfF;
  extern real32_T rtMinusInfF;
  extern real32_T rtNaNF;
  static void rt_InitInfAndNaN(size_t realSize);
  static boolean_T rtIsInf(real_T value);
  static boolean_T rtIsInfF(real32_T value);
  static boolean_T rtIsNaN(real_T value);
  static boolean_T rtIsNaNF(real32_T value);
  struct BigEndianIEEEDouble {
    struct {
      uint32_T wordH;
      uint32_T wordL;
    } words;
  };

  struct LittleEndianIEEEDouble {
    struct {
      uint32_T wordL;
      uint32_T wordH;
    } words;
  };

  struct IEEESingle {
    union {
      real32_T wordLreal;
      uint32_T wordLuint;
    } wordL;
  };
}                                      // extern "C"
  // Class declaration for model FixedwingModel
  class MulticopterModelClass
{
  // public data and function members
 public:
  // Real-Time Model get method
  RT_MODEL_FixedwingModel_T * getRTM();

  // External inputs
  ExtU_FixedwingModel_T FixedwingModel_U;

  // External outputs
  ExtY_FixedwingModel_T FixedwingModel_Y;

  // Tunable parameters
  static P_FixedwingModel_T FixedwingModel_P;

  // model initialize function
  void initialize();

  // model step function
  void step();

  // model terminate function
  static void terminate();

  // Constructor
  MulticopterModelClass();

  // Destructor
  ~MulticopterModelClass();

  // private data and function members
 private:
  // Block signals
  B_FixedwingModel_T FixedwingModel_B;

  // Block states
  DW_FixedwingModel_T FixedwingModel_DW;

  // Block continuous states
  X_FixedwingModel_T FixedwingModel_X;

  // private member function(s) for subsystem '<S17>/Distance into gust (y)'
  static void Fixedwin_Distanceintogusty_Init(B_Distanceintogusty_Fixedwing_T
    *localB, P_Distanceintogusty_Fixedwing_T *localP,
    X_Distanceintogusty_Fixedwing_T *localX);
  static void Fixedwi_Distanceintogusty_Reset(P_Distanceintogusty_Fixedwing_T
    *localP, X_Distanceintogusty_Fixedwing_T *localX);
  void Fixedwi_Distanceintogusty_Deriv(real_T rtu_V, real_T rtp_d_m,
    DW_Distanceintogusty_Fixedwin_T *localDW, P_Distanceintogusty_Fixedwing_T
    *localP, X_Distanceintogusty_Fixedwing_T *localX,
    XDot_Distanceintogusty_Fixedw_T *localXdot);
  static void Fixed_Distanceintogusty_Disable(DW_Distanceintogusty_Fixedwin_T
    *localDW);
  void FixedwingMode_Distanceintogusty(boolean_T rtu_Enable, real_T rtp_d_m,
    B_Distanceintogusty_Fixedwing_T *localB, DW_Distanceintogusty_Fixedwin_T
    *localDW, P_Distanceintogusty_Fixedwing_T *localP,
    X_Distanceintogusty_Fixedwing_T *localX);

  // private member function(s) for subsystem '<S15>/FaultParamsExtract'
  static void FixedwingMod_FaultParamsExtract(int32_T rtu_FaultID, const int32_T
    rtu_inInts[8], const real_T rtu_inFloats[20],
    B_FaultParamsExtract_Fixedwin_T *localB, DW_FaultParamsExtract_Fixedwi_T
    *localDW);

  // private member function(s) for subsystem '<S69>/Hpgw'
  static void FixedwingModel_Hpgw_Init(B_Hpgw_FixedwingModel_T *localB,
    DW_Hpgw_FixedwingModel_T *localDW, P_Hpgw_FixedwingModel_T *localP);
  static void FixedwingModel_Hpgw_Reset(DW_Hpgw_FixedwingModel_T *localDW,
    P_Hpgw_FixedwingModel_T *localP);
  static void FixedwingModel_Hpgw_Disable(B_Hpgw_FixedwingModel_T *localB,
    DW_Hpgw_FixedwingModel_T *localDW, P_Hpgw_FixedwingModel_T *localP);
  void FixedwingModel_Hpgw_Update(B_Hpgw_FixedwingModel_T *localB,
    DW_Hpgw_FixedwingModel_T *localDW);
  void FixedwingModel_Hpgw(real_T rtu_Enable, const real_T rtu_L_wg[2], real_T
    rtu_sigma_wg, real_T rtu_sigma_wg_j, real_T rtu_Noise, real_T rtu_wingspan,
    B_Hpgw_FixedwingModel_T *localB, DW_Hpgw_FixedwingModel_T *localDW,
    P_Hpgw_FixedwingModel_T *localP);

  // private member function(s) for subsystem '<S69>/Hqgw'
  static void FixedwingModel_Hqgw_Init(B_Hqgw_FixedwingModel_T *localB,
    DW_Hqgw_FixedwingModel_T *localDW, P_Hqgw_FixedwingModel_T *localP);
  static void FixedwingModel_Hqgw_Reset(DW_Hqgw_FixedwingModel_T *localDW,
    P_Hqgw_FixedwingModel_T *localP);
  static void FixedwingModel_Hqgw_Disable(B_Hqgw_FixedwingModel_T *localB,
    DW_Hqgw_FixedwingModel_T *localDW, P_Hqgw_FixedwingModel_T *localP);
  void FixedwingModel_Hqgw_Update(const real_T rtu_wg[2],
    B_Hqgw_FixedwingModel_T *localB, DW_Hqgw_FixedwingModel_T *localDW);
  void FixedwingModel_Hqgw(real_T rtu_Enable, real_T rtu_V, const real_T rtu_wg
    [2], real_T rtu_wingspan, B_Hqgw_FixedwingModel_T *localB,
    DW_Hqgw_FixedwingModel_T *localDW, P_Hqgw_FixedwingModel_T *localP);

  // private member function(s) for subsystem '<S69>/Hrgw'
  static void FixedwingModel_Hrgw_Init(B_Hrgw_FixedwingModel_T *localB,
    DW_Hrgw_FixedwingModel_T *localDW, P_Hrgw_FixedwingModel_T *localP);
  static void FixedwingModel_Hrgw_Reset(DW_Hrgw_FixedwingModel_T *localDW,
    P_Hrgw_FixedwingModel_T *localP);
  static void FixedwingModel_Hrgw_Disable(B_Hrgw_FixedwingModel_T *localB,
    DW_Hrgw_FixedwingModel_T *localDW, P_Hrgw_FixedwingModel_T *localP);
  void FixedwingModel_Hrgw_Update(const real_T rtu_vg[2],
    B_Hrgw_FixedwingModel_T *localB, DW_Hrgw_FixedwingModel_T *localDW);
  void FixedwingModel_Hrgw(real_T rtu_Enable, real_T rtu_V, const real_T rtu_vg
    [2], real_T rtu_wingspan, B_Hrgw_FixedwingModel_T *localB,
    DW_Hrgw_FixedwingModel_T *localDW, P_Hrgw_FixedwingModel_T *localP);

  // private member function(s) for subsystem '<S70>/Hugw(z)'
  static void FixedwingModel_Hugwz_Init(B_Hugwz_FixedwingModel_T *localB,
    DW_Hugwz_FixedwingModel_T *localDW, P_Hugwz_FixedwingModel_T *localP);
  static void FixedwingModel_Hugwz_Reset(DW_Hugwz_FixedwingModel_T *localDW,
    P_Hugwz_FixedwingModel_T *localP);
  static void FixedwingModel_Hugwz_Disable(B_Hugwz_FixedwingModel_T *localB,
    DW_Hugwz_FixedwingModel_T *localDW, P_Hugwz_FixedwingModel_T *localP);
  void FixedwingModel_Hugwz_Update(B_Hugwz_FixedwingModel_T *localB,
    DW_Hugwz_FixedwingModel_T *localDW);
  void FixedwingModel_Hugwz(real_T rtu_Enable, real_T rtu_V, real_T rtu_L_ug,
    real_T rtu_L_ug_o, real_T rtu_sigma_ug, real_T rtu_sigma_ug_o, real_T
    rtu_Noise, B_Hugwz_FixedwingModel_T *localB, DW_Hugwz_FixedwingModel_T
    *localDW, P_Hugwz_FixedwingModel_T *localP);

  // private member function(s) for subsystem '<S70>/Hvgw(z)'
  static void FixedwingModel_Hvgwz_Init(B_Hvgwz_FixedwingModel_T *localB,
    DW_Hvgwz_FixedwingModel_T *localDW, P_Hvgwz_FixedwingModel_T *localP);
  static void FixedwingModel_Hvgwz_Reset(DW_Hvgwz_FixedwingModel_T *localDW,
    P_Hvgwz_FixedwingModel_T *localP);
  static void FixedwingModel_Hvgwz_Disable(B_Hvgwz_FixedwingModel_T *localB,
    DW_Hvgwz_FixedwingModel_T *localDW, P_Hvgwz_FixedwingModel_T *localP);
  void FixedwingModel_Hvgwz_Update(B_Hvgwz_FixedwingModel_T *localB,
    DW_Hvgwz_FixedwingModel_T *localDW);
  void FixedwingModel_Hvgwz(real_T rtu_Enable, real_T rtu_sigma_vg, real_T
    rtu_sigma_vg_i, const real_T rtu_L_vg[2], real_T rtu_V, real_T rtu_Noise,
    B_Hvgwz_FixedwingModel_T *localB, DW_Hvgwz_FixedwingModel_T *localDW,
    P_Hvgwz_FixedwingModel_T *localP);

  // private member function(s) for subsystem '<S70>/Hwgw(z)'
  static void FixedwingModel_Hwgwz_Init(B_Hwgwz_FixedwingModel_T *localB,
    DW_Hwgwz_FixedwingModel_T *localDW, P_Hwgwz_FixedwingModel_T *localP);
  static void FixedwingModel_Hwgwz_Reset(DW_Hwgwz_FixedwingModel_T *localDW,
    P_Hwgwz_FixedwingModel_T *localP);
  static void FixedwingModel_Hwgwz_Disable(B_Hwgwz_FixedwingModel_T *localB,
    DW_Hwgwz_FixedwingModel_T *localDW, P_Hwgwz_FixedwingModel_T *localP);
  void FixedwingModel_Hwgwz_Update(B_Hwgwz_FixedwingModel_T *localB,
    DW_Hwgwz_FixedwingModel_T *localDW);
  void FixedwingModel_Hwgwz(real_T rtu_Enable, real_T rtu_V, const real_T
    rtu_L_wg[2], real_T rtu_sigma_wg, real_T rtu_sigma_wg_n, real_T rtu_Noise,
    B_Hwgwz_FixedwingModel_T *localB, DW_Hwgwz_FixedwingModel_T *localDW,
    P_Hwgwz_FixedwingModel_T *localP);

  // private member function(s) for subsystem '<S74>/Low altitude  rates'
  static void FixedwingModel_Lowaltituderates(const real_T rtu_DCM[9], const
    real_T rtu_pgw_hl[2], const real_T rtu_qgw_hl[2], const real_T rtu_rgw_hl[2],
    real_T rtu_Winddirection, real_T rty_pgwqgwrgw[3]);

  // private member function(s) for subsystem '<S74>/Interpolate  rates'
  static void FixedwingModel_Interpolaterates(const real_T rtu_pgw_hl[2], const
    real_T rtu_qgw_hl[2], const real_T rtu_rgw_hl[2], const real_T rtu_DCM[9],
    real_T rtu_Winddirection, real_T rtu_Altitude, real_T rty_pgwqgwrgw[3],
    P_Interpolaterates_FixedwingM_T *localP);

  // private member function(s) for subsystem '<S75>/Low altitude  velocities'
  static void Fixedwing_Lowaltitudevelocities(const real_T rtu_DCM[9], const
    real_T rtu_ugw_hl[2], const real_T rtu_vgw_hl[2], const real_T rtu_wgw_hl[2],
    real_T rtu_Winddirection, real_T rty_ugwvgwwgw[3]);

  // private member function(s) for subsystem '<S75>/Interpolate  velocities'
  static void Fixedwing_Interpolatevelocities(const real_T rtu_ugw_hl[2], const
    real_T rtu_vgw_hl[2], const real_T rtu_wgw_hl[2], const real_T rtu_DCM[9],
    real_T rtu_Winddirection, real_T rtu_Altitude, real_T rty_ugwvgwwgw[3],
    P_Interpolatevelocities_Fixed_T *localP);

  // private member function(s) for subsystem '<S151>/Positive Trace'
  static void FixedwingModel_PositiveTrace(real_T rtu_traceDCM, const real_T
    rtu_DCM[9], real_T *rty_qwqxqyqz, real_T rty_qwqxqyqz_h[3],
    P_PositiveTrace_FixedwingMode_T *localP);

  // private member function(s) for subsystem '<S151>/Negative Trace'
  static void FixedwingMod_NegativeTrace_Init(DW_NegativeTrace_FixedwingMod_T
    *localDW);
  void FixedwingModel_NegativeTrace(const real_T rtu_DCM[9], real_T
    rty_qwqxqyqz[4], DW_NegativeTrace_FixedwingMod_T *localDW,
    P_NegativeTrace_FixedwingMode_T *localP);

  // private member function(s) for subsystem '<S157>/If Warning//Error'
  static void FixedwingModel_IfWarningError(const real_T rtu_dcm[9], real_T
    rtp_action, real_T rtp_tolerance, P_IfWarningError_FixedwingMod_T *localP);

  // private member function(s) for subsystem '<S227>/Acc NoiseFun'
  static void FixedwingModel_AccNoiseFun(const real_T rtu_u[3], boolean_T
    rtu_isAccFault, const real_T rtu_AccFaultParams[20],
    B_AccNoiseFun_FixedwingModel_T *localB);

  // private member function(s) for subsystem '<S369>/Negative Yaw'
  static void FixedwingMo_NegativeYaw_Disable(DW_NegativeYaw_FixedwingModel_T
    *localDW);
  void FixedwingModel_NegativeYaw(boolean_T rtu_Enable, real_T rtu_yaw, real_T
    *rty_yaw_wr, DW_NegativeYaw_FixedwingModel_T *localDW,
    P_NegativeYaw_FixedwingModel_T *localP);

  // private member function(s) for subsystem '<S369>/Positive Yaw'
  static void FixedwingMo_PositiveYaw_Disable(DW_PositiveYaw_FixedwingModel_T
    *localDW);
  void FixedwingModel_PositiveYaw(uint8_T rtu_Enable, real_T rtu_yaw, real_T
    *rty_yaw_wr, DW_PositiveYaw_FixedwingModel_T *localDW,
    P_PositiveYaw_FixedwingModel_T *localP);

  // private member function(s) for subsystem '<Root>'
  real_T FixedwingMod_eml_rand_mt19937ar(uint32_T state[625]);
  real_T FixedwingMode_eml_rand_mcg16807(uint32_T *state);
  real_T FixedwingModel_rand(void);
  void FixedwingModel_rand_p(real_T r[3]);
  real_T FixedwingModel_rand_f(void);

  // Continuous states update member function
  void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si );

  // Derivatives member function
  void FixedwingModel_derivatives();

  // Real-Time Model
  RT_MODEL_FixedwingModel_T FixedwingModel_M;
}

;

//-
//  These blocks were eliminated from the model due to optimizations:
//
//  Block '<S24>/Data Type Duplicate' : Unused code path elimination
//  Block '<S3>/Gain_-1' : Unused code path elimination
//  Block '<S25>/P0' : Unused code path elimination
//  Block '<S25>/Product2' : Unused code path elimination
//  Block '<S25>/a' : Unused code path elimination
//  Block '<S25>/gamma*R' : Unused code path elimination
//  Block '<S3>/Saturation_2' : Unused code path elimination
//  Block '<S55>/Cast' : Unused code path elimination
//  Block '<S56>/Cast' : Unused code path elimination
//  Block '<S152>/Bus Creator1' : Unused code path elimination
//  Block '<S152>/Data Type Conversion1' : Unused code path elimination
//  Block '<S152>/Data Type Conversion12' : Unused code path elimination
//  Block '<S152>/Data Type Conversion13' : Unused code path elimination
//  Block '<S152>/Data Type Conversion14' : Unused code path elimination
//  Block '<S152>/Data Type Conversion15' : Unused code path elimination
//  Block '<S152>/Data Type Conversion16' : Unused code path elimination
//  Block '<S198>/Data Type Duplicate' : Unused code path elimination
//  Block '<S152>/Gain1' : Unused code path elimination
//  Block '<S152>/Gain3' : Unused code path elimination
//  Block '<S152>/VeScale1' : Unused code path elimination
//  Block '<S152>/VelScale1' : Unused code path elimination
//  Block '<S152>/headMotAngle' : Unused code path elimination
//  Block '<S152>/headVehAngleScale' : Unused code path elimination
//  Block '<S226>/Data Type Conversion1' : Unused code path elimination
//  Block '<S236>/Product' : Unused code path elimination
//  Block '<S236>/Product3' : Unused code path elimination
//  Block '<S236>/a' : Unused code path elimination
//  Block '<S236>/gamma*R' : Unused code path elimination
//  Block '<S236>/rho0' : Unused code path elimination
//  Block '<S271>/Unit Conversion' : Unused code path elimination
//  Block '<S272>/Unit Conversion' : Unused code path elimination
//  Block '<S226>/magDecGain' : Unused code path elimination
//  Block '<S154>/Airspeed1' : Unused code path elimination
//  Block '<S154>/Bus Creator' : Unused code path elimination
//  Block '<S154>/Data Type Conversion1' : Unused code path elimination
//  Block '<S154>/Data Type Conversion2' : Unused code path elimination
//  Block '<S154>/Data Type Conversion3' : Unused code path elimination
//  Block '<S154>/Data Type Conversion4' : Unused code path elimination
//  Block '<S154>/Data Type Conversion5' : Unused code path elimination
//  Block '<S154>/Data Type Conversion7' : Unused code path elimination
//  Block '<S154>/Data Type Conversion8' : Unused code path elimination
//  Block '<S154>/Data Type Conversion9' : Unused code path elimination
//  Block '<S338>/1//2rhoV^2' : Unused code path elimination
//  Block '<S338>/Product2' : Unused code path elimination
//  Block '<S340>/Product' : Unused code path elimination
//  Block '<S340>/Product1' : Unused code path elimination
//  Block '<S340>/Product2' : Unused code path elimination
//  Block '<S340>/Sum' : Unused code path elimination
//  Block '<S154>/Gain' : Unused code path elimination
//  Block '<S154>/Gain1' : Unused code path elimination
//  Block '<S154>/Gain2' : Unused code path elimination
//  Block '<S154>/Gain3' : Unused code path elimination
//  Block '<S154>/Gain4' : Unused code path elimination
//  Block '<S154>/Gain5' : Unused code path elimination
//  Block '<S154>/Gain7' : Unused code path elimination
//  Block '<S154>/Sqrt1' : Unused code path elimination
//  Block '<S339>/Product' : Unused code path elimination
//  Block '<S339>/Product1' : Unused code path elimination
//  Block '<S339>/Product2' : Unused code path elimination
//  Block '<S339>/Sum' : Unused code path elimination
//  Block '<S352>/Unit Conversion' : Unused code path elimination
//  Block '<S399>/P0' : Unused code path elimination
//  Block '<S399>/Product2' : Unused code path elimination
//  Block '<S399>/a' : Unused code path elimination
//  Block '<S399>/gamma*R' : Unused code path elimination
//  Block '<S343>/psidot' : Unused code path elimination
//  Block '<S508>/Constant' : Unused code path elimination
//  Block '<S508>/Switch' : Unused code path elimination
//  Block '<S345>/Saturation' : Unused code path elimination
//  Block '<S345>/Sum1' : Unused code path elimination
//  Block '<S522>/Cast' : Unused code path elimination
//  Block '<S1>/Data Type Conversion1' : Eliminate redundant data type conversion
//  Block '<S1>/Data Type Conversion2' : Eliminate redundant data type conversion
//  Block '<S1>/Data Type Conversion3' : Eliminate redundant data type conversion
//  Block '<S1>/Data Type Conversion4' : Eliminate redundant data type conversion
//  Block '<S1>/Data Type Conversion7' : Eliminate redundant data type conversion
//  Block '<S15>/Data Type Conversion1' : Eliminate redundant data type conversion
//  Block '<S17>/Cast' : Eliminate redundant data type conversion
//  Block '<S17>/Cast To Double' : Eliminate redundant data type conversion
//  Block '<S23>/Unit Conversion' : Eliminated nontunable gain of 1
//  Block '<Root>/Data Type Conversion4' : Eliminate redundant data type conversion
//  Block '<S3>/Reshape' : Reshape block reduction
//  Block '<S51>/Unit Conversion' : Eliminated nontunable gain of 1
//  Block '<S53>/Unit Conversion' : Eliminated nontunable gain of 1
//  Block '<S55>/Cast To Double' : Eliminate redundant data type conversion
//  Block '<S55>/Cast To Double1' : Eliminate redundant data type conversion
//  Block '<S55>/Cast To Double2' : Eliminate redundant data type conversion
//  Block '<S55>/Cast To Double3' : Eliminate redundant data type conversion
//  Block '<S55>/Cast To Double4' : Eliminate redundant data type conversion
//  Block '<S92>/Reshape' : Reshape block reduction
//  Block '<S92>/Reshape1' : Reshape block reduction
//  Block '<S94>/Reshape' : Reshape block reduction
//  Block '<S100>/Reshape' : Reshape block reduction
//  Block '<S100>/Reshape1' : Reshape block reduction
//  Block '<S102>/Reshape' : Reshape block reduction
//  Block '<S56>/Cast To Double' : Eliminate redundant data type conversion
//  Block '<S56>/Cast To Double1' : Eliminate redundant data type conversion
//  Block '<S56>/Cast To Double2' : Eliminate redundant data type conversion
//  Block '<S56>/Cast To Double3' : Eliminate redundant data type conversion
//  Block '<S56>/Cast To Double4' : Eliminate redundant data type conversion
//  Block '<S131>/Reshape' : Reshape block reduction
//  Block '<S131>/Reshape1' : Reshape block reduction
//  Block '<S133>/Reshape' : Reshape block reduction
//  Block '<S139>/Reshape' : Reshape block reduction
//  Block '<S139>/Reshape1' : Reshape block reduction
//  Block '<S141>/Reshape' : Reshape block reduction
//  Block '<S66>/Cast To Double' : Eliminate redundant data type conversion
//  Block '<S66>/Reshape' : Reshape block reduction
//  Block '<S66>/Reshape1' : Reshape block reduction
//  Block '<S4>/Data Type Conversion3' : Eliminate redundant data type conversion
//  Block '<S7>/Data Type Conversion11' : Eliminate redundant data type conversion
//  Block '<S7>/Data Type Conversion3' : Eliminate redundant data type conversion
//  Block '<S151>/Reshape 3x3 -> 9' : Reshape block reduction
//  Block '<S184>/Reshape' : Reshape block reduction
//  Block '<S246>/Reshape1' : Reshape block reduction
//  Block '<S268>/maxtype' : Eliminate redundant data type conversion
//  Block '<S268>/mintype' : Eliminate redundant data type conversion
//  Block '<S270>/Unit Conversion' : Eliminated nontunable gain of 1
//  Block '<S239>/Unit Conversion2' : Eliminated nontunable gain of 1
//  Block '<S298>/Reshape' : Reshape block reduction
//  Block '<S305>/Reshape' : Reshape block reduction
//  Block '<S306>/Reshape' : Reshape block reduction
//  Block '<S307>/Reshape' : Reshape block reduction
//  Block '<S307>/Reshape1' : Reshape block reduction
//  Block '<S356>/Reshape (9) to [3x3] column-major' : Reshape block reduction
//  Block '<S358>/Reshape1' : Reshape block reduction
//  Block '<S358>/Reshape2' : Reshape block reduction
//  Block '<S359>/Reshape1' : Reshape block reduction
//  Block '<S359>/Reshape2' : Reshape block reduction
//  Block '<S347>/Reshape' : Reshape block reduction
//  Block '<S347>/Reshape1' : Reshape block reduction
//  Block '<S350>/Unit Conversion' : Eliminated nontunable gain of 1
//  Block '<S351>/Unit Conversion' : Eliminated nontunable gain of 1
//  Block '<S353>/Reshape1' : Reshape block reduction
//  Block '<S353>/Reshape2' : Reshape block reduction
//  Block '<S402>/Reshape (9) to [3x3] column-major' : Reshape block reduction
//  Block '<S405>/Reshape (9) to [3x3] column-major' : Reshape block reduction
//  Block '<S409>/Reshape 3x3 -> 9' : Reshape block reduction
//  Block '<S445>/Reshape' : Reshape block reduction
//  Block '<S410>/Reshape 3x3 -> 9' : Reshape block reduction
//  Block '<S483>/Reshape' : Reshape block reduction
//  Block '<S501>/Reshape (9) to [3x3] column-major' : Reshape block reduction
//  Block '<S345>/Reshape1' : Reshape block reduction
//  Block '<S522>/Cast To Double' : Eliminate redundant data type conversion
//  Block '<S522>/Cast To Double1' : Eliminate redundant data type conversion
//  Block '<S522>/Cast To Double2' : Eliminate redundant data type conversion
//  Block '<S522>/Cast To Double3' : Eliminate redundant data type conversion
//  Block '<S522>/Cast To Double4' : Eliminate redundant data type conversion
//  Block '<S550>/Reshape' : Reshape block reduction
//  Block '<S550>/Reshape1' : Reshape block reduction
//  Block '<S552>/Reshape' : Reshape block reduction
//  Block '<S558>/Reshape' : Reshape block reduction
//  Block '<S558>/Reshape1' : Reshape block reduction
//  Block '<S560>/Reshape' : Reshape block reduction
//  Block '<S567>/Reshape (9) to [3x3] column-major' : Reshape block reduction


//-
//  The generated code includes comments that allow you to trace directly
//  back to the appropriate location in the model.  The basic format
//  is <system>/block_name, where system is the system number (uniquely
//  assigned by Simulink) and block_name is the name of the block.
//
//  Use the MATLAB hilite_system command to trace the generated code back
//  to the model.  For example,
//
//  hilite_system('<S3>')    - opens system 3
//  hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
//
//  Here is the system hierarchy for this model
//
//  '<Root>' : 'FixedwingModel'
//  '<S1>'   : 'FixedwingModel/Actuator Model'
//  '<S2>'   : 'FixedwingModel/CollisionDetection'
//  '<S3>'   : 'FixedwingModel/Environment Model'
//  '<S4>'   : 'FixedwingModel/LogSelectModel'
//  '<S5>'   : 'FixedwingModel/MATLAB Function'
//  '<S6>'   : 'FixedwingModel/Motor Model'
//  '<S7>'   : 'FixedwingModel/OutputPort'
//  '<S8>'   : 'FixedwingModel/Small Fixed Wing UAV Dynamics'
//  '<S9>'   : 'FixedwingModel/Weather Model'
//  '<S10>'  : 'FixedwingModel/Actuator Model/Linear Second Order Actuators'
//  '<S11>'  : 'FixedwingModel/Actuator Model/Linear Second-Order Actuator1'
//  '<S12>'  : 'FixedwingModel/Actuator Model/Linear Second-Order Actuator2'
//  '<S13>'  : 'FixedwingModel/Actuator Model/Linear Second-Order Actuator3'
//  '<S14>'  : 'FixedwingModel/Actuator Model/Linear Second-Order Actuator4'
//  '<S15>'  : 'FixedwingModel/Actuator Model/Steering EngineFault'
//  '<S16>'  : 'FixedwingModel/Actuator Model/Steering EngineFault/Band-Limited White Noise'
//  '<S17>'  : 'FixedwingModel/Actuator Model/Steering EngineFault/Discrete Wind Gust Model'
//  '<S18>'  : 'FixedwingModel/Actuator Model/Steering EngineFault/FaultParamsExtract'
//  '<S19>'  : 'FixedwingModel/Actuator Model/Steering EngineFault/SteerEngineFaultModel'
//  '<S20>'  : 'FixedwingModel/Actuator Model/Steering EngineFault/Discrete Wind Gust Model/Distance into gust (x)'
//  '<S21>'  : 'FixedwingModel/Actuator Model/Steering EngineFault/Discrete Wind Gust Model/Distance into gust (y)'
//  '<S22>'  : 'FixedwingModel/Actuator Model/Steering EngineFault/Discrete Wind Gust Model/Distance into gust (z)'
//  '<S23>'  : 'FixedwingModel/Actuator Model/Steering EngineFault/Discrete Wind Gust Model/Velocity Conversion'
//  '<S24>'  : 'FixedwingModel/Environment Model/Flat Earth to LLA'
//  '<S25>'  : 'FixedwingModel/Environment Model/ISA Atmosphere Model'
//  '<S26>'  : 'FixedwingModel/Environment Model/Temperature Conversion'
//  '<S27>'  : 'FixedwingModel/Environment Model/WGS84 Gravity Model '
//  '<S28>'  : 'FixedwingModel/Environment Model/WindFault'
//  '<S29>'  : 'FixedwingModel/Environment Model/Flat Earth to LLA/LatLong wrap'
//  '<S30>'  : 'FixedwingModel/Environment Model/Flat Earth to LLA/LatLong wrap1'
//  '<S31>'  : 'FixedwingModel/Environment Model/Flat Earth to LLA/LongLat_offset'
//  '<S32>'  : 'FixedwingModel/Environment Model/Flat Earth to LLA/pos_deg'
//  '<S33>'  : 'FixedwingModel/Environment Model/Flat Earth to LLA/LatLong wrap/Latitude Wrap 90'
//  '<S34>'  : 'FixedwingModel/Environment Model/Flat Earth to LLA/LatLong wrap/Wrap Longitude'
//  '<S35>'  : 'FixedwingModel/Environment Model/Flat Earth to LLA/LatLong wrap/Latitude Wrap 90/Compare To Constant'
//  '<S36>'  : 'FixedwingModel/Environment Model/Flat Earth to LLA/LatLong wrap/Latitude Wrap 90/Wrap Angle 180'
//  '<S37>'  : 'FixedwingModel/Environment Model/Flat Earth to LLA/LatLong wrap/Latitude Wrap 90/Wrap Angle 180/Compare To Constant'
//  '<S38>'  : 'FixedwingModel/Environment Model/Flat Earth to LLA/LatLong wrap/Wrap Longitude/Compare To Constant'
//  '<S39>'  : 'FixedwingModel/Environment Model/Flat Earth to LLA/LatLong wrap1/Latitude Wrap 90'
//  '<S40>'  : 'FixedwingModel/Environment Model/Flat Earth to LLA/LatLong wrap1/Wrap Longitude'
//  '<S41>'  : 'FixedwingModel/Environment Model/Flat Earth to LLA/LatLong wrap1/Latitude Wrap 90/Compare To Constant'
//  '<S42>'  : 'FixedwingModel/Environment Model/Flat Earth to LLA/LatLong wrap1/Latitude Wrap 90/Wrap Angle 180'
//  '<S43>'  : 'FixedwingModel/Environment Model/Flat Earth to LLA/LatLong wrap1/Latitude Wrap 90/Wrap Angle 180/Compare To Constant'
//  '<S44>'  : 'FixedwingModel/Environment Model/Flat Earth to LLA/LatLong wrap1/Wrap Longitude/Compare To Constant'
//  '<S45>'  : 'FixedwingModel/Environment Model/Flat Earth to LLA/LongLat_offset/Find Radian//Distance'
//  '<S46>'  : 'FixedwingModel/Environment Model/Flat Earth to LLA/LongLat_offset/rotation_rad'
//  '<S47>'  : 'FixedwingModel/Environment Model/Flat Earth to LLA/LongLat_offset/Find Radian//Distance/Angle Conversion2'
//  '<S48>'  : 'FixedwingModel/Environment Model/Flat Earth to LLA/LongLat_offset/Find Radian//Distance/denom'
//  '<S49>'  : 'FixedwingModel/Environment Model/Flat Earth to LLA/LongLat_offset/Find Radian//Distance/e'
//  '<S50>'  : 'FixedwingModel/Environment Model/Flat Earth to LLA/LongLat_offset/Find Radian//Distance/e^4'
//  '<S51>'  : 'FixedwingModel/Environment Model/WGS84 Gravity Model /Acceleration Conversion'
//  '<S52>'  : 'FixedwingModel/Environment Model/WGS84 Gravity Model /Angle Conversion'
//  '<S53>'  : 'FixedwingModel/Environment Model/WGS84 Gravity Model /Length Conversion'
//  '<S54>'  : 'FixedwingModel/Environment Model/WGS84 Gravity Model /Velocity Conversion2'
//  '<S55>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))'
//  '<S56>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1'
//  '<S57>'  : 'FixedwingModel/Environment Model/WindFault/FaultParamsExtract'
//  '<S58>'  : 'FixedwingModel/Environment Model/WindFault/FaultParamsExtract1'
//  '<S59>'  : 'FixedwingModel/Environment Model/WindFault/FaultParamsExtract2'
//  '<S60>'  : 'FixedwingModel/Environment Model/WindFault/FaultParamsExtract3'
//  '<S61>'  : 'FixedwingModel/Environment Model/WindFault/FaultParamsExtract4'
//  '<S62>'  : 'FixedwingModel/Environment Model/WindFault/MATLAB Function'
//  '<S63>'  : 'FixedwingModel/Environment Model/WindFault/MATLAB Function1'
//  '<S64>'  : 'FixedwingModel/Environment Model/WindFault/SheerWindStrength_Dec_Switch'
//  '<S65>'  : 'FixedwingModel/Environment Model/WindFault/TurbWindStrength_Dec_Switch'
//  '<S66>'  : 'FixedwingModel/Environment Model/WindFault/Wind Shear Model'
//  '<S67>'  : 'FixedwingModel/Environment Model/WindFault/noiseUpperWindBodySwitch'
//  '<S68>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Angle Conversion'
//  '<S69>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Filters on angular rates'
//  '<S70>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Filters on velocities'
//  '<S71>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Length Conversion'
//  '<S72>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Length Conversion1'
//  '<S73>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/RMS turbulence  intensities'
//  '<S74>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select angular rates'
//  '<S75>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select velocities'
//  '<S76>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Turbulence scale lengths'
//  '<S77>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Velocity Conversion'
//  '<S78>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Velocity Conversion2'
//  '<S79>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/White Noise'
//  '<S80>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Filters on angular rates/Hpgw'
//  '<S81>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Filters on angular rates/Hqgw'
//  '<S82>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Filters on angular rates/Hrgw'
//  '<S83>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Filters on velocities/Hugw(z)'
//  '<S84>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Filters on velocities/Hvgw(z)'
//  '<S85>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Filters on velocities/Hwgw(z)'
//  '<S86>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/RMS turbulence  intensities/High Altitude Intensity'
//  '<S87>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/RMS turbulence  intensities/Low Altitude Intensity'
//  '<S88>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select angular rates/Interpolate  rates'
//  '<S89>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select angular rates/Low altitude  rates'
//  '<S90>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select angular rates/Medium//High  altitude rates'
//  '<S91>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select angular rates/Merge Subsystems'
//  '<S92>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select angular rates/Interpolate  rates/wind to body transformation'
//  '<S93>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select angular rates/Interpolate  rates/wind to body transformation/convert to earth coords'
//  '<S94>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select angular rates/Low altitude  rates/wind to body transformation'
//  '<S95>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select angular rates/Low altitude  rates/wind to body transformation/convert to earth coords'
//  '<S96>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select velocities/Interpolate  velocities'
//  '<S97>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select velocities/Low altitude  velocities'
//  '<S98>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select velocities/Medium//High  altitude velocities'
//  '<S99>'  : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select velocities/Merge Subsystems'
//  '<S100>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select velocities/Interpolate  velocities/wind to body transformation'
//  '<S101>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select velocities/Interpolate  velocities/wind to body transformation/convert to earth coords'
//  '<S102>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select velocities/Low altitude  velocities/wind to body transformation'
//  '<S103>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Select velocities/Low altitude  velocities/wind to body transformation/convert to earth coords'
//  '<S104>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Turbulence scale lengths/Low altitude scale length'
//  '<S105>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Turbulence scale lengths/Medium//High altitude scale length'
//  '<S106>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))/Turbulence scale lengths/Medium//High altitude scale length/Length Conversion'
//  '<S107>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Angle Conversion'
//  '<S108>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Filters on angular rates'
//  '<S109>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Filters on velocities'
//  '<S110>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Length Conversion'
//  '<S111>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Length Conversion1'
//  '<S112>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/RMS turbulence  intensities'
//  '<S113>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select angular rates'
//  '<S114>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select velocities'
//  '<S115>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Turbulence scale lengths'
//  '<S116>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Velocity Conversion'
//  '<S117>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Velocity Conversion2'
//  '<S118>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/White Noise'
//  '<S119>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Filters on angular rates/Hpgw'
//  '<S120>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Filters on angular rates/Hqgw'
//  '<S121>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Filters on angular rates/Hrgw'
//  '<S122>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Filters on velocities/Hugw(z)'
//  '<S123>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Filters on velocities/Hvgw(z)'
//  '<S124>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Filters on velocities/Hwgw(z)'
//  '<S125>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/RMS turbulence  intensities/High Altitude Intensity'
//  '<S126>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/RMS turbulence  intensities/Low Altitude Intensity'
//  '<S127>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select angular rates/Interpolate  rates'
//  '<S128>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select angular rates/Low altitude  rates'
//  '<S129>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select angular rates/Medium//High  altitude rates'
//  '<S130>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select angular rates/Merge Subsystems'
//  '<S131>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select angular rates/Interpolate  rates/wind to body transformation'
//  '<S132>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select angular rates/Interpolate  rates/wind to body transformation/convert to earth coords'
//  '<S133>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select angular rates/Low altitude  rates/wind to body transformation'
//  '<S134>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select angular rates/Low altitude  rates/wind to body transformation/convert to earth coords'
//  '<S135>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select velocities/Interpolate  velocities'
//  '<S136>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select velocities/Low altitude  velocities'
//  '<S137>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select velocities/Medium//High  altitude velocities'
//  '<S138>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select velocities/Merge Subsystems'
//  '<S139>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select velocities/Interpolate  velocities/wind to body transformation'
//  '<S140>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select velocities/Interpolate  velocities/wind to body transformation/convert to earth coords'
//  '<S141>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select velocities/Low altitude  velocities/wind to body transformation'
//  '<S142>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Select velocities/Low altitude  velocities/wind to body transformation/convert to earth coords'
//  '<S143>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Turbulence scale lengths/Low altitude scale length'
//  '<S144>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Turbulence scale lengths/Medium//High altitude scale length'
//  '<S145>' : 'FixedwingModel/Environment Model/WindFault/Dryden Wind Turbulence Model  (Discrete (-q +r))1/Turbulence scale lengths/Medium//High altitude scale length/Length Conversion'
//  '<S146>' : 'FixedwingModel/Environment Model/WindFault/Wind Shear Model/Angle Conversion'
//  '<S147>' : 'FixedwingModel/Environment Model/WindFault/Wind Shear Model/Length Conversion'
//  '<S148>' : 'FixedwingModel/Motor Model/Engine Model'
//  '<S149>' : 'FixedwingModel/Motor Model/Engine Model/Get To'
//  '<S150>' : 'FixedwingModel/Motor Model/Engine Model/Mass Conversion'
//  '<S151>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions'
//  '<S152>' : 'FixedwingModel/OutputPort/HILGPSModel'
//  '<S153>' : 'FixedwingModel/OutputPort/HILSensorMavModel'
//  '<S154>' : 'FixedwingModel/OutputPort/HILStateMavModel'
//  '<S155>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Negative Trace'
//  '<S156>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Positive Trace'
//  '<S157>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Validate DCM'
//  '<S158>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/trace(DCM)'
//  '<S159>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(1,1)'
//  '<S160>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(2,2)'
//  '<S161>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(3,3)'
//  '<S162>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Negative Trace/diag(DCM)'
//  '<S163>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(1,1)/cos(phi)sin(theta)cos(psi) + sin(phi)sin(psi) -sin(theta)'
//  '<S164>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(1,1)/cos(theta)sin(phi) - (cos(phi)sin(theta)sin(psi) - sin(phi)cos(psi))'
//  '<S165>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(1,1)/cos(theta)sin(psi) + (sin(phi)sin(theta)cos(psi) - cos(phi)sin(psi))'
//  '<S166>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(1,1)/if s~=0; s=0.5//s'
//  '<S167>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(1,1)/u(1) -(u(5)+u(9)) +1'
//  '<S168>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(2,2)/cos(phi)sin(theta)cos(psi) + sin(phi)sin(psi) +sin(theta)'
//  '<S169>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(2,2)/cos(theta)sin(phi) + (cos(phi)sin(theta)sin(psi) - sin(phi)cos(psi))'
//  '<S170>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(2,2)/cos(theta)sin(psi) + (sin(phi)sin(theta)cos(psi) - cos(phi)sin(psi))'
//  '<S171>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(2,2)/if s~=0; s=0.5//s'
//  '<S172>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(2,2)/u(5) -(u(1)+u(9)) +1'
//  '<S173>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(3,3)/cos(phi)sin(theta)cos(psi) + sin(phi)sin(psi) -sin(theta)'
//  '<S174>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(3,3)/cos(theta)sin(phi) + (cos(phi)sin(theta)sin(psi) - sin(phi)cos(psi))'
//  '<S175>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(3,3)/cos(theta)sin(psi) - (sin(phi)sin(theta)cos(psi) - cos(phi)sin(psi))'
//  '<S176>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(3,3)/if s~=0; s=0.5//s'
//  '<S177>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(3,3)/u(9) -(u(1)+u(5)) +1'
//  '<S178>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Positive Trace/cos(phi)sin(theta)cos(psi) + sin(phi)sin(psi) +sin(theta)'
//  '<S179>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Positive Trace/cos(theta)sin(phi) - (cos(phi)sin(theta)sin(psi) - sin(phi)cos(psi))'
//  '<S180>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Positive Trace/cos(theta)sin(psi) - (sin(phi)sin(theta)cos(psi) - cos(phi)sin(psi))'
//  '<S181>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error'
//  '<S182>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/Else If Not Orthogonal'
//  '<S183>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/If Not Proper'
//  '<S184>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/isNotOrthogonal'
//  '<S185>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/isNotProper'
//  '<S186>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/Else If Not Orthogonal/Error'
//  '<S187>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/Else If Not Orthogonal/Warning'
//  '<S188>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/If Not Proper/Error'
//  '<S189>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/If Not Proper/Warning'
//  '<S190>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/isNotOrthogonal/transpose*dcm ~= eye(3)'
//  '<S191>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/isNotProper/Determinant of 3x3 Matrix'
//  '<S192>' : 'FixedwingModel/OutputPort/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/isNotProper/determinant does not equal 1'
//  '<S193>' : 'FixedwingModel/OutputPort/HILGPSModel/-pi-pi---->0-2pi'
//  '<S194>' : 'FixedwingModel/OutputPort/HILGPSModel/GPSFault'
//  '<S195>' : 'FixedwingModel/OutputPort/HILGPSModel/GenCogVel'
//  '<S196>' : 'FixedwingModel/OutputPort/HILGPSModel/NoiseFilter1'
//  '<S197>' : 'FixedwingModel/OutputPort/HILGPSModel/GPSFault/FaultParamsExtract'
//  '<S198>' : 'FixedwingModel/OutputPort/HILGPSModel/GPSFault/Flat Earth to LLA'
//  '<S199>' : 'FixedwingModel/OutputPort/HILGPSModel/GPSFault/GPSFaultModel'
//  '<S200>' : 'FixedwingModel/OutputPort/HILGPSModel/GPSFault/Flat Earth to LLA/LatLong wrap'
//  '<S201>' : 'FixedwingModel/OutputPort/HILGPSModel/GPSFault/Flat Earth to LLA/LatLong wrap1'
//  '<S202>' : 'FixedwingModel/OutputPort/HILGPSModel/GPSFault/Flat Earth to LLA/LongLat_offset'
//  '<S203>' : 'FixedwingModel/OutputPort/HILGPSModel/GPSFault/Flat Earth to LLA/pos_deg'
//  '<S204>' : 'FixedwingModel/OutputPort/HILGPSModel/GPSFault/Flat Earth to LLA/LatLong wrap/Latitude Wrap 90'
//  '<S205>' : 'FixedwingModel/OutputPort/HILGPSModel/GPSFault/Flat Earth to LLA/LatLong wrap/Wrap Longitude'
//  '<S206>' : 'FixedwingModel/OutputPort/HILGPSModel/GPSFault/Flat Earth to LLA/LatLong wrap/Latitude Wrap 90/Compare To Constant'
//  '<S207>' : 'FixedwingModel/OutputPort/HILGPSModel/GPSFault/Flat Earth to LLA/LatLong wrap/Latitude Wrap 90/Wrap Angle 180'
//  '<S208>' : 'FixedwingModel/OutputPort/HILGPSModel/GPSFault/Flat Earth to LLA/LatLong wrap/Latitude Wrap 90/Wrap Angle 180/Compare To Constant'
//  '<S209>' : 'FixedwingModel/OutputPort/HILGPSModel/GPSFault/Flat Earth to LLA/LatLong wrap/Wrap Longitude/Compare To Constant'
//  '<S210>' : 'FixedwingModel/OutputPort/HILGPSModel/GPSFault/Flat Earth to LLA/LatLong wrap1/Latitude Wrap 90'
//  '<S211>' : 'FixedwingModel/OutputPort/HILGPSModel/GPSFault/Flat Earth to LLA/LatLong wrap1/Wrap Longitude'
//  '<S212>' : 'FixedwingModel/OutputPort/HILGPSModel/GPSFault/Flat Earth to LLA/LatLong wrap1/Latitude Wrap 90/Compare To Constant'
//  '<S213>' : 'FixedwingModel/OutputPort/HILGPSModel/GPSFault/Flat Earth to LLA/LatLong wrap1/Latitude Wrap 90/Wrap Angle 180'
//  '<S214>' : 'FixedwingModel/OutputPort/HILGPSModel/GPSFault/Flat Earth to LLA/LatLong wrap1/Latitude Wrap 90/Wrap Angle 180/Compare To Constant'
//  '<S215>' : 'FixedwingModel/OutputPort/HILGPSModel/GPSFault/Flat Earth to LLA/LatLong wrap1/Wrap Longitude/Compare To Constant'
//  '<S216>' : 'FixedwingModel/OutputPort/HILGPSModel/GPSFault/Flat Earth to LLA/LongLat_offset/Find Radian//Distance'
//  '<S217>' : 'FixedwingModel/OutputPort/HILGPSModel/GPSFault/Flat Earth to LLA/LongLat_offset/rotation_rad'
//  '<S218>' : 'FixedwingModel/OutputPort/HILGPSModel/GPSFault/Flat Earth to LLA/LongLat_offset/Find Radian//Distance/Angle Conversion2'
//  '<S219>' : 'FixedwingModel/OutputPort/HILGPSModel/GPSFault/Flat Earth to LLA/LongLat_offset/Find Radian//Distance/denom'
//  '<S220>' : 'FixedwingModel/OutputPort/HILGPSModel/GPSFault/Flat Earth to LLA/LongLat_offset/Find Radian//Distance/e'
//  '<S221>' : 'FixedwingModel/OutputPort/HILGPSModel/GPSFault/Flat Earth to LLA/LongLat_offset/Find Radian//Distance/e^4'
//  '<S222>' : 'FixedwingModel/OutputPort/HILGPSModel/GPSFault/GPSFaultModel/MATLAB Function'
//  '<S223>' : 'FixedwingModel/OutputPort/HILSensorMavModel/AccelNoiseGainFunction'
//  '<S224>' : 'FixedwingModel/OutputPort/HILSensorMavModel/GyroNoiseGainFunction'
//  '<S225>' : 'FixedwingModel/OutputPort/HILSensorMavModel/MagNoiseGainFunction'
//  '<S226>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault'
//  '<S227>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/AccNoiseSwitch1'
//  '<S228>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/Dynamic Pressure'
//  '<S229>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/FaultParamsExtract'
//  '<S230>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/FaultParamsExtract1'
//  '<S231>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/FaultParamsExtract2'
//  '<S232>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/FaultParamsExtract3'
//  '<S233>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/GyroNoiseSwitch'
//  '<S234>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/GyroNoiseSwitch3'
//  '<S235>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/GyroNoiseSwitch4'
//  '<S236>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/ISA Atmosphere Model'
//  '<S237>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/MagNoiseSwitch'
//  '<S238>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/Three-axis Inertial Measurement Unit3'
//  '<S239>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015'
//  '<S240>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/baro NoiseFun'
//  '<S241>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/AccNoiseSwitch1/Acc NoiseFun'
//  '<S242>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/Dynamic Pressure/dot'
//  '<S243>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/GyroNoiseSwitch/Acc NoiseFun'
//  '<S244>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/MagNoiseSwitch/Acc NoiseFun'
//  '<S245>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/Three-axis Inertial Measurement Unit3/Acceleration Conversion'
//  '<S246>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Accelerometer'
//  '<S247>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Gyroscope'
//  '<S248>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Accelerometer/Dynamics'
//  '<S249>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Accelerometer/w x (w x d)'
//  '<S250>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Accelerometer/wdot x d'
//  '<S251>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Accelerometer/Dynamics/No Dynamics'
//  '<S252>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Accelerometer/Dynamics/Second-order Dynamics'
//  '<S253>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Accelerometer/w x (w x d)/w x (w x d)'
//  '<S254>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Accelerometer/w x (w x d)/w x d'
//  '<S255>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Accelerometer/w x (w x d)/w x (w x d)/Subsystem'
//  '<S256>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Accelerometer/w x (w x d)/w x (w x d)/Subsystem1'
//  '<S257>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Accelerometer/w x (w x d)/w x d/Subsystem'
//  '<S258>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Accelerometer/w x (w x d)/w x d/Subsystem1'
//  '<S259>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Accelerometer/wdot x d/Subsystem'
//  '<S260>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Accelerometer/wdot x d/Subsystem1'
//  '<S261>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Gyroscope/Dynamics'
//  '<S262>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Gyroscope/Dynamics/No Dynamics'
//  '<S263>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/Three-axis Inertial Measurement Unit3/Three-axis Gyroscope/Dynamics/Second-order Dynamics'
//  '<S264>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/Check Altitude'
//  '<S265>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/Check Latitude'
//  '<S266>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/Check Longitude'
//  '<S267>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/Compute x,y,z, and h components of magnetic field'
//  '<S268>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/Is time within model limits'
//  '<S269>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/LatLong wrap'
//  '<S270>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/Length Conversion'
//  '<S271>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/MagField Conversion'
//  '<S272>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/MagField Conversion1'
//  '<S273>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag'
//  '<S274>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/Compute x,y,z, and h components of magnetic field/Angle Conversion'
//  '<S275>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/LatLong wrap/Latitude Wrap 90'
//  '<S276>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/LatLong wrap/Wrap Longitude'
//  '<S277>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/LatLong wrap/Latitude Wrap 90/Compare To Constant'
//  '<S278>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/LatLong wrap/Latitude Wrap 90/Wrap Angle 180'
//  '<S279>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/LatLong wrap/Latitude Wrap 90/Wrap Angle 180/Compare To Constant'
//  '<S280>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/LatLong wrap/Wrap Longitude/Compare To Constant'
//  '<S281>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates'
//  '<S282>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Convert from geodetic to  spherical coordinates'
//  '<S283>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Convert from geodetic to  spherical coordinates '
//  '<S284>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Get Cosine and Sine  of Latitude and Longitude'
//  '<S285>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Has altitude or latitude changed'
//  '<S286>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Has longitude changed '
//  '<S287>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Has time changed'
//  '<S288>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Rotate magnetic vector components  to geodetic from spherical and  compute declination, inclination  and total intensity'
//  '<S289>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem'
//  '<S290>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Accumulate terms of the  spherical harmonic expansion'
//  '<S291>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations'
//  '<S292>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Time adjust the gauss coefficients'
//  '<S293>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Accumulate terms of the  spherical harmonic expansion/Special case - North//South Geographic Pole'
//  '<S294>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Accumulate terms of the  spherical harmonic expansion/calculate  index'
//  '<S295>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Accumulate terms of the  spherical harmonic expansion/calculate temp values'
//  '<S296>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Accumulate terms of the  spherical harmonic expansion/special case'
//  '<S297>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Accumulate terms of the  spherical harmonic expansion/Special case - North//South Geographic Pole/If Action Subsystem1'
//  '<S298>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Accumulate terms of the  spherical harmonic expansion/Special case - North//South Geographic Pole/If Action Subsystem2'
//  '<S299>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Accumulate terms of the  spherical harmonic expansion/Special case - North//South Geographic Pole/If Action Subsystem2/calculate  indices'
//  '<S300>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Accumulate terms of the  spherical harmonic expansion/Special case - North//South Geographic Pole/If Action Subsystem2/calculate  row and column'
//  '<S301>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Accumulate terms of the  spherical harmonic expansion/calculate temp values/If Action Subsystem'
//  '<S302>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Accumulate terms of the  spherical harmonic expansion/calculate temp values/If Action Subsystem1'
//  '<S303>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Accumulate terms of the  spherical harmonic expansion/calculate temp values/If Action Subsystem1/m,n'
//  '<S304>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Accumulate terms of the  spherical harmonic expansion/calculate temp values/If Action Subsystem1/n,m-1'
//  '<S305>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations/If Action Subsystem'
//  '<S306>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations/If Action Subsystem1'
//  '<S307>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations/If Action Subsystem2'
//  '<S308>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations/calculate  index'
//  '<S309>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations/If Action Subsystem/calculate  index'
//  '<S310>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations/If Action Subsystem/calculate  row and column'
//  '<S311>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations/If Action Subsystem1/calculate  index'
//  '<S312>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations/If Action Subsystem1/calculate  row and column'
//  '<S313>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations/If Action Subsystem2/calculate  indices'
//  '<S314>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations/If Action Subsystem2/calculate  row and column1'
//  '<S315>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations/If Action Subsystem2/calculate  row and column2'
//  '<S316>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations/If Action Subsystem2/m<n-2'
//  '<S317>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations/If Action Subsystem2/m<n-2 '
//  '<S318>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Time adjust the gauss coefficients/If Action Subsystem'
//  '<S319>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Time adjust the gauss coefficients/if (m~=0)'
//  '<S320>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Time adjust the gauss coefficients/if (m~=0)/If Action Subsystem1'
//  '<S321>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Compute magnetic vector in spherical coordinates/For Iterator Subsystem/Time adjust the gauss coefficients/if (m~=0)/If Action Subsystem2'
//  '<S322>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Convert from geodetic to  spherical coordinates/calculate ca'
//  '<S323>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Convert from geodetic to  spherical coordinates/calculate ct'
//  '<S324>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Convert from geodetic to  spherical coordinates/calculate d'
//  '<S325>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Convert from geodetic to  spherical coordinates/calculate q'
//  '<S326>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Convert from geodetic to  spherical coordinates/calculate q2'
//  '<S327>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Convert from geodetic to  spherical coordinates/calculate r2'
//  '<S328>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Convert from geodetic to  spherical coordinates/calculate sa'
//  '<S329>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Convert from geodetic to  spherical coordinates/calculate st'
//  '<S330>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Convert from geodetic to  spherical coordinates /For Iterator Subsystem'
//  '<S331>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Get Cosine and Sine  of Latitude and Longitude/Angle Conversion2'
//  '<S332>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Rotate magnetic vector components  to geodetic from spherical and  compute declination, inclination  and total intensity/Calculate bx'
//  '<S333>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Rotate magnetic vector components  to geodetic from spherical and  compute declination, inclination  and total intensity/Calculate by'
//  '<S334>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Rotate magnetic vector components  to geodetic from spherical and  compute declination, inclination  and total intensity/Calculate bz'
//  '<S335>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Rotate magnetic vector components  to geodetic from spherical and  compute declination, inclination  and total intensity/Compute declination, inclination,  and total intensity'
//  '<S336>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Rotate magnetic vector components  to geodetic from spherical and  compute declination, inclination  and total intensity/Compute declination, inclination,  and total intensity/Angle Conversion'
//  '<S337>' : 'FixedwingModel/OutputPort/HILSensorMavModel/SensorFault/World Magnetic Model 2015/geomag/Rotate magnetic vector components  to geodetic from spherical and  compute declination, inclination  and total intensity/Compute declination, inclination,  and total intensity/Angle Conversion1'
//  '<S338>' : 'FixedwingModel/OutputPort/HILStateMavModel/Dynamic Pressure'
//  '<S339>' : 'FixedwingModel/OutputPort/HILStateMavModel/dot1'
//  '<S340>' : 'FixedwingModel/OutputPort/HILStateMavModel/Dynamic Pressure/dot'
//  '<S341>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/6DOF (Euler Angles)'
//  '<S342>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments'
//  '<S343>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Compute psi_dot'
//  '<S344>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel'
//  '<S345>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Three-axis Accelerometer'
//  '<S346>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/6DOF (Euler Angles)/Calculate DCM & Euler Angles'
//  '<S347>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/6DOF (Euler Angles)/Calculate omega_dot'
//  '<S348>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/6DOF (Euler Angles)/Determine Force,  Mass & Inertia'
//  '<S349>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/6DOF (Euler Angles)/Vbxw'
//  '<S350>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/6DOF (Euler Angles)/Velocity Conversion'
//  '<S351>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/6DOF (Euler Angles)/Velocity Conversion1'
//  '<S352>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/6DOF (Euler Angles)/Velocity Conversion2'
//  '<S353>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/6DOF (Euler Angles)/transform to Inertial axes '
//  '<S354>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/6DOF (Euler Angles)/Calculate DCM & Euler Angles/Rotation Angles to Direction Cosine Matrix'
//  '<S355>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/6DOF (Euler Angles)/Calculate DCM & Euler Angles/phidot thetadot psidot'
//  '<S356>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/6DOF (Euler Angles)/Calculate DCM & Euler Angles/Rotation Angles to Direction Cosine Matrix/Create 3x3 Matrix'
//  '<S357>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/6DOF (Euler Angles)/Calculate omega_dot/3x3 Cross Product'
//  '<S358>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/6DOF (Euler Angles)/Calculate omega_dot/I x w'
//  '<S359>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/6DOF (Euler Angles)/Calculate omega_dot/I x w1'
//  '<S360>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/6DOF (Euler Angles)/Calculate omega_dot/3x3 Cross Product/Subsystem'
//  '<S361>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/6DOF (Euler Angles)/Calculate omega_dot/3x3 Cross Product/Subsystem1'
//  '<S362>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/6DOF (Euler Angles)/Vbxw/Subsystem'
//  '<S363>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/6DOF (Euler Angles)/Vbxw/Subsystem1'
//  '<S364>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Air Data'
//  '<S365>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Body Frame  Forces and Moments'
//  '<S366>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Rho'
//  '<S367>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Rotate Vw'
//  '<S368>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Rotate g to Body Frame'
//  '<S369>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/[0, pi] Wrap Around'
//  '<S370>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Air Data/Dynamic Pressure'
//  '<S371>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Air Data/Incidence, Sideslip, & Airspeed'
//  '<S372>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Air Data/Dynamic Pressure/dot'
//  '<S373>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Air Data/Incidence, Sideslip, & Airspeed/Subsystem'
//  '<S374>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Air Data/Incidence, Sideslip, & Airspeed/Subsystem1'
//  '<S375>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Air Data/Incidence, Sideslip, & Airspeed/dot'
//  '<S376>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Body Frame  Forces and Moments/Rotate FM to body frame'
//  '<S377>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Body Frame  Forces and Moments/Wind frame F& M'
//  '<S378>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Body Frame  Forces and Moments/Rotate FM to body frame/Rotate Forces'
//  '<S379>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Body Frame  Forces and Moments/Rotate FM to body frame/Rotate Moments'
//  '<S380>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Body Frame  Forces and Moments/Rotate FM to body frame/Rotate Forces/RB2W'
//  '<S381>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Body Frame  Forces and Moments/Rotate FM to body frame/Rotate Moments/RB2W'
//  '<S382>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Body Frame  Forces and Moments/Wind frame F& M/Get Forces and Moments'
//  '<S383>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Body Frame  Forces and Moments/Wind frame F& M/Lateral Channel'
//  '<S384>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Body Frame  Forces and Moments/Wind frame F& M/Longitudinal Channel'
//  '<S385>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Body Frame  Forces and Moments/Wind frame F& M/Lateral Channel/CY'
//  '<S386>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Body Frame  Forces and Moments/Wind frame F& M/Lateral Channel/Cl'
//  '<S387>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Body Frame  Forces and Moments/Wind frame F& M/Lateral Channel/Cn'
//  '<S388>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Body Frame  Forces and Moments/Wind frame F& M/Lateral Channel/Cl/roll factors'
//  '<S389>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Body Frame  Forces and Moments/Wind frame F& M/Lateral Channel/Cl/roll factors/roll rate fact'
//  '<S390>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Body Frame  Forces and Moments/Wind frame F& M/Lateral Channel/Cl/roll factors/yaw rate fact'
//  '<S391>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Body Frame  Forces and Moments/Wind frame F& M/Lateral Channel/Cn/yaw factors'
//  '<S392>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Body Frame  Forces and Moments/Wind frame F& M/Lateral Channel/Cn/yaw factors/roll rate fact'
//  '<S393>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Body Frame  Forces and Moments/Wind frame F& M/Lateral Channel/Cn/yaw factors/yaw rate fact'
//  '<S394>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Body Frame  Forces and Moments/Wind frame F& M/Longitudinal Channel/CD'
//  '<S395>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Body Frame  Forces and Moments/Wind frame F& M/Longitudinal Channel/CL'
//  '<S396>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Body Frame  Forces and Moments/Wind frame F& M/Longitudinal Channel/Cm'
//  '<S397>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Body Frame  Forces and Moments/Wind frame F& M/Longitudinal Channel/CL/Lift due to pitch rate'
//  '<S398>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Body Frame  Forces and Moments/Wind frame F& M/Longitudinal Channel/CL/Lift due to pitch rate/pitch rate factor'
//  '<S399>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Compute Rho/ISA Atmosphere Model1'
//  '<S400>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Rotate Vw/RL2B'
//  '<S401>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Rotate Vw/RL2B/Rotation Angles to Direction Cosine Matrix'
//  '<S402>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Rotate Vw/RL2B/Rotation Angles to Direction Cosine Matrix/Create 3x3 Matrix'
//  '<S403>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Rotate g to Body Frame/RL2B'
//  '<S404>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Rotate g to Body Frame/RL2B/Rotation Angles to Direction Cosine Matrix'
//  '<S405>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/Rotate g to Body Frame/RL2B/Rotation Angles to Direction Cosine Matrix/Create 3x3 Matrix'
//  '<S406>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/[0, pi] Wrap Around/Compare To Zero'
//  '<S407>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/[0, pi] Wrap Around/Negative Yaw'
//  '<S408>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Aerodynamic  Forces and Moments/[0, pi] Wrap Around/Positive Yaw'
//  '<S409>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions'
//  '<S410>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1'
//  '<S411>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Euler to DCM'
//  '<S412>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Ground Model'
//  '<S413>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/OnGroundFaceup'
//  '<S414>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Quaternion Inverse'
//  '<S415>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Quaternion Multiplication'
//  '<S416>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Negative Trace'
//  '<S417>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Positive Trace'
//  '<S418>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Validate DCM'
//  '<S419>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/trace(DCM)'
//  '<S420>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(1,1)'
//  '<S421>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(2,2)'
//  '<S422>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(3,3)'
//  '<S423>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Negative Trace/diag(DCM)'
//  '<S424>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(1,1)/cos(phi)sin(theta)cos(psi) + sin(phi)sin(psi) -sin(theta)'
//  '<S425>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(1,1)/cos(theta)sin(phi) - (cos(phi)sin(theta)sin(psi) - sin(phi)cos(psi))'
//  '<S426>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(1,1)/cos(theta)sin(psi) + (sin(phi)sin(theta)cos(psi) - cos(phi)sin(psi))'
//  '<S427>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(1,1)/if s~=0; s=0.5//s'
//  '<S428>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(1,1)/u(1) -(u(5)+u(9)) +1'
//  '<S429>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(2,2)/cos(phi)sin(theta)cos(psi) + sin(phi)sin(psi) +sin(theta)'
//  '<S430>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(2,2)/cos(theta)sin(phi) + (cos(phi)sin(theta)sin(psi) - sin(phi)cos(psi))'
//  '<S431>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(2,2)/cos(theta)sin(psi) + (sin(phi)sin(theta)cos(psi) - cos(phi)sin(psi))'
//  '<S432>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(2,2)/if s~=0; s=0.5//s'
//  '<S433>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(2,2)/u(5) -(u(1)+u(9)) +1'
//  '<S434>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(3,3)/cos(phi)sin(theta)cos(psi) + sin(phi)sin(psi) -sin(theta)'
//  '<S435>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(3,3)/cos(theta)sin(phi) + (cos(phi)sin(theta)sin(psi) - sin(phi)cos(psi))'
//  '<S436>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(3,3)/cos(theta)sin(psi) - (sin(phi)sin(theta)cos(psi) - cos(phi)sin(psi))'
//  '<S437>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(3,3)/if s~=0; s=0.5//s'
//  '<S438>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Negative Trace/Maximum Value at DCM(3,3)/u(9) -(u(1)+u(5)) +1'
//  '<S439>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Positive Trace/cos(phi)sin(theta)cos(psi) + sin(phi)sin(psi) +sin(theta)'
//  '<S440>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Positive Trace/cos(theta)sin(phi) - (cos(phi)sin(theta)sin(psi) - sin(phi)cos(psi))'
//  '<S441>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Positive Trace/cos(theta)sin(psi) - (sin(phi)sin(theta)cos(psi) - cos(phi)sin(psi))'
//  '<S442>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error'
//  '<S443>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/Else If Not Orthogonal'
//  '<S444>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/If Not Proper'
//  '<S445>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/isNotOrthogonal'
//  '<S446>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/isNotProper'
//  '<S447>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/Else If Not Orthogonal/Error'
//  '<S448>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/Else If Not Orthogonal/Warning'
//  '<S449>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/If Not Proper/Error'
//  '<S450>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/If Not Proper/Warning'
//  '<S451>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/isNotOrthogonal/transpose*dcm ~= eye(3)'
//  '<S452>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/isNotProper/Determinant of 3x3 Matrix'
//  '<S453>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions/Validate DCM/If Warning//Error/isNotProper/determinant does not equal 1'
//  '<S454>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Negative Trace'
//  '<S455>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Positive Trace'
//  '<S456>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Validate DCM'
//  '<S457>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/trace(DCM)'
//  '<S458>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Negative Trace/Maximum Value at DCM(1,1)'
//  '<S459>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Negative Trace/Maximum Value at DCM(2,2)'
//  '<S460>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Negative Trace/Maximum Value at DCM(3,3)'
//  '<S461>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Negative Trace/diag(DCM)'
//  '<S462>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Negative Trace/Maximum Value at DCM(1,1)/cos(phi)sin(theta)cos(psi) + sin(phi)sin(psi) -sin(theta)'
//  '<S463>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Negative Trace/Maximum Value at DCM(1,1)/cos(theta)sin(phi) - (cos(phi)sin(theta)sin(psi) - sin(phi)cos(psi))'
//  '<S464>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Negative Trace/Maximum Value at DCM(1,1)/cos(theta)sin(psi) + (sin(phi)sin(theta)cos(psi) - cos(phi)sin(psi))'
//  '<S465>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Negative Trace/Maximum Value at DCM(1,1)/if s~=0; s=0.5//s'
//  '<S466>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Negative Trace/Maximum Value at DCM(1,1)/u(1) -(u(5)+u(9)) +1'
//  '<S467>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Negative Trace/Maximum Value at DCM(2,2)/cos(phi)sin(theta)cos(psi) + sin(phi)sin(psi) +sin(theta)'
//  '<S468>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Negative Trace/Maximum Value at DCM(2,2)/cos(theta)sin(phi) + (cos(phi)sin(theta)sin(psi) - sin(phi)cos(psi))'
//  '<S469>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Negative Trace/Maximum Value at DCM(2,2)/cos(theta)sin(psi) + (sin(phi)sin(theta)cos(psi) - cos(phi)sin(psi))'
//  '<S470>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Negative Trace/Maximum Value at DCM(2,2)/if s~=0; s=0.5//s'
//  '<S471>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Negative Trace/Maximum Value at DCM(2,2)/u(5) -(u(1)+u(9)) +1'
//  '<S472>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Negative Trace/Maximum Value at DCM(3,3)/cos(phi)sin(theta)cos(psi) + sin(phi)sin(psi) -sin(theta)'
//  '<S473>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Negative Trace/Maximum Value at DCM(3,3)/cos(theta)sin(phi) + (cos(phi)sin(theta)sin(psi) - sin(phi)cos(psi))'
//  '<S474>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Negative Trace/Maximum Value at DCM(3,3)/cos(theta)sin(psi) - (sin(phi)sin(theta)cos(psi) - cos(phi)sin(psi))'
//  '<S475>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Negative Trace/Maximum Value at DCM(3,3)/if s~=0; s=0.5//s'
//  '<S476>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Negative Trace/Maximum Value at DCM(3,3)/u(9) -(u(1)+u(5)) +1'
//  '<S477>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Positive Trace/cos(phi)sin(theta)cos(psi) + sin(phi)sin(psi) +sin(theta)'
//  '<S478>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Positive Trace/cos(theta)sin(phi) - (cos(phi)sin(theta)sin(psi) - sin(phi)cos(psi))'
//  '<S479>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Positive Trace/cos(theta)sin(psi) - (sin(phi)sin(theta)cos(psi) - cos(phi)sin(psi))'
//  '<S480>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Validate DCM/If Warning//Error'
//  '<S481>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Validate DCM/If Warning//Error/Else If Not Orthogonal'
//  '<S482>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Validate DCM/If Warning//Error/If Not Proper'
//  '<S483>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Validate DCM/If Warning//Error/isNotOrthogonal'
//  '<S484>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Validate DCM/If Warning//Error/isNotProper'
//  '<S485>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Validate DCM/If Warning//Error/Else If Not Orthogonal/Error'
//  '<S486>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Validate DCM/If Warning//Error/Else If Not Orthogonal/Warning'
//  '<S487>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Validate DCM/If Warning//Error/If Not Proper/Error'
//  '<S488>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Validate DCM/If Warning//Error/If Not Proper/Warning'
//  '<S489>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Validate DCM/If Warning//Error/isNotOrthogonal/transpose*dcm ~= eye(3)'
//  '<S490>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Validate DCM/If Warning//Error/isNotProper/Determinant of 3x3 Matrix'
//  '<S491>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Direction Cosine Matrix  to Quaternions1/Validate DCM/If Warning//Error/isNotProper/determinant does not equal 1'
//  '<S492>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Euler to DCM/A11'
//  '<S493>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Euler to DCM/A12'
//  '<S494>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Euler to DCM/A13'
//  '<S495>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Euler to DCM/A21'
//  '<S496>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Euler to DCM/A22'
//  '<S497>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Euler to DCM/A23'
//  '<S498>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Euler to DCM/A31'
//  '<S499>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Euler to DCM/A32'
//  '<S500>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Euler to DCM/A33'
//  '<S501>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Euler to DCM/Create Transformation Matrix'
//  '<S502>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Quaternion Inverse/Quaternion Conjugate'
//  '<S503>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Quaternion Inverse/Quaternion Norm'
//  '<S504>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Quaternion Multiplication/q0'
//  '<S505>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Quaternion Multiplication/q1'
//  '<S506>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Quaternion Multiplication/q2'
//  '<S507>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/GroundModel/Quaternion Multiplication/q3'
//  '<S508>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Three-axis Accelerometer/Dynamics'
//  '<S509>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Three-axis Accelerometer/w x (w x d)'
//  '<S510>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Three-axis Accelerometer/wdot x d'
//  '<S511>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Three-axis Accelerometer/Dynamics/No Dynamics'
//  '<S512>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Three-axis Accelerometer/Dynamics/Second-order Dynamics'
//  '<S513>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Three-axis Accelerometer/w x (w x d)/w x (w x d)'
//  '<S514>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Three-axis Accelerometer/w x (w x d)/w x d'
//  '<S515>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Three-axis Accelerometer/w x (w x d)/w x (w x d)/Subsystem'
//  '<S516>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Three-axis Accelerometer/w x (w x d)/w x (w x d)/Subsystem1'
//  '<S517>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Three-axis Accelerometer/w x (w x d)/w x d/Subsystem'
//  '<S518>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Three-axis Accelerometer/w x (w x d)/w x d/Subsystem1'
//  '<S519>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Three-axis Accelerometer/wdot x d/Subsystem'
//  '<S520>' : 'FixedwingModel/Small Fixed Wing UAV Dynamics/Three-axis Accelerometer/wdot x d/Subsystem1'
//  '<S521>' : 'FixedwingModel/Weather Model/ Compute Norm'
//  '<S522>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model'
//  '<S523>' : 'FixedwingModel/Weather Model/Horizontal Wind Model '
//  '<S524>' : 'FixedwingModel/Weather Model/RL2B'
//  '<S525>' : 'FixedwingModel/Weather Model/[0, pi] Wrap Around'
//  '<S526>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Angle Conversion'
//  '<S527>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Filters on angular rates'
//  '<S528>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Filters on velocities'
//  '<S529>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Length Conversion'
//  '<S530>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Length Conversion1'
//  '<S531>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/RMS turbulence  intensities'
//  '<S532>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Select angular rates'
//  '<S533>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Select velocities'
//  '<S534>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Turbulence scale lengths'
//  '<S535>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Velocity Conversion'
//  '<S536>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Velocity Conversion2'
//  '<S537>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/White Noise'
//  '<S538>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Filters on angular rates/Hpgw'
//  '<S539>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Filters on angular rates/Hqgw'
//  '<S540>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Filters on angular rates/Hrgw'
//  '<S541>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Filters on velocities/Hugw(s)'
//  '<S542>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Filters on velocities/Hvgw(s)'
//  '<S543>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Filters on velocities/Hwgw(s)'
//  '<S544>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/RMS turbulence  intensities/High Altitude Intensity'
//  '<S545>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/RMS turbulence  intensities/Low Altitude Intensity'
//  '<S546>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Select angular rates/Interpolate  rates'
//  '<S547>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Select angular rates/Low altitude  rates'
//  '<S548>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Select angular rates/Medium//High  altitude rates'
//  '<S549>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Select angular rates/Merge Subsystems'
//  '<S550>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Select angular rates/Interpolate  rates/wind to body transformation'
//  '<S551>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Select angular rates/Interpolate  rates/wind to body transformation/convert to earth coords'
//  '<S552>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Select angular rates/Low altitude  rates/wind to body transformation'
//  '<S553>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Select angular rates/Low altitude  rates/wind to body transformation/convert to earth coords'
//  '<S554>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Select velocities/Interpolate  velocities'
//  '<S555>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Select velocities/Low altitude  velocities'
//  '<S556>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Select velocities/Medium//High  altitude velocities'
//  '<S557>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Select velocities/Merge Subsystems'
//  '<S558>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Select velocities/Interpolate  velocities/wind to body transformation'
//  '<S559>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Select velocities/Interpolate  velocities/wind to body transformation/convert to earth coords'
//  '<S560>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Select velocities/Low altitude  velocities/wind to body transformation'
//  '<S561>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Select velocities/Low altitude  velocities/wind to body transformation/convert to earth coords'
//  '<S562>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Turbulence scale lengths/Low altitude scale length'
//  '<S563>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Turbulence scale lengths/Medium//High altitude scale length'
//  '<S564>' : 'FixedwingModel/Weather Model/Dryden Wind Turbulence Model/Turbulence scale lengths/Medium//High altitude scale length/Length Conversion'
//  '<S565>' : 'FixedwingModel/Weather Model/Horizontal Wind Model /Angle Conversion'
//  '<S566>' : 'FixedwingModel/Weather Model/RL2B/Rotation Angles to Direction Cosine Matrix'
//  '<S567>' : 'FixedwingModel/Weather Model/RL2B/Rotation Angles to Direction Cosine Matrix/Create 3x3 Matrix'
//  '<S568>' : 'FixedwingModel/Weather Model/[0, pi] Wrap Around/Compare To Zero'
//  '<S569>' : 'FixedwingModel/Weather Model/[0, pi] Wrap Around/Negative Yaw'
//  '<S570>' : 'FixedwingModel/Weather Model/[0, pi] Wrap Around/Positive Yaw'

#endif                                 // RTW_HEADER_FixedwingModel_h_

//
// File trailer for generated code.
//
// [EOF]
//
