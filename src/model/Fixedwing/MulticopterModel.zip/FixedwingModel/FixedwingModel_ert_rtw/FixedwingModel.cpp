//
// File: FixedwingModel.cpp
//
// Code generated for Simulink model 'FixedwingModel'.
//
// Model version                  : 10.0
// Simulink Coder version         : 9.7 (R2022a) 13-Nov-2021
// C/C++ source code generated on : Tue Oct 18 15:33:03 2022
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#include "FixedwingModel.h"
#include "rtwtypes.h"
#include <cstring>
#include <cmath>
#include <cfloat>
#include <stddef.h>
#define NumBitsPerChar                 8U

// Private macros used by the generated code to access rtModel
#ifndef rtmIsMajorTimeStep
#define rtmIsMajorTimeStep(rtm)        (((rtm)->Timing.simTimeStep) == MAJOR_TIME_STEP)
#endif

#ifndef rtmIsMinorTimeStep
#define rtmIsMinorTimeStep(rtm)        (((rtm)->Timing.simTimeStep) == MINOR_TIME_STEP)
#endif

#ifndef rtmSetTPtr
#define rtmSetTPtr(rtm, val)           ((rtm)->Timing.t = (val))
#endif

#ifndef GRAVITY2_TYPEDEF

typedef enum { WGS84TAYLORSERIES = 1, WGS84CLOSEAPPROX,
  WGS84EXACT } GravityTypeIdx;

typedef enum { METRIC = 1, ENGLISH } UnitIdx;

typedef enum { JANUARY = 1, FEBRUARY, MARCH, APRIL, MAY, JUNE, JULY,
  AUGUST, SEPTEMBER, OCTOBER, NOVEMBER, DECEMBER } MonthIdx;

#define GRAVITY2_TYPEDEF
#endif                                 // GRAVITY2_TYPEDEF

#ifndef WGS84_DEFINE
#define WGS84_A                        6378137.0                 // Semi-major Axis (m) 
#define WGS84_INV_F                    298.257223563             // Reciprocal of Flattening 
#define WGS84_W_DEF                    7292115.0e-11             // WGS 84 Angular Velocity of Earth (rad/sec)
#define WGS84_GM_DEF                   3986004.418e+8            // Earth's Gravitational Const. (m^3/sec^2) 
#define WGS84_GM_PRM                   3986000.9e+8              // Earth's Grav. Const. (m^3/sec^2) [no atmos]
#define WGS84_W_PRM                    7292115.1467e-11          // IAU Angular Velocity of Earth (rad/sec) 
#define WGS84_G_E                      9.7803253359              // Theoretical (Normal) Gravity at the Equator
                                                                 // (on the Ellipsoid) (m/s^2) 
#define WGS84_K                        0.00193185265241          // Theoretical (Normal) Gravity Formula Const.
#define WGS84_E_2                      6.69437999014e-3          // First Eccentricity Squared 
#define WGS84_EL                       5.2185400842339e+5        // Linear Eccentricity 
#define WGS84_B                        6356752.3142              // Semi-minor Axis (m) 
#define WGS84_B_A                      0.996647189335            // Axis Ratio
#define M2FT                           1.0/0.3048
#define AERO_PI                        3.14159265358979323846
#define DEG2RAD                        AERO_PI/180.0
#define YEAR2000                       2000
#define WGS84_DEFINE
#endif                                 // WGS84_DEFINE

// Block parameters (default storage)
P_FixedwingModel_T MulticopterModelClass::FixedwingModel_P = {
  // Variable: uav
  //  Referenced by:
  //    '<Root>/ModelParam.uavMass'
  //    '<Root>/Gain'
  //    '<Root>/Gain1'
  //    '<Root>/Gain3'
  //    '<S8>/Constant1'
  //    '<S344>/ModelParam.uavMass'
  //    '<S522>/Wingspan'
  //    '<S149>/Min Th K'
  //    '<S149>/MaxRPM1'
  //    '<S149>/Th K'
  //    '<S348>/Constant'
  //    '<S382>/chord'
  //    '<S382>/span'
  //    '<S382>/span1'
  //    '<S382>/span2'
  //    '<S385>/CYDr'
  //    '<S385>/CYb'
  //    '<S386>/ClDa'
  //    '<S386>/ClDr'
  //    '<S386>/Clb'
  //    '<S387>/CnDa'
  //    '<S387>/CnDr'
  //    '<S387>/Cnb'
  //    '<S394>/Apolar'
  //    '<S394>/Apolar (A2)'
  //    '<S394>/CD0'
  //    '<S395>/CL0'
  //    '<S395>/CLDe'
  //    '<S395>/CLa'
  //    '<S395>/CLa_dot'
  //    '<S395>/CmDe1'
  //    '<S396>/Cm0'
  //    '<S396>/CmDe'
  //    '<S396>/CmDf'
  //    '<S396>/Cma'
  //    '<S396>/Cma1'
  //    '<S396>/chord'
  //    '<S396>/elarm'
  //    '<S388>/Constant'
  //    '<S388>/Constant1'
  //    '<S391>/Constant'
  //    '<S391>/Constant1'
  //    '<S397>/Constant'
  //    '<S389>/Cmq2'
  //    '<S390>/Cmq4'
  //    '<S392>/Cmq2'
  //    '<S393>/Cmq4'
  //    '<S398>/Cmq2'

  {
    {
      2.795,
      0.35134168157423973,
      0.982,
      1.21,
      8.1646626600000012
    },

    {
      4.12,
      9.58,
      9.85
    },

    {
      0.38,
      18.5,
      2.64,
      7.4,
      0.24,
      0.4,
      0.022,
      0.007,
      0.057,
      -1.098,
      0.143,
      -0.296,
      -1.96,
      0.103,
      0.1695,
      0.106,
      0.3,
      -1.239,
      -7.0,
      -2.4,
      -3.2,
      -0.021,
      0.277,
      -0.0889,
      -0.19997,
      -0.023,
      -0.1997
    },

    {
      0.0,
      2.17,
      0.2
    },

    {
      1.5707963267948966,
      -1.5707963267948966
    },

    {
      1.5707963267948966,
      -1.5707963267948966
    },

    {
      1.5707963267948966,
      -1.5707963267948966
    },

    {
      0.52359877559829882,
      -0.52359877559829882
    },

    {
      1.0,
      0.0
    },

    {
      1.5707963267948966,
      1.5707963267948966,
      0.034906585039886591,
      1.0
    },

    {
      { 0.0, 0.0, 0.0 },

      { 0.0, 0.0, 0.0 },

      { 0.0, 0.0, 0.0 },

      { 0.0, 0.0, 0.0 },

      { 0.001, 0.0, 0.0 },

      { 45.0, 120.0 },
      0.0
    },
    0.005
  },

  // Variable: FaultParamAPI
  //  Referenced by:
  //    '<S55>/Wind direction'
  //    '<S55>/Windspeed at 20ft (6m)'
  //    '<S56>/Wind direction'
  //    '<S56>/Windspeed at 20ft (6m)'
  //    '<S66>/Wind Direction'
  //    '<S66>/Wind speed at reference height'
  //    '<S252>/2*zeta * wn'
  //    '<S263>/2*zeta * wn'

  {
    { 1.0, 2.0, 2.0, 3.0, 1.0, 3.0, 1.0, 2.0, 1.0, 0.707, 0.0, 0.0, 0.0, 0.707,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0 }
  },

  // Variable: env
  //  Referenced by:
  //    '<Root>/Constant3'
  //    '<S148>/kg2N'
  //    '<S522>/Wind direction'
  //    '<S522>/Windspeed at 20ft (6m)'
  //    '<S523>/Wind Direction'
  //    '<S523>/Wind Speed'
  //    '<S399>/Constant'
  //    '<S399>/Sea Level  Temperature'
  //    '<S399>/1//T0'
  //    '<S399>/Lapse Rate'
  //    '<S399>/g//R'
  //    '<S399>/rho0'

  {
    0.0065,
    2000.0,
    287.0531,
    9.80665,
    1.225,
    101325.0,
    288.15,
    12.0,
    180.0,
    90.0,
    0.0
  },

  // Variable: SteerEngineFault
  //  Referenced by: '<S15>/SteerNum'

  {
    123450.0,
    5
  },

  // Variable: ModelInit_AngEuler
  //  Referenced by: '<S346>/phi theta psi'

  { 0.0, 0.0, 0.0 },

  // Variable: ModelInit_Inputs
  //  Referenced by: '<Root>/InitinputNoArmed'

  { 0.0, 0.0, -1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0 },

  // Variable: ModelInit_PosE
  //  Referenced by: '<S341>/xe,ye,ze'

  { 0.0, 0.0, 0.0 },

  // Variable: ModelInit_RateB
  //  Referenced by: '<S341>/p,q,r '

  { 0.0, 0.0, 0.0 },

  // Variable: ModelInit_VelB
  //  Referenced by: '<S341>/ub,vb,wb'

  { 0.001, 0.0, 0.0 },

  // Variable: ModelParam_GPSEphFinal
  //  Referenced by: '<S152>/ModelParam.GPSEphFinal'

  0.3,

  // Variable: ModelParam_GPSEpvFinal
  //  Referenced by: '<S152>/ModelParam.GPSEpvFinal'

  0.4,

  // Variable: ModelParam_GPSLatLong
  //  Referenced by:
  //    '<S24>/ref_position'
  //    '<S198>/ref_position'

  { 40.1540302, 116.2593683 },

  // Variable: ModelParam_envAltitude
  //  Referenced by:
  //    '<S3>/ModelParam.envAltitude'
  //    '<S194>/ModelParam.envAltitude'

  -50.0,

  // Variable: ModelParam_noisePowerOffGainAccel
  //  Referenced by: '<S153>/AccelNoiseGainFunction'

  0.04,

  // Variable: ModelParam_noisePowerOffGainAccelZ
  //  Referenced by: '<S153>/AccelNoiseGainFunction'

  0.03,

  // Variable: ModelParam_noisePowerOffGainGyro
  //  Referenced by: '<S153>/GyroNoiseGainFunction'

  0.02,

  // Variable: ModelParam_noisePowerOffGainGyroZ
  //  Referenced by: '<S153>/GyroNoiseGainFunction'

  0.025,

  // Variable: ModelParam_noisePowerOffGainMag
  //  Referenced by: '<S153>/MagNoiseGainFunction'

  0.02,

  // Variable: ModelParam_noisePowerOffGainMagZ
  //  Referenced by: '<S153>/MagNoiseGainFunction'

  0.035,

  // Variable: ModelParam_noisePowerOnGainAccel
  //  Referenced by: '<S153>/AccelNoiseGainFunction'

  0.8,

  // Variable: ModelParam_noisePowerOnGainAccelZ
  //  Referenced by: '<S153>/AccelNoiseGainFunction'

  4.5,

  // Variable: ModelParam_noisePowerOnGainGyro
  //  Referenced by: '<S153>/GyroNoiseGainFunction'

  2.0,

  // Variable: ModelParam_noisePowerOnGainGyroZ
  //  Referenced by: '<S153>/GyroNoiseGainFunction'

  1.0,

  // Variable: ModelParam_noisePowerOnGainMag
  //  Referenced by: '<S153>/MagNoiseGainFunction'

  0.025,

  // Variable: ModelParam_noisePowerOnGainMagZ
  //  Referenced by: '<S153>/MagNoiseGainFunction'

  0.05,

  // Variable: ModelParam_uavType
  //  Referenced by: '<S7>/UAVType'

  100,

  // Mask Parameter: BandLimitedWhiteNoise_Cov
  //  Referenced by: '<S16>/Output'

  1.0,

  // Mask Parameter: DrydenWindTurbulenceModel_L_hig
  //  Referenced by: '<S563>/Medium//High Altitude'

  533.4,

  // Mask Parameter: DrydenWindTurbulenceModelDiscre
  //  Referenced by: '<S144>/Medium//High Altitude'

  533.4,

  // Mask Parameter: DrydenWindTurbulenceModelDisc_h
  //  Referenced by: '<S105>/Medium//High Altitude'

  533.4,

  // Mask Parameter: DrydenWindTurbulenceModel_Seed
  //  Referenced by: '<S537>/White Noise'

  { 23341.0, 23342.0, 23343.0, 23344.0 },

  // Mask Parameter: DrydenWindTurbulenceModelDisc_o
  //  Referenced by: '<S118>/White Noise'

  { 23301.0, 23542.0, 82443.0, 33344.0 },

  // Mask Parameter: DrydenWindTurbulenceModelDis_o3
  //  Referenced by: '<S79>/White Noise'

  { 23341.0, 23342.0, 23343.0, 23344.0 },

  // Mask Parameter: DrydenWindTurbulenceModel_T_on
  //  Referenced by:
  //    '<S527>/Constant1'
  //    '<S527>/Constant2'
  //    '<S527>/Constant3'
  //    '<S528>/Constant'

  1.0,

  // Mask Parameter: DrydenWindTurbulenceModelDisc_f
  //  Referenced by:
  //    '<S108>/Constant1'
  //    '<S108>/Constant2'
  //    '<S108>/Constant3'
  //    '<S109>/Constant3'

  1.0,

  // Mask Parameter: DrydenWindTurbulenceModelDisc_e
  //  Referenced by:
  //    '<S69>/Constant1'
  //    '<S69>/Constant2'
  //    '<S69>/Constant3'
  //    '<S70>/Constant3'

  1.0,

  // Mask Parameter: WhiteNoise_Ts
  //  Referenced by: '<S537>/Constant1'

  0.01,

  // Mask Parameter: WhiteNoise_Ts_a
  //  Referenced by: '<S118>/Constant1'

  0.01,

  // Mask Parameter: WhiteNoise_Ts_h
  //  Referenced by: '<S79>/Constant1'

  0.01,

  // Mask Parameter: DrydenWindTurbulenceModel_TurbP
  //  Referenced by: '<S544>/Probability of  Exceedance'

  3.0,

  // Mask Parameter: DrydenWindTurbulenceModelDisc_m
  //  Referenced by: '<S125>/Probability of  Exceedance'

  3.0,

  // Mask Parameter: DrydenWindTurbulenceModelDisc_l
  //  Referenced by: '<S86>/Probability of  Exceedance'

  4.0,

  // Mask Parameter: DrydenWindTurbulenceModelDisc_b
  //  Referenced by: '<S55>/Wingspan'

  1.0,

  // Mask Parameter: DrydenWindTurbulenceModelDis_bc
  //  Referenced by: '<S56>/Wingspan'

  1.0,

  // Mask Parameter: ThreeaxisInertialMeasurementUni
  //  Referenced by: '<S246>/Measurement bias'

  { 0.0, 0.0, 0.0 },

  // Mask Parameter: ThreeaxisAccelerometer_a_bias
  //  Referenced by: '<S345>/Measurement bias'

  { 0.0, 0.0, 0.0 },

  // Mask Parameter: ThreeaxisInertialMeasurementU_l
  //  Referenced by: '<S246>/Scale factors & Cross-coupling  errors'

  { 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0 },

  // Mask Parameter: ThreeaxisAccelerometer_a_sf_cc
  //  Referenced by: '<S345>/Scale factors & Cross-coupling  errors'

  { 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0 },

  // Mask Parameter: ThreeaxisAccelerometer_acc
  //  Referenced by: '<S345>/wl_ins'

  { 0.0, 0.0, 0.0 },

  // Mask Parameter: DirectionCosineMatrixtoQuaterni
  //  Referenced by:
  //    '<S157>/If Warning//Error'
  //    '<S157>/Constant'

  1.0,

  // Mask Parameter: DirectionCosineMatrixtoQuater_o
  //  Referenced by:
  //    '<S418>/If Warning//Error'
  //    '<S418>/Constant'

  1.0,

  // Mask Parameter: DirectionCosineMatrixtoQuater_c
  //  Referenced by:
  //    '<S456>/If Warning//Error'
  //    '<S456>/Constant'

  1.0,

  // Mask Parameter: CompareToConstant_const
  //  Referenced by: '<S43>/Constant'

  180.0,

  // Mask Parameter: CompareToConstant_const_j
  //  Referenced by: '<S41>/Constant'

  90.0,

  // Mask Parameter: CompareToConstant_const_jw
  //  Referenced by: '<S44>/Constant'

  180.0,

  // Mask Parameter: CompareToConstant_const_p
  //  Referenced by: '<S37>/Constant'

  180.0,

  // Mask Parameter: CompareToConstant_const_d
  //  Referenced by: '<S35>/Constant'

  90.0,

  // Mask Parameter: CompareToConstant_const_b
  //  Referenced by: '<S38>/Constant'

  180.0,

  // Mask Parameter: CompareToConstant_const_e
  //  Referenced by: '<S279>/Constant'

  180.0,

  // Mask Parameter: CompareToConstant_const_h
  //  Referenced by: '<S277>/Constant'

  90.0,

  // Mask Parameter: CompareToConstant_const_n
  //  Referenced by: '<S280>/Constant'

  180.0,

  // Mask Parameter: CompareToConstant_const_o
  //  Referenced by: '<S214>/Constant'

  180.0,

  // Mask Parameter: CompareToConstant_const_c
  //  Referenced by: '<S212>/Constant'

  90.0,

  // Mask Parameter: CompareToConstant_const_f
  //  Referenced by: '<S215>/Constant'

  180.0,

  // Mask Parameter: CompareToConstant_const_l
  //  Referenced by: '<S208>/Constant'

  180.0,

  // Mask Parameter: CompareToConstant_const_a
  //  Referenced by: '<S206>/Constant'

  90.0,

  // Mask Parameter: CompareToConstant_const_k
  //  Referenced by: '<S209>/Constant'

  180.0,

  // Mask Parameter: Distanceintogustx_d_m
  //  Referenced by: '<S20>/Distance into Gust (x) (Limited to gust length d)'

  120.0,

  // Mask Parameter: Distanceintogusty_d_m
  //  Referenced by: '<S17>/Distance into gust (y)'

  120.0,

  // Mask Parameter: Distanceintogustz_d_m
  //  Referenced by: '<S17>/Distance into gust (z)'

  80.0,

  // Mask Parameter: DiscreteWindGustModel_d_m
  //  Referenced by: '<S17>/pi//Gust length'

  { 120.0, 120.0, 80.0 },

  // Mask Parameter: LinearSecondOrderActuators_fin_
  //  Referenced by: '<S10>/Integrator, Second-Order'

  0.0,

  // Mask Parameter: LinearSecondOrderActuator4_fin_
  //  Referenced by: '<S14>/Integrator, Second-Order'

  0.0,

  // Mask Parameter: LinearSecondOrderActuator1_fin_
  //  Referenced by: '<S11>/Integrator, Second-Order'

  0.0,

  // Mask Parameter: LinearSecondOrderActuator2_fin_
  //  Referenced by: '<S12>/Integrator, Second-Order'

  0.0,

  // Mask Parameter: LinearSecondOrderActuator3_fin_
  //  Referenced by: '<S13>/Integrator, Second-Order'

  0.0,

  // Mask Parameter: LinearSecondOrderActuators_fi_e
  //  Referenced by: '<S10>/Integrator, Second-Order'

  0.0,

  // Mask Parameter: LinearSecondOrderActuator4_fi_c
  //  Referenced by: '<S14>/Integrator, Second-Order'

  0.0,

  // Mask Parameter: LinearSecondOrderActuator1_fi_e
  //  Referenced by: '<S11>/Integrator, Second-Order'

  0.0,

  // Mask Parameter: LinearSecondOrderActuator2_fi_c
  //  Referenced by: '<S12>/Integrator, Second-Order'

  0.0,

  // Mask Parameter: LinearSecondOrderActuator3_fi_l
  //  Referenced by: '<S13>/Integrator, Second-Order'

  0.0,

  // Mask Parameter: ThreeaxisInertialMeasurementU_b
  //  Referenced by: '<S247>/Measurement bias'

  { 0.0, 0.0, 0.0 },

  // Mask Parameter: ThreeaxisInertialMeasurement_b5
  //  Referenced by: '<S247>/g-sensitive bias'

  { 0.0, 0.0, 0.0 },

  // Mask Parameter: ThreeaxisInertialMeasurementU_m
  //  Referenced by: '<S247>/Scale factors & Cross-coupling  errors '

  { 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0 },

  // Mask Parameter: ISAAtmosphereModel1_h0
  //  Referenced by: '<S399>/Limit  altitude  to troposhere'

  0.0,

  // Mask Parameter: ISAAtmosphereModel1_h_strat
  //  Referenced by: '<S399>/Limit  altitude  to Stratosphere'

  20000.0,

  // Mask Parameter: ISAAtmosphereModel1_h_trop
  //  Referenced by:
  //    '<S399>/Altitude of Troposphere'
  //    '<S399>/Limit  altitude  to Stratosphere'
  //    '<S399>/Limit  altitude  to troposhere'

  11000.0,

  // Mask Parameter: ThreeaxisInertialMeasurementU_p
  //  Referenced by: '<S246>/wl_ins'

  { 0.0, 0.0, 0.0 },

  // Mask Parameter: uDOFEulerAngles_inertia
  //  Referenced by: '<S348>/Constant1'

  { 4.12, 0.0, 0.0, 0.0, 9.58, 0.0, 0.0, 0.0, 9.85 },

  // Mask Parameter: CheckAltitude_max
  //  Referenced by: '<S264>/max_val'

  850000.0,

  // Mask Parameter: CheckLatitude_max
  //  Referenced by: '<S265>/max_val'

  90.0,

  // Mask Parameter: CheckLongitude_max
  //  Referenced by: '<S266>/max_val'

  180.0,

  // Mask Parameter: Istimewithinmodellimits_max
  //  Referenced by: '<S268>/max_val'

  5.0,

  // Mask Parameter: CheckAltitude_min
  //  Referenced by: '<S264>/min_val'

  -1000.0,

  // Mask Parameter: CheckLatitude_min
  //  Referenced by: '<S265>/min_val'

  -90.0,

  // Mask Parameter: CheckLongitude_min
  //  Referenced by: '<S266>/min_val'

  -180.0,

  // Mask Parameter: Istimewithinmodellimits_min
  //  Referenced by: '<S268>/min_val'

  0.0,

  // Mask Parameter: FlatEarthtoLLA_psi
  //  Referenced by: '<S24>/ref_rotation'

  0.0,

  // Mask Parameter: FlatEarthtoLLA_psi_i
  //  Referenced by: '<S198>/ref_rotation'

  0.0,

  // Mask Parameter: WhiteNoise_pwr
  //  Referenced by: '<S537>/Constant'

  { 3.1415926535897931, 3.1415926535897931, 3.1415926535897931,
    3.1415926535897931 },

  // Mask Parameter: WhiteNoise_pwr_f
  //  Referenced by: '<S118>/Constant'

  { 0.01, 0.01, 0.01, 0.01 },

  // Mask Parameter: WhiteNoise_pwr_a
  //  Referenced by: '<S79>/Constant'

  { 0.01, 0.01, 0.01, 0.01 },

  // Mask Parameter: BandLimitedWhiteNoise_seed
  //  Referenced by: '<S16>/White Noise'

  23341.0,

  // Mask Parameter: DiscreteWindGustModel_t_0
  //  Referenced by: '<S17>/Gust start time'

  2.0,

  // Mask Parameter: DirectionCosineMatrixtoQuate_o3
  //  Referenced by: '<S157>/If Warning//Error'

  4.4408920985006262E-16,

  // Mask Parameter: DirectionCosineMatrixtoQuater_p
  //  Referenced by: '<S418>/If Warning//Error'

  4.4408920985006262E-16,

  // Mask Parameter: DirectionCosineMatrixtoQuater_k
  //  Referenced by: '<S456>/If Warning//Error'

  4.4408920985006262E-16,

  // Mask Parameter: DiscreteWindGustModel_v_m
  //  Referenced by: '<S17>/Gust magnitude//2.0'

  { 3.5, 3.5, 3.0 },

  // Mask Parameter: ThreeaxisInertialMeasurement_mp
  //  Referenced by:
  //    '<S252>/2*zeta * wn'
  //    '<S252>/wn^2'

  190.0,

  // Mask Parameter: ThreeaxisInertialMeasurementU_e
  //  Referenced by:
  //    '<S263>/2*zeta * wn'
  //    '<S263>/wn^2'

  190.0,

  // Mask Parameter: SecondorderDynamics_wn
  //  Referenced by:
  //    '<S512>/2*zeta * wn'
  //    '<S512>/wn^2'

  190.0,

  // Mask Parameter: LinearSecondOrderActuators_wn_f
  //  Referenced by:
  //    '<S10>/2*zeta * wn'
  //    '<S10>/wn^2'

  35.0,

  // Mask Parameter: LinearSecondOrderActuator1_wn_f
  //  Referenced by:
  //    '<S11>/2*zeta * wn'
  //    '<S11>/wn^2'

  35.0,

  // Mask Parameter: LinearSecondOrderActuator2_wn_f
  //  Referenced by:
  //    '<S12>/2*zeta * wn'
  //    '<S12>/wn^2'

  35.0,

  // Mask Parameter: LinearSecondOrderActuator3_wn_f
  //  Referenced by:
  //    '<S13>/2*zeta * wn'
  //    '<S13>/wn^2'

  35.0,

  // Mask Parameter: LinearSecondOrderActuator4_wn_f
  //  Referenced by:
  //    '<S14>/2*zeta * wn'
  //    '<S14>/wn^2'

  35.0,

  // Mask Parameter: LinearSecondOrderActuators_z_fi
  //  Referenced by: '<S10>/2*zeta * wn'

  0.75,

  // Mask Parameter: LinearSecondOrderActuator1_z_fi
  //  Referenced by: '<S11>/2*zeta * wn'

  0.75,

  // Mask Parameter: LinearSecondOrderActuator2_z_fi
  //  Referenced by: '<S12>/2*zeta * wn'

  0.75,

  // Mask Parameter: LinearSecondOrderActuator3_z_fi
  //  Referenced by: '<S13>/2*zeta * wn'

  0.75,

  // Mask Parameter: LinearSecondOrderActuator4_z_fi
  //  Referenced by: '<S14>/2*zeta * wn'

  0.75,

  // Mask Parameter: SecondorderDynamics_zn
  //  Referenced by: '<S512>/2*zeta * wn'

  0.707,

  // Mask Parameter: DiscreteWindGustModel_Gx
  //  Referenced by: '<S17>/Constant'

  true,

  // Mask Parameter: DiscreteWindGustModel_Gy
  //  Referenced by: '<S17>/Constant1'

  true,

  // Mask Parameter: DiscreteWindGustModel_Gz
  //  Referenced by: '<S17>/Constant2'

  true,

  // Expression: [0]
  //  Referenced by: '<S20>/x'

  0.0,

  // Expression: 0
  //  Referenced by: '<S20>/Distance into Gust (x) (Limited to gust length d)'

  0.0,

  // Expression: 0
  //  Referenced by: '<S20>/Distance into Gust (x) (Limited to gust length d)'

  0.0,

  // Expression: -90
  //  Referenced by: '<S33>/Bias'

  -90.0,

  // Expression: -1
  //  Referenced by: '<S33>/Gain'

  -1.0,

  // Expression: +90
  //  Referenced by: '<S33>/Bias1'

  90.0,

  // Expression: 180
  //  Referenced by: '<S36>/Bias'

  180.0,

  // Expression: -180
  //  Referenced by: '<S36>/Bias1'

  -180.0,

  // Expression: 180
  //  Referenced by: '<S34>/Bias'

  180.0,

  // Expression: -180
  //  Referenced by: '<S34>/Bias1'

  -180.0,

  // Expression: -90
  //  Referenced by: '<S39>/Bias'

  -90.0,

  // Expression: -1
  //  Referenced by: '<S39>/Gain'

  -1.0,

  // Expression: +90
  //  Referenced by: '<S39>/Bias1'

  90.0,

  // Expression: 360
  //  Referenced by: '<S42>/Constant2'

  360.0,

  // Expression: 180
  //  Referenced by: '<S42>/Bias'

  180.0,

  // Expression: -180
  //  Referenced by: '<S42>/Bias1'

  -180.0,

  // Expression: 180
  //  Referenced by: '<S30>/Constant'

  180.0,

  // Expression: 0
  //  Referenced by: '<S30>/Constant1'

  0.0,

  // Expression: 360
  //  Referenced by: '<S40>/Constant2'

  360.0,

  // Expression: 180
  //  Referenced by: '<S40>/Bias'

  180.0,

  // Expression: -180
  //  Referenced by: '<S40>/Bias1'

  -180.0,

  // Expression: 1
  //  Referenced by: '<S90>/Gain'

  1.0,

  // Expression: 1
  //  Referenced by: '<S98>/Gain'

  1.0,

  // Expression: 1
  //  Referenced by: '<S129>/Gain'

  1.0,

  // Expression: 1
  //  Referenced by: '<S137>/Gain'

  1.0,

  // Expression: -90
  //  Referenced by: '<S204>/Bias'

  -90.0,

  // Expression: -1
  //  Referenced by: '<S204>/Gain'

  -1.0,

  // Expression: +90
  //  Referenced by: '<S204>/Bias1'

  90.0,

  // Expression: 180
  //  Referenced by: '<S207>/Bias'

  180.0,

  // Expression: -180
  //  Referenced by: '<S207>/Bias1'

  -180.0,

  // Expression: 180
  //  Referenced by: '<S205>/Bias'

  180.0,

  // Expression: -180
  //  Referenced by: '<S205>/Bias1'

  -180.0,

  // Expression: -90
  //  Referenced by: '<S210>/Bias'

  -90.0,

  // Expression: -1
  //  Referenced by: '<S210>/Gain'

  -1.0,

  // Expression: +90
  //  Referenced by: '<S210>/Bias1'

  90.0,

  // Expression: 360
  //  Referenced by: '<S213>/Constant2'

  360.0,

  // Expression: 180
  //  Referenced by: '<S213>/Bias'

  180.0,

  // Expression: -180
  //  Referenced by: '<S213>/Bias1'

  -180.0,

  // Expression: 180
  //  Referenced by: '<S201>/Constant'

  180.0,

  // Expression: 0
  //  Referenced by: '<S201>/Constant1'

  0.0,

  // Expression: 360
  //  Referenced by: '<S211>/Constant2'

  360.0,

  // Expression: 180
  //  Referenced by: '<S211>/Bias'

  180.0,

  // Expression: -180
  //  Referenced by: '<S211>/Bias1'

  -180.0,

  // Expression: -90
  //  Referenced by: '<S275>/Bias'

  -90.0,

  // Expression: -1
  //  Referenced by: '<S275>/Gain'

  -1.0,

  // Expression: +90
  //  Referenced by: '<S275>/Bias1'

  90.0,

  // Expression: 180
  //  Referenced by: '<S278>/Bias'

  180.0,

  // Expression: -180
  //  Referenced by: '<S278>/Bias1'

  -180.0,

  // Expression: 180
  //  Referenced by: '<S276>/Bias'

  180.0,

  // Expression: -180
  //  Referenced by: '<S276>/Bias1'

  -180.0,

  // Expression: ones(1,maxdef+1)
  //  Referenced by: '<S297>/pp[13]'

  { 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0 },

  // Expression: 1
  //  Referenced by: '<S297>/Constant'

  1.0,

  // Expression: ones(1,maxdef+1)
  //  Referenced by: '<S298>/pp[13]'

  { 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0 },

  // Expression: k
  //  Referenced by: '<S298>/k[13][13]'

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.33333333333333331,
    0.0, -1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.26666666666666666, 0.2, 0.0, -0.33333333333333331, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.25714285714285712, 0.22857142857142856,
    0.14285714285714285, 0.0, -0.2, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.25396825396825395, 0.23809523809523808, 0.19047619047619047,
    0.1111111111111111, 0.0, -0.14285714285714285, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.25252525252525254, 0.24242424242424243, 0.21212121212121213,
    0.16161616161616163, 0.090909090909090912, 0.0, -0.1111111111111111, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.25174825174825177, 0.24475524475524477,
    0.22377622377622378, 0.1888111888111888, 0.13986013986013987,
    0.076923076923076927, 0.0, -0.090909090909090912, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.25128205128205128, 0.24615384615384617, 0.23076923076923078,
    0.20512820512820512, 0.16923076923076924, 0.12307692307692308,
    0.066666666666666666, 0.0, -0.076923076923076927, 0.0, 0.0, 0.0, 0.0,
    0.25098039215686274, 0.24705882352941178, 0.23529411764705882,
    0.21568627450980393, 0.18823529411764706, 0.15294117647058825,
    0.10980392156862745, 0.058823529411764705, 0.0, -0.066666666666666666, 0.0,
    0.0, 0.0, 0.25077399380804954, 0.24767801857585139, 0.23839009287925697,
    0.22291021671826625, 0.20123839009287925, 0.17337461300309598,
    0.13931888544891641, 0.099071207430340563, 0.052631578947368418, 0.0,
    -0.058823529411764705, 0.0, 0.0, 0.25062656641604009, 0.24812030075187969,
    0.24060150375939848, 0.22807017543859648, 0.21052631578947367,
    0.18796992481203006, 0.16040100250626566, 0.12781954887218044,
    0.090225563909774431, 0.047619047619047616, 0.0, -0.052631578947368418, 0.0,
    0.25051759834368531, 0.2484472049689441, 0.24223602484472051,
    0.2318840579710145, 0.21739130434782608, 0.19875776397515527,
    0.17598343685300208, 0.14906832298136646, 0.11801242236024845,
    0.082815734989648032, 0.043478260869565216, 0.0, -0.047619047619047616 },

  // Expression: 0
  //  Referenced by: '<S293>/bpp'

  0.0,

  // Expression: fm(2)
  //  Referenced by: '<S293>/Constant'

  1.0,

  // Expression: 1
  //  Referenced by: '<S293>/Constant1'

  1.0,

  // Expression: ones(1,maxdef+1)
  //  Referenced by: '<S293>/Unit Delay1'

  { 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0 },

  // Expression: 1
  //  Referenced by: '<S301>/Constant'

  1.0,

  // Expression: 1
  //  Referenced by: '<S301>/Gain1'

  1.0,

  // Expression: 1
  //  Referenced by: '<S301>/Gain2'

  1.0,

  // Expression: 1
  //  Referenced by: '<S303>/Constant'

  1.0,

  // Expression: 1
  //  Referenced by: '<S304>/Constant'

  1.0,

  // Expression: 0
  //  Referenced by: '<S307>/Constant1'

  0.0,

  // Expression: 0
  //  Referenced by: '<S307>/Constant'

  0.0,

  // Expression: k
  //  Referenced by: '<S307>/k[13][13]'

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.33333333333333331,
    0.0, -1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.26666666666666666, 0.2, 0.0, -0.33333333333333331, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.25714285714285712, 0.22857142857142856,
    0.14285714285714285, 0.0, -0.2, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.25396825396825395, 0.23809523809523808, 0.19047619047619047,
    0.1111111111111111, 0.0, -0.14285714285714285, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.25252525252525254, 0.24242424242424243, 0.21212121212121213,
    0.16161616161616163, 0.090909090909090912, 0.0, -0.1111111111111111, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.25174825174825177, 0.24475524475524477,
    0.22377622377622378, 0.1888111888111888, 0.13986013986013987,
    0.076923076923076927, 0.0, -0.090909090909090912, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.25128205128205128, 0.24615384615384617, 0.23076923076923078,
    0.20512820512820512, 0.16923076923076924, 0.12307692307692308,
    0.066666666666666666, 0.0, -0.076923076923076927, 0.0, 0.0, 0.0, 0.0,
    0.25098039215686274, 0.24705882352941178, 0.23529411764705882,
    0.21568627450980393, 0.18823529411764706, 0.15294117647058825,
    0.10980392156862745, 0.058823529411764705, 0.0, -0.066666666666666666, 0.0,
    0.0, 0.0, 0.25077399380804954, 0.24767801857585139, 0.23839009287925697,
    0.22291021671826625, 0.20123839009287925, 0.17337461300309598,
    0.13931888544891641, 0.099071207430340563, 0.052631578947368418, 0.0,
    -0.058823529411764705, 0.0, 0.0, 0.25062656641604009, 0.24812030075187969,
    0.24060150375939848, 0.22807017543859648, 0.21052631578947367,
    0.18796992481203006, 0.16040100250626566, 0.12781954887218044,
    0.090225563909774431, 0.047619047619047616, 0.0, -0.052631578947368418, 0.0,
    0.25051759834368531, 0.2484472049689441, 0.24223602484472051,
    0.2318840579710145, 0.21739130434782608, 0.19875776397515527,
    0.17598343685300208, 0.14906832298136646, 0.11801242236024845,
    0.082815734989648032, 0.043478260869565216, 0.0, -0.047619047619047616 },

  // Expression: zeros(maxdef+1,maxdef+1)
  //  Referenced by: '<S291>/dp[13][13]'

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0 },

  // Expression: snorm
  //  Referenced by: '<S291>/snorm[169]'

  { 1.0, 1.0, 1.5, 2.5, 4.375, 7.875, 14.4375, 26.8125, 50.2734375, 94.9609375,
    180.42578125, 344.44921875, 660.1943359375, 0.0, 1.0, 1.7320508075688772,
    3.0618621784789726, 5.5339859052946636, 10.16658128379447,
    18.903124741692839, 35.469603513959669, 67.03125, 127.40346687426536,
    243.28607380714598, 466.38644692864216, 897.027461585248, 0.0, 0.0,
    0.8660254037844386, 1.9364916731037085, 3.9131189606246322,
    7.685213074469698, 14.944232269507859, 28.960809996010127,
    56.082367403612253, 108.65004161512664, 210.69192030396434,
    409.04797337487776, 795.12986069746626, 0.0, 0.0, 0.0, 0.79056941504209488,
    2.0916500663351889, 4.7062126492541738, 9.9628215130052382,
    20.478385136833914, 41.41957332816817, 82.982839993569982,
    165.28034045942309, 327.9680080977904, 649.22081265302029, 0.0, 0.0, 0.0,
    0.0, 0.739509972887452, 2.2185299186623553, 5.4568620790707172,
    12.348930874776167, 26.736219617835371, 56.375738371688975,
    116.87084953567937, 239.5139682335957, 486.91560948976519, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.7015607600201138, 2.3268138086232852, 6.1744654373880836,
    14.830586268334102, 33.69094768709671, 73.915615322315773,
    158.42359886807964, 334.02135244518831, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.671693289381396, 2.4218245962496963, 6.8652274293172546, 17.39793057467611,
    41.320085114855779, 94.117642301250768, 208.29891011946015, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.6472598492877496, 2.5068266169601756,
    7.5335249254737544, 20.043185339772048, 49.604352946160631,
    117.05388227149012, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.6267066542400439, 2.5839777317091466, 8.1825961504123, 22.760038068635609,
    58.526941135745062, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.60904939217552367, 2.65478475211798, 8.8149248398872544,
    25.543251233216804, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.59362791713657326, 2.72034486491732, 9.4324706362690076, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.579979473934679,
    2.7814838439702596, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.56776801212685635 },

  // Expression: zeros(maxdef+1,maxdef+1)
  //  Referenced by: '<S291>/Unit Delay'

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0 },

  // Expression: snorm
  //  Referenced by: '<S291>/Unit Delay1'

  { 1.0, 1.0, 1.5, 2.5, 4.375, 7.875, 14.4375, 26.8125, 50.2734375, 94.9609375,
    180.42578125, 344.44921875, 660.1943359375, 0.0, 1.0, 1.7320508075688772,
    3.0618621784789726, 5.5339859052946636, 10.16658128379447,
    18.903124741692839, 35.469603513959669, 67.03125, 127.40346687426536,
    243.28607380714598, 466.38644692864216, 897.027461585248, 0.0, 0.0,
    0.8660254037844386, 1.9364916731037085, 3.9131189606246322,
    7.685213074469698, 14.944232269507859, 28.960809996010127,
    56.082367403612253, 108.65004161512664, 210.69192030396434,
    409.04797337487776, 795.12986069746626, 0.0, 0.0, 0.0, 0.79056941504209488,
    2.0916500663351889, 4.7062126492541738, 9.9628215130052382,
    20.478385136833914, 41.41957332816817, 82.982839993569982,
    165.28034045942309, 327.9680080977904, 649.22081265302029, 0.0, 0.0, 0.0,
    0.0, 0.739509972887452, 2.2185299186623553, 5.4568620790707172,
    12.348930874776167, 26.736219617835371, 56.375738371688975,
    116.87084953567937, 239.5139682335957, 486.91560948976519, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.7015607600201138, 2.3268138086232852, 6.1744654373880836,
    14.830586268334102, 33.69094768709671, 73.915615322315773,
    158.42359886807964, 334.02135244518831, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.671693289381396, 2.4218245962496963, 6.8652274293172546, 17.39793057467611,
    41.320085114855779, 94.117642301250768, 208.29891011946015, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.6472598492877496, 2.5068266169601756,
    7.5335249254737544, 20.043185339772048, 49.604352946160631,
    117.05388227149012, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.6267066542400439, 2.5839777317091466, 8.1825961504123, 22.760038068635609,
    58.526941135745062, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.60904939217552367, 2.65478475211798, 8.8149248398872544,
    25.543251233216804, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.59362791713657326, 2.72034486491732, 9.4324706362690076, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.579979473934679,
    2.7814838439702596, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.56776801212685635 },

  // Expression: 0
  //  Referenced by: '<S291>/Merge1'

  0.0,

  // Expression: 0
  //  Referenced by: '<S291>/Merge'

  0.0,

  // Expression: 1
  //  Referenced by: '<S320>/Gain'

  1.0,

  // Expression: zeros(maxdef+1,maxdef+1)
  //  Referenced by: '<S319>/zeros(maxdef+1,maxdef+1)'

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0 },

  // Expression: zeros(maxdef+1,maxdef+1)
  //  Referenced by: '<S292>/tc[13][13]'

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0 },

  // Expression: zeros(maxdef+1,maxdef+1)
  //  Referenced by: '<S292>/Unit Delay'

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0 },

  // Expression: c
  //  Referenced by: '<S292>/c[maxdef][maxdef]'

  { 0.0, 4796.3, -4923.1812154337767, -348.13372969305919, 1567.7782069699783,
    476.81266220996059, -379.95280730802608, -1925.9994708080098, 677.015625,
    -2777.3955778589848, 802.84404356358175, -0.0, -897.027461585248, -29438.2,
    -1493.5, -553.21702793749932, 477.34519742006415, -738.01423597380563,
    1510.1443691332956, 490.17081843985773, -564.73579492219744,
    -1026.3073234861042, 1162.5554452818549, -84.276768121585746,
    859.00074408724333, 238.53895820923987, -3666.75, 5221.6135695778939,
    1454.0566529540724, -424.8520036436218, 377.9611669867686,
    -564.2748966455755, 588.80275141860955, 122.87031082100349,
    550.88032526463667, 979.19751192412582, 760.28956611334615,
    -196.78080485867423, 1168.5974627754365, 3379.5, -7200.2750989111519,
    2369.4912112096977, 460.34857037901179, -244.03829105285917,
    35.496478698597684, -366.1554455056451, 302.54880643201608,
    -387.67518445861288, -383.35502092748504, 514.23173795698926,
    -263.46536505695531, -1071.2143408774834, 3970.3125, 4509.091715634092,
    460.96541356158167, -701.95776226208943, 51.543845110255411,
    70.577012458023447, 18.84719184984861, 21.610629030858291,
    240.25549754701245, -232.4675390409673, -583.93336104629464,
    110.89651920765574, 100.20640573355649, -1834.0875, 3660.9859202943885,
    1473.2553463758411, -664.98784733961486, -348.75290321372222,
    5.4020178521548763, 41.577814612708416, -67.084541316116585,
    41.191364575903528, 137.44365153994127, -24.792051068913466,
    -18.823528460250156, 145.80923708362209, 1001.9625000000001,
    1279.7415450126052, 1080.4679930854181, -1286.2002573289762,
    -154.97488304560835, 31.644667797276679, -47.220038243512143,
    -1.8770535629344738, -23.062804876033614, 7.5335249254737544,
    -84.1813784270426, -104.16914118693732, -11.705388227149014, 2190.58125,
    -2692.1429067095391, -205.6217509716719, 1068.9717041427305,
    185.23396312164252, 56.187635480231556, -7.2654737887490892,
    3.8188331107977227, 1.5040959701761054, -10.077513153665672,
    -23.729528836195669, -34.140057102953413, 17.558082340723519, 1216.6171875,
    596.578125, -947.792009121047, -128.40067731732134, -553.43974608919211,
    197.24679736884357, 79.636638180080155, -40.861273856450865,
    -1.3160839739040922, 5.1769198334919508, -2.9202632273297784,
    -22.918804583706862, 5.1086502466433608, 522.28515625, 1121.1505084935352,
    325.95012484537995, -265.54508797942395, 33.825443023013385,
    -444.72050946967653, -1.739793057467611, 65.541666851621656,
    -23.514197358553233, -6.3341136786254468, -5.2239256708018447,
    -5.44068972983464, -8.489223572642107, -360.8515625, -1484.0450502235904,
    42.138384060792873, 99.168204275653849, -58.435424767839685,
    133.04810758016839, -28.924059580399042, 44.095007747498506,
    19.638230760989519, -4.7786125538123647, -2.1370605016916637,
    -1.3339527900497614, -0.556296768794052, 1033.34765625, -652.941025700099,
    -940.81033876221875, 688.73281700535983, -191.61117458687659,
    95.054159320847774, -65.882349610875536, 4.9604352946160635,
    38.692064716680534, -1.762984967977451, 1.088137945966928,
    2.0299281587713764, 0.45421440970148508, -1320.388671875, -89.7027461585248,
    397.56493034873313, 779.06497518362437, -438.22404854078866,
    300.61921720066948, 20.829891011946017, 70.232329362894077,
    -23.410776454298027, -12.771625616608402, 1.8864941272538016,
    -2.5033354595732336, -0.0 },

  // Expression: cd
  //  Referenced by: '<S292>/cd[maxdef][maxdef]'

  { 0.0, -30.2, -51.268703904038766, 19.902104160113321, -2.2135943621178655,
    2.0333162567588938, 5.6709374225078513, 21.2817621083758, -26.8125,
    -38.221040062279606, 0.0, 0.0, -0.0, 7.0, 9.0, -14.982239485470789,
    -1.5491933384829668, 22.696089971622865, 17.675990071280303,
    -22.41634840426179, 14.480404998005064, 33.649420442167347,
    10.865004161512665, 21.069192030396437, 40.904797337487778, 0.0, -16.5,
    -10.738715006927039, 0.25980762113533157, -1.5811388300841898,
    7.9482702520737174, -0.0, -11.955385815606286, -16.382708109467131,
    -4.1419573328168173, -33.193135997427994, -33.056068091884619, 0.0,
    -64.922081265302026, 6.0, -17.452614417330143, 3.872983346207417,
    -8.6962635654630436, -2.5882849051060819, 7.3211487315857724,
    2.1827448316282871, -2.4697861749552334, 16.041731770701222,
    16.912721511506692, 11.687084953567938, 23.951396823359573,
    48.691560948976523, -3.5, -4.9805873147651978, -25.435273244060109,
    10.876580344942983, -2.9580398915498081, -0.42093645601206825,
    0.46536276172465707, -6.7919119811268924, -2.9661172536668206,
    3.3690947687096711, -7.3915615322315773, -0.0, -0.0, -2.3625,
    6.0999487702766819, -6.1481704595757591, 0.47062126492541739,
    2.6622359023948263, 0.9821850640281593, 0.87320127619581489,
    0.24218245962496965, -3.4326137146586273, -0.0, 4.1320085114855782, -0.0,
    0.0, -11.55, -9.45156237084642, -1.494423226950786, 15.940514420808382,
    -8.7309793265131486, 0.0, 0.80603194725767524, 0.12945196985754992,
    1.2534133084800878, -0.75335249254737546, -0.0, 4.9604352946160635, -0.0,
    -8.04375, -7.0939207027919338, -8.6882429988030374, 18.430546623150523,
    1.2348930874776167, -3.70467926243285, -2.1796421366247265,
    0.45308189450142466, 0.062670665424004388, 1.2919888658545733,
    -0.81825961504123, -0.0, 0.0, -5.02734375, 13.40625, -11.216473480722451,
    20.709786664084085, -2.6736219617835371, 5.9322345073336411,
    2.7460909717269022, -0.25068266169601755, 0.25068266169601755,
    0.12180987843510474, 0.530956950423596, -0.88149248398872548, 0.0,
    -9.49609375, -12.740346687426538, -0.0, 33.193135997427994,
    -22.55029534867559, 0.0, 5.2193791724028324, 0.0, -0.0, -0.1827148176526571,
    -0.0, -0.0, -0.0, 0.0, -0.0, -21.069192030396437, 33.056068091884619,
    -11.687084953567938, -14.783123064463155, -0.0, -2.0043185339772047,
    -1.63651923008246, -0.265478475211798, -0.0, -0.0579979473934679, 0.0, -0.0,
    0.0, -0.0, 0.0, -0.0, -15.842359886807964, 0.0, -0.0, -0.0,
    -0.88149248398872548, -0.0, -0.0579979473934679, -0.056776801212685635, 0.0,
    0.0, -0.0, 0.0, -48.691560948976523, -0.0, 0.0, -0.0, 0.0, -0.0, -0.0, -0.0,
    -0.056776801212685635 },

  // Expression: zeros(maxdef+1,maxdef+1)
  //  Referenced by: '<S319>/Unit Delay'

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0 },

  // Expression: 0
  //  Referenced by: '<S289>/bt'

  0.0,

  // Expression: 0
  //  Referenced by: '<S289>/bp'

  0.0,

  // Expression: 0
  //  Referenced by: '<S289>/br'

  0.0,

  // Expression: 0
  //  Referenced by: '<S289>/bpp'

  0.0,

  // Expression: 1
  //  Referenced by: '<S295>/Constant1'

  1.0,

  // Expression: 0
  //  Referenced by: '<S295>/Merge'

  0.0,

  // Expression: fm
  //  Referenced by: '<S290>/fm'

  { 0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0 },

  // Expression: 0
  //  Referenced by: '<S295>/Merge1'

  0.0,

  // Expression: fn
  //  Referenced by: '<S290>/fn'

  { 0.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0, 13.0 },

  // Expression: 0
  //  Referenced by: '<S296>/Constant1'

  0.0,

  // Expression: 0
  //  Referenced by: '<S290>/Unit Delay1'

  0.0,

  // Expression: 0
  //  Referenced by: '<S290>/Unit Delay3'

  0.0,

  // Expression: 0
  //  Referenced by: '<S290>/Unit Delay2'

  0.0,

  // Expression: 0
  //  Referenced by: '<S290>/Unit Delay4'

  0.0,

  // Expression: [0 0 0 0]
  //  Referenced by: '<S281>/bt,bp,br,bpp'

  { 0.0, 0.0, 0.0, 0.0 },

  // Expression: 0
  //  Referenced by: '<S281>/Unit Delay'

  0.0,

  // Expression: [0 0 0 0]
  //  Referenced by: '<S281>/Unit Delay2'

  { 0.0, 0.0, 0.0, 0.0 },

  // Expression: 6378.137
  //  Referenced by: '<S282>/r'

  6378.137,

  // Expression: 1
  //  Referenced by: '<S282>/ct'

  1.0,

  // Expression: 0
  //  Referenced by: '<S282>/st'

  0.0,

  // Expression: 0
  //  Referenced by: '<S282>/sa'

  0.0,

  // Expression: 0
  //  Referenced by: '<S282>/ca'

  0.0,

  // Expression: 6356.7523142
  //  Referenced by: '<S282>/b'

  6356.7523142,

  // Expression: 6378.137
  //  Referenced by: '<S282>/a'

  6378.137,

  // Expression: 2
  //  Referenced by: '<S327>/Gain'

  2.0,

  // Expression: 1
  //  Referenced by: '<S329>/Constant'

  1.0,

  // Expression: (1:(maxdef-1))
  //  Referenced by: '<S330>/sp[11]'

  { 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0 },

  // Expression: (1:(maxdef-1))
  //  Referenced by: '<S330>/cp[11]'

  { 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0 },

  // Expression: maxdef-1
  //  Referenced by: '<S330>/For Iterator'

  11.0,

  // Expression: [1:maxdef-1]
  //  Referenced by: '<S330>/Constant'

  { 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0 },

  // Expression: 0
  //  Referenced by: '<S330>/Unit Delay1'

  0.0,

  // Expression: 1
  //  Referenced by: '<S330>/cp[m-1] sp[m-1]'

  1.0,

  // Expression: [1:maxdef-1]
  //  Referenced by: '<S330>/Constant1'

  { 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0 },

  // Expression: [0 0 (1:(maxdef-1))]
  //  Referenced by: '<S283>/sp[13]'

  { 0.0, 0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0 },

  // Expression: [1 1 (1:(maxdef-1))]
  //  Referenced by: '<S283>/cp[13]'

  { 1.0, 1.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0 },

  // Expression: 1
  //  Referenced by: '<S283>/Gain'

  1.0,

  // Expression: 1
  //  Referenced by: '<S283>/Gain1'

  1.0,

  // Expression: 1
  //  Referenced by: '<S283>/cp[1]'

  1.0,

  // Expression: 0
  //  Referenced by: '<S283>/sp[1]'

  0.0,

  // Expression: 1/2
  //  Referenced by: '<S370>/1//2rhoV^2'

  0.5,

  // Expression: 0
  //  Referenced by: '<S538>/pgw'

  0.0,

  // Expression: 1/3
  //  Referenced by: '<S538>/Constant1'

  0.33333333333333331,

  // Expression: 1/6
  //  Referenced by: '<S538>/Constant2'

  0.16666666666666666,

  // Expression: pi/4
  //  Referenced by: '<S538>/Constant3'

  0.78539816339744828,

  // Expression: 0
  //  Referenced by: '<S538>/pgw_p'

  0.0,

  // Expression: 0
  //  Referenced by: '<S539>/qgw'

  0.0,

  // Expression: 0
  //  Referenced by: '<S539>/qgw_p'

  0.0,

  // Expression: pi/4
  //  Referenced by: '<S539>/pi//4'

  0.78539816339744828,

  // Expression: 0
  //  Referenced by: '<S540>/rgw'

  0.0,

  // Expression: 0
  //  Referenced by: '<S540>/rgw_p'

  0.0,

  // Expression: pi/3
  //  Referenced by: '<S540>/pi//3'

  1.0471975511965976,

  // Expression: 0
  //  Referenced by: '<S541>/ugw'

  0.0,

  // Expression: 2/pi
  //  Referenced by: '<S541>/(2//pi)'

  0.63661977236758138,

  // Expression: 0
  //  Referenced by: '<S541>/ug_p'

  0.0,

  // Expression: 0
  //  Referenced by: '<S542>/vgw'

  0.0,

  // Expression: 1/pi
  //  Referenced by: '<S542>/(1//pi)'

  0.31830988618379069,

  // Expression: 0
  //  Referenced by: '<S542>/vg_p1'

  0.0,

  // Expression: 0
  //  Referenced by: '<S542>/vgw_p2'

  0.0,

  // Expression: sqrt(3)
  //  Referenced by: '<S542>/sqrt(3)'

  1.7320508075688772,

  // Expression: 0
  //  Referenced by: '<S543>/wgw'

  0.0,

  // Expression: 1/pi
  //  Referenced by: '<S543>/1//pi'

  0.31830988618379069,

  // Expression: 3
  //  Referenced by: '<S543>/Constant'

  3.0,

  // Expression: 0
  //  Referenced by: '<S543>/wg_p1'

  0.0,

  // Expression: 0
  //  Referenced by: '<S543>/wg_p2'

  0.0,

  // Expression: 1
  //  Referenced by: '<S548>/Gain'

  1.0,

  // Expression: 1
  //  Referenced by: '<S556>/Gain'

  1.0,

  // Expression: [1 1 0.1]
  //  Referenced by: '<S9>/Reduce Z Wind'

  { 1.0, 1.0, 0.1 },

  // Expression: 0
  //  Referenced by: '<S406>/Constant'

  0.0,

  // Expression: 0
  //  Referenced by: '<S568>/Constant'

  0.0,

  // Expression: 1E6
  //  Referenced by: '<S7>/Gain_clock'

  1.0E+6,

  // Expression: 0
  //  Referenced by: '<S252>/Integrator, Second-Order Limited'

  0.0,

  // Expression: 0
  //  Referenced by: '<S252>/Integrator, Second-Order Limited'

  0.0,

  // Expression: dtype_a
  //  Referenced by: '<S248>/Constant'

  1.0,

  // Expression: 1.0
  //  Referenced by: '<S149>/Saturation'

  1.0,

  // Expression: 0
  //  Referenced by: '<S149>/Saturation'

  0.0,

  // Expression: 8000
  //  Referenced by: '<S149>/MaxRPM'

  8000.0,

  // Expression: 0
  //  Referenced by: '<S149>/Min RPM'

  0.0,

  // Expression: 2
  //  Referenced by: '<S149>/Prop Diameter (in)1'

  2.0,

  // Expression: 17
  //  Referenced by: '<S149>/Prop Diameter (in)'

  17.0,

  // Expression: 4
  //  Referenced by: '<S149>/Prop Diameter (in)2'

  4.0,

  // Expression: 2.83e-12
  //  Referenced by: '<S149>/To Constant'

  2.83E-12,

  // Expression: pi
  //  Referenced by: '<S346>/phi theta psi'

  3.1415926535897931,

  // Expression: -pi
  //  Referenced by: '<S346>/phi theta psi'

  -3.1415926535897931,

  // Expression: 0
  //  Referenced by: '<S369>/Merge'

  0.0,

  // Expression: 0
  //  Referenced by: '<S525>/Merge'

  0.0,

  // Expression: -1
  //  Referenced by: '<S9>/Gain1'

  -1.0,

  // Expression: inf
  //  Referenced by: '<S521>/Zero Bound'

  0.0,

  // Expression: 0.001
  //  Referenced by: '<S521>/Zero Bound'

  0.001,

  // Expression: max_height_low
  //  Referenced by: '<S562>/Limit Function 10ft to 1000ft'

  1000.0,

  // Expression: 10
  //  Referenced by: '<S562>/Limit Function 10ft to 1000ft'

  10.0,

  // Expression: max_height_low
  //  Referenced by: '<S545>/Limit Height h<1000ft'

  1000.0,

  // Expression: 0
  //  Referenced by: '<S545>/Limit Height h<1000ft'

  0.0,

  // Expression: 0.1
  //  Referenced by: '<S545>/sigma_wg '

  0.1,

  // Expression: h_vec
  //  Referenced by: '<S544>/PreLook-Up Index Search  (altitude)'

  { 500.0, 1750.0, 3750.0, 7500.0, 15000.0, 25000.0, 35000.0, 45000.0, 55000.0,
    65000.0, 75000.0, 80000.0 },

  // Expression: [1:7]
  //  Referenced by: '<S544>/PreLook-Up Index Search  (prob of exceed)'

  { 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0 },

  // Expression: sigma_vec'
  //  Referenced by: '<S544>/Medium//High Altitude Intensity'

  { 3.2, 2.2, 1.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 4.2, 3.6, 3.3,
    1.6, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 6.6, 6.9, 7.4, 6.7, 4.6, 2.7,
    0.4, 0.0, 0.0, 0.0, 0.0, 0.0, 8.6, 9.6, 10.6, 10.1, 8.0, 6.6, 5.0, 4.2, 2.7,
    0.0, 0.0, 0.0, 11.8, 13.0, 16.0, 15.1, 11.6, 9.7, 8.1, 8.2, 7.9, 4.9, 3.2,
    2.1, 15.6, 17.6, 23.0, 23.6, 22.1, 20.0, 16.0, 15.1, 12.1, 7.9, 6.2, 5.1,
    18.7, 21.5, 28.4, 30.2, 30.7, 31.0, 25.2, 23.1, 17.5, 10.7, 8.4, 7.2 },

  // Expression: 0
  //  Referenced by: '<S537>/White Noise'

  0.0,

  // Computed Parameter: WhiteNoise_StdDev
  //  Referenced by: '<S537>/White Noise'

  1.0,

  // Expression: 1
  //  Referenced by: '<S534>/Lv'

  1.0,

  // Expression: 1
  //  Referenced by: '<S534>/Lw'

  1.0,

  // Expression: 0
  //  Referenced by: '<S523>/Wdeg1'

  0.0,

  // Expression: -1
  //  Referenced by: '<S523>/ '

  -1.0,

  // Expression: [ 0 0 0]
  //  Referenced by: '<S9>/Constant'

  { 0.0, 0.0, 0.0 },

  // Expression: 0.3
  //  Referenced by: '<S9>/Switch'

  0.3,

  // Computed Parameter: TransferFcn_A
  //  Referenced by: '<S366>/Transfer Fcn'

  -100.0,

  // Computed Parameter: TransferFcn_C
  //  Referenced by: '<S366>/Transfer Fcn'

  100.0,

  // Expression: -1
  //  Referenced by: '<S366>/Gain'

  -1.0,

  // Expression: 0
  //  Referenced by: '<S399>/Limit  altitude  to Stratosphere'

  0.0,

  // Expression: 0
  //  Referenced by: '<S6>/Constant1'

  0.0,

  // Expression: 0
  //  Referenced by: '<S6>/Constant2'

  0.0,

  // Expression: 0
  //  Referenced by: '<S6>/Constant3'

  0.0,

  // Expression: 0
  //  Referenced by: '<S6>/Constant4'

  0.0,

  // Expression: 0
  //  Referenced by: '<S6>/Constant5'

  0.0,

  // Expression: [ 0 0 0]
  //  Referenced by: '<S342>/Constant'

  { 0.0, 0.0, 0.0 },

  // Expression: 0
  //  Referenced by: '<S342>/Constant1'

  0.0,

  // Computed Parameter: TransferFcn_A_p
  //  Referenced by: '<S384>/Transfer Fcn'

  -10.0,

  // Computed Parameter: TransferFcn_C_m
  //  Referenced by: '<S384>/Transfer Fcn'

  -100.0,

  // Computed Parameter: TransferFcn_D
  //  Referenced by: '<S384>/Transfer Fcn'

  10.0,

  // Expression: inf
  //  Referenced by: '<S398>/Saturation'

  0.0,

  // Expression: 0.1
  //  Referenced by: '<S398>/Saturation'

  0.1,

  // Expression: -1
  //  Referenced by: '<S394>/Gain'

  -1.0,

  // Expression: -1
  //  Referenced by: '<S384>/Y-down'

  -1.0,

  // Expression: -1
  //  Referenced by: '<S342>/Gain'

  -1.0,

  // Expression: 0
  //  Referenced by: '<S342>/Saturation'

  0.0,

  // Expression: -inf
  //  Referenced by: '<S342>/Saturation'

  0.0,

  // Expression: [0 0 uav.geometry.mass*env.ISA_g]
  //  Referenced by: '<S342>/Gravitational Force'

  { 0.0, 0.0, 80.067989074689009 },

  // Expression: .5
  //  Referenced by: '<S389>/Cmq1'

  0.5,

  // Expression: inf
  //  Referenced by: '<S389>/Saturation'

  0.0,

  // Expression: 0.1
  //  Referenced by: '<S389>/Saturation'

  0.1,

  // Expression: .5
  //  Referenced by: '<S390>/Cmq3'

  0.5,

  // Expression: inf
  //  Referenced by: '<S390>/Saturation'

  0.0,

  // Expression: 0.1
  //  Referenced by: '<S390>/Saturation'

  0.1,

  // Expression: .5
  //  Referenced by: '<S392>/Cmq1'

  0.5,

  // Expression: inf
  //  Referenced by: '<S392>/Saturation'

  0.0,

  // Expression: 0.1
  //  Referenced by: '<S392>/Saturation'

  0.1,

  // Expression: .5
  //  Referenced by: '<S393>/Cmq3'

  0.5,

  // Expression: inf
  //  Referenced by: '<S393>/Saturation'

  0.0,

  // Expression: 0.1
  //  Referenced by: '<S393>/Saturation'

  0.1,

  // Expression: 1
  //  Referenced by: '<S8>/Gain4'

  1.0,

  // Expression: [0 0 9.8]
  //  Referenced by: '<S344>/Gain'

  { 0.0, 0.0, 9.8 },

  // Expression: 1
  //  Referenced by: '<S8>/Gain6'

  1.0,

  // Expression: 1
  //  Referenced by: '<S8>/Gain2'

  1.0,

  // Expression: 1
  //  Referenced by: '<S8>/Gain'

  1.0,

  // Expression: 1
  //  Referenced by: '<S8>/Gain3'

  1.0,

  // Expression: [1 0 0 0]
  //  Referenced by: '<S410>/Merge'

  { 1.0, 0.0, 0.0, 0.0 },

  // Expression: [1 0 0 0]
  //  Referenced by: '<S409>/Merge'

  { 1.0, 0.0, 0.0, 0.0 },

  // Expression: 1
  //  Referenced by: '<S8>/Gain8'

  1.0,

  // Expression: 1
  //  Referenced by: '<S246>/Zero-Order Hold1'

  1.0,

  // Expression: 1
  //  Referenced by: '<S45>/Constant2'

  1.0,

  // Expression: R
  //  Referenced by: '<S45>/Constant1'

  6.378137E+6,

  // Expression: 1
  //  Referenced by: '<S48>/Constant'

  1.0,

  // Expression: 1
  //  Referenced by: '<S50>/Constant'

  1.0,

  // Expression: F
  //  Referenced by: '<S49>/Constant'

  0.0033528106647474805,

  // Expression: 1
  //  Referenced by: '<S49>/f'

  1.0,

  // Expression: 1
  //  Referenced by: '<S45>/Constant'

  1.0,

  // Expression: 1
  //  Referenced by: '<S45>/Constant3'

  1.0,

  // Expression: 360
  //  Referenced by: '<S36>/Constant2'

  360.0,

  // Expression: 180
  //  Referenced by: '<S29>/Constant'

  180.0,

  // Expression: 0
  //  Referenced by: '<S29>/Constant1'

  0.0,

  // Expression: 360
  //  Referenced by: '<S34>/Constant2'

  360.0,

  // Expression: 100000
  //  Referenced by: '<S3>/Saturation_1'

  100000.0,

  // Expression: 0
  //  Referenced by: '<S3>/Saturation_1'

  0.0,

  // Expression: juliandate(year,month,day)
  //  Referenced by: '<S27>/Julian Date'

  2.4532885E+6,

  // Expression: 1
  //  Referenced by: '<S246>/Zero-Order Hold2'

  1.0,

  // Expression: 1
  //  Referenced by: '<S246>/Zero-Order Hold'

  1.0,

  // Expression: [0 0 0]
  //  Referenced by: '<S226>/center of gravity'

  { 0.0, 0.0, 0.0 },

  // Expression: 1
  //  Referenced by: '<S246>/Zero-Order Hold4'

  1.0,

  // Expression: [1 -1 1]
  //  Referenced by: '<S246>/Gain'

  { 1.0, -1.0, 1.0 },

  // Expression: zeros(3)
  //  Referenced by: '<S348>/Constant2'

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

  // Expression: 1
  //  Referenced by: '<S8>/Gain7'

  1.0,

  // Expression: 1
  //  Referenced by: '<S246>/Zero-Order Hold3'

  1.0,

  // Expression: 0.5
  //  Referenced by: '<S248>/Switch'

  0.5,

  // Expression: a_sath
  //  Referenced by: '<S246>/Saturation'

  { 160.0, 160.0, 160.0 },

  // Expression: a_satl
  //  Referenced by: '<S246>/Saturation'

  { -160.0, -160.0, -160.0 },

  // Expression: -[0.1,0.1,0.2]
  //  Referenced by: '<S226>/Uniform Random Number5'

  { -0.1, -0.1, -0.2 },

  // Expression: [0.1,0.1,0.2]
  //  Referenced by: '<S226>/Uniform Random Number5'

  { 0.1, 0.1, 0.2 },

  // Expression: [12233,645554,678766]
  //  Referenced by: '<S226>/Uniform Random Number5'

  { 12233.0, 645554.0, 678766.0 },

  // Expression: 5
  //  Referenced by: '<S226>/Gain10'

  5.0,

  // Expression: 0
  //  Referenced by: '<S263>/Integrator, Second-Order Limited'

  0.0,

  // Expression: 0
  //  Referenced by: '<S263>/Integrator, Second-Order Limited'

  0.0,

  // Expression: dtype_g
  //  Referenced by: '<S261>/Constant'

  1.0,

  // Expression: 1
  //  Referenced by: '<S247>/Zero-Order Hold'

  1.0,

  // Expression: 1
  //  Referenced by: '<S247>/Zero-Order Hold1'

  1.0,

  // Expression: 0.5
  //  Referenced by: '<S261>/Switch'

  0.5,

  // Expression: g_sath
  //  Referenced by: '<S247>/Saturation'

  { 4.36, 4.36, 4.36 },

  // Expression: g_satl
  //  Referenced by: '<S247>/Saturation'

  { -4.36, -4.36, -4.36 },

  // Expression: -[0.01,0.01,0.01]
  //  Referenced by: '<S226>/Uniform Random Number1'

  { -0.01, -0.01, -0.01 },

  // Expression: [0.01,0.01,0.01]
  //  Referenced by: '<S226>/Uniform Random Number1'

  { 0.01, 0.01, 0.01 },

  // Expression: [3243,44556,2334343]
  //  Referenced by: '<S226>/Uniform Random Number1'

  { 3243.0, 44556.0, 2.334343E+6 },

  // Expression: 5
  //  Referenced by: '<S226>/Gain6'

  5.0,

  // Expression: epoch
  //  Referenced by: '<S273>/epoch'

  2015.0,

  // Expression: dyear
  //  Referenced by: '<S239>/Decimal Year'

  2017.8383561643836,

  // Expression: -1000
  //  Referenced by: '<S287>/otime'

  -1000.0,

  // Expression: 180
  //  Referenced by: '<S269>/Constant'

  180.0,

  // Expression: 360
  //  Referenced by: '<S278>/Constant2'

  360.0,

  // Expression: 0
  //  Referenced by: '<S269>/Constant1'

  0.0,

  // Expression: 360
  //  Referenced by: '<S276>/Constant2'

  360.0,

  // Expression: -1000
  //  Referenced by: '<S286>/olon'

  -1000.0,

  // Expression: -1000
  //  Referenced by: '<S285>/olat'

  -1000.0,

  // Expression: 0.001
  //  Referenced by: '<S239>/Gain'

  0.001,

  // Expression: -1000
  //  Referenced by: '<S285>/oalt'

  -1000.0,

  // Expression: 6371.2
  //  Referenced by: '<S273>/re'

  6371.2,

  // Expression: 1
  //  Referenced by: '<S226>/Gain_Mag'

  1.0,

  // Expression: 1E-5
  //  Referenced by: '<S226>/nT2Gauss'

  1.0E-5,

  // Expression: -[0.01,0.01,0.01]
  //  Referenced by: '<S226>/Uniform Random Number7'

  { -0.01, -0.01, -0.01 },

  // Expression: [0.01,0.01,0.01]
  //  Referenced by: '<S226>/Uniform Random Number7'

  { 0.01, 0.01, 0.01 },

  // Expression: [45465,454534,1234232]
  //  Referenced by: '<S226>/Uniform Random Number7'

  { 45465.0, 454534.0, 1.234232E+6 },

  // Expression: 2
  //  Referenced by: '<S226>/Gain11'

  2.0,

  // Expression: T0
  //  Referenced by: '<S236>/Sea Level  Temperature'

  288.15,

  // Expression: [1,1,1]
  //  Referenced by: '<S28>/Constant_[1 1 1]'

  { 1.0, 1.0, 1.0 },

  // Expression: [-1,-1,-0.5]
  //  Referenced by: '<S28>/Uniform Random Number'

  { -1.0, -1.0, -0.5 },

  // Expression: [1,1,0.5]
  //  Referenced by: '<S28>/Uniform Random Number'

  { 1.0, 1.0, 0.5 },

  // Expression: [564565,6846798,46545]
  //  Referenced by: '<S28>/Uniform Random Number'

  { 564565.0, 6.846798E+6, 46545.0 },

  // Expression: 1
  //  Referenced by: '<S8>/Gain5'

  1.0,

  // Expression: -1
  //  Referenced by: '<S28>/Gain_-1'

  -1.0,

  // Expression: 10000
  //  Referenced by: '<S28>/Saturation_2'

  10000.0,

  // Expression: 0
  //  Referenced by: '<S28>/Saturation_2'

  0.0,

  // Expression: 5
  //  Referenced by: '<S28>/Constant_V'

  5.0,

  // Expression: max_height_low
  //  Referenced by: '<S143>/Limit Function 10ft to 1000ft'

  1000.0,

  // Expression: 10
  //  Referenced by: '<S143>/Limit Function 10ft to 1000ft'

  10.0,

  // Expression: max_height_low
  //  Referenced by: '<S126>/Limit Height h<1000ft'

  1000.0,

  // Expression: 0
  //  Referenced by: '<S126>/Limit Height h<1000ft'

  0.0,

  // Expression: 0.1
  //  Referenced by: '<S126>/sigma_wg '

  0.1,

  // Expression: h_vec
  //  Referenced by: '<S125>/PreLook-Up Index Search  (altitude)'

  { 500.0, 1750.0, 3750.0, 7500.0, 15000.0, 25000.0, 35000.0, 45000.0, 55000.0,
    65000.0, 75000.0, 80000.0 },

  // Expression: [1:7]
  //  Referenced by: '<S125>/PreLook-Up Index Search  (prob of exceed)'

  { 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0 },

  // Expression: sigma_vec'
  //  Referenced by: '<S125>/Medium//High Altitude Intensity'

  { 3.2, 2.2, 1.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 4.2, 3.6, 3.3,
    1.6, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 6.6, 6.9, 7.4, 6.7, 4.6, 2.7,
    0.4, 0.0, 0.0, 0.0, 0.0, 0.0, 8.6, 9.6, 10.6, 10.1, 8.0, 6.6, 5.0, 4.2, 2.7,
    0.0, 0.0, 0.0, 11.8, 13.0, 16.0, 15.1, 11.6, 9.7, 8.1, 8.2, 7.9, 4.9, 3.2,
    2.1, 15.6, 17.6, 23.0, 23.6, 22.1, 20.0, 16.0, 15.1, 12.1, 7.9, 6.2, 5.1,
    18.7, 21.5, 28.4, 30.2, 30.7, 31.0, 25.2, 23.1, 17.5, 10.7, 8.4, 7.2 },

  // Expression: 0
  //  Referenced by: '<S118>/White Noise'

  0.0,

  // Computed Parameter: WhiteNoise_StdDev_a
  //  Referenced by: '<S118>/White Noise'

  1.0,

  // Expression: 1
  //  Referenced by: '<S115>/Lv'

  1.0,

  // Expression: 1
  //  Referenced by: '<S115>/Lw'

  1.0,

  // Expression: eye(3)
  //  Referenced by: '<S28>/Constant_DCM'

  { 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0 },

  // Expression: max_height_low
  //  Referenced by: '<S104>/Limit Function 10ft to 1000ft'

  1000.0,

  // Expression: 10
  //  Referenced by: '<S104>/Limit Function 10ft to 1000ft'

  10.0,

  // Expression: max_height_low
  //  Referenced by: '<S87>/Limit Height h<1000ft'

  1000.0,

  // Expression: 0
  //  Referenced by: '<S87>/Limit Height h<1000ft'

  0.0,

  // Expression: 0.1
  //  Referenced by: '<S87>/sigma_wg '

  0.1,

  // Expression: h_vec
  //  Referenced by: '<S86>/PreLook-Up Index Search  (altitude)'

  { 500.0, 1750.0, 3750.0, 7500.0, 15000.0, 25000.0, 35000.0, 45000.0, 55000.0,
    65000.0, 75000.0, 80000.0 },

  // Expression: [1:7]
  //  Referenced by: '<S86>/PreLook-Up Index Search  (prob of exceed)'

  { 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0 },

  // Expression: sigma_vec'
  //  Referenced by: '<S86>/Medium//High Altitude Intensity'

  { 3.2, 2.2, 1.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 4.2, 3.6, 3.3,
    1.6, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 6.6, 6.9, 7.4, 6.7, 4.6, 2.7,
    0.4, 0.0, 0.0, 0.0, 0.0, 0.0, 8.6, 9.6, 10.6, 10.1, 8.0, 6.6, 5.0, 4.2, 2.7,
    0.0, 0.0, 0.0, 11.8, 13.0, 16.0, 15.1, 11.6, 9.7, 8.1, 8.2, 7.9, 4.9, 3.2,
    2.1, 15.6, 17.6, 23.0, 23.6, 22.1, 20.0, 16.0, 15.1, 12.1, 7.9, 6.2, 5.1,
    18.7, 21.5, 28.4, 30.2, 30.7, 31.0, 25.2, 23.1, 17.5, 10.7, 8.4, 7.2 },

  // Expression: 0
  //  Referenced by: '<S79>/White Noise'

  0.0,

  // Computed Parameter: WhiteNoise_StdDev_h
  //  Referenced by: '<S79>/White Noise'

  1.0,

  // Expression: 1
  //  Referenced by: '<S76>/Lv'

  1.0,

  // Expression: 1
  //  Referenced by: '<S76>/Lw'

  1.0,

  // Expression: inf
  //  Referenced by: '<S66>/3ft-->inf'

  0.0,

  // Expression: 3
  //  Referenced by: '<S66>/3ft-->inf'

  3.0,

  // Expression: 1/z0
  //  Referenced by: '<S66>/h//z0'

  6.666666666666667,

  // Expression: 20/z0
  //  Referenced by: '<S66>/ref_height//z0'

  133.33333333333334,

  // Expression: 0
  //  Referenced by: '<S66>/Wdeg1'

  0.0,

  // Expression: T0
  //  Referenced by: '<S25>/Sea Level  Temperature'

  288.15,

  // Expression: h_trop
  //  Referenced by: '<S25>/Limit  altitude  to troposhere'

  11000.0,

  // Expression: h0
  //  Referenced by: '<S25>/Limit  altitude  to troposhere'

  0.0,

  // Expression: L
  //  Referenced by: '<S25>/Lapse Rate'

  0.0065,

  // Expression: 1/T0
  //  Referenced by: '<S25>/1//T0'

  0.00347041471455839,

  // Expression: g/(L*R)
  //  Referenced by: '<S25>/Constant'

  5.2558756014667134,

  // Expression: rho0
  //  Referenced by: '<S25>/rho0'

  1.225,

  // Expression: h_trop
  //  Referenced by: '<S25>/Altitude of Troposphere'

  11000.0,

  // Expression: 0
  //  Referenced by: '<S25>/Limit  altitude  to Stratosphere'

  0.0,

  // Expression: h_trop-h_strat
  //  Referenced by: '<S25>/Limit  altitude  to Stratosphere'

  -9000.0,

  // Expression: g/R
  //  Referenced by: '<S25>/g//R'

  0.034163191409533639,

  // Expression: 1/2
  //  Referenced by: '<S228>/1//2rhoV^2'

  0.5,

  // Expression: -2
  //  Referenced by: '<S226>/Uniform Random Number'

  -2.0,

  // Expression: 2
  //  Referenced by: '<S226>/Uniform Random Number'

  2.0,

  // Expression: 15634
  //  Referenced by: '<S226>/Uniform Random Number'

  15634.0,

  // Expression: 0.2
  //  Referenced by: '<S226>/Gain5'

  0.2,

  // Expression: 0.3
  //  Referenced by: '<S234>/Constant2'

  0.3,

  // Expression: h_trop
  //  Referenced by: '<S236>/Limit  altitude  to troposhere'

  11000.0,

  // Expression: h0
  //  Referenced by: '<S236>/Limit  altitude  to troposhere'

  0.0,

  // Expression: L
  //  Referenced by: '<S236>/Lapse Rate'

  0.0065,

  // Expression: 1/T0
  //  Referenced by: '<S236>/1//T0'

  0.00347041471455839,

  // Expression: g/(L*R)
  //  Referenced by: '<S236>/Constant'

  5.2558756014667134,

  // Expression: P0
  //  Referenced by: '<S236>/P0'

  101325.0,

  // Expression: h_trop
  //  Referenced by: '<S236>/Altitude of Troposphere'

  11000.0,

  // Expression: 0
  //  Referenced by: '<S236>/Limit  altitude  to Stratosphere'

  0.0,

  // Expression: h_trop-h_strat
  //  Referenced by: '<S236>/Limit  altitude  to Stratosphere'

  -9000.0,

  // Expression: g/R
  //  Referenced by: '<S236>/g//R'

  0.034163191409533639,

  // Expression: 0.01
  //  Referenced by: '<S226>/Gain'

  0.01,

  // Expression: -1
  //  Referenced by: '<S226>/Uniform Random Number4'

  -1.0,

  // Expression: 1
  //  Referenced by: '<S226>/Uniform Random Number4'

  1.0,

  // Expression: 25634
  //  Referenced by: '<S226>/Uniform Random Number4'

  25634.0,

  // Expression: 0.01
  //  Referenced by: '<S226>/Gain9'

  0.01,

  // Expression: 0.5
  //  Referenced by: '<S235>/Constant'

  0.5,

  // Expression: 0.7
  //  Referenced by: '<S235>/Gain2'

  0.7,

  // Expression: 0.3
  //  Referenced by: '<S235>/Constant2'

  0.3,

  // Expression: 0.01
  //  Referenced by: '<S226>/Gain1'

  0.01,

  // Expression: 10
  //  Referenced by: '<S3>/Constant1'

  10.0,

  // Expression: 8191
  //  Referenced by: '<S153>/Constant'

  8191.0,

  // Expression: [-1,-1,-2]
  //  Referenced by: '<S194>/Uniform Random Number5'

  { -1.0, -1.0, -2.0 },

  // Expression: [1,1,2]
  //  Referenced by: '<S194>/Uniform Random Number5'

  { 1.0, 1.0, 2.0 },

  // Expression: [1452,787,69]
  //  Referenced by: '<S194>/Uniform Random Number5'

  { 1452.0, 787.0, 69.0 },

  // Expression: 0.5
  //  Referenced by: '<S194>/BiasGain2'

  0.5,

  // Expression: 1
  //  Referenced by: '<S216>/Constant2'

  1.0,

  // Expression: R
  //  Referenced by: '<S216>/Constant1'

  6.378137E+6,

  // Expression: 1
  //  Referenced by: '<S219>/Constant'

  1.0,

  // Expression: 1
  //  Referenced by: '<S221>/Constant'

  1.0,

  // Expression: F
  //  Referenced by: '<S220>/Constant'

  0.0033528106647474805,

  // Expression: 1
  //  Referenced by: '<S220>/f'

  1.0,

  // Expression: 1
  //  Referenced by: '<S216>/Constant'

  1.0,

  // Expression: 1
  //  Referenced by: '<S216>/Constant3'

  1.0,

  // Expression: 360
  //  Referenced by: '<S207>/Constant2'

  360.0,

  // Expression: 1E7
  //  Referenced by: '<S152>/latScale'

  1.0E+7,

  // Expression: 180
  //  Referenced by: '<S200>/Constant'

  180.0,

  // Expression: 0
  //  Referenced by: '<S200>/Constant1'

  0.0,

  // Expression: 360
  //  Referenced by: '<S205>/Constant2'

  360.0,

  // Expression: 1E7
  //  Referenced by: '<S152>/lonScale'

  1.0E+7,

  // Expression: 100000
  //  Referenced by: '<S194>/Saturation'

  100000.0,

  // Expression: 0
  //  Referenced by: '<S194>/Saturation'

  0.0,

  // Expression: 1E3
  //  Referenced by: '<S152>/altScale'

  1000.0,

  // Expression: 100
  //  Referenced by: '<S152>/Gain6'

  100.0,

  // Expression: 100
  //  Referenced by: '<S152>/Gain8'

  100.0,

  // Computed Parameter: TransferFcn4_A
  //  Referenced by: '<S196>/Transfer Fcn4'

  -20.0,

  // Computed Parameter: TransferFcn4_C
  //  Referenced by: '<S196>/Transfer Fcn4'

  20.0,

  // Computed Parameter: TransferFcn1_A
  //  Referenced by: '<S196>/Transfer Fcn1'

  -20.0,

  // Computed Parameter: TransferFcn1_C
  //  Referenced by: '<S196>/Transfer Fcn1'

  20.0,

  // Computed Parameter: TransferFcn2_A
  //  Referenced by: '<S196>/Transfer Fcn2'

  -20.0,

  // Computed Parameter: TransferFcn2_C
  //  Referenced by: '<S196>/Transfer Fcn2'

  20.0,

  // Expression: 1E2
  //  Referenced by: '<S152>/VelScale'

  100.0,

  // Expression: 1E2
  //  Referenced by: '<S152>/VeScale'

  100.0,

  // Expression: 1E2
  //  Referenced by: '<S152>/AngleScale'

  100.0,

  // Expression: 1
  //  Referenced by: '<S7>/CopterID'

  1.0,

  // Expression: [1 0 0 0]
  //  Referenced by: '<S151>/Merge'

  { 1.0, 0.0, 0.0, 0.0 },

  // Expression: 1
  //  Referenced by: '<S1>/Gain'

  1.0,

  // Expression: 1000
  //  Referenced by: '<S1>/Gain1'

  1000.0,

  // Expression: 1
  //  Referenced by: '<S1>/Gain2'

  1.0,

  // Expression: 180/pi
  //  Referenced by: '<S1>/Gain6'

  57.295779513082323,

  // Expression: 1
  //  Referenced by: '<S1>/Gain3'

  1.0,

  // Expression: 180/pi
  //  Referenced by: '<S1>/Gain7'

  57.295779513082323,

  // Expression: -1
  //  Referenced by: '<S1>/Gain10'

  -1.0,

  // Expression: 1
  //  Referenced by: '<S1>/Gain4'

  1.0,

  // Expression: 180/pi
  //  Referenced by: '<S1>/Gain8'

  57.295779513082323,

  // Expression: 1
  //  Referenced by: '<S1>/Gain5'

  1.0,

  // Expression: 180/pi
  //  Referenced by: '<S1>/Gain9'

  57.295779513082323,

  // Expression: -1
  //  Referenced by: '<Root>/Gain4'

  -1.0,

  // Expression: 0
  //  Referenced by: '<Root>/flap'

  0.0,

  // Expression: 1
  //  Referenced by: '<Root>/Constant1'

  1.0,

  // Expression: 0.5
  //  Referenced by: '<Root>/Gain2'

  0.5,

  // Expression: 0
  //  Referenced by: '<S16>/White Noise'

  0.0,

  // Computed Parameter: WhiteNoise_StdDev_k
  //  Referenced by: '<S16>/White Noise'

  1.0,

  // Expression: 1
  //  Referenced by: '<S15>/Gain'

  1.0,

  // Expression: 1.0
  //  Referenced by: '<S17>/2'

  1.0,

  // Expression: [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
  //  Referenced by: '<S4>/Constant'

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0 },

  // Expression: 2
  //  Referenced by: '<S15>/Constant'

  2.0,

  // Expression: [-1,-1,-2]
  //  Referenced by: '<S152>/Uniform Random Number4'

  { -1.0, -1.0, -2.0 },

  // Expression: [1,1,2]
  //  Referenced by: '<S152>/Uniform Random Number4'

  { 1.0, 1.0, 2.0 },

  // Expression: [5445,45433,33433]
  //  Referenced by: '<S152>/Uniform Random Number4'

  { 5445.0, 45433.0, 33433.0 },

  // Expression: 0.1
  //  Referenced by: '<S152>/BiasGain1'

  0.1,

  // Expression: [0 0 0]
  //  Referenced by: '<S8>/Constant'

  { 0.0, 0.0, 0.0 },

  // Expression: 0
  //  Referenced by: '<S512>/Integrator, Second-Order Limited'

  0.0,

  // Expression: 0
  //  Referenced by: '<S512>/Integrator, Second-Order Limited'

  0.0,

  // Expression: 1
  //  Referenced by: '<S345>/Zero-Order Hold1'

  1.0,

  // Expression: 1
  //  Referenced by: '<S345>/Zero-Order Hold2'

  1.0,

  // Expression: 1
  //  Referenced by: '<S345>/Zero-Order Hold'

  1.0,

  // Expression: 1
  //  Referenced by: '<S345>/Zero-Order Hold4'

  1.0,

  // Expression: [1 -1 1]
  //  Referenced by: '<S345>/Gain'

  { 1.0, -1.0, 1.0 },

  // Expression: 1
  //  Referenced by: '<S345>/Zero-Order Hold3'

  1.0,

  // Computed Parameter: Constant1_Value_kv
  //  Referenced by: '<S299>/Constant1'

  1,

  // Computed Parameter: Constant_Value_mb
  //  Referenced by: '<S300>/Constant'

  1,

  // Computed Parameter: Constant_Value_ce
  //  Referenced by: '<S298>/Constant'

  1,

  // Computed Parameter: Constant_Value_e3
  //  Referenced by: '<S309>/Constant'

  1,

  // Computed Parameter: Gain_Gain_ow
  //  Referenced by: '<S309>/Gain'

  13,

  // Computed Parameter: Constant_Value_p
  //  Referenced by: '<S312>/Constant'

  1,

  // Computed Parameter: Gain_Gain_kt
  //  Referenced by: '<S311>/Gain'

  13,

  // Computed Parameter: Constant_Value_b4
  //  Referenced by: '<S315>/Constant'

  1,

  // Computed Parameter: Constant1_Value_e
  //  Referenced by: '<S315>/Constant1'

  1,

  // Computed Parameter: Constant1_Value_a
  //  Referenced by: '<S316>/Constant1'

  2,

  // Computed Parameter: Constant_Value_kw
  //  Referenced by: '<S314>/Constant'

  1,

  // Computed Parameter: Constant1_Value_oh
  //  Referenced by: '<S313>/Constant1'

  1,

  // Computed Parameter: Gain_Gain_ai
  //  Referenced by: '<S313>/Gain'

  13,

  // Computed Parameter: Constant1_Value_ck
  //  Referenced by: '<S317>/Constant1'

  2,

  // Computed Parameter: Constant_Value_o5
  //  Referenced by: '<S291>/Constant'

  1,

  // Computed Parameter: Constant_Value_kn
  //  Referenced by: '<S308>/Constant'

  1,

  // Computed Parameter: Gain_Gain_ag
  //  Referenced by: '<S308>/Gain'

  13,

  // Computed Parameter: Constant_Value_mq
  //  Referenced by: '<S318>/Constant'

  1,

  // Computed Parameter: Constant1_Value_ab
  //  Referenced by: '<S318>/Constant1'

  1,

  // Computed Parameter: Constant_Value_khy
  //  Referenced by: '<S320>/Constant'

  1,

  // Computed Parameter: tc_old_Threshold
  //  Referenced by: '<S319>/tc_old'

  1,

  // Computed Parameter: Constant_Value_ct
  //  Referenced by: '<S290>/Constant'

  1,

  // Computed Parameter: Constant1_Value_d
  //  Referenced by: '<S290>/Constant1'

  1,

  // Computed Parameter: Constant_Value_lcx
  //  Referenced by: '<S289>/Constant'

  1,

  // Computed Parameter: Constant_Value_ba
  //  Referenced by: '<S294>/Constant'

  1,

  // Computed Parameter: Gain_Gain_jb
  //  Referenced by: '<S294>/Gain'

  13,

  // Computed Parameter: Constant_Value_mw
  //  Referenced by: '<S296>/Constant'

  1,

  // Computed Parameter: ForIterator_IterationLimit_c
  //  Referenced by: '<S281>/For Iterator'

  12,

  // Computed Parameter: Constant_Value_b5
  //  Referenced by: '<S281>/Constant'

  1,

  // Computed Parameter: arn_Threshold
  //  Referenced by: '<S281>/ar(n)'

  1,

  // Computed Parameter: FaultID_Value
  //  Referenced by: '<S226>/FaultID'

  123544,

  // Computed Parameter: FaultID1_Value
  //  Referenced by: '<S226>/FaultID1'

  123545,

  // Computed Parameter: FaultID2_Value
  //  Referenced by: '<S226>/FaultID2'

  123546,

  // Expression: FaultParamStruct.NoiseWindFaultID
  //  Referenced by: '<S28>/FaultID4'

  123543,

  // Expression: FaultParamStruct.ConstWindFaultID
  //  Referenced by: '<S28>/FaultID'

  123459,

  // Expression: FaultParamStruct.GustWindFaultID
  //  Referenced by: '<S28>/FaultID1'

  123540,

  // Expression: FaultParamStruct.TurbWindFaultID
  //  Referenced by: '<S28>/FaultID2'

  123541,

  // Expression: FaultParamStruct.SheerWindFaultID
  //  Referenced by: '<S28>/FaultID3'

  123542,

  // Computed Parameter: FaultID3_Value_h
  //  Referenced by: '<S226>/FaultID3'

  123547,

  // Expression: FaultParamStruct.GPSNoiseFaultID
  //  Referenced by: '<S194>/FaultID'

  123548,

  // Expression: FaultParamStruct.FaultID
  //  Referenced by: '<S15>/FaultID'

  123450,

  // Computed Parameter: MediumHighAltitudeIntensity_max
  //  Referenced by: '<S544>/Medium//High Altitude Intensity'

  { 11U, 6U },

  // Computed Parameter: MediumHighAltitudeIntensity_m_o
  //  Referenced by: '<S125>/Medium//High Altitude Intensity'

  { 11U, 6U },

  // Computed Parameter: MediumHighAltitudeIntensity_m_h
  //  Referenced by: '<S86>/Medium//High Altitude Intensity'

  { 11U, 6U },

  // Start of '<S525>/Positive Yaw'
  {
    // Expression: 2*pi
    //  Referenced by: '<S570>/Constant1'

    6.2831853071795862
  }
  ,

  // End of '<S525>/Positive Yaw'

  // Start of '<S525>/Negative Yaw'
  {
    // Expression: 2*pi
    //  Referenced by: '<S569>/Constant1'

    6.2831853071795862,

    // Expression: 2*pi
    //  Referenced by: '<S569>/Constant2'

    6.2831853071795862
  }
  ,

  // End of '<S525>/Negative Yaw'

  // Start of '<S533>/Interpolate  velocities'
  {
    // Expression: max_height_low
    //  Referenced by: '<S554>/max_height_low'

    1000.0,

    // Expression: min_height_high
    //  Referenced by: '<S554>/min_height_high'

    2000.0
  }
  ,

  // End of '<S533>/Interpolate  velocities'

  // Start of '<S532>/Interpolate  rates'
  {
    // Expression: max_height_low
    //  Referenced by: '<S546>/max_height_low'

    1000.0,

    // Expression: min_height_high
    //  Referenced by: '<S546>/min_height_high'

    2000.0
  }
  ,

  // End of '<S532>/Interpolate  rates'

  // Start of '<S456>/If Warning//Error'
  {
    // Expression: 0
    //  Referenced by: '<S482>/Constant1'

    0.0,

    // Expression: 0
    //  Referenced by: '<S481>/Constant1'

    0.0,

    // Expression: -1
    //  Referenced by: '<S484>/Bias'

    -1.0,

    // Expression: -eye(3)
    //  Referenced by: '<S483>/Bias1'

    { -1.0, -0.0, -0.0, -0.0, -1.0, -0.0, -0.0, -0.0, -1.0 }
  }
  ,

  // End of '<S456>/If Warning//Error'

  // Start of '<S410>/Negative Trace'
  {
    // Expression: 1
    //  Referenced by: '<S471>/Constant'

    1.0,

    // Expression: 0.5
    //  Referenced by: '<S459>/Gain'

    0.5,

    // Expression: 0.5
    //  Referenced by: '<S470>/Constant1'

    0.5,

    // Expression: [0 1]
    //  Referenced by: '<S470>/Constant2'

    { 0.0, 1.0 },

    // Expression: 1
    //  Referenced by: '<S459>/Gain1'

    1.0,

    // Expression: 1
    //  Referenced by: '<S459>/Gain3'

    1.0,

    // Expression: 1
    //  Referenced by: '<S459>/Gain4'

    1.0,

    // Expression: 1
    //  Referenced by: '<S476>/Constant'

    1.0,

    // Expression: 0.5
    //  Referenced by: '<S460>/Gain'

    0.5,

    // Expression: 0.5
    //  Referenced by: '<S475>/Constant1'

    0.5,

    // Expression: [0 1]
    //  Referenced by: '<S475>/Constant2'

    { 0.0, 1.0 },

    // Expression: 1
    //  Referenced by: '<S460>/Gain1'

    1.0,

    // Expression: 1
    //  Referenced by: '<S460>/Gain2'

    1.0,

    // Expression: 1
    //  Referenced by: '<S460>/Gain3'

    1.0,

    // Expression: 1
    //  Referenced by: '<S466>/Constant'

    1.0,

    // Expression: 0.5
    //  Referenced by: '<S458>/Gain'

    0.5,

    // Expression: 0.5
    //  Referenced by: '<S465>/Constant1'

    0.5,

    // Expression: [0 1]
    //  Referenced by: '<S465>/Constant2'

    { 0.0, 1.0 },

    // Expression: 1
    //  Referenced by: '<S458>/Gain1'

    1.0,

    // Expression: 1
    //  Referenced by: '<S458>/Gain2'

    1.0,

    // Expression: 1
    //  Referenced by: '<S458>/Gain3'

    1.0
  }
  ,

  // End of '<S410>/Negative Trace'

  // Start of '<S410>/Positive Trace'
  {
    // Expression: 1
    //  Referenced by: '<S455>/Constant'

    1.0,

    // Expression: 0.5
    //  Referenced by: '<S455>/Gain'

    0.5,

    // Expression: 2
    //  Referenced by: '<S455>/Gain1'

    2.0
  }
  ,

  // End of '<S410>/Positive Trace'

  // Start of '<S418>/If Warning//Error'
  {
    // Expression: 0
    //  Referenced by: '<S444>/Constant1'

    0.0,

    // Expression: 0
    //  Referenced by: '<S443>/Constant1'

    0.0,

    // Expression: -1
    //  Referenced by: '<S446>/Bias'

    -1.0,

    // Expression: -eye(3)
    //  Referenced by: '<S445>/Bias1'

    { -1.0, -0.0, -0.0, -0.0, -1.0, -0.0, -0.0, -0.0, -1.0 }
  }
  ,

  // End of '<S418>/If Warning//Error'

  // Start of '<S409>/Negative Trace'
  {
    // Expression: 1
    //  Referenced by: '<S433>/Constant'

    1.0,

    // Expression: 0.5
    //  Referenced by: '<S421>/Gain'

    0.5,

    // Expression: 0.5
    //  Referenced by: '<S432>/Constant1'

    0.5,

    // Expression: [0 1]
    //  Referenced by: '<S432>/Constant2'

    { 0.0, 1.0 },

    // Expression: 1
    //  Referenced by: '<S421>/Gain1'

    1.0,

    // Expression: 1
    //  Referenced by: '<S421>/Gain3'

    1.0,

    // Expression: 1
    //  Referenced by: '<S421>/Gain4'

    1.0,

    // Expression: 1
    //  Referenced by: '<S438>/Constant'

    1.0,

    // Expression: 0.5
    //  Referenced by: '<S422>/Gain'

    0.5,

    // Expression: 0.5
    //  Referenced by: '<S437>/Constant1'

    0.5,

    // Expression: [0 1]
    //  Referenced by: '<S437>/Constant2'

    { 0.0, 1.0 },

    // Expression: 1
    //  Referenced by: '<S422>/Gain1'

    1.0,

    // Expression: 1
    //  Referenced by: '<S422>/Gain2'

    1.0,

    // Expression: 1
    //  Referenced by: '<S422>/Gain3'

    1.0,

    // Expression: 1
    //  Referenced by: '<S428>/Constant'

    1.0,

    // Expression: 0.5
    //  Referenced by: '<S420>/Gain'

    0.5,

    // Expression: 0.5
    //  Referenced by: '<S427>/Constant1'

    0.5,

    // Expression: [0 1]
    //  Referenced by: '<S427>/Constant2'

    { 0.0, 1.0 },

    // Expression: 1
    //  Referenced by: '<S420>/Gain1'

    1.0,

    // Expression: 1
    //  Referenced by: '<S420>/Gain2'

    1.0,

    // Expression: 1
    //  Referenced by: '<S420>/Gain3'

    1.0
  }
  ,

  // End of '<S409>/Negative Trace'

  // Start of '<S409>/Positive Trace'
  {
    // Expression: 1
    //  Referenced by: '<S417>/Constant'

    1.0,

    // Expression: 0.5
    //  Referenced by: '<S417>/Gain'

    0.5,

    // Expression: 2
    //  Referenced by: '<S417>/Gain1'

    2.0
  }
  ,

  // End of '<S409>/Positive Trace'

  // Start of '<S369>/Positive Yaw'
  {
    // Expression: 2*pi
    //  Referenced by: '<S408>/Constant1'

    6.2831853071795862
  }
  ,

  // End of '<S369>/Positive Yaw'

  // Start of '<S369>/Negative Yaw'
  {
    // Expression: 2*pi
    //  Referenced by: '<S407>/Constant1'

    6.2831853071795862,

    // Expression: 2*pi
    //  Referenced by: '<S407>/Constant2'

    6.2831853071795862
  }
  ,

  // End of '<S369>/Negative Yaw'

  // Start of '<S157>/If Warning//Error'
  {
    // Expression: 0
    //  Referenced by: '<S183>/Constant1'

    0.0,

    // Expression: 0
    //  Referenced by: '<S182>/Constant1'

    0.0,

    // Expression: -1
    //  Referenced by: '<S185>/Bias'

    -1.0,

    // Expression: -eye(3)
    //  Referenced by: '<S184>/Bias1'

    { -1.0, -0.0, -0.0, -0.0, -1.0, -0.0, -0.0, -0.0, -1.0 }
  }
  ,

  // End of '<S157>/If Warning//Error'

  // Start of '<S151>/Negative Trace'
  {
    // Expression: 1
    //  Referenced by: '<S172>/Constant'

    1.0,

    // Expression: 0.5
    //  Referenced by: '<S160>/Gain'

    0.5,

    // Expression: 0.5
    //  Referenced by: '<S171>/Constant1'

    0.5,

    // Expression: [0 1]
    //  Referenced by: '<S171>/Constant2'

    { 0.0, 1.0 },

    // Expression: 1
    //  Referenced by: '<S160>/Gain1'

    1.0,

    // Expression: 1
    //  Referenced by: '<S160>/Gain3'

    1.0,

    // Expression: 1
    //  Referenced by: '<S160>/Gain4'

    1.0,

    // Expression: 1
    //  Referenced by: '<S177>/Constant'

    1.0,

    // Expression: 0.5
    //  Referenced by: '<S161>/Gain'

    0.5,

    // Expression: 0.5
    //  Referenced by: '<S176>/Constant1'

    0.5,

    // Expression: [0 1]
    //  Referenced by: '<S176>/Constant2'

    { 0.0, 1.0 },

    // Expression: 1
    //  Referenced by: '<S161>/Gain1'

    1.0,

    // Expression: 1
    //  Referenced by: '<S161>/Gain2'

    1.0,

    // Expression: 1
    //  Referenced by: '<S161>/Gain3'

    1.0,

    // Expression: 1
    //  Referenced by: '<S167>/Constant'

    1.0,

    // Expression: 0.5
    //  Referenced by: '<S159>/Gain'

    0.5,

    // Expression: 0.5
    //  Referenced by: '<S166>/Constant1'

    0.5,

    // Expression: [0 1]
    //  Referenced by: '<S166>/Constant2'

    { 0.0, 1.0 },

    // Expression: 1
    //  Referenced by: '<S159>/Gain1'

    1.0,

    // Expression: 1
    //  Referenced by: '<S159>/Gain2'

    1.0,

    // Expression: 1
    //  Referenced by: '<S159>/Gain3'

    1.0
  }
  ,

  // End of '<S151>/Negative Trace'

  // Start of '<S151>/Positive Trace'
  {
    // Expression: 1
    //  Referenced by: '<S156>/Constant'

    1.0,

    // Expression: 0.5
    //  Referenced by: '<S156>/Gain'

    0.5,

    // Expression: 2
    //  Referenced by: '<S156>/Gain1'

    2.0
  }
  ,

  // End of '<S151>/Positive Trace'

  // Start of '<S114>/Interpolate  velocities'
  {
    // Expression: max_height_low
    //  Referenced by: '<S135>/max_height_low'

    1000.0,

    // Expression: min_height_high
    //  Referenced by: '<S135>/min_height_high'

    2000.0
  }
  ,

  // End of '<S114>/Interpolate  velocities'

  // Start of '<S113>/Interpolate  rates'
  {
    // Expression: max_height_low
    //  Referenced by: '<S127>/max_height_low'

    1000.0,

    // Expression: min_height_high
    //  Referenced by: '<S127>/min_height_high'

    2000.0
  }
  ,

  // End of '<S113>/Interpolate  rates'

  // Start of '<S109>/Hwgw(z)'
  {
    // Expression: 0
    //  Referenced by: '<S124>/wgw'

    0.0,

    // Expression: 2*dt
    //  Referenced by: '<S124>/2'

    0.02,

    // Expression: 1
    //  Referenced by: '<S124>/Constant'

    1.0,

    // Expression: dt
    //  Referenced by: '<S124>/dt'

    0.01,

    // Expression: 0
    //  Referenced by: '<S124>/Unit Delay'

    0.0
  }
  ,

  // End of '<S109>/Hwgw(z)'

  // Start of '<S109>/Hvgw(z)'
  {
    // Expression: 0
    //  Referenced by: '<S123>/vgw'

    0.0,

    // Expression: 2*dt
    //  Referenced by: '<S123>/2'

    0.02,

    // Expression: 1
    //  Referenced by: '<S123>/Constant'

    1.0,

    // Expression: dt
    //  Referenced by: '<S123>/dt'

    0.01,

    // Expression: 0
    //  Referenced by: '<S123>/Unit Delay'

    0.0
  }
  ,

  // End of '<S109>/Hvgw(z)'

  // Start of '<S109>/Hugw(z)'
  {
    // Expression: 0
    //  Referenced by: '<S122>/ugw'

    0.0,

    // Expression: 2*dt
    //  Referenced by: '<S122>/2'

    0.02,

    // Expression: 1
    //  Referenced by: '<S122>/Constant'

    1.0,

    // Expression: dt
    //  Referenced by: '<S122>/dt'

    0.01,

    // Expression: 0
    //  Referenced by: '<S122>/Unit Delay'

    0.0
  }
  ,

  // End of '<S109>/Hugw(z)'

  // Start of '<S108>/Hrgw'
  {
    // Expression: 0
    //  Referenced by: '<S121>/rgw'

    0.0,

    // Expression: 1
    //  Referenced by: '<S121>/Constant'

    1.0,

    // Expression: 3/pi
    //  Referenced by: '<S121>/dt1'

    0.954929658551372,

    // Expression: dt
    //  Referenced by: '<S121>/dt'

    0.01,

    // Expression: 0
    //  Referenced by: '<S121>/Unit Delay'

    0.0,

    // Expression: 0
    //  Referenced by: '<S121>/Unit Delay1'

    0.0
  }
  ,

  // End of '<S108>/Hrgw'

  // Start of '<S108>/Hqgw'
  {
    // Expression: 0
    //  Referenced by: '<S120>/qgw'

    0.0,

    // Expression: 1
    //  Referenced by: '<S120>/Constant'

    1.0,

    // Expression: 4/pi
    //  Referenced by: '<S120>/dt1'

    1.2732395447351628,

    // Expression: dt
    //  Referenced by: '<S120>/dt'

    0.01,

    // Expression: 0
    //  Referenced by: '<S120>/Unit Delay'

    0.0,

    // Expression: 0
    //  Referenced by: '<S120>/Unit Delay1'

    0.0
  }
  ,

  // End of '<S108>/Hqgw'

  // Start of '<S108>/Hpgw'
  {
    // Expression: 0
    //  Referenced by: '<S119>/pgw'

    0.0,

    // Expression: 2.6
    //  Referenced by: '<S119>/Constant2'

    2.6,

    // Expression: 2*dt
    //  Referenced by: '<S119>/2'

    0.02,

    // Expression: 1
    //  Referenced by: '<S119>/Constant'

    1.0,

    // Expression: 0.95
    //  Referenced by: '<S119>/Constant1'

    0.95,

    // Expression: 1/3
    //  Referenced by: '<S119>/Constant3'

    0.33333333333333331,

    // Expression: dt
    //  Referenced by: '<S119>/dt'

    0.01,

    // Expression: 0
    //  Referenced by: '<S119>/Unit Delay'

    0.0
  }
  ,

  // End of '<S108>/Hpgw'

  // Start of '<S75>/Interpolate  velocities'
  {
    // Expression: max_height_low
    //  Referenced by: '<S96>/max_height_low'

    1000.0,

    // Expression: min_height_high
    //  Referenced by: '<S96>/min_height_high'

    2000.0
  }
  ,

  // End of '<S75>/Interpolate  velocities'

  // Start of '<S74>/Interpolate  rates'
  {
    // Expression: max_height_low
    //  Referenced by: '<S88>/max_height_low'

    1000.0,

    // Expression: min_height_high
    //  Referenced by: '<S88>/min_height_high'

    2000.0
  }
  ,

  // End of '<S74>/Interpolate  rates'

  // Start of '<S70>/Hwgw(z)'
  {
    // Expression: 0
    //  Referenced by: '<S85>/wgw'

    0.0,

    // Expression: 2*dt
    //  Referenced by: '<S85>/2'

    0.02,

    // Expression: 1
    //  Referenced by: '<S85>/Constant'

    1.0,

    // Expression: dt
    //  Referenced by: '<S85>/dt'

    0.01,

    // Expression: 0
    //  Referenced by: '<S85>/Unit Delay'

    0.0
  }
  ,

  // End of '<S70>/Hwgw(z)'

  // Start of '<S70>/Hvgw(z)'
  {
    // Expression: 0
    //  Referenced by: '<S84>/vgw'

    0.0,

    // Expression: 2*dt
    //  Referenced by: '<S84>/2'

    0.02,

    // Expression: 1
    //  Referenced by: '<S84>/Constant'

    1.0,

    // Expression: dt
    //  Referenced by: '<S84>/dt'

    0.01,

    // Expression: 0
    //  Referenced by: '<S84>/Unit Delay'

    0.0
  }
  ,

  // End of '<S70>/Hvgw(z)'

  // Start of '<S70>/Hugw(z)'
  {
    // Expression: 0
    //  Referenced by: '<S83>/ugw'

    0.0,

    // Expression: 2*dt
    //  Referenced by: '<S83>/2'

    0.02,

    // Expression: 1
    //  Referenced by: '<S83>/Constant'

    1.0,

    // Expression: dt
    //  Referenced by: '<S83>/dt'

    0.01,

    // Expression: 0
    //  Referenced by: '<S83>/Unit Delay'

    0.0
  }
  ,

  // End of '<S70>/Hugw(z)'

  // Start of '<S69>/Hrgw'
  {
    // Expression: 0
    //  Referenced by: '<S82>/rgw'

    0.0,

    // Expression: 1
    //  Referenced by: '<S82>/Constant'

    1.0,

    // Expression: 3/pi
    //  Referenced by: '<S82>/dt1'

    0.954929658551372,

    // Expression: dt
    //  Referenced by: '<S82>/dt'

    0.01,

    // Expression: 0
    //  Referenced by: '<S82>/Unit Delay'

    0.0,

    // Expression: 0
    //  Referenced by: '<S82>/Unit Delay1'

    0.0
  }
  ,

  // End of '<S69>/Hrgw'

  // Start of '<S69>/Hqgw'
  {
    // Expression: 0
    //  Referenced by: '<S81>/qgw'

    0.0,

    // Expression: 1
    //  Referenced by: '<S81>/Constant'

    1.0,

    // Expression: 4/pi
    //  Referenced by: '<S81>/dt1'

    1.2732395447351628,

    // Expression: dt
    //  Referenced by: '<S81>/dt'

    0.01,

    // Expression: 0
    //  Referenced by: '<S81>/Unit Delay'

    0.0,

    // Expression: 0
    //  Referenced by: '<S81>/Unit Delay1'

    0.0
  }
  ,

  // End of '<S69>/Hqgw'

  // Start of '<S69>/Hpgw'
  {
    // Expression: 0
    //  Referenced by: '<S80>/pgw'

    0.0,

    // Expression: 2.6
    //  Referenced by: '<S80>/Constant2'

    2.6,

    // Expression: 2*dt
    //  Referenced by: '<S80>/2'

    0.02,

    // Expression: 1
    //  Referenced by: '<S80>/Constant'

    1.0,

    // Expression: 0.95
    //  Referenced by: '<S80>/Constant1'

    0.95,

    // Expression: 1/3
    //  Referenced by: '<S80>/Constant3'

    0.33333333333333331,

    // Expression: dt
    //  Referenced by: '<S80>/dt'

    0.01,

    // Expression: 0
    //  Referenced by: '<S80>/Unit Delay'

    0.0
  }
  ,

  // End of '<S69>/Hpgw'

  // Start of '<S17>/Distance into gust (z)'
  {
    // Expression: [0]
    //  Referenced by: '<S22>/x'

    0.0,

    // Expression: 0
    //  Referenced by: '<S22>/Distance into Gust (x) (Limited to gust length d) '

    0.0,

    // Expression: 0
    //  Referenced by: '<S22>/Distance into Gust (x) (Limited to gust length d) '

    0.0
  }
  ,

  // End of '<S17>/Distance into gust (z)'

  // Start of '<S17>/Distance into gust (y)'
  {
    // Expression: [0]
    //  Referenced by: '<S21>/x'

    0.0,

    // Expression: 0
    //  Referenced by: '<S21>/Distance into Gust (x) (Limited to gust length d) '

    0.0,

    // Expression: 0
    //  Referenced by: '<S21>/Distance into Gust (x) (Limited to gust length d) '

    0.0
  }
  // End of '<S17>/Distance into gust (y)'
};

extern real_T rt_powd_snf(real_T u0, real_T u1);
extern real_T rt_modd_snf(real_T u0, real_T u1);
extern real_T rt_atan2d_snf(real_T u0, real_T u1);
extern void rt_mrdivide_U1d1x3_U2d_9vOrDY9Z(const real_T u0[3], const real_T u1
  [9], real_T y[3]);
extern real_T rt_roundd_snf(real_T u);
extern real_T rt_urand_Upu32_Yd_f_pw_snf(uint32_T *u);
extern real_T rt_nrand_Upu32_Yd_f_pw_snf(uint32_T *u);
void wgs84_taylor_series(real_T *h, real_T *phi, real_T opt_m2ft, real_T *y,
  int_T k);
static uint32_T plook_bincpa(real_T u, const real_T bp[], uint32_T maxIndex,
  real_T *fraction, uint32_T *prevIndex);
static real_T intrp2d_la_pw(const uint32_T bpIndex[], const real_T frac[], const
  real_T table[], const uint32_T stride, const uint32_T maxIndex[]);
static uint32_T binsearch_u32d_prevIdx(real_T u, const real_T bp[], uint32_T
  startIndex, uint32_T maxIndex);
static void mul_wide_s32(int32_T in0, int32_T in1, uint32_T *ptrOutBitsHi,
  uint32_T *ptrOutBitsLo);
static int32_T mul_s32_sat(int32_T a, int32_T b);

// private model entry point functions
extern void FixedwingModel_derivatives();
static void rate_scheduler(RT_MODEL_FixedwingModel_T *const FixedwingModel_M);

//===========*
//  Constants *
// ===========
#define RT_PI                          3.14159265358979323846
#define RT_PIF                         3.1415927F
#define RT_LN_10                       2.30258509299404568402
#define RT_LN_10F                      2.3025851F
#define RT_LOG10E                      0.43429448190325182765
#define RT_LOG10EF                     0.43429449F
#define RT_E                           2.7182818284590452354
#define RT_EF                          2.7182817F

//
//  UNUSED_PARAMETER(x)
//    Used to specify that a function parameter (argument) is required but not
//    accessed by the function body.

#ifndef UNUSED_PARAMETER
#if defined(__LCC__)
#define UNUSED_PARAMETER(x)                                      // do nothing
#else

//
//  This is the semi-ANSI standard way of indicating that an
//  unused function parameter is required.

#define UNUSED_PARAMETER(x)            (void) (x)
#endif
#endif

extern "C" {
  real_T rtInf;
  real_T rtMinusInf;
  real_T rtNaN;
  real32_T rtInfF;
  real32_T rtMinusInfF;
  real32_T rtNaNF;
}
//=========*
//  Asserts *
// =========
#ifndef utAssert
#if defined(DOASSERTS)
#if !defined(PRINT_ASSERTS)
#include <assert.h>
#define utAssert(exp)                  assert(exp)
#else
#include <stdio.h>

static void _assert(char *statement, char *file, int line)
{
  printf("%s in %s on line %d\n", statement, file, line);
}

#define utAssert(_EX)                  ((_EX) ? (void)0 : _assert(#_EX, __FILE__, __LINE__))
#endif

#else
#define utAssert(exp)                                            // do nothing
#endif
#endif

extern "C" {
  //
  // Initialize rtInf needed by the generated code.
  // Inf is initialized as non-signaling. Assumes IEEE.
  //
  static real_T rtGetInf(void)
  {
    size_t bitsPerReal = sizeof(real_T) * (NumBitsPerChar);
    real_T inf = 0.0;
    if (bitsPerReal == 32U) {
      inf = rtGetInfF();
    } else {
      union {
        LittleEndianIEEEDouble bitVal;
        real_T fltVal;
      } tmpVal;

      tmpVal.bitVal.words.wordH = 0x7FF00000U;
      tmpVal.bitVal.words.wordL = 0x00000000U;
      inf = tmpVal.fltVal;
    }

    return inf;
  }

  //
  // Initialize rtInfF needed by the generated code.
  // Inf is initialized as non-signaling. Assumes IEEE.
  //
  static real32_T rtGetInfF(void)
  {
    IEEESingle infF;
    infF.wordL.wordLuint = 0x7F800000U;
    return infF.wordL.wordLreal;
  }

  //
  // Initialize rtMinusInf needed by the generated code.
  // Inf is initialized as non-signaling. Assumes IEEE.
  //
  static real_T rtGetMinusInf(void)
  {
    size_t bitsPerReal = sizeof(real_T) * (NumBitsPerChar);
    real_T minf = 0.0;
    if (bitsPerReal == 32U) {
      minf = rtGetMinusInfF();
    } else {
      union {
        LittleEndianIEEEDouble bitVal;
        real_T fltVal;
      } tmpVal;

      tmpVal.bitVal.words.wordH = 0xFFF00000U;
      tmpVal.bitVal.words.wordL = 0x00000000U;
      minf = tmpVal.fltVal;
    }

    return minf;
  }

  //
  // Initialize rtMinusInfF needed by the generated code.
  // Inf is initialized as non-signaling. Assumes IEEE.
  //
  static real32_T rtGetMinusInfF(void)
  {
    IEEESingle minfF;
    minfF.wordL.wordLuint = 0xFF800000U;
    return minfF.wordL.wordLreal;
  }
}
  extern "C"
{
  //
  // Initialize rtNaN needed by the generated code.
  // NaN is initialized as non-signaling. Assumes IEEE.
  //
  static real_T rtGetNaN(void)
  {
    size_t bitsPerReal = sizeof(real_T) * (NumBitsPerChar);
    real_T nan = 0.0;
    if (bitsPerReal == 32U) {
      nan = rtGetNaNF();
    } else {
      union {
        LittleEndianIEEEDouble bitVal;
        real_T fltVal;
      } tmpVal;

      tmpVal.bitVal.words.wordH = 0xFFF80000U;
      tmpVal.bitVal.words.wordL = 0x00000000U;
      nan = tmpVal.fltVal;
    }

    return nan;
  }

  //
  // Initialize rtNaNF needed by the generated code.
  // NaN is initialized as non-signaling. Assumes IEEE.
  //
  static real32_T rtGetNaNF(void)
  {
    IEEESingle nanF = { { 0.0F } };

    nanF.wordL.wordLuint = 0xFFC00000U;
    return nanF.wordL.wordLreal;
  }
}

extern "C" {
  //
  // Initialize the rtInf, rtMinusInf, and rtNaN needed by the
  // generated code. NaN is initialized as non-signaling. Assumes IEEE.
  //
  static void rt_InitInfAndNaN(size_t realSize)
  {
    (void) (realSize);
    rtNaN = rtGetNaN();
    rtNaNF = rtGetNaNF();
    rtInf = rtGetInf();
    rtInfF = rtGetInfF();
    rtMinusInf = rtGetMinusInf();
    rtMinusInfF = rtGetMinusInfF();
  }

  // Test if value is infinite
  static boolean_T rtIsInf(real_T value)
  {
    return (boolean_T)((value==rtInf || value==rtMinusInf) ? 1U : 0U);
  }

  // Test if single-precision value is infinite
  static boolean_T rtIsInfF(real32_T value)
  {
    return (boolean_T)(((value)==rtInfF || (value)==rtMinusInfF) ? 1U : 0U);
  }

  // Test if value is not a number
  static boolean_T rtIsNaN(real_T value)
  {
    boolean_T result = (boolean_T) 0;
    size_t bitsPerReal = sizeof(real_T) * (NumBitsPerChar);
    if (bitsPerReal == 32U) {
      result = rtIsNaNF((real32_T)value);
    } else {
      union {
        LittleEndianIEEEDouble bitVal;
        real_T fltVal;
      } tmpVal;

      tmpVal.fltVal = value;
      result = (boolean_T)((tmpVal.bitVal.words.wordH & 0x7FF00000) ==
                           0x7FF00000 &&
                           ( (tmpVal.bitVal.words.wordH & 0x000FFFFF) != 0 ||
                            (tmpVal.bitVal.words.wordL != 0) ));
    }

    return result;
  }

  // Test if single-precision value is not a number
  static boolean_T rtIsNaNF(real32_T value)
  {
    IEEESingle tmp;
    tmp.wordL.wordLreal = value;
    return (boolean_T)( (tmp.wordL.wordLuint & 0x7F800000) == 0x7F800000 &&
                       (tmp.wordL.wordLuint & 0x007FFFFF) != 0 );
  }
}
//
//         Taylor Series expansion approximation of WGS84 model of
//         ellipsoid normal gravity
//
  void wgs84_taylor_series(real_T *h, real_T *phi, real_T opt_m2ft, real_T *y,
  int_T k)
{
  real_T gamma_ts, m, sinphi, sin2phi;
  int_T i;
  for (i = 0; i < k; i++ ) {
    sinphi = std::sin(phi[i]);
    sin2phi = sinphi*sinphi;

    // Calculate theoretical normal gravity (gamma) /eq. 4-1/
    gamma_ts = (WGS84_G_E)*( 1.0 + (WGS84_K)*sin2phi )/( std::sqrt(1.0 -
      (WGS84_E_2)*sin2phi) );
    m = (WGS84_A)*(WGS84_A)*(WGS84_B)*(WGS84_W_DEF)*(WGS84_W_DEF)/
      (WGS84_GM_DEF);

    // Return normal gravity as the output /eq. 4-3/
    y[i] = opt_m2ft*gamma_ts*( 1.0 - 2.0*( 1.0 + 1.0/(WGS84_INV_F) + m -
      2.0*sin2phi/(WGS84_INV_F) )*h[i]/(WGS84_A) + 3.0*h[i]*h[i]/(
      (WGS84_A)*(WGS84_A)) );
  }
}

static uint32_T plook_bincpa(real_T u, const real_T bp[], uint32_T maxIndex,
  real_T *fraction, uint32_T *prevIndex)
{
  uint32_T bpIndex;

  // Prelookup - Index and Fraction
  // Index Search method: 'binary'
  // Extrapolation method: 'Clip'
  // Use previous index: 'on'
  // Use last breakpoint for index at or above upper limit: 'on'
  // Remove protection against out-of-range input in generated code: 'off'

  if (u <= bp[0U]) {
    bpIndex = 0U;
    *fraction = 0.0;
  } else if (u < bp[maxIndex]) {
    bpIndex = binsearch_u32d_prevIdx(u, bp, *prevIndex, maxIndex);
    *fraction = (u - bp[bpIndex]) / (bp[bpIndex + 1U] - bp[bpIndex]);
  } else {
    bpIndex = maxIndex;
    *fraction = 0.0;
  }

  *prevIndex = bpIndex;
  return bpIndex;
}

static real_T intrp2d_la_pw(const uint32_T bpIndex[], const real_T frac[], const
  real_T table[], const uint32_T stride, const uint32_T maxIndex[])
{
  real_T y;
  real_T yL_0d0;
  uint32_T offset_1d;

  // Column-major Interpolation 2-D
  // Interpolation method: 'Linear point-slope'
  // Use last breakpoint for index at or above upper limit: 'on'
  // Overflow mode: 'portable wrapping'

  offset_1d = bpIndex[1U] * stride + bpIndex[0U];
  if (bpIndex[0U] == maxIndex[0U]) {
    y = table[offset_1d];
  } else {
    yL_0d0 = table[offset_1d];
    y = (table[offset_1d + 1U] - yL_0d0) * frac[0U] + yL_0d0;
  }

  if (bpIndex[1U] == maxIndex[1U]) {
  } else {
    offset_1d += stride;
    if (bpIndex[0U] == maxIndex[0U]) {
      yL_0d0 = table[offset_1d];
    } else {
      yL_0d0 = table[offset_1d];
      yL_0d0 += (table[offset_1d + 1U] - yL_0d0) * frac[0U];
    }

    y += (yL_0d0 - y) * frac[1U];
  }

  return y;
}

static uint32_T binsearch_u32d_prevIdx(real_T u, const real_T bp[], uint32_T
  startIndex, uint32_T maxIndex)
{
  uint32_T bpIndex;
  uint32_T found;
  uint32_T iLeft;
  uint32_T iRght;

  // Binary Search using Previous Index
  bpIndex = startIndex;
  iLeft = 0U;
  iRght = maxIndex;
  found = 0U;
  while (found == 0U) {
    if (u < bp[bpIndex]) {
      iRght = bpIndex - 1U;
      bpIndex = ((bpIndex + iLeft) - 1U) >> 1U;
    } else if (u < bp[bpIndex + 1U]) {
      found = 1U;
    } else {
      iLeft = bpIndex + 1U;
      bpIndex = ((bpIndex + iRght) + 1U) >> 1U;
    }
  }

  return bpIndex;
}

static void mul_wide_s32(int32_T in0, int32_T in1, uint32_T *ptrOutBitsHi,
  uint32_T *ptrOutBitsLo)
{
  uint32_T absIn0;
  uint32_T absIn1;
  uint32_T in0Hi;
  uint32_T in0Lo;
  uint32_T in1Hi;
  uint32_T productHiLo;
  uint32_T productLoHi;
  absIn0 = in0 < 0 ? ~static_cast<uint32_T>(in0) + 1U : static_cast<uint32_T>
    (in0);
  absIn1 = in1 < 0 ? ~static_cast<uint32_T>(in1) + 1U : static_cast<uint32_T>
    (in1);
  in0Hi = absIn0 >> 16U;
  in0Lo = absIn0 & 65535U;
  in1Hi = absIn1 >> 16U;
  absIn0 = absIn1 & 65535U;
  productHiLo = in0Hi * absIn0;
  productLoHi = in0Lo * in1Hi;
  absIn0 *= in0Lo;
  absIn1 = 0U;
  in0Lo = (productLoHi << /*MW:OvBitwiseOk*/ 16U) + /*MW:OvCarryOk*/ absIn0;
  if (in0Lo < absIn0) {
    absIn1 = 1U;
  }

  absIn0 = in0Lo;
  in0Lo += /*MW:OvCarryOk*/ productHiLo << /*MW:OvBitwiseOk*/ 16U;
  if (in0Lo < absIn0) {
    absIn1++;
  }

  absIn0 = (((productLoHi >> 16U) + (productHiLo >> 16U)) + in0Hi * in1Hi) +
    absIn1;
  if (static_cast<int32_T>((in0 != 0) && ((in1 != 0) && ((in0 > 0) != (in1 > 0)))))
  {
    absIn0 = ~absIn0;
    in0Lo = ~in0Lo;
    in0Lo++;
    if (in0Lo == 0U) {
      absIn0++;
    }
  }

  *ptrOutBitsHi = absIn0;
  *ptrOutBitsLo = in0Lo;
}

static int32_T mul_s32_sat(int32_T a, int32_T b)
{
  int32_T result;
  uint32_T u32_chi;
  uint32_T u32_clo;
  mul_wide_s32(a, b, &u32_chi, &u32_clo);
  if ((static_cast<int32_T>(u32_chi) > 0) || ((u32_chi == 0U) && (u32_clo >=
        2147483648U))) {
    result = MAX_int32_T;
  } else if ((static_cast<int32_T>(u32_chi) < -1) || ((static_cast<int32_T>
               (u32_chi) == -1) && (u32_clo < 2147483648U))) {
    result = MIN_int32_T;
  } else {
    result = static_cast<int32_T>(u32_clo);
  }

  return result;
}

//
//         This function updates active task flag for each subrate.
//         The function is called at model base rate, hence the
//         generated code self-manages all its subrates.
//
static void rate_scheduler(RT_MODEL_FixedwingModel_T *const FixedwingModel_M)
{
  // Compute which subrates run during the next base time step.  Subrates
  //  are an integer multiple of the base rate counter.  Therefore, the subtask
  //  counter is reset when it reaches its limit (zero means run).

  (FixedwingModel_M->Timing.TaskCounters.TID[2])++;
  if ((FixedwingModel_M->Timing.TaskCounters.TID[2]) > 2) {// Sample time: [0.003s, 0.0s] 
    FixedwingModel_M->Timing.TaskCounters.TID[2] = 0;
  }

  (FixedwingModel_M->Timing.TaskCounters.TID[3])++;
  if ((FixedwingModel_M->Timing.TaskCounters.TID[3]) > 9) {// Sample time: [0.01s, 0.0s] 
    FixedwingModel_M->Timing.TaskCounters.TID[3] = 0;
  }

  (FixedwingModel_M->Timing.TaskCounters.TID[4])++;
  if ((FixedwingModel_M->Timing.TaskCounters.TID[4]) > 99) {// Sample time: [0.1s, 0.0s] 
    FixedwingModel_M->Timing.TaskCounters.TID[4] = 0;
  }

  (FixedwingModel_M->Timing.TaskCounters.TID[5])++;
  if ((FixedwingModel_M->Timing.TaskCounters.TID[5]) > 199) {// Sample time: [0.2s, 0.0s] 
    FixedwingModel_M->Timing.TaskCounters.TID[5] = 0;
  }
}

// State reduction function
void local_stateReduction(real_T* x, int_T* p, int_T n, real_T* r)
{
  int_T i, j;
  for (i = 0, j = 0; i < n; ++i, ++j) {
    int_T k = p[i];
    real_T lb = r[j++];
    real_T xk = x[k]-lb;
    real_T rk = r[j]-lb;
    int_T q = (int_T) std::floor(xk/rk);
    if (q) {
      x[k] = xk-q*rk+lb;
    }
  }
}

//
// This function updates continuous states using the ODE4 fixed-step
// solver algorithm
//
void MulticopterModelClass::rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE4_IntgData *id = static_cast<ODE4_IntgData *>(rtsiGetSolverData(si));
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T *f3 = id->f[3];
  real_T temp;
  int_T i;
  int_T nXc = 64;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  // Save the state values at time t in y, we'll use x as ynew.
  (void) std::memcpy(y, x,
                     static_cast<uint_T>(nXc)*sizeof(real_T));

  // Assumes that rtsiSetT and ModelOutputs are up-to-date
  // f0 = f(t,y)
  rtsiSetdX(si, f0);
  FixedwingModel_derivatives();

  // f1 = f(t + (h/2), y + (h/2)*f0)
  temp = 0.5 * h;
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (temp*f0[i]);
  }

  rtsiSetT(si, t + temp);
  rtsiSetdX(si, f1);
  this->step();
  FixedwingModel_derivatives();

  // f2 = f(t + (h/2), y + (h/2)*f1)
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (temp*f1[i]);
  }

  rtsiSetdX(si, f2);
  this->step();
  FixedwingModel_derivatives();

  // f3 = f(t + h, y + h*f2)
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (h*f2[i]);
  }

  rtsiSetT(si, tnew);
  rtsiSetdX(si, f3);
  this->step();
  FixedwingModel_derivatives();

  // tnew = t + h
  // ynew = y + (h/6)*(f0 + 2*f1 + 2*f2 + 2*f3)
  temp = h / 6.0;
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + temp*(f0[i] + 2.0*f1[i] + 2.0*f2[i] + f3[i]);
  }

  local_stateReduction(rtsiGetContStates(si), rtsiGetPeriodicContStateIndices(si),
                       3,
                       rtsiGetPeriodicContStateRanges(si));
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

//
// System initialize for enable system:
//    '<S17>/Distance into gust (y)'
//    '<S17>/Distance into gust (z)'
//
void MulticopterModelClass::Fixedwin_Distanceintogusty_Init
  (B_Distanceintogusty_Fixedwing_T *localB, P_Distanceintogusty_Fixedwing_T
   *localP, X_Distanceintogusty_Fixedwing_T *localX)
{
  // InitializeConditions for Integrator: '<S21>/Distance into Gust (x) (Limited to gust length d) ' 
  localX->DistanceintoGustxLimitedtogustl =
    localP->DistanceintoGustxLimitedtogustl;

  // SystemInitialize for Integrator: '<S21>/Distance into Gust (x) (Limited to gust length d) ' incorporates:
  //   Outport: '<S21>/x'

  localB->DistanceintoGustxLimitedtogustl = localP->x_Y0;
}

//
// System reset for enable system:
//    '<S17>/Distance into gust (y)'
//    '<S17>/Distance into gust (z)'
//
void MulticopterModelClass::Fixedwi_Distanceintogusty_Reset
  (P_Distanceintogusty_Fixedwing_T *localP, X_Distanceintogusty_Fixedwing_T
   *localX)
{
  // InitializeConditions for Integrator: '<S21>/Distance into Gust (x) (Limited to gust length d) ' 
  localX->DistanceintoGustxLimitedtogustl =
    localP->DistanceintoGustxLimitedtogustl;
}

//
// Disable for enable system:
//    '<S17>/Distance into gust (y)'
//    '<S17>/Distance into gust (z)'
//
void MulticopterModelClass::Fixed_Distanceintogusty_Disable
  (DW_Distanceintogusty_Fixedwin_T *localDW)
{
  localDW->Distanceintogusty_MODE = false;
}

//
// Outputs for enable system:
//    '<S17>/Distance into gust (y)'
//    '<S17>/Distance into gust (z)'
//
void MulticopterModelClass::FixedwingMode_Distanceintogusty(boolean_T rtu_Enable,
  real_T rtp_d_m, B_Distanceintogusty_Fixedwing_T *localB,
  DW_Distanceintogusty_Fixedwin_T *localDW, P_Distanceintogusty_Fixedwing_T
  *localP, X_Distanceintogusty_Fixedwing_T *localX)
{
  // Outputs for Enabled SubSystem: '<S17>/Distance into gust (y)' incorporates:
  //   EnablePort: '<S21>/Enable'

  if ((rtmIsMajorTimeStep((&FixedwingModel_M)) &&
       (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) &&
      rtsiIsModeUpdateTimeStep(&(&FixedwingModel_M)->solverInfo)) {
    if (rtu_Enable) {
      if (!localDW->Distanceintogusty_MODE) {
        Fixedwi_Distanceintogusty_Reset(localP, localX);
        localDW->Distanceintogusty_MODE = true;
      }
    } else if (localDW->Distanceintogusty_MODE) {
      Fixed_Distanceintogusty_Disable(localDW);
    }
  }

  if (localDW->Distanceintogusty_MODE) {
    // Integrator: '<S21>/Distance into Gust (x) (Limited to gust length d) '
    // Limited  Integrator
    if (localX->DistanceintoGustxLimitedtogustl >= rtp_d_m) {
      localX->DistanceintoGustxLimitedtogustl = rtp_d_m;
    } else if (localX->DistanceintoGustxLimitedtogustl <=
               localP->DistanceintoGustxLimitedtogus_a) {
      localX->DistanceintoGustxLimitedtogustl =
        localP->DistanceintoGustxLimitedtogus_a;
    }

    // Integrator: '<S21>/Distance into Gust (x) (Limited to gust length d) '
    localB->DistanceintoGustxLimitedtogustl =
      localX->DistanceintoGustxLimitedtogustl;
  }

  // End of Outputs for SubSystem: '<S17>/Distance into gust (y)'
}

//
// Derivatives for enable system:
//    '<S17>/Distance into gust (y)'
//    '<S17>/Distance into gust (z)'
//
void MulticopterModelClass::Fixedwi_Distanceintogusty_Deriv(real_T rtu_V, real_T
  rtp_d_m, DW_Distanceintogusty_Fixedwin_T *localDW,
  P_Distanceintogusty_Fixedwing_T *localP, X_Distanceintogusty_Fixedwing_T
  *localX, XDot_Distanceintogusty_Fixedw_T *localXdot)
{
  if (localDW->Distanceintogusty_MODE) {
    boolean_T lsat;
    boolean_T usat;

    // Derivatives for Integrator: '<S21>/Distance into Gust (x) (Limited to gust length d) ' 
    lsat = (localX->DistanceintoGustxLimitedtogustl <=
            localP->DistanceintoGustxLimitedtogus_a);
    usat = (localX->DistanceintoGustxLimitedtogustl >= rtp_d_m);
    if (((!lsat) && (!usat)) || (lsat && (rtu_V > 0.0)) || (usat && (rtu_V < 0.0)))
    {
      localXdot->DistanceintoGustxLimitedtogustl = rtu_V;
    } else {
      // in saturation
      localXdot->DistanceintoGustxLimitedtogustl = 0.0;
    }

    // End of Derivatives for Integrator: '<S21>/Distance into Gust (x) (Limited to gust length d) ' 
  } else {
    localXdot->DistanceintoGustxLimitedtogustl = 0.0;
  }
}

//
// Output and update for atomic system:
//    '<S15>/FaultParamsExtract'
//    '<S194>/FaultParamsExtract'
//
void MulticopterModelClass::FixedwingMod_FaultParamsExtract(int32_T rtu_FaultID,
  const int32_T rtu_inInts[8], const real_T rtu_inFloats[20],
  B_FaultParamsExtract_Fixedwin_T *localB, DW_FaultParamsExtract_Fixedwi_T
  *localDW)
{
  real_T fParamTmp[20];
  real_T j;
  boolean_T hFaultTmp;

  // MATLAB Function 'Steering EngineFault/FaultParamsExtract': '<S18>:1'
  // '<S18>:1:5' if isempty(hFault)
  // '<S18>:1:8' if isempty(fParam)
  // '<S18>:1:12' hFaultTmp=false;
  hFaultTmp = false;

  // '<S18>:1:13' fParamTmp=zeros(20,1);
  std::memset(&fParamTmp[0], 0, 20U * sizeof(real_T));

  // '<S18>:1:14' j=1;
  j = 1.0;

  // '<S18>:1:15' for i=1:8
  for (int32_T i = 0; i < 8; i++) {
    // '<S18>:1:16' if inInts(i) == FaultID
    if (rtu_inInts[i] == rtu_FaultID) {
      int32_T fParamTmp_tmp;

      // '<S18>:1:17' hFaultTmp=true;
      hFaultTmp = true;

      // '<S18>:1:18' fParamTmp(2*j-1)=inFloats(2*i-1);
      fParamTmp_tmp = (i + 1) << 1;
      fParamTmp[static_cast<int32_T>(2.0 * j - 1.0) - 1] =
        rtu_inFloats[fParamTmp_tmp - 2];

      // '<S18>:1:19' fParamTmp(2*j)=inFloats(2*i);
      fParamTmp[static_cast<int32_T>(2.0 * j) - 1] = rtu_inFloats[fParamTmp_tmp
        - 1];

      // '<S18>:1:20' j=j+1;
      j++;
    }
  }

  // '<S18>:1:23' if hFaultTmp
  if (hFaultTmp) {
    // '<S18>:1:24' hFault=hFaultTmp;
    localDW->hFault = true;

    // '<S18>:1:25' fParamTmp(17:20) = inFloats(17:20);
    fParamTmp[16] = rtu_inFloats[16];
    fParamTmp[17] = rtu_inFloats[17];
    fParamTmp[18] = rtu_inFloats[18];
    fParamTmp[19] = rtu_inFloats[19];

    // '<S18>:1:26' fParam=fParamTmp;
    std::memcpy(&localDW->fParam[0], &fParamTmp[0], 20U * sizeof(real_T));
  }

  // '<S18>:1:29' hasFault=hFault;
  localB->hasFault = localDW->hFault;

  // '<S18>:1:30' FaultParam=fParam;
  std::memcpy(&localB->FaultParam[0], &localDW->fParam[0], 20U * sizeof(real_T));
}

real_T rt_powd_snf(real_T u0, real_T u1)
{
  real_T y;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = (rtNaN);
  } else {
    real_T tmp;
    real_T tmp_0;
    tmp = std::abs(u0);
    tmp_0 = std::abs(u1);
    if (rtIsInf(u1)) {
      if (tmp == 1.0) {
        y = 1.0;
      } else if (tmp > 1.0) {
        if (u1 > 0.0) {
          y = (rtInf);
        } else {
          y = 0.0;
        }
      } else if (u1 > 0.0) {
        y = 0.0;
      } else {
        y = (rtInf);
      }
    } else if (tmp_0 == 0.0) {
      y = 1.0;
    } else if (tmp_0 == 1.0) {
      if (u1 > 0.0) {
        y = u0;
      } else {
        y = 1.0 / u0;
      }
    } else if (u1 == 2.0) {
      y = u0 * u0;
    } else if ((u1 == 0.5) && (u0 >= 0.0)) {
      y = std::sqrt(u0);
    } else if ((u0 < 0.0) && (u1 > std::floor(u1))) {
      y = (rtNaN);
    } else {
      y = std::pow(u0, u1);
    }
  }

  return y;
}

//
// System initialize for enable system:
//    '<S69>/Hpgw'
//    '<S108>/Hpgw'
//
void MulticopterModelClass::FixedwingModel_Hpgw_Init(B_Hpgw_FixedwingModel_T
  *localB, DW_Hpgw_FixedwingModel_T *localDW, P_Hpgw_FixedwingModel_T *localP)
{
  // InitializeConditions for UnitDelay: '<S80>/Unit Delay'
  localDW->UnitDelay_DSTATE[0] = localP->UnitDelay_InitialCondition;

  // SystemInitialize for Sum: '<S80>/Sum' incorporates:
  //   Outport: '<S80>/pgw'

  localB->Sum[0] = localP->pgw_Y0;

  // InitializeConditions for UnitDelay: '<S80>/Unit Delay'
  localDW->UnitDelay_DSTATE[1] = localP->UnitDelay_InitialCondition;

  // SystemInitialize for Sum: '<S80>/Sum' incorporates:
  //   Outport: '<S80>/pgw'

  localB->Sum[1] = localP->pgw_Y0;
}

//
// System reset for enable system:
//    '<S69>/Hpgw'
//    '<S108>/Hpgw'
//
void MulticopterModelClass::FixedwingModel_Hpgw_Reset(DW_Hpgw_FixedwingModel_T
  *localDW, P_Hpgw_FixedwingModel_T *localP)
{
  // InitializeConditions for UnitDelay: '<S80>/Unit Delay'
  localDW->UnitDelay_DSTATE[0] = localP->UnitDelay_InitialCondition;
  localDW->UnitDelay_DSTATE[1] = localP->UnitDelay_InitialCondition;
}

//
// Disable for enable system:
//    '<S69>/Hpgw'
//    '<S108>/Hpgw'
//
void MulticopterModelClass::FixedwingModel_Hpgw_Disable(B_Hpgw_FixedwingModel_T *
  localB, DW_Hpgw_FixedwingModel_T *localDW, P_Hpgw_FixedwingModel_T *localP)
{
  // Disable for Sum: '<S80>/Sum' incorporates:
  //   Outport: '<S80>/pgw'

  localB->Sum[0] = localP->pgw_Y0;
  localB->Sum[1] = localP->pgw_Y0;
  localDW->Hpgw_MODE = false;
}

//
// Outputs for enable system:
//    '<S69>/Hpgw'
//    '<S108>/Hpgw'
//
void MulticopterModelClass::FixedwingModel_Hpgw(real_T rtu_Enable, const real_T
  rtu_L_wg[2], real_T rtu_sigma_wg, real_T rtu_sigma_wg_j, real_T rtu_Noise,
  real_T rtu_wingspan, B_Hpgw_FixedwingModel_T *localB, DW_Hpgw_FixedwingModel_T
  *localDW, P_Hpgw_FixedwingModel_T *localP)
{
  // Outputs for Enabled SubSystem: '<S69>/Hpgw' incorporates:
  //   EnablePort: '<S80>/Enable'

  if ((rtmIsMajorTimeStep((&FixedwingModel_M)) &&
       (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) &&
      rtsiIsModeUpdateTimeStep(&(&FixedwingModel_M)->solverInfo)) {
    if (rtu_Enable > 0.0) {
      if (!localDW->Hpgw_MODE) {
        FixedwingModel_Hpgw_Reset(localDW, localP);
        localDW->Hpgw_MODE = true;
      }
    } else if (localDW->Hpgw_MODE) {
      FixedwingModel_Hpgw_Disable(localB, localDW, localP);
    }
  }

  if (localDW->Hpgw_MODE) {
    real_T rtb_ap_idx_0;
    real_T rtb_ap_idx_1;
    real_T rtb_sp;
    real_T rtb_sp_idx_0;
    real_T tmp;

    // Product: '<S80>/w2'
    rtb_sp = rtu_L_wg[0] * rtu_wingspan;

    // Product: '<S80>/w1' incorporates:
    //   Constant: '<S80>/Constant2'
    //   Sqrt: '<S80>/sqrt'

    rtb_ap_idx_0 = localP->Constant2_Value / std::sqrt(rtb_sp);

    // Product: '<S80>/w2'
    rtb_sp_idx_0 = rtb_sp;
    rtb_sp = rtu_L_wg[1] * rtu_wingspan;

    // Product: '<S80>/w1' incorporates:
    //   Constant: '<S80>/Constant2'
    //   Sqrt: '<S80>/sqrt'

    rtb_ap_idx_1 = localP->Constant2_Value / std::sqrt(rtb_sp);
    if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
        (&FixedwingModel_M)->Timing.TaskCounters.TID[3] == 0) {
      // UnitDelay: '<S80>/Unit Delay'
      localB->UnitDelay[0] = localDW->UnitDelay_DSTATE[0];
      localB->UnitDelay[1] = localDW->UnitDelay_DSTATE[1];
    }

    // Product: '<S80>/w4'
    rtb_sp_idx_0 *= rtu_wingspan;

    // Math: '<S80>/Math Function' incorporates:
    //   Constant: '<S80>/Constant3'

    tmp = std::floor(localP->Constant3_Value);
    if ((rtb_sp_idx_0 < 0.0) && (localP->Constant3_Value > tmp)) {
      rtb_sp_idx_0 = -rt_powd_snf(-rtb_sp_idx_0, localP->Constant3_Value);
    } else {
      rtb_sp_idx_0 = rt_powd_snf(rtb_sp_idx_0, localP->Constant3_Value);
    }

    // Sum: '<S80>/Sum' incorporates:
    //   Constant: '<S80>/Constant'
    //   Constant: '<S80>/Constant1'
    //   Gain: '<S80>/2'
    //   Gain: '<S80>/dt'
    //   Product: '<S80>/Lug//V1'
    //   Product: '<S80>/Lug//V2'
    //   Product: '<S80>/w3'
    //   Sqrt: '<S80>/sqrt1'
    //   Sum: '<S80>/Sum1'

    localB->Sum[0] = localP->Constant1_Value / rtb_sp_idx_0 * rtu_sigma_wg * std::
      sqrt(localP->u_Gain * rtb_ap_idx_0) * rtu_Noise + (localP->Constant_Value
      - localP->dt_Gain * rtb_ap_idx_0) * localB->UnitDelay[0];

    // Product: '<S80>/w4'
    rtb_sp_idx_0 = rtb_sp * rtu_wingspan;

    // Math: '<S80>/Math Function' incorporates:
    //   Constant: '<S80>/Constant3'

    if ((rtb_sp_idx_0 < 0.0) && (localP->Constant3_Value > tmp)) {
      rtb_sp_idx_0 = -rt_powd_snf(-rtb_sp_idx_0, localP->Constant3_Value);
    } else {
      rtb_sp_idx_0 = rt_powd_snf(rtb_sp_idx_0, localP->Constant3_Value);
    }

    // Sum: '<S80>/Sum' incorporates:
    //   Constant: '<S80>/Constant'
    //   Constant: '<S80>/Constant1'
    //   Gain: '<S80>/2'
    //   Gain: '<S80>/dt'
    //   Product: '<S80>/Lug//V1'
    //   Product: '<S80>/Lug//V2'
    //   Product: '<S80>/w3'
    //   Sqrt: '<S80>/sqrt1'
    //   Sum: '<S80>/Sum1'

    localB->Sum[1] = localP->Constant1_Value / rtb_sp_idx_0 * rtu_sigma_wg_j *
      std::sqrt(localP->u_Gain * rtb_ap_idx_1) * rtu_Noise +
      (localP->Constant_Value - localP->dt_Gain * rtb_ap_idx_1) *
      localB->UnitDelay[1];
  }

  // End of Outputs for SubSystem: '<S69>/Hpgw'
}

//
// Update for enable system:
//    '<S69>/Hpgw'
//    '<S108>/Hpgw'
//
void MulticopterModelClass::FixedwingModel_Hpgw_Update(B_Hpgw_FixedwingModel_T
  *localB, DW_Hpgw_FixedwingModel_T *localDW)
{
  // Update for Enabled SubSystem: '<S69>/Hpgw' incorporates:
  //   EnablePort: '<S80>/Enable'

  if (localDW->Hpgw_MODE && (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
       (&FixedwingModel_M)->Timing.TaskCounters.TID[3] == 0)) {
    // Update for UnitDelay: '<S80>/Unit Delay'
    localDW->UnitDelay_DSTATE[0] = localB->Sum[0];
    localDW->UnitDelay_DSTATE[1] = localB->Sum[1];
  }

  // End of Update for SubSystem: '<S69>/Hpgw'
}

//
// System initialize for enable system:
//    '<S69>/Hqgw'
//    '<S108>/Hqgw'
//
void MulticopterModelClass::FixedwingModel_Hqgw_Init(B_Hqgw_FixedwingModel_T
  *localB, DW_Hqgw_FixedwingModel_T *localDW, P_Hqgw_FixedwingModel_T *localP)
{
  // InitializeConditions for UnitDelay: '<S81>/Unit Delay'
  localDW->UnitDelay_DSTATE[0] = localP->UnitDelay_InitialCondition;

  // InitializeConditions for UnitDelay: '<S81>/Unit Delay1'
  localDW->UnitDelay1_DSTATE[0] = localP->UnitDelay1_InitialCondition;

  // SystemInitialize for Sum: '<S81>/Sum1' incorporates:
  //   Outport: '<S81>/qgw'

  localB->Sum1[0] = localP->qgw_Y0;

  // InitializeConditions for UnitDelay: '<S81>/Unit Delay'
  localDW->UnitDelay_DSTATE[1] = localP->UnitDelay_InitialCondition;

  // InitializeConditions for UnitDelay: '<S81>/Unit Delay1'
  localDW->UnitDelay1_DSTATE[1] = localP->UnitDelay1_InitialCondition;

  // SystemInitialize for Sum: '<S81>/Sum1' incorporates:
  //   Outport: '<S81>/qgw'

  localB->Sum1[1] = localP->qgw_Y0;
}

//
// System reset for enable system:
//    '<S69>/Hqgw'
//    '<S108>/Hqgw'
//
void MulticopterModelClass::FixedwingModel_Hqgw_Reset(DW_Hqgw_FixedwingModel_T
  *localDW, P_Hqgw_FixedwingModel_T *localP)
{
  // InitializeConditions for UnitDelay: '<S81>/Unit Delay'
  localDW->UnitDelay_DSTATE[0] = localP->UnitDelay_InitialCondition;

  // InitializeConditions for UnitDelay: '<S81>/Unit Delay1'
  localDW->UnitDelay1_DSTATE[0] = localP->UnitDelay1_InitialCondition;

  // InitializeConditions for UnitDelay: '<S81>/Unit Delay'
  localDW->UnitDelay_DSTATE[1] = localP->UnitDelay_InitialCondition;

  // InitializeConditions for UnitDelay: '<S81>/Unit Delay1'
  localDW->UnitDelay1_DSTATE[1] = localP->UnitDelay1_InitialCondition;
}

//
// Disable for enable system:
//    '<S69>/Hqgw'
//    '<S108>/Hqgw'
//
void MulticopterModelClass::FixedwingModel_Hqgw_Disable(B_Hqgw_FixedwingModel_T *
  localB, DW_Hqgw_FixedwingModel_T *localDW, P_Hqgw_FixedwingModel_T *localP)
{
  // Disable for Sum: '<S81>/Sum1' incorporates:
  //   Outport: '<S81>/qgw'

  localB->Sum1[0] = localP->qgw_Y0;
  localB->Sum1[1] = localP->qgw_Y0;
  localDW->Hqgw_MODE = false;
}

//
// Outputs for enable system:
//    '<S69>/Hqgw'
//    '<S108>/Hqgw'
//
void MulticopterModelClass::FixedwingModel_Hqgw(real_T rtu_Enable, real_T rtu_V,
  const real_T rtu_wg[2], real_T rtu_wingspan, B_Hqgw_FixedwingModel_T *localB,
  DW_Hqgw_FixedwingModel_T *localDW, P_Hqgw_FixedwingModel_T *localP)
{
  // Outputs for Enabled SubSystem: '<S69>/Hqgw' incorporates:
  //   EnablePort: '<S81>/Enable'

  if ((rtmIsMajorTimeStep((&FixedwingModel_M)) &&
       (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) &&
      rtsiIsModeUpdateTimeStep(&(&FixedwingModel_M)->solverInfo)) {
    if (rtu_Enable > 0.0) {
      if (!localDW->Hqgw_MODE) {
        FixedwingModel_Hqgw_Reset(localDW, localP);
        localDW->Hqgw_MODE = true;
      }
    } else if (localDW->Hqgw_MODE) {
      FixedwingModel_Hqgw_Disable(localB, localDW, localP);
    }
  }

  if (localDW->Hqgw_MODE) {
    if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
        (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
      // Gain: '<S81>/dt1'
      localB->dt1 = localP->dt1_Gain * rtu_wingspan;

      // Sum: '<S81>/Sum2' incorporates:
      //   Constant: '<S81>/Constant'
      //   Gain: '<S81>/dt'
      //   Product: '<S81>/w1'

      localB->Sum2 = localP->Constant_Value - rtu_V / localB->dt1 *
        localP->dt_Gain;
    }

    if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
        (&FixedwingModel_M)->Timing.TaskCounters.TID[3] == 0) {
      // Product: '<S81>/Lug//V2' incorporates:
      //   UnitDelay: '<S81>/Unit Delay'

      localB->LugV2[0] = localB->Sum2 * localDW->UnitDelay_DSTATE[0];

      // UnitDelay: '<S81>/Unit Delay1'
      localB->UnitDelay1[0] = localDW->UnitDelay1_DSTATE[0];

      // Product: '<S81>/Lug//V2' incorporates:
      //   UnitDelay: '<S81>/Unit Delay'

      localB->LugV2[1] = localB->Sum2 * localDW->UnitDelay_DSTATE[1];

      // UnitDelay: '<S81>/Unit Delay1'
      localB->UnitDelay1[1] = localDW->UnitDelay1_DSTATE[1];
    }

    // Sum: '<S81>/Sum1' incorporates:
    //   Product: '<S81>/w2'
    //   Sum: '<S81>/Sum3'

    localB->Sum1[0] = localB->LugV2[0] - (rtu_wg[0] - localB->UnitDelay1[0]) /
      localB->dt1;
    localB->Sum1[1] = localB->LugV2[1] - (rtu_wg[1] - localB->UnitDelay1[1]) /
      localB->dt1;
  }

  // End of Outputs for SubSystem: '<S69>/Hqgw'
}

//
// Update for enable system:
//    '<S69>/Hqgw'
//    '<S108>/Hqgw'
//
void MulticopterModelClass::FixedwingModel_Hqgw_Update(const real_T rtu_wg[2],
  B_Hqgw_FixedwingModel_T *localB, DW_Hqgw_FixedwingModel_T *localDW)
{
  // Update for Enabled SubSystem: '<S69>/Hqgw' incorporates:
  //   EnablePort: '<S81>/Enable'

  if (localDW->Hqgw_MODE && (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
       (&FixedwingModel_M)->Timing.TaskCounters.TID[3] == 0)) {
    // Update for UnitDelay: '<S81>/Unit Delay'
    localDW->UnitDelay_DSTATE[0] = localB->Sum1[0];

    // Update for UnitDelay: '<S81>/Unit Delay1'
    localDW->UnitDelay1_DSTATE[0] = rtu_wg[0];

    // Update for UnitDelay: '<S81>/Unit Delay'
    localDW->UnitDelay_DSTATE[1] = localB->Sum1[1];

    // Update for UnitDelay: '<S81>/Unit Delay1'
    localDW->UnitDelay1_DSTATE[1] = rtu_wg[1];
  }

  // End of Update for SubSystem: '<S69>/Hqgw'
}

//
// System initialize for enable system:
//    '<S69>/Hrgw'
//    '<S108>/Hrgw'
//
void MulticopterModelClass::FixedwingModel_Hrgw_Init(B_Hrgw_FixedwingModel_T
  *localB, DW_Hrgw_FixedwingModel_T *localDW, P_Hrgw_FixedwingModel_T *localP)
{
  // InitializeConditions for UnitDelay: '<S82>/Unit Delay'
  localDW->UnitDelay_DSTATE[0] = localP->UnitDelay_InitialCondition;

  // InitializeConditions for UnitDelay: '<S82>/Unit Delay1'
  localDW->UnitDelay1_DSTATE[0] = localP->UnitDelay1_InitialCondition;

  // SystemInitialize for Sum: '<S82>/Sum1' incorporates:
  //   Outport: '<S82>/rgw'

  localB->Sum1[0] = localP->rgw_Y0;

  // InitializeConditions for UnitDelay: '<S82>/Unit Delay'
  localDW->UnitDelay_DSTATE[1] = localP->UnitDelay_InitialCondition;

  // InitializeConditions for UnitDelay: '<S82>/Unit Delay1'
  localDW->UnitDelay1_DSTATE[1] = localP->UnitDelay1_InitialCondition;

  // SystemInitialize for Sum: '<S82>/Sum1' incorporates:
  //   Outport: '<S82>/rgw'

  localB->Sum1[1] = localP->rgw_Y0;
}

//
// System reset for enable system:
//    '<S69>/Hrgw'
//    '<S108>/Hrgw'
//
void MulticopterModelClass::FixedwingModel_Hrgw_Reset(DW_Hrgw_FixedwingModel_T
  *localDW, P_Hrgw_FixedwingModel_T *localP)
{
  // InitializeConditions for UnitDelay: '<S82>/Unit Delay'
  localDW->UnitDelay_DSTATE[0] = localP->UnitDelay_InitialCondition;

  // InitializeConditions for UnitDelay: '<S82>/Unit Delay1'
  localDW->UnitDelay1_DSTATE[0] = localP->UnitDelay1_InitialCondition;

  // InitializeConditions for UnitDelay: '<S82>/Unit Delay'
  localDW->UnitDelay_DSTATE[1] = localP->UnitDelay_InitialCondition;

  // InitializeConditions for UnitDelay: '<S82>/Unit Delay1'
  localDW->UnitDelay1_DSTATE[1] = localP->UnitDelay1_InitialCondition;
}

//
// Disable for enable system:
//    '<S69>/Hrgw'
//    '<S108>/Hrgw'
//
void MulticopterModelClass::FixedwingModel_Hrgw_Disable(B_Hrgw_FixedwingModel_T *
  localB, DW_Hrgw_FixedwingModel_T *localDW, P_Hrgw_FixedwingModel_T *localP)
{
  // Disable for Sum: '<S82>/Sum1' incorporates:
  //   Outport: '<S82>/rgw'

  localB->Sum1[0] = localP->rgw_Y0;
  localB->Sum1[1] = localP->rgw_Y0;
  localDW->Hrgw_MODE = false;
}

//
// Outputs for enable system:
//    '<S69>/Hrgw'
//    '<S108>/Hrgw'
//
void MulticopterModelClass::FixedwingModel_Hrgw(real_T rtu_Enable, real_T rtu_V,
  const real_T rtu_vg[2], real_T rtu_wingspan, B_Hrgw_FixedwingModel_T *localB,
  DW_Hrgw_FixedwingModel_T *localDW, P_Hrgw_FixedwingModel_T *localP)
{
  // Outputs for Enabled SubSystem: '<S69>/Hrgw' incorporates:
  //   EnablePort: '<S82>/Enable'

  if ((rtmIsMajorTimeStep((&FixedwingModel_M)) &&
       (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) &&
      rtsiIsModeUpdateTimeStep(&(&FixedwingModel_M)->solverInfo)) {
    if (rtu_Enable > 0.0) {
      if (!localDW->Hrgw_MODE) {
        FixedwingModel_Hrgw_Reset(localDW, localP);
        localDW->Hrgw_MODE = true;
      }
    } else if (localDW->Hrgw_MODE) {
      FixedwingModel_Hrgw_Disable(localB, localDW, localP);
    }
  }

  if (localDW->Hrgw_MODE) {
    if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
        (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
      // Gain: '<S82>/dt1'
      localB->dt1 = localP->dt1_Gain * rtu_wingspan;

      // Sum: '<S82>/Sum2' incorporates:
      //   Constant: '<S82>/Constant'
      //   Gain: '<S82>/dt'
      //   Product: '<S82>/w1'

      localB->Sum2 = localP->Constant_Value - rtu_V / localB->dt1 *
        localP->dt_Gain;
    }

    if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
        (&FixedwingModel_M)->Timing.TaskCounters.TID[3] == 0) {
      // Product: '<S82>/Lug//V2' incorporates:
      //   UnitDelay: '<S82>/Unit Delay'

      localB->LugV2[0] = localB->Sum2 * localDW->UnitDelay_DSTATE[0];

      // UnitDelay: '<S82>/Unit Delay1'
      localB->UnitDelay1[0] = localDW->UnitDelay1_DSTATE[0];

      // Product: '<S82>/Lug//V2' incorporates:
      //   UnitDelay: '<S82>/Unit Delay'

      localB->LugV2[1] = localB->Sum2 * localDW->UnitDelay_DSTATE[1];

      // UnitDelay: '<S82>/Unit Delay1'
      localB->UnitDelay1[1] = localDW->UnitDelay1_DSTATE[1];
    }

    // Sum: '<S82>/Sum1' incorporates:
    //   Product: '<S82>/w2'
    //   Sum: '<S82>/Sum3'

    localB->Sum1[0] = (rtu_vg[0] - localB->UnitDelay1[0]) / localB->dt1 +
      localB->LugV2[0];
    localB->Sum1[1] = (rtu_vg[1] - localB->UnitDelay1[1]) / localB->dt1 +
      localB->LugV2[1];
  }

  // End of Outputs for SubSystem: '<S69>/Hrgw'
}

//
// Update for enable system:
//    '<S69>/Hrgw'
//    '<S108>/Hrgw'
//
void MulticopterModelClass::FixedwingModel_Hrgw_Update(const real_T rtu_vg[2],
  B_Hrgw_FixedwingModel_T *localB, DW_Hrgw_FixedwingModel_T *localDW)
{
  // Update for Enabled SubSystem: '<S69>/Hrgw' incorporates:
  //   EnablePort: '<S82>/Enable'

  if (localDW->Hrgw_MODE && (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
       (&FixedwingModel_M)->Timing.TaskCounters.TID[3] == 0)) {
    // Update for UnitDelay: '<S82>/Unit Delay'
    localDW->UnitDelay_DSTATE[0] = localB->Sum1[0];

    // Update for UnitDelay: '<S82>/Unit Delay1'
    localDW->UnitDelay1_DSTATE[0] = rtu_vg[0];

    // Update for UnitDelay: '<S82>/Unit Delay'
    localDW->UnitDelay_DSTATE[1] = localB->Sum1[1];

    // Update for UnitDelay: '<S82>/Unit Delay1'
    localDW->UnitDelay1_DSTATE[1] = rtu_vg[1];
  }

  // End of Update for SubSystem: '<S69>/Hrgw'
}

//
// System initialize for enable system:
//    '<S70>/Hugw(z)'
//    '<S109>/Hugw(z)'
//
void MulticopterModelClass::FixedwingModel_Hugwz_Init(B_Hugwz_FixedwingModel_T
  *localB, DW_Hugwz_FixedwingModel_T *localDW, P_Hugwz_FixedwingModel_T *localP)
{
  // InitializeConditions for UnitDelay: '<S83>/Unit Delay'
  localDW->UnitDelay_DSTATE[0] = localP->UnitDelay_InitialCondition;

  // SystemInitialize for Sum: '<S83>/Sum' incorporates:
  //   Outport: '<S83>/ugw'

  localB->Sum[0] = localP->ugw_Y0;

  // InitializeConditions for UnitDelay: '<S83>/Unit Delay'
  localDW->UnitDelay_DSTATE[1] = localP->UnitDelay_InitialCondition;

  // SystemInitialize for Sum: '<S83>/Sum' incorporates:
  //   Outport: '<S83>/ugw'

  localB->Sum[1] = localP->ugw_Y0;
}

//
// System reset for enable system:
//    '<S70>/Hugw(z)'
//    '<S109>/Hugw(z)'
//
void MulticopterModelClass::FixedwingModel_Hugwz_Reset(DW_Hugwz_FixedwingModel_T
  *localDW, P_Hugwz_FixedwingModel_T *localP)
{
  // InitializeConditions for UnitDelay: '<S83>/Unit Delay'
  localDW->UnitDelay_DSTATE[0] = localP->UnitDelay_InitialCondition;
  localDW->UnitDelay_DSTATE[1] = localP->UnitDelay_InitialCondition;
}

//
// Disable for enable system:
//    '<S70>/Hugw(z)'
//    '<S109>/Hugw(z)'
//
void MulticopterModelClass::FixedwingModel_Hugwz_Disable
  (B_Hugwz_FixedwingModel_T *localB, DW_Hugwz_FixedwingModel_T *localDW,
   P_Hugwz_FixedwingModel_T *localP)
{
  // Disable for Sum: '<S83>/Sum' incorporates:
  //   Outport: '<S83>/ugw'

  localB->Sum[0] = localP->ugw_Y0;
  localB->Sum[1] = localP->ugw_Y0;
  localDW->Hugwz_MODE = false;
}

//
// Outputs for enable system:
//    '<S70>/Hugw(z)'
//    '<S109>/Hugw(z)'
//
void MulticopterModelClass::FixedwingModel_Hugwz(real_T rtu_Enable, real_T rtu_V,
  real_T rtu_L_ug, real_T rtu_L_ug_o, real_T rtu_sigma_ug, real_T rtu_sigma_ug_o,
  real_T rtu_Noise, B_Hugwz_FixedwingModel_T *localB, DW_Hugwz_FixedwingModel_T *
  localDW, P_Hugwz_FixedwingModel_T *localP)
{
  // Outputs for Enabled SubSystem: '<S70>/Hugw(z)' incorporates:
  //   EnablePort: '<S83>/Enable'

  if ((rtmIsMajorTimeStep((&FixedwingModel_M)) &&
       (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) &&
      rtsiIsModeUpdateTimeStep(&(&FixedwingModel_M)->solverInfo)) {
    if (rtu_Enable > 0.0) {
      if (!localDW->Hugwz_MODE) {
        FixedwingModel_Hugwz_Reset(localDW, localP);
        localDW->Hugwz_MODE = true;
      }
    } else if (localDW->Hugwz_MODE) {
      FixedwingModel_Hugwz_Disable(localB, localDW, localP);
    }
  }

  if (localDW->Hugwz_MODE) {
    real_T rtb_VLug_idx_0;
    real_T rtb_VLug_idx_1;

    // Product: '<S83>/V//Lug'
    rtb_VLug_idx_0 = rtu_V / rtu_L_ug;
    rtb_VLug_idx_1 = rtu_V / rtu_L_ug_o;
    if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
        (&FixedwingModel_M)->Timing.TaskCounters.TID[3] == 0) {
      // UnitDelay: '<S83>/Unit Delay'
      localB->UnitDelay[0] = localDW->UnitDelay_DSTATE[0];
      localB->UnitDelay[1] = localDW->UnitDelay_DSTATE[1];
    }

    // Sum: '<S83>/Sum' incorporates:
    //   Constant: '<S83>/Constant'
    //   Gain: '<S83>/2'
    //   Gain: '<S83>/dt'
    //   Product: '<S83>/Lug//V1'
    //   Product: '<S83>/Lug//V2'
    //   Sqrt: '<S83>/sqrt'
    //   Sum: '<S83>/Sum1'

    localB->Sum[0] = (localP->Constant_Value - localP->dt_Gain * rtb_VLug_idx_0)
      * localB->UnitDelay[0] + std::sqrt(localP->u_Gain * rtb_VLug_idx_0) *
      rtu_Noise * rtu_sigma_ug;
    localB->Sum[1] = (localP->Constant_Value - localP->dt_Gain * rtb_VLug_idx_1)
      * localB->UnitDelay[1] + std::sqrt(localP->u_Gain * rtb_VLug_idx_1) *
      rtu_Noise * rtu_sigma_ug_o;
  }

  // End of Outputs for SubSystem: '<S70>/Hugw(z)'
}

//
// Update for enable system:
//    '<S70>/Hugw(z)'
//    '<S109>/Hugw(z)'
//
void MulticopterModelClass::FixedwingModel_Hugwz_Update(B_Hugwz_FixedwingModel_T
  *localB, DW_Hugwz_FixedwingModel_T *localDW)
{
  // Update for Enabled SubSystem: '<S70>/Hugw(z)' incorporates:
  //   EnablePort: '<S83>/Enable'

  if (localDW->Hugwz_MODE && (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
       (&FixedwingModel_M)->Timing.TaskCounters.TID[3] == 0)) {
    // Update for UnitDelay: '<S83>/Unit Delay'
    localDW->UnitDelay_DSTATE[0] = localB->Sum[0];
    localDW->UnitDelay_DSTATE[1] = localB->Sum[1];
  }

  // End of Update for SubSystem: '<S70>/Hugw(z)'
}

//
// System initialize for enable system:
//    '<S70>/Hvgw(z)'
//    '<S109>/Hvgw(z)'
//
void MulticopterModelClass::FixedwingModel_Hvgwz_Init(B_Hvgwz_FixedwingModel_T
  *localB, DW_Hvgwz_FixedwingModel_T *localDW, P_Hvgwz_FixedwingModel_T *localP)
{
  // InitializeConditions for UnitDelay: '<S84>/Unit Delay'
  localDW->UnitDelay_DSTATE[0] = localP->UnitDelay_InitialCondition;

  // SystemInitialize for Sum: '<S84>/Sum' incorporates:
  //   Outport: '<S84>/vgw'

  localB->Sum[0] = localP->vgw_Y0;

  // InitializeConditions for UnitDelay: '<S84>/Unit Delay'
  localDW->UnitDelay_DSTATE[1] = localP->UnitDelay_InitialCondition;

  // SystemInitialize for Sum: '<S84>/Sum' incorporates:
  //   Outport: '<S84>/vgw'

  localB->Sum[1] = localP->vgw_Y0;
}

//
// System reset for enable system:
//    '<S70>/Hvgw(z)'
//    '<S109>/Hvgw(z)'
//
void MulticopterModelClass::FixedwingModel_Hvgwz_Reset(DW_Hvgwz_FixedwingModel_T
  *localDW, P_Hvgwz_FixedwingModel_T *localP)
{
  // InitializeConditions for UnitDelay: '<S84>/Unit Delay'
  localDW->UnitDelay_DSTATE[0] = localP->UnitDelay_InitialCondition;
  localDW->UnitDelay_DSTATE[1] = localP->UnitDelay_InitialCondition;
}

//
// Disable for enable system:
//    '<S70>/Hvgw(z)'
//    '<S109>/Hvgw(z)'
//
void MulticopterModelClass::FixedwingModel_Hvgwz_Disable
  (B_Hvgwz_FixedwingModel_T *localB, DW_Hvgwz_FixedwingModel_T *localDW,
   P_Hvgwz_FixedwingModel_T *localP)
{
  // Disable for Sum: '<S84>/Sum' incorporates:
  //   Outport: '<S84>/vgw'

  localB->Sum[0] = localP->vgw_Y0;
  localB->Sum[1] = localP->vgw_Y0;
  localDW->Hvgwz_MODE = false;
}

//
// Outputs for enable system:
//    '<S70>/Hvgw(z)'
//    '<S109>/Hvgw(z)'
//
void MulticopterModelClass::FixedwingModel_Hvgwz(real_T rtu_Enable, real_T
  rtu_sigma_vg, real_T rtu_sigma_vg_i, const real_T rtu_L_vg[2], real_T rtu_V,
  real_T rtu_Noise, B_Hvgwz_FixedwingModel_T *localB, DW_Hvgwz_FixedwingModel_T *
  localDW, P_Hvgwz_FixedwingModel_T *localP)
{
  // Outputs for Enabled SubSystem: '<S70>/Hvgw(z)' incorporates:
  //   EnablePort: '<S84>/Enable'

  if ((rtmIsMajorTimeStep((&FixedwingModel_M)) &&
       (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) &&
      rtsiIsModeUpdateTimeStep(&(&FixedwingModel_M)->solverInfo)) {
    if (rtu_Enable > 0.0) {
      if (!localDW->Hvgwz_MODE) {
        FixedwingModel_Hvgwz_Reset(localDW, localP);
        localDW->Hvgwz_MODE = true;
      }
    } else if (localDW->Hvgwz_MODE) {
      FixedwingModel_Hvgwz_Disable(localB, localDW, localP);
    }
  }

  if (localDW->Hvgwz_MODE) {
    real_T rtb_VLvg_idx_0;
    real_T rtb_VLvg_idx_1;

    // Product: '<S84>/V//Lvg'
    rtb_VLvg_idx_0 = rtu_V / rtu_L_vg[0];
    rtb_VLvg_idx_1 = rtu_V / rtu_L_vg[1];
    if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
        (&FixedwingModel_M)->Timing.TaskCounters.TID[3] == 0) {
      // UnitDelay: '<S84>/Unit Delay'
      localB->UnitDelay[0] = localDW->UnitDelay_DSTATE[0];
      localB->UnitDelay[1] = localDW->UnitDelay_DSTATE[1];
    }

    // Sum: '<S84>/Sum' incorporates:
    //   Constant: '<S84>/Constant'
    //   Gain: '<S84>/2'
    //   Gain: '<S84>/dt'
    //   Product: '<S84>/Lug//V1'
    //   Product: '<S84>/Lug//V2'
    //   Sqrt: '<S84>/sqrt'
    //   Sum: '<S84>/Sum1'

    localB->Sum[0] = (localP->Constant_Value - localP->dt_Gain * rtb_VLvg_idx_0)
      * localB->UnitDelay[0] + std::sqrt(localP->u_Gain * rtb_VLvg_idx_0) *
      rtu_Noise * rtu_sigma_vg;
    localB->Sum[1] = (localP->Constant_Value - localP->dt_Gain * rtb_VLvg_idx_1)
      * localB->UnitDelay[1] + std::sqrt(localP->u_Gain * rtb_VLvg_idx_1) *
      rtu_Noise * rtu_sigma_vg_i;
  }

  // End of Outputs for SubSystem: '<S70>/Hvgw(z)'
}

//
// Update for enable system:
//    '<S70>/Hvgw(z)'
//    '<S109>/Hvgw(z)'
//
void MulticopterModelClass::FixedwingModel_Hvgwz_Update(B_Hvgwz_FixedwingModel_T
  *localB, DW_Hvgwz_FixedwingModel_T *localDW)
{
  // Update for Enabled SubSystem: '<S70>/Hvgw(z)' incorporates:
  //   EnablePort: '<S84>/Enable'

  if (localDW->Hvgwz_MODE && (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
       (&FixedwingModel_M)->Timing.TaskCounters.TID[3] == 0)) {
    // Update for UnitDelay: '<S84>/Unit Delay'
    localDW->UnitDelay_DSTATE[0] = localB->Sum[0];
    localDW->UnitDelay_DSTATE[1] = localB->Sum[1];
  }

  // End of Update for SubSystem: '<S70>/Hvgw(z)'
}

//
// System initialize for enable system:
//    '<S70>/Hwgw(z)'
//    '<S109>/Hwgw(z)'
//
void MulticopterModelClass::FixedwingModel_Hwgwz_Init(B_Hwgwz_FixedwingModel_T
  *localB, DW_Hwgwz_FixedwingModel_T *localDW, P_Hwgwz_FixedwingModel_T *localP)
{
  // InitializeConditions for UnitDelay: '<S85>/Unit Delay'
  localDW->UnitDelay_DSTATE[0] = localP->UnitDelay_InitialCondition;

  // SystemInitialize for Sum: '<S85>/Sum' incorporates:
  //   Outport: '<S85>/wgw'

  localB->Sum[0] = localP->wgw_Y0;

  // InitializeConditions for UnitDelay: '<S85>/Unit Delay'
  localDW->UnitDelay_DSTATE[1] = localP->UnitDelay_InitialCondition;

  // SystemInitialize for Sum: '<S85>/Sum' incorporates:
  //   Outport: '<S85>/wgw'

  localB->Sum[1] = localP->wgw_Y0;
}

//
// System reset for enable system:
//    '<S70>/Hwgw(z)'
//    '<S109>/Hwgw(z)'
//
void MulticopterModelClass::FixedwingModel_Hwgwz_Reset(DW_Hwgwz_FixedwingModel_T
  *localDW, P_Hwgwz_FixedwingModel_T *localP)
{
  // InitializeConditions for UnitDelay: '<S85>/Unit Delay'
  localDW->UnitDelay_DSTATE[0] = localP->UnitDelay_InitialCondition;
  localDW->UnitDelay_DSTATE[1] = localP->UnitDelay_InitialCondition;
}

//
// Disable for enable system:
//    '<S70>/Hwgw(z)'
//    '<S109>/Hwgw(z)'
//
void MulticopterModelClass::FixedwingModel_Hwgwz_Disable
  (B_Hwgwz_FixedwingModel_T *localB, DW_Hwgwz_FixedwingModel_T *localDW,
   P_Hwgwz_FixedwingModel_T *localP)
{
  // Disable for Sum: '<S85>/Sum' incorporates:
  //   Outport: '<S85>/wgw'

  localB->Sum[0] = localP->wgw_Y0;
  localB->Sum[1] = localP->wgw_Y0;
  localDW->Hwgwz_MODE = false;
}

//
// Outputs for enable system:
//    '<S70>/Hwgw(z)'
//    '<S109>/Hwgw(z)'
//
void MulticopterModelClass::FixedwingModel_Hwgwz(real_T rtu_Enable, real_T rtu_V,
  const real_T rtu_L_wg[2], real_T rtu_sigma_wg, real_T rtu_sigma_wg_n, real_T
  rtu_Noise, B_Hwgwz_FixedwingModel_T *localB, DW_Hwgwz_FixedwingModel_T
  *localDW, P_Hwgwz_FixedwingModel_T *localP)
{
  // Outputs for Enabled SubSystem: '<S70>/Hwgw(z)' incorporates:
  //   EnablePort: '<S85>/Enable'

  if ((rtmIsMajorTimeStep((&FixedwingModel_M)) &&
       (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) &&
      rtsiIsModeUpdateTimeStep(&(&FixedwingModel_M)->solverInfo)) {
    if (rtu_Enable > 0.0) {
      if (!localDW->Hwgwz_MODE) {
        FixedwingModel_Hwgwz_Reset(localDW, localP);
        localDW->Hwgwz_MODE = true;
      }
    } else if (localDW->Hwgwz_MODE) {
      FixedwingModel_Hwgwz_Disable(localB, localDW, localP);
    }
  }

  if (localDW->Hwgwz_MODE) {
    real_T rtb_VLwg_idx_0;
    real_T rtb_VLwg_idx_1;

    // Product: '<S85>/V//Lwg'
    rtb_VLwg_idx_0 = rtu_V / rtu_L_wg[0];
    rtb_VLwg_idx_1 = rtu_V / rtu_L_wg[1];
    if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
        (&FixedwingModel_M)->Timing.TaskCounters.TID[3] == 0) {
      // UnitDelay: '<S85>/Unit Delay'
      localB->UnitDelay[0] = localDW->UnitDelay_DSTATE[0];
      localB->UnitDelay[1] = localDW->UnitDelay_DSTATE[1];
    }

    // Sum: '<S85>/Sum' incorporates:
    //   Constant: '<S85>/Constant'
    //   Gain: '<S85>/2'
    //   Gain: '<S85>/dt'
    //   Product: '<S85>/Lug//V1'
    //   Product: '<S85>/Lug//V2'
    //   Sqrt: '<S85>/sqrt'
    //   Sum: '<S85>/Sum1'

    localB->Sum[0] = (localP->Constant_Value - localP->dt_Gain * rtb_VLwg_idx_0)
      * localB->UnitDelay[0] + std::sqrt(localP->u_Gain * rtb_VLwg_idx_0) *
      rtu_Noise * rtu_sigma_wg;
    localB->Sum[1] = (localP->Constant_Value - localP->dt_Gain * rtb_VLwg_idx_1)
      * localB->UnitDelay[1] + std::sqrt(localP->u_Gain * rtb_VLwg_idx_1) *
      rtu_Noise * rtu_sigma_wg_n;
  }

  // End of Outputs for SubSystem: '<S70>/Hwgw(z)'
}

//
// Update for enable system:
//    '<S70>/Hwgw(z)'
//    '<S109>/Hwgw(z)'
//
void MulticopterModelClass::FixedwingModel_Hwgwz_Update(B_Hwgwz_FixedwingModel_T
  *localB, DW_Hwgwz_FixedwingModel_T *localDW)
{
  // Update for Enabled SubSystem: '<S70>/Hwgw(z)' incorporates:
  //   EnablePort: '<S85>/Enable'

  if (localDW->Hwgwz_MODE && (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
       (&FixedwingModel_M)->Timing.TaskCounters.TID[3] == 0)) {
    // Update for UnitDelay: '<S85>/Unit Delay'
    localDW->UnitDelay_DSTATE[0] = localB->Sum[0];
    localDW->UnitDelay_DSTATE[1] = localB->Sum[1];
  }

  // End of Update for SubSystem: '<S70>/Hwgw(z)'
}

//
// Output and update for action system:
//    '<S74>/Low altitude  rates'
//    '<S113>/Low altitude  rates'
//    '<S532>/Low altitude  rates'
//
void MulticopterModelClass::FixedwingModel_Lowaltituderates(const real_T
  rtu_DCM[9], const real_T rtu_pgw_hl[2], const real_T rtu_qgw_hl[2], const
  real_T rtu_rgw_hl[2], real_T rtu_Winddirection, real_T rty_pgwqgwrgw[3])
{
  real_T rtb_TrigonometricFunction1_o1;
  real_T rtb_TrigonometricFunction1_o2;
  real_T rtb_VectorConcatenate_j_idx_0;
  real_T rtb_VectorConcatenate_j_idx_2;

  // SignalConversion generated from: '<S94>/Vector Concatenate'
  rtb_VectorConcatenate_j_idx_2 = rtu_rgw_hl[0];

  // Trigonometry: '<S95>/Trigonometric Function1'
  rtb_TrigonometricFunction1_o1 = std::sin(rtu_Winddirection);
  rtb_TrigonometricFunction1_o2 = std::cos(rtu_Winddirection);

  // Sum: '<S95>/Sum' incorporates:
  //   Product: '<S95>/Product1'
  //   Product: '<S95>/Product2'

  rtb_VectorConcatenate_j_idx_0 = rtu_pgw_hl[0] * rtb_TrigonometricFunction1_o2
    - rtb_TrigonometricFunction1_o1 * rtu_qgw_hl[0];

  // Sum: '<S95>/Sum1' incorporates:
  //   Product: '<S95>/Product1'
  //   Product: '<S95>/Product2'

  rtb_TrigonometricFunction1_o1 = rtb_TrigonometricFunction1_o1 * rtu_pgw_hl[0]
    + rtu_qgw_hl[0] * rtb_TrigonometricFunction1_o2;

  // Reshape: '<S94>/Reshape1' incorporates:
  //   Concatenate: '<S94>/Vector Concatenate'
  //   Product: '<S94>/Product'

  for (int32_T i = 0; i < 3; i++) {
    rty_pgwqgwrgw[i] = 0.0;
    rty_pgwqgwrgw[i] += rtu_DCM[i] * rtb_VectorConcatenate_j_idx_0;
    rty_pgwqgwrgw[i] += rtu_DCM[i + 3] * rtb_TrigonometricFunction1_o1;
    rty_pgwqgwrgw[i] += rtu_DCM[i + 6] * rtb_VectorConcatenate_j_idx_2;
  }

  // End of Reshape: '<S94>/Reshape1'
}

//
// Output and update for action system:
//    '<S74>/Interpolate  rates'
//    '<S113>/Interpolate  rates'
//    '<S532>/Interpolate  rates'
//
void MulticopterModelClass::FixedwingModel_Interpolaterates(const real_T
  rtu_pgw_hl[2], const real_T rtu_qgw_hl[2], const real_T rtu_rgw_hl[2], const
  real_T rtu_DCM[9], real_T rtu_Winddirection, real_T rtu_Altitude, real_T
  rty_pgwqgwrgw[3], P_Interpolaterates_FixedwingM_T *localP)
{
  real_T rtb_Product_ms[3];
  real_T rtb_TrigonometricFunction_o1;
  real_T rtb_TrigonometricFunction_o2;
  real_T rtb_VectorConcatenate_d_idx_0;

  // Trigonometry: '<S93>/Trigonometric Function'
  rtb_TrigonometricFunction_o1 = std::sin(rtu_Winddirection);
  rtb_TrigonometricFunction_o2 = std::cos(rtu_Winddirection);

  // Sum: '<S93>/Sum' incorporates:
  //   Product: '<S93>/Product1'
  //   Product: '<S93>/Product2'

  rtb_VectorConcatenate_d_idx_0 = rtu_pgw_hl[0] * rtb_TrigonometricFunction_o2 -
    rtb_TrigonometricFunction_o1 * rtu_qgw_hl[0];

  // Sum: '<S93>/Sum1' incorporates:
  //   Product: '<S93>/Product1'
  //   Product: '<S93>/Product2'

  rtb_TrigonometricFunction_o1 = rtb_TrigonometricFunction_o1 * rtu_pgw_hl[0] +
    rtu_qgw_hl[0] * rtb_TrigonometricFunction_o2;

  // SignalConversion generated from: '<S92>/Vector Concatenate'
  rtb_TrigonometricFunction_o2 = rtu_rgw_hl[0];

  // Product: '<S92>/Product' incorporates:
  //   Concatenate: '<S92>/Vector Concatenate'

  for (int32_T i = 0; i < 3; i++) {
    rtb_Product_ms[i] = (rtu_DCM[i + 3] * rtb_TrigonometricFunction_o1 +
                         rtu_DCM[i] * rtb_VectorConcatenate_d_idx_0) + rtu_DCM[i
      + 6] * rtb_TrigonometricFunction_o2;
  }

  // End of Product: '<S92>/Product'

  // Sum: '<S88>/Sum1' incorporates:
  //   Constant: '<S88>/max_height_low'

  rtb_TrigonometricFunction_o1 = rtu_Altitude - localP->max_height_low_Value;

  // Sum: '<S88>/Sum' incorporates:
  //   Constant: '<S88>/max_height_low'
  //   Constant: '<S88>/min_height_high'

  rtb_TrigonometricFunction_o2 = localP->min_height_high_Value -
    localP->max_height_low_Value;

  // Sum: '<S88>/Sum3' incorporates:
  //   Product: '<S88>/Product1'
  //   Sum: '<S88>/Sum2'

  rty_pgwqgwrgw[0] = (rtu_pgw_hl[1] - rtb_Product_ms[0]) *
    rtb_TrigonometricFunction_o1 / rtb_TrigonometricFunction_o2 +
    rtb_Product_ms[0];
  rty_pgwqgwrgw[1] = (rtu_qgw_hl[1] - rtb_Product_ms[1]) *
    rtb_TrigonometricFunction_o1 / rtb_TrigonometricFunction_o2 +
    rtb_Product_ms[1];
  rty_pgwqgwrgw[2] = (rtu_rgw_hl[1] - rtb_Product_ms[2]) *
    rtb_TrigonometricFunction_o1 / rtb_TrigonometricFunction_o2 +
    rtb_Product_ms[2];
}

//
// Output and update for action system:
//    '<S75>/Low altitude  velocities'
//    '<S114>/Low altitude  velocities'
//    '<S533>/Low altitude  velocities'
//
void MulticopterModelClass::Fixedwing_Lowaltitudevelocities(const real_T
  rtu_DCM[9], const real_T rtu_ugw_hl[2], const real_T rtu_vgw_hl[2], const
  real_T rtu_wgw_hl[2], real_T rtu_Winddirection, real_T rty_ugwvgwwgw[3])
{
  real_T rtb_TrigonometricFunction_o1;
  real_T rtb_TrigonometricFunction_o2;
  real_T rtb_VectorConcatenate_m_idx_0;
  real_T rtb_VectorConcatenate_m_idx_2;

  // SignalConversion generated from: '<S102>/Vector Concatenate'
  rtb_VectorConcatenate_m_idx_2 = rtu_wgw_hl[0];

  // Trigonometry: '<S103>/Trigonometric Function'
  rtb_TrigonometricFunction_o1 = std::sin(rtu_Winddirection);
  rtb_TrigonometricFunction_o2 = std::cos(rtu_Winddirection);

  // Sum: '<S103>/Sum' incorporates:
  //   Product: '<S103>/Product1'
  //   Product: '<S103>/Product2'

  rtb_VectorConcatenate_m_idx_0 = rtu_ugw_hl[0] * rtb_TrigonometricFunction_o2 -
    rtb_TrigonometricFunction_o1 * rtu_vgw_hl[0];

  // Sum: '<S103>/Sum1' incorporates:
  //   Product: '<S103>/Product1'
  //   Product: '<S103>/Product2'

  rtb_TrigonometricFunction_o1 = rtb_TrigonometricFunction_o1 * rtu_ugw_hl[0] +
    rtu_vgw_hl[0] * rtb_TrigonometricFunction_o2;

  // Reshape: '<S102>/Reshape1' incorporates:
  //   Concatenate: '<S102>/Vector Concatenate'
  //   Product: '<S102>/Product'

  for (int32_T i = 0; i < 3; i++) {
    rty_ugwvgwwgw[i] = 0.0;
    rty_ugwvgwwgw[i] += rtu_DCM[i] * rtb_VectorConcatenate_m_idx_0;
    rty_ugwvgwwgw[i] += rtu_DCM[i + 3] * rtb_TrigonometricFunction_o1;
    rty_ugwvgwwgw[i] += rtu_DCM[i + 6] * rtb_VectorConcatenate_m_idx_2;
  }

  // End of Reshape: '<S102>/Reshape1'
}

//
// Output and update for action system:
//    '<S75>/Interpolate  velocities'
//    '<S114>/Interpolate  velocities'
//    '<S533>/Interpolate  velocities'
//
void MulticopterModelClass::Fixedwing_Interpolatevelocities(const real_T
  rtu_ugw_hl[2], const real_T rtu_vgw_hl[2], const real_T rtu_wgw_hl[2], const
  real_T rtu_DCM[9], real_T rtu_Winddirection, real_T rtu_Altitude, real_T
  rty_ugwvgwwgw[3], P_Interpolatevelocities_Fixed_T *localP)
{
  real_T rtb_Product_a4[3];
  real_T rtb_TrigonometricFunction_o1;
  real_T rtb_TrigonometricFunction_o2;
  real_T rtb_VectorConcatenate_p_idx_0;

  // Trigonometry: '<S101>/Trigonometric Function'
  rtb_TrigonometricFunction_o1 = std::sin(rtu_Winddirection);
  rtb_TrigonometricFunction_o2 = std::cos(rtu_Winddirection);

  // Sum: '<S101>/Sum' incorporates:
  //   Product: '<S101>/Product1'
  //   Product: '<S101>/Product2'

  rtb_VectorConcatenate_p_idx_0 = rtu_ugw_hl[0] * rtb_TrigonometricFunction_o2 -
    rtb_TrigonometricFunction_o1 * rtu_vgw_hl[0];

  // Sum: '<S101>/Sum1' incorporates:
  //   Product: '<S101>/Product1'
  //   Product: '<S101>/Product2'

  rtb_TrigonometricFunction_o1 = rtb_TrigonometricFunction_o1 * rtu_ugw_hl[0] +
    rtu_vgw_hl[0] * rtb_TrigonometricFunction_o2;

  // SignalConversion generated from: '<S100>/Vector Concatenate'
  rtb_TrigonometricFunction_o2 = rtu_wgw_hl[0];

  // Product: '<S100>/Product' incorporates:
  //   Concatenate: '<S100>/Vector Concatenate'

  for (int32_T i = 0; i < 3; i++) {
    rtb_Product_a4[i] = (rtu_DCM[i + 3] * rtb_TrigonometricFunction_o1 +
                         rtu_DCM[i] * rtb_VectorConcatenate_p_idx_0) + rtu_DCM[i
      + 6] * rtb_TrigonometricFunction_o2;
  }

  // End of Product: '<S100>/Product'

  // Sum: '<S96>/Sum1' incorporates:
  //   Constant: '<S96>/max_height_low'

  rtb_TrigonometricFunction_o1 = rtu_Altitude - localP->max_height_low_Value;

  // Sum: '<S96>/Sum' incorporates:
  //   Constant: '<S96>/max_height_low'
  //   Constant: '<S96>/min_height_high'

  rtb_TrigonometricFunction_o2 = localP->min_height_high_Value -
    localP->max_height_low_Value;

  // Sum: '<S96>/Sum3' incorporates:
  //   Product: '<S96>/Product1'
  //   Sum: '<S96>/Sum2'

  rty_ugwvgwwgw[0] = (rtu_ugw_hl[1] - rtb_Product_a4[0]) *
    rtb_TrigonometricFunction_o1 / rtb_TrigonometricFunction_o2 +
    rtb_Product_a4[0];
  rty_ugwvgwwgw[1] = (rtu_vgw_hl[1] - rtb_Product_a4[1]) *
    rtb_TrigonometricFunction_o1 / rtb_TrigonometricFunction_o2 +
    rtb_Product_a4[1];
  rty_ugwvgwwgw[2] = (rtu_wgw_hl[1] - rtb_Product_a4[2]) *
    rtb_TrigonometricFunction_o1 / rtb_TrigonometricFunction_o2 +
    rtb_Product_a4[2];
}

//
// Output and update for action system:
//    '<S151>/Positive Trace'
//    '<S409>/Positive Trace'
//    '<S410>/Positive Trace'
//
void MulticopterModelClass::FixedwingModel_PositiveTrace(real_T rtu_traceDCM,
  const real_T rtu_DCM[9], real_T *rty_qwqxqyqz, real_T rty_qwqxqyqz_h[3],
  P_PositiveTrace_FixedwingMode_T *localP)
{
  real_T rtb_Gain1_a;

  // Sqrt: '<S156>/sqrt' incorporates:
  //   Constant: '<S156>/Constant'
  //   Sum: '<S156>/Sum'

  rtb_Gain1_a = std::sqrt(rtu_traceDCM + localP->Constant_Value);

  // Gain: '<S156>/Gain'
  *rty_qwqxqyqz = localP->Gain_Gain * rtb_Gain1_a;

  // Gain: '<S156>/Gain1'
  rtb_Gain1_a *= localP->Gain1_Gain;

  // Product: '<S156>/Product' incorporates:
  //   Sum: '<S178>/Add'
  //   Sum: '<S179>/Add'
  //   Sum: '<S180>/Add'

  rty_qwqxqyqz_h[0] = (rtu_DCM[7] - rtu_DCM[5]) / rtb_Gain1_a;
  rty_qwqxqyqz_h[1] = (rtu_DCM[2] - rtu_DCM[6]) / rtb_Gain1_a;
  rty_qwqxqyqz_h[2] = (rtu_DCM[3] - rtu_DCM[1]) / rtb_Gain1_a;
}

//
// System initialize for action system:
//    '<S151>/Negative Trace'
//    '<S409>/Negative Trace'
//    '<S410>/Negative Trace'
//
void MulticopterModelClass::FixedwingMod_NegativeTrace_Init
  (DW_NegativeTrace_FixedwingMod_T *localDW)
{
  // Start for If: '<S155>/Find Maximum Diagonal Value'
  localDW->FindMaximumDiagonalValue_Active = -1;
}

//
// Output and update for action system:
//    '<S151>/Negative Trace'
//    '<S409>/Negative Trace'
//    '<S410>/Negative Trace'
//
void MulticopterModelClass::FixedwingModel_NegativeTrace(const real_T rtu_DCM[9],
  real_T rty_qwqxqyqz[4], DW_NegativeTrace_FixedwingMod_T *localDW,
  P_NegativeTrace_FixedwingMode_T *localP)
{
  int8_T rtAction;

  // If: '<S155>/Find Maximum Diagonal Value'
  if (rtsiIsModeUpdateTimeStep(&(&FixedwingModel_M)->solverInfo)) {
    if ((rtu_DCM[4] > rtu_DCM[0]) && (rtu_DCM[4] > rtu_DCM[8])) {
      rtAction = 0;
    } else if (rtu_DCM[8] > rtu_DCM[0]) {
      rtAction = 1;
    } else {
      rtAction = 2;
    }

    localDW->FindMaximumDiagonalValue_Active = rtAction;
  } else {
    rtAction = localDW->FindMaximumDiagonalValue_Active;
  }

  switch (rtAction) {
   case 0:
    {
      real_T rtb_Product_n44;
      real_T rtb_Switch_d_idx_0;

      // Outputs for IfAction SubSystem: '<S155>/Maximum Value at DCM(2,2)' incorporates:
      //   ActionPort: '<S160>/Action Port'

      // Sqrt: '<S160>/sqrt' incorporates:
      //   Constant: '<S172>/Constant'
      //   Sum: '<S172>/Add'

      rtb_Product_n44 = std::sqrt(((rtu_DCM[4] - rtu_DCM[0]) - rtu_DCM[8]) +
        localP->Constant_Value);

      // Gain: '<S160>/Gain'
      rty_qwqxqyqz[2] = localP->Gain_Gain * rtb_Product_n44;

      // Switch: '<S171>/Switch' incorporates:
      //   Constant: '<S171>/Constant1'
      //   Constant: '<S171>/Constant2'

      if (rtb_Product_n44 != 0.0) {
        rtb_Switch_d_idx_0 = localP->Constant1_Value;
      } else {
        rtb_Switch_d_idx_0 = localP->Constant2_Value[0];
        rtb_Product_n44 = localP->Constant2_Value[1];
      }

      // End of Switch: '<S171>/Switch'

      // Product: '<S171>/Product'
      rtb_Product_n44 = rtb_Switch_d_idx_0 / rtb_Product_n44;

      // Gain: '<S160>/Gain1' incorporates:
      //   Product: '<S160>/Product'
      //   Sum: '<S170>/Add'

      rty_qwqxqyqz[1] = (rtu_DCM[1] + rtu_DCM[3]) * rtb_Product_n44 *
        localP->Gain1_Gain;

      // Gain: '<S160>/Gain3' incorporates:
      //   Product: '<S160>/Product'
      //   Sum: '<S169>/Add'

      rty_qwqxqyqz[3] = (rtu_DCM[5] + rtu_DCM[7]) * rtb_Product_n44 *
        localP->Gain3_Gain;

      // Gain: '<S160>/Gain4' incorporates:
      //   Product: '<S160>/Product'
      //   Sum: '<S168>/Add'

      rty_qwqxqyqz[0] = (rtu_DCM[2] - rtu_DCM[6]) * rtb_Product_n44 *
        localP->Gain4_Gain;

      // End of Outputs for SubSystem: '<S155>/Maximum Value at DCM(2,2)'
    }
    break;

   case 1:
    {
      real_T rtb_Product_n44;
      real_T rtb_Switch_d_idx_0;

      // Outputs for IfAction SubSystem: '<S155>/Maximum Value at DCM(3,3)' incorporates:
      //   ActionPort: '<S161>/Action Port'

      // Sqrt: '<S161>/sqrt' incorporates:
      //   Constant: '<S177>/Constant'
      //   Sum: '<S177>/Add'

      rtb_Product_n44 = std::sqrt(((rtu_DCM[8] - rtu_DCM[0]) - rtu_DCM[4]) +
        localP->Constant_Value_c);

      // Gain: '<S161>/Gain'
      rty_qwqxqyqz[3] = localP->Gain_Gain_j * rtb_Product_n44;

      // Switch: '<S176>/Switch' incorporates:
      //   Constant: '<S176>/Constant1'
      //   Constant: '<S176>/Constant2'

      if (rtb_Product_n44 != 0.0) {
        rtb_Switch_d_idx_0 = localP->Constant1_Value_m;
      } else {
        rtb_Switch_d_idx_0 = localP->Constant2_Value_d[0];
        rtb_Product_n44 = localP->Constant2_Value_d[1];
      }

      // End of Switch: '<S176>/Switch'

      // Product: '<S176>/Product'
      rtb_Product_n44 = rtb_Switch_d_idx_0 / rtb_Product_n44;

      // Gain: '<S161>/Gain1' incorporates:
      //   Product: '<S161>/Product'
      //   Sum: '<S173>/Add'

      rty_qwqxqyqz[1] = (rtu_DCM[2] + rtu_DCM[6]) * rtb_Product_n44 *
        localP->Gain1_Gain_l;

      // Gain: '<S161>/Gain2' incorporates:
      //   Product: '<S161>/Product'
      //   Sum: '<S174>/Add'

      rty_qwqxqyqz[2] = (rtu_DCM[5] + rtu_DCM[7]) * rtb_Product_n44 *
        localP->Gain2_Gain;

      // Gain: '<S161>/Gain3' incorporates:
      //   Product: '<S161>/Product'
      //   Sum: '<S175>/Add'

      rty_qwqxqyqz[0] = (rtu_DCM[3] - rtu_DCM[1]) * rtb_Product_n44 *
        localP->Gain3_Gain_j;

      // End of Outputs for SubSystem: '<S155>/Maximum Value at DCM(3,3)'
    }
    break;

   case 2:
    {
      real_T rtb_Product_n44;
      real_T rtb_Switch_d_idx_0;

      // Outputs for IfAction SubSystem: '<S155>/Maximum Value at DCM(1,1)' incorporates:
      //   ActionPort: '<S159>/Action Port'

      // Sqrt: '<S159>/sqrt' incorporates:
      //   Constant: '<S167>/Constant'
      //   Sum: '<S167>/Add'

      rtb_Product_n44 = std::sqrt(((rtu_DCM[0] - rtu_DCM[4]) - rtu_DCM[8]) +
        localP->Constant_Value_f);

      // Gain: '<S159>/Gain'
      rty_qwqxqyqz[1] = localP->Gain_Gain_e * rtb_Product_n44;

      // Switch: '<S166>/Switch' incorporates:
      //   Constant: '<S166>/Constant1'
      //   Constant: '<S166>/Constant2'

      if (rtb_Product_n44 != 0.0) {
        rtb_Switch_d_idx_0 = localP->Constant1_Value_a;
      } else {
        rtb_Switch_d_idx_0 = localP->Constant2_Value_a[0];
        rtb_Product_n44 = localP->Constant2_Value_a[1];
      }

      // End of Switch: '<S166>/Switch'

      // Product: '<S166>/Product'
      rtb_Product_n44 = rtb_Switch_d_idx_0 / rtb_Product_n44;

      // Gain: '<S159>/Gain1' incorporates:
      //   Product: '<S159>/Product'
      //   Sum: '<S165>/Add'

      rty_qwqxqyqz[2] = (rtu_DCM[1] + rtu_DCM[3]) * rtb_Product_n44 *
        localP->Gain1_Gain_h;

      // Gain: '<S159>/Gain2' incorporates:
      //   Product: '<S159>/Product'
      //   Sum: '<S163>/Add'

      rty_qwqxqyqz[3] = (rtu_DCM[2] + rtu_DCM[6]) * rtb_Product_n44 *
        localP->Gain2_Gain_b;

      // Gain: '<S159>/Gain3' incorporates:
      //   Product: '<S159>/Product'
      //   Sum: '<S164>/Add'

      rty_qwqxqyqz[0] = (rtu_DCM[7] - rtu_DCM[5]) * rtb_Product_n44 *
        localP->Gain3_Gain_n;

      // End of Outputs for SubSystem: '<S155>/Maximum Value at DCM(1,1)'
    }
    break;
  }

  // End of If: '<S155>/Find Maximum Diagonal Value'
}

//
// Output and update for action system:
//    '<S157>/If Warning//Error'
//    '<S418>/If Warning//Error'
//    '<S456>/If Warning//Error'
//
void MulticopterModelClass::FixedwingModel_IfWarningError(const real_T rtu_dcm[9],
  real_T rtp_action, real_T rtp_tolerance, P_IfWarningError_FixedwingMod_T
  *localP)
{
  real_T rtu_dcm_0[9];
  boolean_T rtb_Compare_k[9];
  boolean_T tmp;

  // Bias: '<S184>/Bias1' incorporates:
  //   Math: '<S184>/Math Function'
  //   Product: '<S184>/Product'

  for (int32_T i = 0; i < 3; i++) {
    for (int32_T i_0 = 0; i_0 < 3; i_0++) {
      int32_T rtu_dcm_tmp;
      rtu_dcm_tmp = 3 * i_0 + i;
      rtu_dcm_0[rtu_dcm_tmp] = ((rtu_dcm[3 * i + 1] * rtu_dcm[3 * i_0 + 1] +
        rtu_dcm[3 * i] * rtu_dcm[3 * i_0]) + rtu_dcm[3 * i + 2] * rtu_dcm[3 *
        i_0 + 2]) + localP->Bias1_Bias[rtu_dcm_tmp];
    }
  }

  // End of Bias: '<S184>/Bias1'

  // RelationalOperator: '<S190>/Compare' incorporates:
  //   Abs: '<S184>/Abs2'
  //   Constant: '<S190>/Constant'

  for (int32_T i = 0; i < 9; i++) {
    rtb_Compare_k[i] = (std::abs(rtu_dcm_0[i]) > rtp_tolerance);
  }

  // End of RelationalOperator: '<S190>/Compare'

  // Logic: '<S184>/Logical Operator1' incorporates:
  //   RelationalOperator: '<S190>/Compare'

  tmp = rtb_Compare_k[0];
  for (int32_T i = 0; i < 8; i++) {
    tmp = (tmp || rtb_Compare_k[i + 1]);
  }

  // If: '<S181>/If' incorporates:
  //   Abs: '<S185>/Abs1'
  //   Bias: '<S185>/Bias'
  //   Constant: '<S192>/Constant'
  //   Logic: '<S184>/Logical Operator1'
  //   Product: '<S191>/Product'
  //   Product: '<S191>/Product1'
  //   Product: '<S191>/Product2'
  //   Product: '<S191>/Product3'
  //   Product: '<S191>/Product4'
  //   Product: '<S191>/Product5'
  //   RelationalOperator: '<S192>/Compare'
  //   Reshape: '<S191>/Reshape'
  //   Sum: '<S191>/Sum'

  if (std::abs((((((rtu_dcm[0] * rtu_dcm[4] * rtu_dcm[8] - rtu_dcm[0] * rtu_dcm
                    [5] * rtu_dcm[7]) - rtu_dcm[1] * rtu_dcm[3] * rtu_dcm[8]) +
                  rtu_dcm[2] * rtu_dcm[3] * rtu_dcm[7]) + rtu_dcm[1] * rtu_dcm[5]
                 * rtu_dcm[6]) - rtu_dcm[2] * rtu_dcm[4] * rtu_dcm[6]) +
               localP->Bias_Bias) > rtp_tolerance) {
    // Outputs for IfAction SubSystem: '<S181>/If Not Proper' incorporates:
    //   ActionPort: '<S183>/Action Port'

    // If: '<S183>/If' incorporates:
    //   Constant: '<S183>/Constant'

    if (rtp_action == 2.0) {
      // Outputs for IfAction SubSystem: '<S183>/Warning' incorporates:
      //   ActionPort: '<S189>/Action Port'

      // Assertion: '<S189>/Assertion' incorporates:
      //   Constant: '<S183>/Constant1'

      utAssert(localP->Constant1_Value != 0.0);

      // End of Outputs for SubSystem: '<S183>/Warning'
    } else if (rtp_action == 3.0) {
      // Outputs for IfAction SubSystem: '<S183>/Error' incorporates:
      //   ActionPort: '<S188>/Action Port'

      // Assertion: '<S188>/Assertion' incorporates:
      //   Constant: '<S183>/Constant1'

      utAssert(localP->Constant1_Value != 0.0);

      // End of Outputs for SubSystem: '<S183>/Error'
    }

    // End of If: '<S183>/If'
    // End of Outputs for SubSystem: '<S181>/If Not Proper'
  } else if (tmp) {
    // Outputs for IfAction SubSystem: '<S181>/Else If Not Orthogonal' incorporates:
    //   ActionPort: '<S182>/Action Port'

    // If: '<S182>/If' incorporates:
    //   Constant: '<S182>/Constant'

    if (rtp_action == 2.0) {
      // Outputs for IfAction SubSystem: '<S182>/Warning' incorporates:
      //   ActionPort: '<S187>/Action Port'

      // Assertion: '<S187>/Assertion' incorporates:
      //   Constant: '<S182>/Constant1'

      utAssert(localP->Constant1_Value_d != 0.0);

      // End of Outputs for SubSystem: '<S182>/Warning'
    } else if (rtp_action == 3.0) {
      // Outputs for IfAction SubSystem: '<S182>/Error' incorporates:
      //   ActionPort: '<S186>/Action Port'

      // Assertion: '<S186>/Assertion' incorporates:
      //   Constant: '<S182>/Constant1'

      utAssert(localP->Constant1_Value_d != 0.0);

      // End of Outputs for SubSystem: '<S182>/Error'
    }

    // End of If: '<S182>/If'
    // End of Outputs for SubSystem: '<S181>/Else If Not Orthogonal'
  }

  // End of If: '<S181>/If'
}

//
// Output and update for atomic system:
//    '<S227>/Acc NoiseFun'
//    '<S233>/Acc NoiseFun'
//    '<S237>/Acc NoiseFun'
//
void MulticopterModelClass::FixedwingModel_AccNoiseFun(const real_T rtu_u[3],
  boolean_T rtu_isAccFault, const real_T rtu_AccFaultParams[20],
  B_AccNoiseFun_FixedwingModel_T *localB)
{
  // MATLAB Function 'SensorFault/AccNoiseSwitch1/Acc NoiseFun': '<S241>:1'
  // '<S241>:1:3' y = 0.2*u;
  localB->y[0] = 0.2 * rtu_u[0];
  localB->y[1] = 0.2 * rtu_u[1];
  localB->y[2] = 0.2 * rtu_u[2];

  // '<S241>:1:5' if isAccFault
  if (rtu_isAccFault) {
    real_T a;

    // '<S241>:1:6' y = (0.2+0.8*AccFaultParams(1))*u;
    a = 0.8 * rtu_AccFaultParams[0] + 0.2;
    localB->y[0] = a * rtu_u[0];
    localB->y[1] = a * rtu_u[1];
    localB->y[2] = a * rtu_u[2];
  }
}

real_T rt_modd_snf(real_T u0, real_T u1)
{
  real_T y;
  y = u0;
  if (u1 == 0.0) {
    if (u0 == 0.0) {
      y = u1;
    }
  } else if (rtIsNaN(u0) || rtIsNaN(u1) || rtIsInf(u0)) {
    y = (rtNaN);
  } else if (u0 == 0.0) {
    y = 0.0 / u1;
  } else if (rtIsInf(u1)) {
    if ((u1 < 0.0) != (u0 < 0.0)) {
      y = u1;
    }
  } else {
    boolean_T yEq;
    y = std::fmod(u0, u1);
    yEq = (y == 0.0);
    if ((!yEq) && (u1 > std::floor(u1))) {
      real_T q;
      q = std::abs(u0 / u1);
      yEq = !(std::abs(q - std::floor(q + 0.5)) > DBL_EPSILON * q);
    }

    if (yEq) {
      y = u1 * 0.0;
    } else if ((u0 < 0.0) != (u1 < 0.0)) {
      y += u1;
    }
  }

  return y;
}

//
// Disable for enable system:
//    '<S369>/Negative Yaw'
//    '<S525>/Negative Yaw'
//
void MulticopterModelClass::FixedwingMo_NegativeYaw_Disable
  (DW_NegativeYaw_FixedwingModel_T *localDW)
{
  localDW->NegativeYaw_MODE = false;
}

//
// Output and update for enable system:
//    '<S369>/Negative Yaw'
//    '<S525>/Negative Yaw'
//
void MulticopterModelClass::FixedwingModel_NegativeYaw(boolean_T rtu_Enable,
  real_T rtu_yaw, real_T *rty_yaw_wr, DW_NegativeYaw_FixedwingModel_T *localDW,
  P_NegativeYaw_FixedwingModel_T *localP)
{
  // Outputs for Enabled SubSystem: '<S369>/Negative Yaw' incorporates:
  //   EnablePort: '<S407>/Enable'

  if ((rtmIsMajorTimeStep((&FixedwingModel_M)) &&
       (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) &&
      rtsiIsModeUpdateTimeStep(&(&FixedwingModel_M)->solverInfo)) {
    if (rtu_Enable) {
      localDW->NegativeYaw_MODE = true;
    } else if (localDW->NegativeYaw_MODE) {
      FixedwingMo_NegativeYaw_Disable(localDW);
    }
  }

  if (localDW->NegativeYaw_MODE) {
    // Sum: '<S407>/Sum' incorporates:
    //   Abs: '<S407>/Abs'
    //   Constant: '<S407>/Constant1'
    //   Constant: '<S407>/Constant2'
    //   Math: '<S407>/Math Function'

    *rty_yaw_wr = localP->Constant2_Value - rt_modd_snf(std::abs(rtu_yaw),
      localP->Constant1_Value);
  }

  // End of Outputs for SubSystem: '<S369>/Negative Yaw'
}

//
// Disable for enable system:
//    '<S369>/Positive Yaw'
//    '<S525>/Positive Yaw'
//
void MulticopterModelClass::FixedwingMo_PositiveYaw_Disable
  (DW_PositiveYaw_FixedwingModel_T *localDW)
{
  localDW->PositiveYaw_MODE = false;
}

//
// Output and update for enable system:
//    '<S369>/Positive Yaw'
//    '<S525>/Positive Yaw'
//
void MulticopterModelClass::FixedwingModel_PositiveYaw(uint8_T rtu_Enable,
  real_T rtu_yaw, real_T *rty_yaw_wr, DW_PositiveYaw_FixedwingModel_T *localDW,
  P_PositiveYaw_FixedwingModel_T *localP)
{
  // Outputs for Enabled SubSystem: '<S369>/Positive Yaw' incorporates:
  //   EnablePort: '<S408>/Enable'

  if ((rtmIsMajorTimeStep((&FixedwingModel_M)) &&
       (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) &&
      rtsiIsModeUpdateTimeStep(&(&FixedwingModel_M)->solverInfo)) {
    if (rtu_Enable > 0) {
      localDW->PositiveYaw_MODE = true;
    } else if (localDW->PositiveYaw_MODE) {
      FixedwingMo_PositiveYaw_Disable(localDW);
    }
  }

  if (localDW->PositiveYaw_MODE) {
    // Math: '<S408>/Math Function' incorporates:
    //   Constant: '<S408>/Constant1'

    *rty_yaw_wr = rt_modd_snf(rtu_yaw, localP->Constant1_Value);
  }

  // End of Outputs for SubSystem: '<S369>/Positive Yaw'
}

real_T rt_atan2d_snf(real_T u0, real_T u1)
{
  real_T y;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = (rtNaN);
  } else if (rtIsInf(u0) && rtIsInf(u1)) {
    int32_T u0_0;
    int32_T u1_0;
    if (u0 > 0.0) {
      u0_0 = 1;
    } else {
      u0_0 = -1;
    }

    if (u1 > 0.0) {
      u1_0 = 1;
    } else {
      u1_0 = -1;
    }

    y = std::atan2(static_cast<real_T>(u0_0), static_cast<real_T>(u1_0));
  } else if (u1 == 0.0) {
    if (u0 > 0.0) {
      y = RT_PI / 2.0;
    } else if (u0 < 0.0) {
      y = -(RT_PI / 2.0);
    } else {
      y = 0.0;
    }
  } else {
    y = std::atan2(u0, u1);
  }

  return y;
}

// Function for MATLAB Function: '<Root>/CollisionDetection'
real_T MulticopterModelClass::FixedwingMod_eml_rand_mt19937ar(uint32_T state[625])
{
  real_T r;
  uint32_T u[2];

  // ========================= COPYRIGHT NOTICE ============================
  //  This is a uniform (0,1) pseudorandom number generator based on:
  //
  //  A C-program for MT19937, with initialization improved 2002/1/26.
  //  Coded by Takuji Nishimura and Makoto Matsumoto.
  //
  //  Copyright (C) 1997 - 2002, Makoto Matsumoto and Takuji Nishimura,
  //  All rights reserved.
  //
  //  Redistribution and use in source and binary forms, with or without
  //  modification, are permitted provided that the following conditions
  //  are met:
  //
  //    1. Redistributions of source code must retain the above copyright
  //       notice, this list of conditions and the following disclaimer.
  //
  //    2. Redistributions in binary form must reproduce the above copyright
  //       notice, this list of conditions and the following disclaimer
  //       in the documentation and/or other materials provided with the
  //       distribution.
  //
  //    3. The names of its contributors may not be used to endorse or
  //       promote products derived from this software without specific
  //       prior written permission.
  //
  //  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  //  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  //  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  //  A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT
  //  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  //  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  //  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  //  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  //  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  //  (INCLUDING  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  //  OF THIS  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  //
  // =============================   END   =================================
  int32_T exitg1;
  do {
    int32_T k;
    uint32_T mti;
    exitg1 = 0;
    for (k = 0; k < 2; k++) {
      uint32_T y;
      mti = state[624] + 1U;
      if (state[624] + 1U >= 625U) {
        for (int32_T kk = 0; kk < 227; kk++) {
          mti = (state[kk + 1] & 2147483647U) | (state[kk] & 2147483648U);
          if ((mti & 1U) == 0U) {
            mti >>= 1U;
          } else {
            mti = mti >> 1U ^ 2567483615U;
          }

          state[kk] = state[kk + 397] ^ mti;
        }

        for (int32_T kk = 0; kk < 396; kk++) {
          mti = (state[kk + 227] & 2147483648U) | (state[kk + 228] & 2147483647U);
          if ((mti & 1U) == 0U) {
            mti >>= 1U;
          } else {
            mti = mti >> 1U ^ 2567483615U;
          }

          state[kk + 227] = state[kk] ^ mti;
        }

        mti = (state[623] & 2147483648U) | (state[0] & 2147483647U);
        if ((mti & 1U) == 0U) {
          mti >>= 1U;
        } else {
          mti = mti >> 1U ^ 2567483615U;
        }

        state[623] = state[396] ^ mti;
        mti = 1U;
      }

      y = state[static_cast<int32_T>(mti) - 1];
      state[624] = mti;
      y ^= y >> 11U;
      y ^= y << 7U & 2636928640U;
      y ^= y << 15U & 4022730752U;
      u[k] = y >> 18U ^ y;
    }

    r = (static_cast<real_T>(u[0] >> 5U) * 6.7108864E+7 + static_cast<real_T>(u
          [1] >> 6U)) * 1.1102230246251565E-16;
    if (r == 0.0) {
      boolean_T b_isvalid;
      b_isvalid = ((state[624] >= 1U) && (state[624] < 625U));
      if (b_isvalid) {
        boolean_T exitg2;
        b_isvalid = false;
        k = 1;
        exitg2 = false;
        while ((!exitg2) && (k < 625)) {
          if (state[k - 1] == 0U) {
            k++;
          } else {
            b_isvalid = true;
            exitg2 = true;
          }
        }
      }

      if (!b_isvalid) {
        mti = 5489U;
        state[0] = 5489U;
        for (k = 0; k < 623; k++) {
          mti = ((mti >> 30U ^ mti) * 1812433253U + k) + 1U;
          state[k + 1] = mti;
        }

        state[624] = 624U;
      }
    } else {
      exitg1 = 1;
    }
  } while (exitg1 == 0);

  return r;
}

// Function for MATLAB Function: '<Root>/CollisionDetection'
real_T MulticopterModelClass::FixedwingMode_eml_rand_mcg16807(uint32_T *state)
{
  real_T r;
  int32_T hi;
  uint32_T a;
  uint32_T b;
  hi = static_cast<int32_T>(*state / 127773U);
  a = (*state - hi * 127773U) * 16807U;
  b = 2836U * hi;
  if (a < b) {
    a = ~(b - a) & 2147483647U;
  } else {
    a -= b;
  }

  r = static_cast<real_T>(a) * 4.6566128752457969E-10;
  *state = a;
  return r;
}

// Function for MATLAB Function: '<Root>/CollisionDetection'
real_T MulticopterModelClass::FixedwingModel_rand(void)
{
  real_T r;
  switch (FixedwingModel_DW.method_o) {
   case 4U:
    r = FixedwingMode_eml_rand_mcg16807(&FixedwingModel_DW.state_n);
    break;

   case 5U:
    {
      uint32_T b;
      uint32_T c;
      b = 69069U * FixedwingModel_DW.state_an[0] + 1234567U;
      c = FixedwingModel_DW.state_an[1] << 13 ^ FixedwingModel_DW.state_an[1];
      c ^= c >> 17;
      c ^= c << 5;
      FixedwingModel_DW.state_an[0] = b;
      FixedwingModel_DW.state_an[1] = c;
      r = static_cast<real_T>(b + c) * 2.328306436538696E-10;
    }
    break;

   default:
    r = FixedwingMod_eml_rand_mt19937ar(FixedwingModel_DW.state_k);
    break;
  }

  return r;
}

// Function for MATLAB Function: '<Root>/CollisionDetection'
void MulticopterModelClass::FixedwingModel_rand_p(real_T r[3])
{
  switch (FixedwingModel_DW.method_o) {
   case 4U:
    r[0] = FixedwingMode_eml_rand_mcg16807(&FixedwingModel_DW.state_n);
    r[1] = FixedwingMode_eml_rand_mcg16807(&FixedwingModel_DW.state_n);
    r[2] = FixedwingMode_eml_rand_mcg16807(&FixedwingModel_DW.state_n);
    break;

   case 5U:
    {
      uint32_T b;
      uint32_T c;
      b = 69069U * FixedwingModel_DW.state_an[0] + 1234567U;
      c = FixedwingModel_DW.state_an[1] << 13 ^ FixedwingModel_DW.state_an[1];
      c ^= c >> 17;
      c ^= c << 5;
      FixedwingModel_DW.state_an[0] = b;
      FixedwingModel_DW.state_an[1] = c;
      r[0] = static_cast<real_T>(b + c) * 2.328306436538696E-10;
      b = 69069U * FixedwingModel_DW.state_an[0] + 1234567U;
      c = FixedwingModel_DW.state_an[1] << 13 ^ FixedwingModel_DW.state_an[1];
      c ^= c >> 17;
      c ^= c << 5;
      FixedwingModel_DW.state_an[0] = b;
      FixedwingModel_DW.state_an[1] = c;
      r[1] = static_cast<real_T>(b + c) * 2.328306436538696E-10;
      b = 69069U * FixedwingModel_DW.state_an[0] + 1234567U;
      c = FixedwingModel_DW.state_an[1] << 13 ^ FixedwingModel_DW.state_an[1];
      c ^= c >> 17;
      c ^= c << 5;
      FixedwingModel_DW.state_an[0] = b;
      FixedwingModel_DW.state_an[1] = c;
      r[2] = static_cast<real_T>(b + c) * 2.328306436538696E-10;
    }
    break;

   default:
    r[0] = FixedwingMod_eml_rand_mt19937ar(FixedwingModel_DW.state_k);
    r[1] = FixedwingMod_eml_rand_mt19937ar(FixedwingModel_DW.state_k);
    r[2] = FixedwingMod_eml_rand_mt19937ar(FixedwingModel_DW.state_k);
    break;
  }
}

void rt_mrdivide_U1d1x3_U2d_9vOrDY9Z(const real_T u0[3], const real_T u1[9],
  real_T y[3])
{
  real_T A[9];
  real_T a21;
  real_T maxval;
  int32_T r1;
  int32_T r2;
  int32_T r3;
  std::memcpy(&A[0], &u1[0], 9U * sizeof(real_T));
  r1 = 0;
  r2 = 1;
  r3 = 2;
  maxval = std::abs(u1[0]);
  a21 = std::abs(u1[1]);
  if (a21 > maxval) {
    maxval = a21;
    r1 = 1;
    r2 = 0;
  }

  if (std::abs(u1[2]) > maxval) {
    r1 = 2;
    r2 = 1;
    r3 = 0;
  }

  A[r2] = u1[r2] / u1[r1];
  A[r3] /= A[r1];
  A[r2 + 3] -= A[r1 + 3] * A[r2];
  A[r3 + 3] -= A[r1 + 3] * A[r3];
  A[r2 + 6] -= A[r1 + 6] * A[r2];
  A[r3 + 6] -= A[r1 + 6] * A[r3];
  if (std::abs(A[r3 + 3]) > std::abs(A[r2 + 3])) {
    int32_T rtemp;
    rtemp = r2 + 1;
    r2 = r3;
    r3 = rtemp - 1;
  }

  A[r3 + 3] /= A[r2 + 3];
  A[r3 + 6] -= A[r3 + 3] * A[r2 + 6];
  y[r1] = u0[0] / A[r1];
  y[r2] = u0[1] - A[r1 + 3] * y[r1];
  y[r3] = u0[2] - A[r1 + 6] * y[r1];
  y[r2] /= A[r2 + 3];
  y[r3] -= A[r2 + 6] * y[r2];
  y[r3] /= A[r3 + 6];
  y[r2] -= A[r3 + 3] * y[r3];
  y[r1] -= y[r3] * A[r3];
  y[r1] -= y[r2] * A[r2];
}

// Function for MATLAB Function: '<S28>/MATLAB Function'
real_T MulticopterModelClass::FixedwingModel_rand_f(void)
{
  real_T r;
  uint32_T u[2];
  switch (FixedwingModel_DW.method) {
   case 4U:
    {
      int32_T k;
      uint32_T mti;
      uint32_T y;
      k = static_cast<int32_T>(FixedwingModel_DW.state / 127773U);
      mti = (FixedwingModel_DW.state - k * 127773U) * 16807U;
      y = 2836U * k;
      if (mti < y) {
        mti = ~(y - mti) & 2147483647U;
      } else {
        mti -= y;
      }

      r = static_cast<real_T>(mti) * 4.6566128752457969E-10;
      FixedwingModel_DW.state = mti;
    }
    break;

   case 5U:
    {
      uint32_T mti;
      uint32_T y;
      mti = 69069U * FixedwingModel_DW.state_b[0] + 1234567U;
      y = FixedwingModel_DW.state_b[1] << 13 ^ FixedwingModel_DW.state_b[1];
      y ^= y >> 17;
      y ^= y << 5;
      FixedwingModel_DW.state_b[0] = mti;
      FixedwingModel_DW.state_b[1] = y;
      r = static_cast<real_T>(mti + y) * 2.328306436538696E-10;
    }
    break;

   default:
    {
      // ========================= COPYRIGHT NOTICE ============================ 
      //  This is a uniform (0,1) pseudorandom number generator based on:        
      //                                                                         
      //  A C-program for MT19937, with initialization improved 2002/1/26.       
      //  Coded by Takuji Nishimura and Makoto Matsumoto.                        
      //                                                                         
      //  Copyright (C) 1997 - 2002, Makoto Matsumoto and Takuji Nishimura,      
      //  All rights reserved.                                                   
      //                                                                         
      //  Redistribution and use in source and binary forms, with or without     
      //  modification, are permitted provided that the following conditions     
      //  are met:                                                               
      //                                                                         
      //    1. Redistributions of source code must retain the above copyright    
      //       notice, this list of conditions and the following disclaimer.     
      //                                                                         
      //    2. Redistributions in binary form must reproduce the above copyright 
      //       notice, this list of conditions and the following disclaimer      
      //       in the documentation and/or other materials provided with the     
      //       distribution.                                                     
      //                                                                         
      //    3. The names of its contributors may not be used to endorse or       
      //       promote products derived from this software without specific      
      //       prior written permission.                                         
      //                                                                         
      //  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS    
      //  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT      
      //  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR  
      //  A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT  
      //  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,  
      //  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT       
      //  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,  
      //  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY  
      //  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT    
      //  (INCLUDING  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
      //  OF THIS  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.  
      //                                                                         
      // =============================   END   ================================= 
      int32_T exitg1;
      do {
        int32_T k;
        uint32_T mti;
        exitg1 = 0;
        for (k = 0; k < 2; k++) {
          uint32_T y;
          mti = FixedwingModel_DW.state_a[624] + 1U;
          if (FixedwingModel_DW.state_a[624] + 1U >= 625U) {
            for (int32_T kk = 0; kk < 227; kk++) {
              mti = (FixedwingModel_DW.state_a[kk + 1] & 2147483647U) |
                (FixedwingModel_DW.state_a[kk] & 2147483648U);
              if ((mti & 1U) == 0U) {
                mti >>= 1U;
              } else {
                mti = mti >> 1U ^ 2567483615U;
              }

              FixedwingModel_DW.state_a[kk] = FixedwingModel_DW.state_a[kk + 397]
                ^ mti;
            }

            for (int32_T kk = 0; kk < 396; kk++) {
              mti = (FixedwingModel_DW.state_a[kk + 227] & 2147483648U) |
                (FixedwingModel_DW.state_a[kk + 228] & 2147483647U);
              if ((mti & 1U) == 0U) {
                mti >>= 1U;
              } else {
                mti = mti >> 1U ^ 2567483615U;
              }

              FixedwingModel_DW.state_a[kk + 227] = FixedwingModel_DW.state_a[kk]
                ^ mti;
            }

            mti = (FixedwingModel_DW.state_a[623] & 2147483648U) |
              (FixedwingModel_DW.state_a[0] & 2147483647U);
            if ((mti & 1U) == 0U) {
              mti >>= 1U;
            } else {
              mti = mti >> 1U ^ 2567483615U;
            }

            FixedwingModel_DW.state_a[623] = FixedwingModel_DW.state_a[396] ^
              mti;
            mti = 1U;
          }

          y = FixedwingModel_DW.state_a[static_cast<int32_T>(mti) - 1];
          FixedwingModel_DW.state_a[624] = mti;
          y ^= y >> 11U;
          y ^= y << 7U & 2636928640U;
          y ^= y << 15U & 4022730752U;
          u[k] = y >> 18U ^ y;
        }

        r = (static_cast<real_T>(u[0] >> 5U) * 6.7108864E+7 + static_cast<real_T>
             (u[1] >> 6U)) * 1.1102230246251565E-16;
        if (r == 0.0) {
          boolean_T b_isvalid;
          b_isvalid = ((FixedwingModel_DW.state_a[624] >= 1U) &&
                       (FixedwingModel_DW.state_a[624] < 625U));
          if (b_isvalid) {
            boolean_T exitg2;
            b_isvalid = false;
            k = 1;
            exitg2 = false;
            while ((!exitg2) && (k < 625)) {
              if (FixedwingModel_DW.state_a[k - 1] == 0U) {
                k++;
              } else {
                b_isvalid = true;
                exitg2 = true;
              }
            }
          }

          if (!b_isvalid) {
            mti = 5489U;
            FixedwingModel_DW.state_a[0] = 5489U;
            for (k = 0; k < 623; k++) {
              mti = ((mti >> 30U ^ mti) * 1812433253U + k) + 1U;
              FixedwingModel_DW.state_a[k + 1] = mti;
            }

            FixedwingModel_DW.state_a[624] = 624U;
          }
        } else {
          exitg1 = 1;
        }
      } while (exitg1 == 0);
    }
    break;
  }

  return r;
}

real_T rt_roundd_snf(real_T u)
{
  real_T y;
  if (std::abs(u) < 4.503599627370496E+15) {
    if (u >= 0.5) {
      y = std::floor(u + 0.5);
    } else if (u > -0.5) {
      y = u * 0.0;
    } else {
      y = std::ceil(u - 0.5);
    }
  } else {
    y = u;
  }

  return y;
}

real_T rt_urand_Upu32_Yd_f_pw_snf(uint32_T *u)
{
  uint32_T hi;
  uint32_T lo;

  // Uniform random number generator (random number between 0 and 1)

  // #define IA      16807                      magic multiplier = 7^5
  // #define IM      2147483647                 modulus = 2^31-1
  // #define IQ      127773                     IM div IA
  // #define IR      2836                       IM modulo IA
  // #define S       4.656612875245797e-10      reciprocal of 2^31-1
  // test = IA * (seed % IQ) - IR * (seed/IQ)
  // seed = test < 0 ? (test + IM) : test
  // return (seed*S)

  lo = *u % 127773U * 16807U;
  hi = *u / 127773U * 2836U;
  if (lo < hi) {
    *u = 2147483647U - (hi - lo);
  } else {
    *u = lo - hi;
  }

  return static_cast<real_T>(*u) * 4.6566128752457969E-10;
}

real_T rt_nrand_Upu32_Yd_f_pw_snf(uint32_T *u)
{
  real_T si;
  real_T sr;
  real_T y;

  // Normal (Gaussian) random number generator
  do {
    sr = 2.0 * rt_urand_Upu32_Yd_f_pw_snf(u) - 1.0;
    si = 2.0 * rt_urand_Upu32_Yd_f_pw_snf(u) - 1.0;
    si = sr * sr + si * si;
  } while (si > 1.0);

  y = std::sqrt(-2.0 * std::log(si) / si) * sr;
  return y;
}

// Model step function
void MulticopterModelClass::step()
{
  // local block i/o variables
  real_T rtb_ZeroOrderHold[3];
  real_T rtb_tc_old[169];
  real_T fParamTmp[20];
  real_T inSILFloats[20];
  real_T rtb_VectorConcatenate_c[18];
  real_T rtb_TmpSignalConversionAtppnInp[13];
  real_T rtb_Assignment[11];
  real_T rtb_Assignment1[11];
  real_T rtb_RW2B[9];
  real_T rtb_VectorConcatenate[9];
  real_T rtb_VectorConcatenate_bz[9];
  real_T rtb_VectorConcatenate_g[9];
  real_T ddm[6];
  real_T rtb_Sum4_a[6];
  real_T rtb_VectorConcatenate_n[6];
  real_T tmp[6];
  real_T rtb_TmpSignalConversionAtSFunct[5];
  real_T rtb_DataTypeConversion2[3];
  real_T rtb_Gain_d[3];
  real_T rtb_IntegratorSecondOrderLimi_m[3];
  real_T rtb_IntegratorSecondOrderLimite[3];
  real_T rtb_Sum4_a_0[3];
  real_T rtb_Sum4_p[3];
  real_T rtb_UniformRandomNumber7[3];
  real_T rtb_ubvbwb[3];
  real_T rtb_y_j[3];
  real_T wb[3];
  real_T frac[2];
  real_T frac_0[2];
  real_T frac_1[2];
  real_T rtb_pgw_p[2];
  const real_T *rtb_Switch_j_0;
  real_T Sum_l;
  real_T Sum_p;
  real_T Ve_idx_2;
  real_T Xe_idx_2;
  real_T mv0_tmp;
  real_T rtb_Add;
  real_T rtb_Add_m_tmp;
  real_T rtb_DataTypeConversion2_tmp;
  real_T rtb_DataTypeConversion2_tmp_0;
  real_T rtb_Eularrad_idx_2;
  real_T rtb_Gain9_d;
  real_T rtb_IntegratorSecondOrderLim_ff;
  real_T rtb_IntegratorSecondOrder_o2_e;
  real_T rtb_LowAltitudeScaleLength;
  real_T rtb_MediumHighAltitudeIntensity;
  real_T rtb_Product2_g;
  real_T rtb_Rn;
  real_T rtb_Sum4_a_tmp;
  real_T rtb_Sum4_a_tmp_0;
  real_T rtb_Sum_gz;
  real_T rtb_Sum_le;
  real_T rtb_UniformRandomNumber4_j;
  real_T rtb_UnitConversion;
  real_T rtb_UnitConversion_a;
  real_T rtb_WhiteNoise_l_idx_0;
  real_T rtb_WhiteNoise_l_idx_2;
  real_T rtb_WhiteNoise_l_idx_3;
  real_T rtb_aileronCmd;
  real_T rtb_elevatorCmd;
  real_T rtb_jxi;
  real_T rtb_jxi_d;
  real_T rtb_rgw_p_idx_0;
  real_T rtb_rgw_p_idx_1;
  real_T rtb_rudderCmd;
  real_T rtb_sigma_ugsigma_vg;
  real_T rtb_sincos_o1_i_idx_0;
  real_T rtb_sincos_o1_idx_0;
  real_T rtb_throttleCmd;
  real_T rtb_ubvbwb_tmp;
  real_T rtb_ubvbwb_tmp_0;
  real_T rtb_y3DFix;
  real_T rtb_ySats;
  real_T y;
  real_T y_0;
  int32_T i;
  int32_T qY;
  int32_T rtb_VectorConcatenate_a_tmp;
  int32_T s281_iter;
  int32_T s281_iter_0;
  int32_T s281_iter_1;
  int32_T s289_iter;
  int32_T s330_iter;
  real32_T rtb_AngEuler[3];
  uint32_T bpIndex[2];
  uint32_T bpIndex_0[2];
  uint32_T bpIndex_1[2];
  uint32_T rtb_time_usec;
  int8_T rtAction;
  uint8_T ForIterator_IterationMarker[6];
  uint8_T Compare;
  boolean_T rtb_Compare_n;
  boolean_T rtb_DataTypeConversion2_e;
  boolean_T rtb_RelationalOperator;
  if (rtmIsMajorTimeStep((&FixedwingModel_M))) {
    // set solver stop time
    rtsiSetSolverStopTime(&(&FixedwingModel_M)->solverInfo,(((&FixedwingModel_M
      )->Timing.clockTick0+1)*(&FixedwingModel_M)->Timing.stepSize0));
  }                                    // end MajorTimeStep

  // Update absolute time of base rate at minor time step
  if (rtmIsMinorTimeStep((&FixedwingModel_M))) {
    (&FixedwingModel_M)->Timing.t[0] = rtsiGetT(&(&FixedwingModel_M)->solverInfo);
  }

  // Clock: '<S7>/Clock1' incorporates:
  //   Clock: '<Root>/Clock'
  //   Clock: '<S17>/Time'
  //   Clock: '<S28>/Clock1'

  Sum_p = (&FixedwingModel_M)->Timing.t[0];

  // DataTypeConversion: '<S7>/Data Type Conversion1' incorporates:
  //   Clock: '<S7>/Clock1'
  //   Gain: '<S7>/Gain_clock'

  rtb_IntegratorSecondOrderLim_ff = std::floor(FixedwingModel_P.Gain_clock_Gain *
    Sum_p);
  if (rtIsNaN(rtb_IntegratorSecondOrderLim_ff) || rtIsInf
      (rtb_IntegratorSecondOrderLim_ff)) {
    rtb_IntegratorSecondOrderLim_ff = 0.0;
  } else {
    rtb_IntegratorSecondOrderLim_ff = std::fmod(rtb_IntegratorSecondOrderLim_ff,
      4.294967296E+9);
  }

  rtb_time_usec = rtb_IntegratorSecondOrderLim_ff < 0.0 ? static_cast<uint32_T>(
    -static_cast<int32_T>(static_cast<uint32_T>(-rtb_IntegratorSecondOrderLim_ff)))
    : static_cast<uint32_T>(rtb_IntegratorSecondOrderLim_ff);

  // End of DataTypeConversion: '<S7>/Data Type Conversion1'

  // SecondOrderIntegrator: '<S10>/Integrator, Second-Order'
  s330_iter = 1;

  // Saturate: '<S149>/Saturation' incorporates:
  //   SecondOrderIntegrator: '<S10>/Integrator, Second-Order'

  if (FixedwingModel_X.IntegratorSecondOrder_CSTATE[0] >
      FixedwingModel_P.Saturation_UpperSat) {
    rtb_IntegratorSecondOrderLim_ff = FixedwingModel_P.Saturation_UpperSat;
  } else if (FixedwingModel_X.IntegratorSecondOrder_CSTATE[0] <
             FixedwingModel_P.Saturation_LowerSat) {
    rtb_IntegratorSecondOrderLim_ff = FixedwingModel_P.Saturation_LowerSat;
  } else {
    rtb_IntegratorSecondOrderLim_ff =
      FixedwingModel_X.IntegratorSecondOrder_CSTATE[0];
  }

  // End of Saturate: '<S149>/Saturation'

  // Sum: '<S149>/Sum' incorporates:
  //   Constant: '<S149>/Min RPM'
  //   Constant: '<S149>/Min Th K'
  //   Gain: '<S149>/MaxRPM'
  //   Gain: '<S149>/Th K'
  //   Sum: '<S149>/Sum1'

  rtb_sincos_o1_i_idx_0 = (FixedwingModel_P.uav.engine.ThK *
    rtb_IntegratorSecondOrderLim_ff + FixedwingModel_P.uav.engine.MinThK) *
    FixedwingModel_P.MaxRPM_Gain + FixedwingModel_P.MinRPM_Value;

  // Math: '<S149>/Math Function' incorporates:
  //   Constant: '<S149>/Prop Diameter (in)1'

  if ((rtb_sincos_o1_i_idx_0 < 0.0) && (FixedwingModel_P.PropDiameterin1_Value >
       std::floor(FixedwingModel_P.PropDiameterin1_Value))) {
    rtb_sincos_o1_i_idx_0 = -rt_powd_snf(-rtb_sincos_o1_i_idx_0,
      FixedwingModel_P.PropDiameterin1_Value);
  } else {
    rtb_sincos_o1_i_idx_0 = rt_powd_snf(rtb_sincos_o1_i_idx_0,
      FixedwingModel_P.PropDiameterin1_Value);
  }

  // End of Math: '<S149>/Math Function'
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // Math: '<S149>/Math Function1' incorporates:
    //   Constant: '<S149>/Prop Diameter (in)'
    //   Constant: '<S149>/Prop Diameter (in)2'

    if ((FixedwingModel_P.PropDiameterin_Value < 0.0) &&
        (FixedwingModel_P.PropDiameterin2_Value > std::floor
         (FixedwingModel_P.PropDiameterin2_Value))) {
      // Math: '<S149>/Math Function1'
      FixedwingModel_B.MathFunction1 = -rt_powd_snf
        (-FixedwingModel_P.PropDiameterin_Value,
         FixedwingModel_P.PropDiameterin2_Value);
    } else {
      // Math: '<S149>/Math Function1'
      FixedwingModel_B.MathFunction1 = rt_powd_snf
        (FixedwingModel_P.PropDiameterin_Value,
         FixedwingModel_P.PropDiameterin2_Value);
    }

    // End of Math: '<S149>/Math Function1'
  }

  // Gain: '<S149>/MaxRPM1' incorporates:
  //   Constant: '<S149>/To Constant'
  //   Product: '<S149>/Divide'

  rtb_sincos_o1_i_idx_0 = rtb_sincos_o1_i_idx_0 * FixedwingModel_B.MathFunction1
    * FixedwingModel_P.ToConstant_Value * FixedwingModel_P.uav.engine.TFact;

  // RelationalOperator: '<S406>/Compare' incorporates:
  //   Constant: '<S406>/Constant'
  //   Integrator: '<S346>/phi theta psi'

  Compare = (FixedwingModel_X.phithetapsi_CSTATE[2] >=
             FixedwingModel_P.Constant_Value_e);
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // SignalConversion generated from: '<S408>/Enable'
    FixedwingModel_B.HiddenBuf_InsertedFor_PositiveY = Compare;
  }

  // Outputs for Enabled SubSystem: '<S369>/Positive Yaw'
  // Integrator: '<S346>/phi theta psi'
  FixedwingModel_PositiveYaw(FixedwingModel_B.HiddenBuf_InsertedFor_PositiveY,
    FixedwingModel_X.phithetapsi_CSTATE[2], &FixedwingModel_B.Merge,
    &FixedwingModel_DW.PositiveYaw, &FixedwingModel_P.PositiveYaw);

  // End of Outputs for SubSystem: '<S369>/Positive Yaw'
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // SignalConversion generated from: '<S407>/Enable' incorporates:
    //   Logic: '<S369>/Logical Operator'

    FixedwingModel_B.HiddenBuf_InsertedFor_NegativeY = (Compare == 0);
  }

  // Outputs for Enabled SubSystem: '<S369>/Negative Yaw'
  // Integrator: '<S346>/phi theta psi'
  FixedwingModel_NegativeYaw(FixedwingModel_B.HiddenBuf_InsertedFor_NegativeY,
    FixedwingModel_X.phithetapsi_CSTATE[2], &FixedwingModel_B.Merge,
    &FixedwingModel_DW.NegativeYaw, &FixedwingModel_P.NegativeYaw);

  // End of Outputs for SubSystem: '<S369>/Negative Yaw'

  // SignalConversion generated from: '<S401>/sincos' incorporates:
  //   Integrator: '<S346>/phi theta psi'

  rtb_IntegratorSecondOrderLimi_m[0] = FixedwingModel_B.Merge;
  rtb_IntegratorSecondOrderLimi_m[1] = FixedwingModel_X.phithetapsi_CSTATE[1];
  rtb_IntegratorSecondOrderLimi_m[2] = FixedwingModel_X.phithetapsi_CSTATE[0];

  // Trigonometry: '<S401>/sincos' incorporates:
  //   Integrator: '<S346>/phi theta psi'
  //   SignalConversion generated from: '<S401>/sincos'
  //   Trigonometry: '<S354>/sincos'
  //   Trigonometry: '<S355>/sincos'
  //   Trigonometry: '<S566>/sincos'

  rtb_Sum4_p[0] = std::sin(FixedwingModel_B.Merge);
  rtb_ubvbwb[0] = std::cos(FixedwingModel_B.Merge);
  rtb_Sum4_a_tmp = std::sin(FixedwingModel_X.phithetapsi_CSTATE[1]);
  rtb_ubvbwb_tmp = std::cos(FixedwingModel_X.phithetapsi_CSTATE[1]);
  rtb_Sum4_a_tmp_0 = std::sin(FixedwingModel_X.phithetapsi_CSTATE[0]);
  rtb_ubvbwb_tmp_0 = std::cos(FixedwingModel_X.phithetapsi_CSTATE[0]);

  // Fcn: '<S401>/Fcn11' incorporates:
  //   Trigonometry: '<S401>/sincos'

  rtb_VectorConcatenate_bz[0] = rtb_ubvbwb[0] * rtb_ubvbwb_tmp;

  // Fcn: '<S401>/Fcn21' incorporates:
  //   Fcn: '<S354>/Fcn21'
  //   Fcn: '<S566>/Fcn21'
  //   Trigonometry: '<S401>/sincos'

  rtb_UnitConversion_a = rtb_Sum4_a_tmp * rtb_Sum4_a_tmp_0;
  rtb_VectorConcatenate_bz[1] = rtb_UnitConversion_a * rtb_ubvbwb[0] -
    rtb_Sum4_p[0] * rtb_ubvbwb_tmp_0;

  // Fcn: '<S401>/Fcn31' incorporates:
  //   Fcn: '<S354>/Fcn31'
  //   Trigonometry: '<S401>/sincos'

  rtb_IntegratorSecondOrderLim_ff = rtb_Sum4_a_tmp * rtb_ubvbwb_tmp_0;
  rtb_VectorConcatenate_bz[2] = rtb_IntegratorSecondOrderLim_ff * rtb_ubvbwb[0]
    + rtb_Sum4_p[0] * rtb_Sum4_a_tmp_0;

  // Fcn: '<S401>/Fcn12' incorporates:
  //   Trigonometry: '<S401>/sincos'

  rtb_VectorConcatenate_bz[3] = rtb_Sum4_p[0] * rtb_ubvbwb_tmp;

  // Fcn: '<S401>/Fcn22' incorporates:
  //   Fcn: '<S401>/Fcn21'
  //   Trigonometry: '<S401>/sincos'

  rtb_VectorConcatenate_bz[4] = rtb_UnitConversion_a * rtb_Sum4_p[0] +
    rtb_ubvbwb[0] * rtb_ubvbwb_tmp_0;

  // Fcn: '<S401>/Fcn32' incorporates:
  //   Fcn: '<S401>/Fcn31'
  //   Trigonometry: '<S401>/sincos'

  rtb_VectorConcatenate_bz[5] = rtb_IntegratorSecondOrderLim_ff * rtb_Sum4_p[0]
    - rtb_ubvbwb[0] * rtb_Sum4_a_tmp_0;

  // Fcn: '<S401>/Fcn13' incorporates:
  //   Trigonometry: '<S401>/sincos'

  rtb_VectorConcatenate_bz[6] = -rtb_Sum4_a_tmp;

  // Fcn: '<S401>/Fcn23' incorporates:
  //   Fcn: '<S354>/Fcn23'
  //   Trigonometry: '<S401>/sincos'

  rtb_UnitConversion = rtb_ubvbwb_tmp * rtb_Sum4_a_tmp_0;
  rtb_VectorConcatenate_bz[7] = rtb_UnitConversion;

  // Fcn: '<S401>/Fcn33' incorporates:
  //   Fcn: '<S354>/Fcn33'
  //   Trigonometry: '<S401>/sincos'

  rtb_MediumHighAltitudeIntensity = rtb_ubvbwb_tmp * rtb_ubvbwb_tmp_0;
  rtb_VectorConcatenate_bz[8] = rtb_MediumHighAltitudeIntensity;

  // Trigonometry: '<S354>/sincos' incorporates:
  //   Integrator: '<S346>/phi theta psi'
  //   SignalConversion generated from: '<S354>/sincos'

  rtb_Sum4_p[0] = std::cos(FixedwingModel_X.phithetapsi_CSTATE[2]);
  rtb_sincos_o1_idx_0 = std::sin(FixedwingModel_X.phithetapsi_CSTATE[2]);

  // Fcn: '<S354>/Fcn11'
  rtb_VectorConcatenate_g[0] = rtb_Sum4_p[0] * rtb_ubvbwb_tmp;

  // Fcn: '<S354>/Fcn21'
  rtb_VectorConcatenate_g[1] = rtb_UnitConversion_a * rtb_Sum4_p[0] -
    rtb_sincos_o1_idx_0 * rtb_ubvbwb_tmp_0;

  // Fcn: '<S354>/Fcn31'
  rtb_VectorConcatenate_g[2] = rtb_IntegratorSecondOrderLim_ff * rtb_Sum4_p[0] +
    rtb_sincos_o1_idx_0 * rtb_Sum4_a_tmp_0;

  // Fcn: '<S354>/Fcn12'
  rtb_VectorConcatenate_g[3] = rtb_sincos_o1_idx_0 * rtb_ubvbwb_tmp;

  // Fcn: '<S354>/Fcn22'
  rtb_VectorConcatenate_g[4] = rtb_UnitConversion_a * rtb_sincos_o1_idx_0 +
    rtb_Sum4_p[0] * rtb_ubvbwb_tmp_0;

  // Fcn: '<S354>/Fcn32'
  rtb_VectorConcatenate_g[5] = rtb_IntegratorSecondOrderLim_ff *
    rtb_sincos_o1_idx_0 - rtb_Sum4_p[0] * rtb_Sum4_a_tmp_0;

  // Fcn: '<S354>/Fcn13'
  rtb_VectorConcatenate_g[6] = -rtb_Sum4_a_tmp;

  // Fcn: '<S354>/Fcn23'
  rtb_VectorConcatenate_g[7] = rtb_UnitConversion;

  // Fcn: '<S354>/Fcn33'
  rtb_VectorConcatenate_g[8] = rtb_MediumHighAltitudeIntensity;
  for (i = 0; i < 3; i++) {
    // Product: '<S353>/Product' incorporates:
    //   Concatenate: '<S356>/Vector Concatenate'
    //   Integrator: '<S341>/ub,vb,wb'
    //   Math: '<S341>/Transpose'

    FixedwingModel_B.Product[i] = 0.0;
    FixedwingModel_B.Product[i] += rtb_VectorConcatenate_g[3 * i] *
      FixedwingModel_X.ubvbwb_CSTATE[0];
    FixedwingModel_B.Product[i] += rtb_VectorConcatenate_g[3 * i + 1] *
      FixedwingModel_X.ubvbwb_CSTATE[1];
    FixedwingModel_B.Product[i] += rtb_VectorConcatenate_g[3 * i + 2] *
      FixedwingModel_X.ubvbwb_CSTATE[2];
  }

  // RelationalOperator: '<S568>/Compare' incorporates:
  //   Constant: '<S568>/Constant'
  //   Integrator: '<S346>/phi theta psi'

  Compare = (FixedwingModel_X.phithetapsi_CSTATE[2] >=
             FixedwingModel_P.Constant_Value_f);
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // SignalConversion generated from: '<S570>/Enable'
    FixedwingModel_B.HiddenBuf_InsertedFor_Positiv_n = Compare;
  }

  // Outputs for Enabled SubSystem: '<S525>/Positive Yaw'
  // Integrator: '<S346>/phi theta psi'
  FixedwingModel_PositiveYaw(FixedwingModel_B.HiddenBuf_InsertedFor_Positiv_n,
    FixedwingModel_X.phithetapsi_CSTATE[2], &FixedwingModel_B.Merge_c,
    &FixedwingModel_DW.PositiveYaw_i, &FixedwingModel_P.PositiveYaw_i);

  // End of Outputs for SubSystem: '<S525>/Positive Yaw'
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // SignalConversion generated from: '<S569>/Enable' incorporates:
    //   Logic: '<S525>/Logical Operator'

    FixedwingModel_B.HiddenBuf_InsertedFor_Negativ_e = (Compare == 0);
  }

  // Outputs for Enabled SubSystem: '<S525>/Negative Yaw'
  // Integrator: '<S346>/phi theta psi'
  FixedwingModel_NegativeYaw(FixedwingModel_B.HiddenBuf_InsertedFor_Negativ_e,
    FixedwingModel_X.phithetapsi_CSTATE[2], &FixedwingModel_B.Merge_c,
    &FixedwingModel_DW.NegativeYaw_d, &FixedwingModel_P.NegativeYaw_d);

  // End of Outputs for SubSystem: '<S525>/Negative Yaw'

  // Gain: '<S345>/Zero-Order Hold' incorporates:
  //   SignalConversion generated from: '<S566>/sincos'
  //   Trigonometry: '<S566>/sincos'

  // Unit Conversion - from: m to: ft
  // Expression: output = (3.28084*input) + (0)
  // Unit Conversion - from: m/s to: ft/s
  // Expression: output = (3.28084*input) + (0)
  rtb_ZeroOrderHold[0] = std::cos(FixedwingModel_B.Merge_c);

  // Trigonometry: '<S566>/sincos' incorporates:
  //   SignalConversion generated from: '<S566>/sincos'

  rtb_UnitConversion = std::sin(FixedwingModel_B.Merge_c);

  // Integrator: '<S341>/xe,ye,ze'
  FixedwingModel_B.xeyeze[0] = FixedwingModel_X.xeyeze_CSTATE[0];

  // Gain: '<S345>/Zero-Order Hold' incorporates:
  //   Trigonometry: '<S566>/sincos'

  rtb_ZeroOrderHold[1] = rtb_ubvbwb_tmp;

  // Integrator: '<S341>/xe,ye,ze'
  FixedwingModel_B.xeyeze[1] = FixedwingModel_X.xeyeze_CSTATE[1];

  // Gain: '<S345>/Zero-Order Hold' incorporates:
  //   Trigonometry: '<S566>/sincos'

  rtb_ZeroOrderHold[2] = rtb_ubvbwb_tmp_0;

  // Integrator: '<S341>/xe,ye,ze'
  FixedwingModel_B.xeyeze[2] = FixedwingModel_X.xeyeze_CSTATE[2];

  // DotProduct: '<S521>/Dot Product'
  rtb_IntegratorSecondOrderLim_ff = (FixedwingModel_B.Product[0] *
    FixedwingModel_B.Product[0] + FixedwingModel_B.Product[1] *
    FixedwingModel_B.Product[1]) + FixedwingModel_B.Product[2] *
    FixedwingModel_B.Product[2];

  // Fcn: '<S566>/Fcn11' incorporates:
  //   Concatenate: '<S567>/Vector Concatenate'

  rtb_VectorConcatenate[0] = rtb_ZeroOrderHold[0] * rtb_ZeroOrderHold[1];

  // Fcn: '<S566>/Fcn21' incorporates:
  //   Concatenate: '<S567>/Vector Concatenate'

  rtb_VectorConcatenate[1] = rtb_UnitConversion_a * rtb_ZeroOrderHold[0] -
    rtb_UnitConversion * rtb_ZeroOrderHold[2];

  // Fcn: '<S566>/Fcn31' incorporates:
  //   Concatenate: '<S567>/Vector Concatenate'
  //   Fcn: '<S566>/Fcn32'

  rtb_MediumHighAltitudeIntensity = rtb_Sum4_a_tmp * rtb_ZeroOrderHold[2];
  rtb_VectorConcatenate[2] = rtb_MediumHighAltitudeIntensity *
    rtb_ZeroOrderHold[0] + rtb_UnitConversion * rtb_Sum4_a_tmp_0;

  // Fcn: '<S566>/Fcn12' incorporates:
  //   Concatenate: '<S567>/Vector Concatenate'

  rtb_VectorConcatenate[3] = rtb_UnitConversion * rtb_ZeroOrderHold[1];

  // Fcn: '<S566>/Fcn22' incorporates:
  //   Concatenate: '<S567>/Vector Concatenate'

  rtb_VectorConcatenate[4] = rtb_UnitConversion_a * rtb_UnitConversion +
    rtb_ZeroOrderHold[0] * rtb_ZeroOrderHold[2];

  // Fcn: '<S566>/Fcn32' incorporates:
  //   Concatenate: '<S567>/Vector Concatenate'

  rtb_VectorConcatenate[5] = rtb_MediumHighAltitudeIntensity *
    rtb_UnitConversion - rtb_ZeroOrderHold[0] * rtb_Sum4_a_tmp_0;

  // Fcn: '<S566>/Fcn13' incorporates:
  //   Concatenate: '<S567>/Vector Concatenate'

  rtb_VectorConcatenate[6] = -rtb_Sum4_a_tmp;

  // Fcn: '<S566>/Fcn23' incorporates:
  //   Concatenate: '<S567>/Vector Concatenate'

  rtb_VectorConcatenate[7] = rtb_ZeroOrderHold[1] * rtb_Sum4_a_tmp_0;

  // Fcn: '<S566>/Fcn33' incorporates:
  //   Concatenate: '<S567>/Vector Concatenate'

  rtb_VectorConcatenate[8] = rtb_ZeroOrderHold[1] * rtb_ZeroOrderHold[2];

  // UnitConversion: '<S529>/Unit Conversion' incorporates:
  //   Gain: '<S9>/Gain1'

  rtb_UnitConversion = FixedwingModel_P.Gain1_Gain_k * FixedwingModel_B.xeyeze[2]
    * 3.280839895013123;

  // Saturate: '<S521>/Zero Bound' incorporates:
  //   DotProduct: '<S521>/Dot Product'

  if (rtb_IntegratorSecondOrderLim_ff > FixedwingModel_P.ZeroBound_UpperSat) {
    rtb_IntegratorSecondOrderLim_ff = FixedwingModel_P.ZeroBound_UpperSat;
  } else if (rtb_IntegratorSecondOrderLim_ff <
             FixedwingModel_P.ZeroBound_LowerSat) {
    rtb_IntegratorSecondOrderLim_ff = FixedwingModel_P.ZeroBound_LowerSat;
  }

  // End of Saturate: '<S521>/Zero Bound'

  // UnitConversion: '<S535>/Unit Conversion' incorporates:
  //   Sqrt: '<S521>/Math Function1'

  rtb_UnitConversion_a = 3.280839895013123 * std::sqrt
    (rtb_IntegratorSecondOrderLim_ff);

  // Saturate: '<S562>/Limit Function 10ft to 1000ft'
  if (rtb_UnitConversion > FixedwingModel_P.LimitFunction10ftto1000ft_Upper) {
    rtb_jxi = FixedwingModel_P.LimitFunction10ftto1000ft_Upper;
  } else if (rtb_UnitConversion <
             FixedwingModel_P.LimitFunction10ftto1000ft_Lower) {
    rtb_jxi = FixedwingModel_P.LimitFunction10ftto1000ft_Lower;
  } else {
    rtb_jxi = rtb_UnitConversion;
  }

  // End of Saturate: '<S562>/Limit Function 10ft to 1000ft'

  // Fcn: '<S562>/Low Altitude Scale Length'
  rtb_UniformRandomNumber4_j = 0.000823 * rtb_jxi + 0.177;
  if (rtb_UniformRandomNumber4_j < 0.0) {
    rtb_UniformRandomNumber4_j = -rt_powd_snf(-rtb_UniformRandomNumber4_j, 1.2);
  } else {
    rtb_UniformRandomNumber4_j = rt_powd_snf(rtb_UniformRandomNumber4_j, 1.2);
  }

  rtb_LowAltitudeScaleLength = rtb_jxi / rtb_UniformRandomNumber4_j;

  // End of Fcn: '<S562>/Low Altitude Scale Length'
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // UnitConversion: '<S564>/Unit Conversion' incorporates:
    //   Constant: '<S563>/Medium//High Altitude'

    // Unit Conversion - from: m to: ft
    // Expression: output = (3.28084*input) + (0)
    FixedwingModel_B.UnitConversion = 3.280839895013123 *
      FixedwingModel_P.DrydenWindTurbulenceModel_L_hig;
  }

  // Saturate: '<S545>/Limit Height h<1000ft'
  if (rtb_UnitConversion > FixedwingModel_P.LimitHeighth1000ft_UpperSat) {
    rtb_IntegratorSecondOrder_o2_e =
      FixedwingModel_P.LimitHeighth1000ft_UpperSat;
  } else if (rtb_UnitConversion < FixedwingModel_P.LimitHeighth1000ft_LowerSat)
  {
    rtb_IntegratorSecondOrder_o2_e =
      FixedwingModel_P.LimitHeighth1000ft_LowerSat;
  } else {
    rtb_IntegratorSecondOrder_o2_e = rtb_UnitConversion;
  }

  // End of Saturate: '<S545>/Limit Height h<1000ft'

  // Fcn: '<S545>/Low Altitude Intensity'
  rtb_UniformRandomNumber4_j = 0.000823 * rtb_IntegratorSecondOrder_o2_e + 0.177;
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // Gain: '<S545>/sigma_wg ' incorporates:
    //   Constant: '<S522>/Windspeed at 20ft (6m)'
    //   UnitConversion: '<S536>/Unit Conversion'

    // Unit Conversion - from: m/s to: ft/s
    // Expression: output = (3.28084*input) + (0)
    FixedwingModel_B.sigma_wg = FixedwingModel_P.env.windBase / 4.0 *
      3.280839895013123 * FixedwingModel_P.sigma_wg_Gain;
  }

  // Fcn: '<S545>/Low Altitude Intensity'
  if (rtb_UniformRandomNumber4_j < 0.0) {
    rtb_UniformRandomNumber4_j = -rt_powd_snf(-rtb_UniformRandomNumber4_j, 0.4);
  } else {
    rtb_UniformRandomNumber4_j = rt_powd_snf(rtb_UniformRandomNumber4_j, 0.4);
  }

  // Product: '<S545>/sigma_ug, sigma_vg' incorporates:
  //   Fcn: '<S545>/Low Altitude Intensity'

  rtb_sigma_ugsigma_vg = 1.0 / rtb_UniformRandomNumber4_j *
    FixedwingModel_B.sigma_wg;

  // Interpolation_n-D: '<S544>/Medium//High Altitude Intensity' incorporates:
  //   PreLookup: '<S544>/PreLook-Up Index Search  (altitude)'

  bpIndex[0] = plook_bincpa(rtb_UnitConversion,
    FixedwingModel_P.PreLookUpIndexSearchaltitude_Br, 11U,
    &rtb_IntegratorSecondOrder_o2_e,
    &FixedwingModel_DW.PreLookUpIndexSearchaltitude_DW);
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // PreLookup: '<S544>/PreLook-Up Index Search  (prob of exceed)' incorporates:
    //   Constant: '<S544>/Probability of  Exceedance'

    FixedwingModel_B.PreLookUpIndexSearchprobofexc_h = plook_bincpa
      (FixedwingModel_P.DrydenWindTurbulenceModel_TurbP,
       FixedwingModel_P.PreLookUpIndexSearchprobofexcee, 6U,
       &FixedwingModel_B.PreLookUpIndexSearchprobofexcee,
       &FixedwingModel_DW.PreLookUpIndexSearchprobofexcee);
  }

  // Interpolation_n-D: '<S544>/Medium//High Altitude Intensity'
  frac[0] = rtb_IntegratorSecondOrder_o2_e;
  frac[1] = FixedwingModel_B.PreLookUpIndexSearchprobofexcee;
  bpIndex[1] = FixedwingModel_B.PreLookUpIndexSearchprobofexc_h;
  rtb_MediumHighAltitudeIntensity = intrp2d_la_pw(bpIndex, frac,
    FixedwingModel_P.MediumHighAltitudeIntensity_Tab, 12U,
    FixedwingModel_P.MediumHighAltitudeIntensity_max);
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[3] == 0) {
    // Sqrt: '<S537>/Sqrt1' incorporates:
    //   Constant: '<S537>/Constant1'

    rtb_UniformRandomNumber4_j = std::sqrt(FixedwingModel_P.WhiteNoise_Ts);

    // Product: '<S537>/Product' incorporates:
    //   Constant: '<S537>/Constant'
    //   Product: '<S537>/Divide'
    //   RandomNumber: '<S537>/White Noise'
    //   Sqrt: '<S537>/Sqrt'

    FixedwingModel_B.Product_m[0] = std::sqrt(FixedwingModel_P.WhiteNoise_pwr[0])
      / rtb_UniformRandomNumber4_j * FixedwingModel_DW.NextOutput[0];
    FixedwingModel_B.Product_m[1] = std::sqrt(FixedwingModel_P.WhiteNoise_pwr[1])
      / rtb_UniformRandomNumber4_j * FixedwingModel_DW.NextOutput[1];
    FixedwingModel_B.Product_m[2] = std::sqrt(FixedwingModel_P.WhiteNoise_pwr[2])
      / rtb_UniformRandomNumber4_j * FixedwingModel_DW.NextOutput[2];
    FixedwingModel_B.Product_m[3] = std::sqrt(FixedwingModel_P.WhiteNoise_pwr[3])
      / rtb_UniformRandomNumber4_j * FixedwingModel_DW.NextOutput[3];
  }

  // Outputs for Enabled SubSystem: '<S528>/Hvgw(s)' incorporates:
  //   EnablePort: '<S542>/Enable'

  // Outputs for Enabled SubSystem: '<S528>/Hugw(s)' incorporates:
  //   EnablePort: '<S541>/Enable'

  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    if (rtsiIsModeUpdateTimeStep(&(&FixedwingModel_M)->solverInfo)) {
      // Constant: '<S528>/Constant'
      if (FixedwingModel_P.DrydenWindTurbulenceModel_T_on > 0.0) {
        if (!FixedwingModel_DW.Hugws_MODE) {
          // InitializeConditions for Integrator: '<S541>/ug_p'
          FixedwingModel_X.ug_p_CSTATE[0] = FixedwingModel_P.ug_p_IC;
          FixedwingModel_X.ug_p_CSTATE[1] = FixedwingModel_P.ug_p_IC;
          FixedwingModel_DW.Hugws_MODE = true;
        }
      } else if (FixedwingModel_DW.Hugws_MODE) {
        // Disable for Product: '<S541>/w1' incorporates:
        //   Outport: '<S541>/ugw'

        FixedwingModel_B.w1_f[0] = FixedwingModel_P.ugw_Y0;
        FixedwingModel_B.w1_f[1] = FixedwingModel_P.ugw_Y0;
        FixedwingModel_DW.Hugws_MODE = false;
      }
    }

    if (rtsiIsModeUpdateTimeStep(&(&FixedwingModel_M)->solverInfo)) {
      // Constant: '<S528>/Constant'
      if (FixedwingModel_P.DrydenWindTurbulenceModel_T_on > 0.0) {
        if (!FixedwingModel_DW.Hvgws_MODE) {
          // InitializeConditions for Integrator: '<S542>/vg_p1'
          FixedwingModel_X.vg_p1_CSTATE[0] = FixedwingModel_P.vg_p1_IC;

          // InitializeConditions for Integrator: '<S542>/vgw_p2'
          FixedwingModel_X.vgw_p2_CSTATE[0] = FixedwingModel_P.vgw_p2_IC;

          // InitializeConditions for Integrator: '<S542>/vg_p1'
          FixedwingModel_X.vg_p1_CSTATE[1] = FixedwingModel_P.vg_p1_IC;

          // InitializeConditions for Integrator: '<S542>/vgw_p2'
          FixedwingModel_X.vgw_p2_CSTATE[1] = FixedwingModel_P.vgw_p2_IC;
          FixedwingModel_DW.Hvgws_MODE = true;
        }
      } else if (FixedwingModel_DW.Hvgws_MODE) {
        // Disable for Product: '<S542>/w 1' incorporates:
        //   Outport: '<S542>/vgw'

        FixedwingModel_B.w1[0] = FixedwingModel_P.vgw_Y0;
        FixedwingModel_B.w1[1] = FixedwingModel_P.vgw_Y0;
        FixedwingModel_DW.Hvgws_MODE = false;
      }
    }
  }

  // End of Outputs for SubSystem: '<S528>/Hvgw(s)'
  if (FixedwingModel_DW.Hugws_MODE) {
    // Product: '<S541>/Lug//V'
    rtb_rgw_p_idx_0 = rtb_LowAltitudeScaleLength / rtb_UnitConversion_a;
    rtb_rgw_p_idx_1 = FixedwingModel_B.UnitConversion / rtb_UnitConversion_a;

    // Product: '<S541>/w' incorporates:
    //   Gain: '<S541>/(2//pi)'
    //   Integrator: '<S541>/ug_p'
    //   Product: '<S541>/Lug//V1'
    //   Sqrt: '<S541>/sqrt'
    //   Sum: '<S541>/Sum'

    FixedwingModel_B.w_a[0] = (std::sqrt(FixedwingModel_P.upi_Gain *
      rtb_rgw_p_idx_0) * FixedwingModel_B.Product_m[0] -
      FixedwingModel_X.ug_p_CSTATE[0]) / rtb_rgw_p_idx_0;
    FixedwingModel_B.w_a[1] = (std::sqrt(FixedwingModel_P.upi_Gain *
      rtb_rgw_p_idx_1) * FixedwingModel_B.Product_m[0] -
      FixedwingModel_X.ug_p_CSTATE[1]) / rtb_rgw_p_idx_1;

    // Product: '<S541>/w1' incorporates:
    //   Integrator: '<S541>/ug_p'

    FixedwingModel_B.w1_f[0] = FixedwingModel_X.ug_p_CSTATE[0] *
      rtb_sigma_ugsigma_vg;
    FixedwingModel_B.w1_f[1] = FixedwingModel_X.ug_p_CSTATE[1] *
      rtb_MediumHighAltitudeIntensity;
  }

  // End of Outputs for SubSystem: '<S528>/Hugw(s)'

  // Outputs for Enabled SubSystem: '<S528>/Hvgw(s)' incorporates:
  //   EnablePort: '<S542>/Enable'

  if (FixedwingModel_DW.Hvgws_MODE) {
    // Product: '<S542>/Lvg//V' incorporates:
    //   Gain: '<S534>/Lv'

    rtb_rgw_p_idx_0 = FixedwingModel_P.Lv_Gain * rtb_LowAltitudeScaleLength /
      rtb_UnitConversion_a;
    rtb_rgw_p_idx_1 = FixedwingModel_P.Lv_Gain * FixedwingModel_B.UnitConversion
      / rtb_UnitConversion_a;

    // Product: '<S542>/w' incorporates:
    //   Gain: '<S542>/(1//pi)'
    //   Integrator: '<S542>/vg_p1'
    //   Product: '<S542>/Lug//V1'
    //   Sqrt: '<S542>/sqrt'
    //   Sum: '<S542>/Sum'

    FixedwingModel_B.w_f[0] = (std::sqrt(FixedwingModel_P.upi_Gain_d *
      rtb_rgw_p_idx_0) * FixedwingModel_B.Product_m[1] -
      FixedwingModel_X.vg_p1_CSTATE[0]) / rtb_rgw_p_idx_0;

    // Product: '<S542>/w ' incorporates:
    //   Gain: '<S542>/(1//pi)'
    //   Gain: '<S542>/sqrt(3)'
    //   Integrator: '<S542>/vg_p1'
    //   Integrator: '<S542>/vgw_p2'
    //   Product: '<S542>/Lvg//V '
    //   Sum: '<S542>/Sum1'

    FixedwingModel_B.w_d[0] = (FixedwingModel_B.w_f[0] * rtb_rgw_p_idx_0 *
      FixedwingModel_P.sqrt3_Gain + (FixedwingModel_X.vg_p1_CSTATE[0] -
      FixedwingModel_X.vgw_p2_CSTATE[0])) / rtb_rgw_p_idx_0;

    // Product: '<S542>/w' incorporates:
    //   Gain: '<S542>/(1//pi)'
    //   Integrator: '<S542>/vg_p1'
    //   Product: '<S542>/Lug//V1'
    //   Sqrt: '<S542>/sqrt'
    //   Sum: '<S542>/Sum'

    FixedwingModel_B.w_f[1] = (std::sqrt(FixedwingModel_P.upi_Gain_d *
      rtb_rgw_p_idx_1) * FixedwingModel_B.Product_m[1] -
      FixedwingModel_X.vg_p1_CSTATE[1]) / rtb_rgw_p_idx_1;

    // Product: '<S542>/w ' incorporates:
    //   Gain: '<S542>/(1//pi)'
    //   Gain: '<S542>/sqrt(3)'
    //   Integrator: '<S542>/vg_p1'
    //   Integrator: '<S542>/vgw_p2'
    //   Product: '<S542>/Lvg//V '
    //   Sum: '<S542>/Sum1'

    FixedwingModel_B.w_d[1] = (FixedwingModel_B.w_f[1] * rtb_rgw_p_idx_1 *
      FixedwingModel_P.sqrt3_Gain + (FixedwingModel_X.vg_p1_CSTATE[1] -
      FixedwingModel_X.vgw_p2_CSTATE[1])) / rtb_rgw_p_idx_1;

    // Product: '<S542>/w 1' incorporates:
    //   Integrator: '<S542>/vgw_p2'

    FixedwingModel_B.w1[0] = rtb_sigma_ugsigma_vg *
      FixedwingModel_X.vgw_p2_CSTATE[0];
    FixedwingModel_B.w1[1] = rtb_MediumHighAltitudeIntensity *
      FixedwingModel_X.vgw_p2_CSTATE[1];
  }

  // End of Outputs for SubSystem: '<S528>/Hvgw(s)'

  // Gain: '<S534>/Lw'
  frac[0] = FixedwingModel_P.Lw_Gain * rtb_jxi;
  frac[1] = FixedwingModel_P.Lw_Gain * FixedwingModel_B.UnitConversion;

  // Outputs for Enabled SubSystem: '<S528>/Hwgw(s)' incorporates:
  //   EnablePort: '<S543>/Enable'

  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    if (rtsiIsModeUpdateTimeStep(&(&FixedwingModel_M)->solverInfo)) {
      // Constant: '<S528>/Constant'
      if (FixedwingModel_P.DrydenWindTurbulenceModel_T_on > 0.0) {
        if (!FixedwingModel_DW.Hwgws_MODE) {
          // InitializeConditions for Integrator: '<S543>/wg_p1'
          FixedwingModel_X.wg_p1_CSTATE[0] = FixedwingModel_P.wg_p1_IC;

          // InitializeConditions for Integrator: '<S543>/wg_p2'
          FixedwingModel_X.wg_p2_CSTATE[0] = FixedwingModel_P.wg_p2_IC;

          // InitializeConditions for Integrator: '<S543>/wg_p1'
          FixedwingModel_X.wg_p1_CSTATE[1] = FixedwingModel_P.wg_p1_IC;

          // InitializeConditions for Integrator: '<S543>/wg_p2'
          FixedwingModel_X.wg_p2_CSTATE[1] = FixedwingModel_P.wg_p2_IC;
          FixedwingModel_DW.Hwgws_MODE = true;
        }
      } else if (FixedwingModel_DW.Hwgws_MODE) {
        // Disable for Product: '<S543>/Lwg//V 1' incorporates:
        //   Outport: '<S543>/wgw'

        FixedwingModel_B.LwgV1[0] = FixedwingModel_P.wgw_Y0;
        FixedwingModel_B.LwgV1[1] = FixedwingModel_P.wgw_Y0;
        FixedwingModel_DW.Hwgws_MODE = false;
      }
    }

    // UnitConversion: '<S526>/Unit Conversion' incorporates:
    //   Constant: '<S522>/Wind direction'

    // Unit Conversion - from: deg to: rad
    // Expression: output = (0.0174533*input) + (0)
    FixedwingModel_B.UnitConversion_k = 0.017453292519943295 *
      FixedwingModel_P.env.windDirTurb;
  }

  if (FixedwingModel_DW.Hwgws_MODE) {
    // Product: '<S543>/Lwg//V'
    rtb_jxi = frac[0] / rtb_UnitConversion_a;

    // Product: '<S543>/w' incorporates:
    //   Gain: '<S543>/1//pi'
    //   Integrator: '<S543>/wg_p1'
    //   Product: '<S543>/Lug//V1'
    //   Sqrt: '<S543>/sqrt1'
    //   Sum: '<S543>/Sum'

    FixedwingModel_B.w[0] = (std::sqrt(FixedwingModel_P.upi_Gain_o * rtb_jxi) *
      FixedwingModel_B.Product_m[2] - FixedwingModel_X.wg_p1_CSTATE[0]) /
      rtb_jxi;

    // Product: '<S543>/Lwg//V'
    rtb_rgw_p_idx_0 = rtb_jxi;
    rtb_jxi = frac[1] / rtb_UnitConversion_a;

    // Product: '<S543>/w' incorporates:
    //   Gain: '<S543>/1//pi'
    //   Integrator: '<S543>/wg_p1'
    //   Product: '<S543>/Lug//V1'
    //   Sqrt: '<S543>/sqrt1'
    //   Sum: '<S543>/Sum'

    FixedwingModel_B.w[1] = (std::sqrt(FixedwingModel_P.upi_Gain_o * rtb_jxi) *
      FixedwingModel_B.Product_m[2] - FixedwingModel_X.wg_p1_CSTATE[1]) /
      rtb_jxi;
    if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
        (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
      // Sqrt: '<S543>/sqrt' incorporates:
      //   Constant: '<S543>/Constant'

      FixedwingModel_B.sqrt_f = std::sqrt(FixedwingModel_P.Constant_Value_mt);
    }

    // Product: '<S543>/Lwg//V 1' incorporates:
    //   Integrator: '<S543>/wg_p2'

    FixedwingModel_B.LwgV1[0] = FixedwingModel_B.sigma_wg *
      FixedwingModel_X.wg_p2_CSTATE[0];
    FixedwingModel_B.LwgV1[1] = rtb_MediumHighAltitudeIntensity *
      FixedwingModel_X.wg_p2_CSTATE[1];

    // Product: '<S543>/w ' incorporates:
    //   Integrator: '<S543>/wg_p1'
    //   Integrator: '<S543>/wg_p2'
    //   Product: '<S543>/Lwg//V '
    //   Sum: '<S543>/Sum1'

    FixedwingModel_B.w_m[0] = (FixedwingModel_B.w[0] * FixedwingModel_B.sqrt_f *
      rtb_rgw_p_idx_0 + (FixedwingModel_X.wg_p1_CSTATE[0] -
                         FixedwingModel_X.wg_p2_CSTATE[0])) / rtb_rgw_p_idx_0;
    FixedwingModel_B.w_m[1] = (FixedwingModel_B.w[1] * FixedwingModel_B.sqrt_f *
      rtb_jxi + (FixedwingModel_X.wg_p1_CSTATE[1] -
                 FixedwingModel_X.wg_p2_CSTATE[1])) / rtb_jxi;
  }

  // End of Outputs for SubSystem: '<S528>/Hwgw(s)'

  // If: '<S533>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 
  if (rtsiIsModeUpdateTimeStep(&(&FixedwingModel_M)->solverInfo)) {
    if (rtb_UnitConversion <= 1000.0) {
      rtAction = 0;
    } else if (rtb_UnitConversion >= 2000.0) {
      rtAction = 1;
    } else {
      rtAction = 2;
    }

    FixedwingModel_DW.ifHeightMaxlowaltitudeelseifHei = rtAction;
  } else {
    rtAction = FixedwingModel_DW.ifHeightMaxlowaltitudeelseifHei;
  }

  switch (rtAction) {
   case 0:
    // Outputs for IfAction SubSystem: '<S533>/Low altitude  velocities' incorporates:
    //   ActionPort: '<S555>/Action Port'

    Fixedwing_Lowaltitudevelocities(rtb_VectorConcatenate, FixedwingModel_B.w1_f,
      FixedwingModel_B.w1, FixedwingModel_B.LwgV1,
      FixedwingModel_B.UnitConversion_k, rtb_ZeroOrderHold);

    // End of Outputs for SubSystem: '<S533>/Low altitude  velocities'
    break;

   case 1:
    // Outputs for IfAction SubSystem: '<S533>/Medium//High  altitude velocities' incorporates:
    //   ActionPort: '<S556>/Action Port'

    // Gain: '<S345>/Zero-Order Hold' incorporates:
    //   Gain: '<S556>/Gain'

    rtb_ZeroOrderHold[0] = FixedwingModel_P.Gain_Gain_k * FixedwingModel_B.w1_f
      [1];
    rtb_ZeroOrderHold[1] = FixedwingModel_P.Gain_Gain_k * FixedwingModel_B.w1[1];
    rtb_ZeroOrderHold[2] = FixedwingModel_P.Gain_Gain_k *
      FixedwingModel_B.LwgV1[1];

    // End of Outputs for SubSystem: '<S533>/Medium//High  altitude velocities'
    break;

   case 2:
    // Outputs for IfAction SubSystem: '<S533>/Interpolate  velocities' incorporates:
    //   ActionPort: '<S554>/Action Port'

    Fixedwing_Interpolatevelocities(FixedwingModel_B.w1_f, FixedwingModel_B.w1,
      FixedwingModel_B.LwgV1, rtb_VectorConcatenate,
      FixedwingModel_B.UnitConversion_k, rtb_UnitConversion, rtb_ZeroOrderHold,
      &FixedwingModel_P.Interpolatevelocities_k);

    // End of Outputs for SubSystem: '<S533>/Interpolate  velocities'
    break;
  }

  // End of If: '<S533>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 
  // Unit Conversion - from: ft/s to: m/s
  // Expression: output = (0.3048*input) + (0)
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // UnitConversion: '<S565>/Unit Conversion' incorporates:
    //   Constant: '<S523>/Wind Direction'

    // Unit Conversion - from: deg to: rad
    // Expression: output = (0.0174533*input) + (0)
    rtb_Rn = 0.017453292519943295 * FixedwingModel_P.env.windDirHor;

    // Product: '<S523>/Product1' incorporates:
    //   Constant: '<S523>/Wdeg1'
    //   Constant: '<S523>/Wind Speed'
    //   Gain: '<S523>/ '
    //   Trigonometry: '<S523>/SinCos'

    FixedwingModel_B.Product1[0] = FixedwingModel_P._Gain * std::cos(rtb_Rn) *
      FixedwingModel_P.env.windBase;
    FixedwingModel_B.Product1[1] = FixedwingModel_P._Gain * std::sin(rtb_Rn) *
      FixedwingModel_P.env.windBase;
    FixedwingModel_B.Product1[2] = FixedwingModel_P._Gain *
      FixedwingModel_P.Wdeg1_Value * FixedwingModel_P.env.windBase;
  }

  // Switch: '<S9>/Switch' incorporates:
  //   Constant: '<Root>/Constant3'

  if (FixedwingModel_P.env.windOn > FixedwingModel_P.Switch_Threshold) {
    // Gain: '<S345>/Zero-Order Hold' incorporates:
    //   Concatenate: '<S567>/Vector Concatenate'
    //   Gain: '<S9>/Reduce Z Wind'
    //   Product: '<S523>/Transform from Inertial to Body axes'
    //   Sum: '<S9>/Add'
    //   UnitConversion: '<S522>/Unit Conversion'

    for (i = 0; i < 3; i++) {
      rtb_ZeroOrderHold[i] = ((rtb_VectorConcatenate[i + 3] *
        FixedwingModel_B.Product1[1] + rtb_VectorConcatenate[i] *
        FixedwingModel_B.Product1[0]) + rtb_VectorConcatenate[i + 6] *
        FixedwingModel_B.Product1[2]) + 0.3048 * rtb_ZeroOrderHold[i] *
        FixedwingModel_P.ReduceZWind_Gain[i];
    }
  } else {
    // Gain: '<S345>/Zero-Order Hold' incorporates:
    //   Constant: '<S9>/Constant'

    rtb_ZeroOrderHold[0] = FixedwingModel_P.Constant_Value_a[0];
    rtb_ZeroOrderHold[1] = FixedwingModel_P.Constant_Value_a[1];
    rtb_ZeroOrderHold[2] = FixedwingModel_P.Constant_Value_a[2];
  }

  // End of Switch: '<S9>/Switch'

  // Sum: '<S342>/Vair' incorporates:
  //   Concatenate: '<S567>/Vector Concatenate'
  //   Math: '<S9>/Transpose'
  //   Product: '<S9>/Rotate to E Frame'

  for (i = 0; i < 3; i++) {
    rtb_UniformRandomNumber7[i] = FixedwingModel_B.Product[i] -
      ((rtb_VectorConcatenate[3 * i + 1] * rtb_ZeroOrderHold[1] +
        rtb_VectorConcatenate[3 * i] * rtb_ZeroOrderHold[0]) +
       rtb_VectorConcatenate[3 * i + 2] * rtb_ZeroOrderHold[2]);
  }

  // End of Sum: '<S342>/Vair'

  // Product: '<S367>/RL2B * Vw' incorporates:
  //   Concatenate: '<S405>/Vector Concatenate'

  for (i = 0; i < 3; i++) {
    rtb_Sum4_p[i] = (rtb_VectorConcatenate_bz[i + 3] * rtb_UniformRandomNumber7
                     [1] + rtb_VectorConcatenate_bz[i] *
                     rtb_UniformRandomNumber7[0]) + rtb_VectorConcatenate_bz[i +
      6] * rtb_UniformRandomNumber7[2];
  }

  // End of Product: '<S367>/RL2B * Vw'

  // Gain: '<S366>/Gain' incorporates:
  //   TransferFcn: '<S366>/Transfer Fcn'

  rtb_IntegratorSecondOrder_o2_e = FixedwingModel_P.TransferFcn_C *
    FixedwingModel_X.TransferFcn_CSTATE * FixedwingModel_P.Gain_Gain_ly;

  // Saturate: '<S399>/Limit  altitude  to troposhere'
  if (rtb_IntegratorSecondOrder_o2_e >
      FixedwingModel_P.ISAAtmosphereModel1_h_trop) {
    rtb_jxi = FixedwingModel_P.ISAAtmosphereModel1_h_trop;
  } else if (rtb_IntegratorSecondOrder_o2_e <
             FixedwingModel_P.ISAAtmosphereModel1_h0) {
    rtb_jxi = FixedwingModel_P.ISAAtmosphereModel1_h0;
  } else {
    rtb_jxi = rtb_IntegratorSecondOrder_o2_e;
  }

  // End of Saturate: '<S399>/Limit  altitude  to troposhere'

  // Sum: '<S399>/Sum1' incorporates:
  //   Constant: '<S399>/Sea Level  Temperature'
  //   Gain: '<S399>/Lapse Rate'

  rtb_jxi = FixedwingModel_P.env.ISA_T0 - FixedwingModel_P.env.ISA_lapse *
    rtb_jxi;

  // Gain: '<S399>/1//T0'
  rtb_LowAltitudeScaleLength = 1.0 / FixedwingModel_P.env.ISA_T0 * rtb_jxi;

  // Math: '<S399>/(T//T0)^(g//LR) ' incorporates:
  //   Constant: '<S399>/Constant'

  rtb_UniformRandomNumber4_j = FixedwingModel_P.env.ISA_g /
    (FixedwingModel_P.env.ISA_lapse * FixedwingModel_P.env.ISA_R);

  // Sum: '<S399>/Sum' incorporates:
  //   Constant: '<S399>/Altitude of Troposphere'

  Sum_l = FixedwingModel_P.ISAAtmosphereModel1_h_trop -
    rtb_IntegratorSecondOrder_o2_e;

  // Saturate: '<S399>/Limit  altitude  to Stratosphere'
  rtb_sigma_ugsigma_vg = FixedwingModel_P.ISAAtmosphereModel1_h_trop -
    FixedwingModel_P.ISAAtmosphereModel1_h_strat;

  // Math: '<S399>/(T//T0)^(g//LR) '
  if ((rtb_LowAltitudeScaleLength < 0.0) && (rtb_UniformRandomNumber4_j > std::
       floor(rtb_UniformRandomNumber4_j))) {
    rtb_UniformRandomNumber4_j = -rt_powd_snf(-rtb_LowAltitudeScaleLength,
      rtb_UniformRandomNumber4_j);
  } else {
    rtb_UniformRandomNumber4_j = rt_powd_snf(rtb_LowAltitudeScaleLength,
      rtb_UniformRandomNumber4_j);
  }

  // Saturate: '<S399>/Limit  altitude  to Stratosphere'
  if (Sum_l > FixedwingModel_P.LimitaltitudetoStratosphere_Upp) {
    Sum_l = FixedwingModel_P.LimitaltitudetoStratosphere_Upp;
  } else if (Sum_l < rtb_sigma_ugsigma_vg) {
    Sum_l = rtb_sigma_ugsigma_vg;
  }

  // Outputs for Atomic SubSystem: '<S342>/Compute Air Data'
  // Sum: '<S372>/Sum' incorporates:
  //   Product: '<S372>/Product'
  //   Product: '<S372>/Product1'
  //   Product: '<S372>/Product2'
  //   Sum: '<S375>/Sum'

  rtb_sigma_ugsigma_vg = (rtb_Sum4_p[0] * rtb_Sum4_p[0] + rtb_Sum4_p[1] *
    rtb_Sum4_p[1]) + rtb_Sum4_p[2] * rtb_Sum4_p[2];

  // Product: '<S370>/Product2' incorporates:
  //   Gain: '<S399>/g//R'
  //   Gain: '<S399>/rho0'
  //   Math: '<S399>/Stratosphere Model'
  //   Product: '<S399>/Product'
  //   Product: '<S399>/Product1'
  //   Product: '<S399>/Product3'
  //   Sum: '<S372>/Sum'
  //
  //  About '<S399>/Stratosphere Model':
  //   Operator: exp

  rtb_Product2_g = std::exp(FixedwingModel_P.env.ISA_g /
    FixedwingModel_P.env.ISA_R * Sum_l * (1.0 / rtb_jxi)) *
    (rtb_UniformRandomNumber4_j / rtb_LowAltitudeScaleLength *
     FixedwingModel_P.env.ISA_rho0) * rtb_sigma_ugsigma_vg;

  // Sqrt: '<S371>/Airspeed'
  rtb_sincos_o1_idx_0 = std::sqrt(rtb_sigma_ugsigma_vg);

  // Trigonometry: '<S371>/Incidence'
  FixedwingModel_B.Incidence = rt_atan2d_snf(rtb_Sum4_p[2], rtb_Sum4_p[0]);

  // Product: '<S371>/Product'
  Sum_l = rtb_Sum4_p[1] / rtb_sincos_o1_idx_0;

  // Trigonometry: '<S371>/Sideslip'
  if (Sum_l > 1.0) {
    Sum_l = 1.0;
  } else if (Sum_l < -1.0) {
    Sum_l = -1.0;
  }

  rtb_jxi = std::asin(Sum_l);

  // End of Trigonometry: '<S371>/Sideslip'
  // End of Outputs for SubSystem: '<S342>/Compute Air Data'

  // Trigonometry: '<S380>/sincos' incorporates:
  //   SignalConversion generated from: '<S380>/sincos'
  //   Trigonometry: '<S381>/sincos'

  // Unit Conversion - from: lbm to: kg
  // Expression: output = (0.453592*input) + (0)
  rtb_UniformRandomNumber4_j = std::sin(FixedwingModel_B.Incidence);
  rtb_LowAltitudeScaleLength = std::cos(FixedwingModel_B.Incidence);
  rtb_sigma_ugsigma_vg = std::sin(rtb_jxi);
  rtb_IntegratorSecondOrder_o2_e = std::cos(rtb_jxi);

  // Fcn: '<S380>/11' incorporates:
  //   Fcn: '<S381>/11'
  //   Trigonometry: '<S380>/sincos'

  rtb_rgw_p_idx_0 = rtb_LowAltitudeScaleLength * rtb_IntegratorSecondOrder_o2_e;

  // Math: '<S378>/RW2B' incorporates:
  //   Fcn: '<S380>/11'
  //   Math: '<S379>/RW2B'
  //   Trigonometry: '<S380>/sincos'

  rtb_RW2B[0] = rtb_rgw_p_idx_0;
  rtb_RW2B[1] = rtb_sigma_ugsigma_vg;

  // Fcn: '<S380>/13' incorporates:
  //   Fcn: '<S381>/13'
  //   Trigonometry: '<S380>/sincos'

  rtb_rgw_p_idx_1 = rtb_UniformRandomNumber4_j * rtb_IntegratorSecondOrder_o2_e;

  // Math: '<S378>/RW2B' incorporates:
  //   Fcn: '<S380>/13'
  //   Math: '<S379>/RW2B'

  rtb_RW2B[2] = rtb_rgw_p_idx_1;

  // Fcn: '<S380>/21' incorporates:
  //   Fcn: '<S381>/21'
  //   Trigonometry: '<S380>/sincos'

  rtb_Eularrad_idx_2 = -rtb_LowAltitudeScaleLength * rtb_sigma_ugsigma_vg;

  // Math: '<S378>/RW2B' incorporates:
  //   Fcn: '<S380>/21'
  //   Math: '<S379>/RW2B'
  //   Trigonometry: '<S380>/sincos'

  rtb_RW2B[3] = rtb_Eularrad_idx_2;
  rtb_RW2B[4] = rtb_IntegratorSecondOrder_o2_e;

  // Fcn: '<S380>/23' incorporates:
  //   Fcn: '<S381>/23'
  //   Trigonometry: '<S380>/sincos'

  rtb_Add = -rtb_UniformRandomNumber4_j * rtb_sigma_ugsigma_vg;

  // Math: '<S378>/RW2B' incorporates:
  //   Fcn: '<S380>/23'
  //   Fcn: '<S380>/31'
  //   Fcn: '<S380>/32'
  //   Math: '<S379>/RW2B'
  //   Trigonometry: '<S380>/sincos'

  rtb_RW2B[5] = rtb_Add;
  rtb_RW2B[6] = -rtb_UniformRandomNumber4_j;
  rtb_RW2B[7] = 0.0;
  rtb_RW2B[8] = rtb_LowAltitudeScaleLength;

  // Gain: '<S345>/Zero-Order Hold' incorporates:
  //   Integrator: '<S341>/p,q,r '

  rtb_ZeroOrderHold[0] = FixedwingModel_X.pqr_CSTATE[0];
  rtb_ZeroOrderHold[1] = FixedwingModel_X.pqr_CSTATE[1];
  rtb_ZeroOrderHold[2] = FixedwingModel_X.pqr_CSTATE[2];

  // Saturate: '<S398>/Saturation'
  if (rtb_sincos_o1_idx_0 > FixedwingModel_P.Saturation_UpperSat_a) {
    Xe_idx_2 = FixedwingModel_P.Saturation_UpperSat_a;
  } else if (rtb_sincos_o1_idx_0 < FixedwingModel_P.Saturation_LowerSat_c) {
    Xe_idx_2 = FixedwingModel_P.Saturation_LowerSat_c;
  } else {
    Xe_idx_2 = rtb_sincos_o1_idx_0;
  }

  // End of Saturate: '<S398>/Saturation'

  // Sum: '<S395>/Sum' incorporates:
  //   Constant: '<S395>/CL0'
  //   Constant: '<S395>/CLDe'
  //   Constant: '<S395>/CLa'
  //   Constant: '<S395>/CLa_dot'
  //   Constant: '<S395>/CmDe1'
  //   Constant: '<S397>/Constant'
  //   Constant: '<S398>/Cmq2'
  //   Product: '<S395>/Product1'
  //   Product: '<S395>/Product2'
  //   Product: '<S395>/Product4'
  //   Product: '<S395>/Product5'
  //   Product: '<S397>/Product'
  //   Product: '<S398>/Product'
  //   SecondOrderIntegrator: '<S11>/Integrator, Second-Order'
  //   SecondOrderIntegrator: '<S14>/Integrator, Second-Order'
  //   TransferFcn: '<S384>/Transfer Fcn'

  rtb_Rn = ((((FixedwingModel_P.TransferFcn_C_m *
               FixedwingModel_X.TransferFcn_CSTATE_n +
               FixedwingModel_P.TransferFcn_D * FixedwingModel_B.Incidence) *
              FixedwingModel_P.uav.aero.CLa_dot + (FixedwingModel_P.uav.aero.CLa
    * FixedwingModel_B.Incidence + FixedwingModel_P.uav.aero.CL0)) +
             FixedwingModel_P.uav.aero.CLDe *
             FixedwingModel_X.IntegratorSecondOrder_CSTATE_e[0]) +
            FixedwingModel_P.uav.aero.CLDf *
            FixedwingModel_X.IntegratorSecondOrder_CSTATE_k[0]) +
    rtb_ZeroOrderHold[1] * FixedwingModel_P.uav.geometry.chord / Xe_idx_2 *
    FixedwingModel_P.uav.aero.CLq;

  // Outputs for Atomic SubSystem: '<S342>/Compute Air Data'
  // Product: '<S382>/Product1' incorporates:
  //   Constant: '<S382>/span1'
  //   Constant: '<S382>/span2'
  //   Gain: '<S370>/1//2rhoV^2'

  rtb_Gain9_d = FixedwingModel_P.u2rhoV2_Gain * rtb_Product2_g *
    FixedwingModel_P.uav.geometry.span * FixedwingModel_P.uav.geometry.chord;

  // End of Outputs for SubSystem: '<S342>/Compute Air Data'

  // SignalConversion generated from: '<S378>/Product2' incorporates:
  //   Constant: '<S385>/CYDr'
  //   Constant: '<S385>/CYb'
  //   Constant: '<S394>/Apolar'
  //   Constant: '<S394>/Apolar (A2)'
  //   Constant: '<S394>/CD0'
  //   Gain: '<S384>/Y-down'
  //   Gain: '<S394>/Gain'
  //   Math: '<S394>/Math Function'
  //   Product: '<S382>/Fx_a(Drag)'
  //   Product: '<S382>/Fy_a(Side)'
  //   Product: '<S382>/Fz_a(Lift)'
  //   Product: '<S385>/Product'
  //   Product: '<S385>/Product1'
  //   Product: '<S394>/Product'
  //   Product: '<S394>/Product1'
  //   SecondOrderIntegrator: '<S12>/Integrator, Second-Order'
  //   Sum: '<S385>/Sum2'
  //   Sum: '<S394>/Sum1'

  rtb_Product2_g = ((rtb_Rn * rtb_Rn * FixedwingModel_P.uav.aero.Apolar +
                     FixedwingModel_P.uav.aero.CD0) + rtb_Rn *
                    FixedwingModel_P.uav.aero.A1) *
    FixedwingModel_P.Gain_Gain_g1 * rtb_Gain9_d;
  Xe_idx_2 = (FixedwingModel_P.uav.aero.CYb * rtb_jxi +
              FixedwingModel_P.uav.aero.CYDr *
              FixedwingModel_X.IntegratorSecondOrder_CSTATE_a[0]) * rtb_Gain9_d;
  Ve_idx_2 = FixedwingModel_P.Ydown_Gain * rtb_Rn * rtb_Gain9_d;
  for (s281_iter = 0; s281_iter < 3; s281_iter++) {
    // Trigonometry: '<S404>/sincos'
    rtb_IntegratorSecondOrderLim_ff = rtb_IntegratorSecondOrderLimi_m[s281_iter];
    rtb_DataTypeConversion2[s281_iter] = std::cos
      (rtb_IntegratorSecondOrderLim_ff);
    rtb_IntegratorSecondOrderLimi_m[s281_iter] = std::sin
      (rtb_IntegratorSecondOrderLim_ff);

    // Product: '<S378>/Product2' incorporates:
    //   Math: '<S379>/RW2B'

    rtb_ubvbwb[s281_iter] = (rtb_RW2B[s281_iter + 3] * Xe_idx_2 +
      rtb_RW2B[s281_iter] * rtb_Product2_g) + rtb_RW2B[s281_iter + 6] * Ve_idx_2;
  }

  // Fcn: '<S404>/Fcn11'
  rtb_VectorConcatenate_bz[0] = rtb_DataTypeConversion2[0] *
    rtb_DataTypeConversion2[1];

  // Fcn: '<S404>/Fcn21' incorporates:
  //   Fcn: '<S404>/Fcn22'

  rtb_Product2_g = rtb_IntegratorSecondOrderLimi_m[1] *
    rtb_IntegratorSecondOrderLimi_m[2];
  rtb_VectorConcatenate_bz[1] = rtb_Product2_g * rtb_DataTypeConversion2[0] -
    rtb_IntegratorSecondOrderLimi_m[0] * rtb_DataTypeConversion2[2];

  // Fcn: '<S404>/Fcn31' incorporates:
  //   Fcn: '<S404>/Fcn32'

  Xe_idx_2 = rtb_IntegratorSecondOrderLimi_m[1] * rtb_DataTypeConversion2[2];
  rtb_VectorConcatenate_bz[2] = Xe_idx_2 * rtb_DataTypeConversion2[0] +
    rtb_IntegratorSecondOrderLimi_m[0] * rtb_IntegratorSecondOrderLimi_m[2];

  // Fcn: '<S404>/Fcn12'
  rtb_VectorConcatenate_bz[3] = rtb_IntegratorSecondOrderLimi_m[0] *
    rtb_DataTypeConversion2[1];

  // Fcn: '<S404>/Fcn22'
  rtb_VectorConcatenate_bz[4] = rtb_Product2_g *
    rtb_IntegratorSecondOrderLimi_m[0] + rtb_DataTypeConversion2[0] *
    rtb_DataTypeConversion2[2];

  // Fcn: '<S404>/Fcn32'
  rtb_VectorConcatenate_bz[5] = Xe_idx_2 * rtb_IntegratorSecondOrderLimi_m[0] -
    rtb_DataTypeConversion2[0] * rtb_IntegratorSecondOrderLimi_m[2];

  // Fcn: '<S404>/Fcn13'
  rtb_VectorConcatenate_bz[6] = -rtb_IntegratorSecondOrderLimi_m[1];

  // Fcn: '<S404>/Fcn23'
  rtb_VectorConcatenate_bz[7] = rtb_DataTypeConversion2[1] *
    rtb_IntegratorSecondOrderLimi_m[2];

  // Fcn: '<S404>/Fcn33'
  rtb_VectorConcatenate_bz[8] = rtb_DataTypeConversion2[1] *
    rtb_DataTypeConversion2[2];

  // Sum: '<S342>/Sum4' incorporates:
  //   Constant: '<S342>/Constant'
  //   Constant: '<S342>/Constant1'
  //   Gain: '<S342>/Gain'

  rtb_UniformRandomNumber7[0] = (FixedwingModel_P.Constant_Value_h[0] +
    FixedwingModel_P.Constant1_Value_o3) * FixedwingModel_P.Gain_Gain_kp;
  rtb_UniformRandomNumber7[1] = (FixedwingModel_P.Constant_Value_h[1] +
    FixedwingModel_P.Constant1_Value_o3) * FixedwingModel_P.Gain_Gain_kp;
  rtb_UniformRandomNumber7[2] = (FixedwingModel_P.Constant_Value_h[2] +
    rtb_ubvbwb[2]) * FixedwingModel_P.Gain_Gain_kp;

  // Sum: '<S342>/Sum' incorporates:
  //   Concatenate: '<S405>/Vector Concatenate'
  //   Constant: '<S342>/Gravitational Force'
  //   Product: '<S368>/Product1'

  for (i = 0; i < 3; i++) {
    // Saturate: '<S342>/Saturation' incorporates:
    //   Product: '<S368>/Product1'

    Sum_l = rtb_UniformRandomNumber7[i];
    if (Sum_l > FixedwingModel_P.Saturation_UpperSat_g) {
      Sum_l = FixedwingModel_P.Saturation_UpperSat_g;
    } else if (Sum_l < FixedwingModel_P.Saturation_LowerSat_p) {
      Sum_l = FixedwingModel_P.Saturation_LowerSat_p;
    }

    // End of Saturate: '<S342>/Saturation'
    rtb_Sum4_p[i] = ((rtb_VectorConcatenate_bz[i + 3] *
                      FixedwingModel_P.GravitationalForce_Value[1] +
                      rtb_VectorConcatenate_bz[i] *
                      FixedwingModel_P.GravitationalForce_Value[0]) +
                     rtb_VectorConcatenate_bz[i + 6] *
                     FixedwingModel_P.GravitationalForce_Value[2]) + (Sum_l +
      rtb_ubvbwb[i]);
  }

  // End of Sum: '<S342>/Sum'

  // Math: '<S379>/RW2B' incorporates:
  //   Fcn: '<S381>/31'
  //   Fcn: '<S381>/32'

  rtb_RW2B[6] = -rtb_UniformRandomNumber4_j;
  rtb_RW2B[0] = rtb_rgw_p_idx_0;
  rtb_RW2B[1] = rtb_sigma_ugsigma_vg;
  rtb_RW2B[2] = rtb_rgw_p_idx_1;
  rtb_RW2B[3] = rtb_Eularrad_idx_2;
  rtb_RW2B[4] = rtb_IntegratorSecondOrder_o2_e;
  rtb_RW2B[5] = rtb_Add;
  rtb_RW2B[7] = 0.0;
  rtb_RW2B[8] = rtb_LowAltitudeScaleLength;

  // Saturate: '<S389>/Saturation'
  if (rtb_sincos_o1_idx_0 > FixedwingModel_P.Saturation_UpperSat_n) {
    Xe_idx_2 = FixedwingModel_P.Saturation_UpperSat_n;
  } else if (rtb_sincos_o1_idx_0 < FixedwingModel_P.Saturation_LowerSat_h) {
    Xe_idx_2 = FixedwingModel_P.Saturation_LowerSat_h;
  } else {
    Xe_idx_2 = rtb_sincos_o1_idx_0;
  }

  // End of Saturate: '<S389>/Saturation'

  // Saturate: '<S390>/Saturation'
  if (rtb_sincos_o1_idx_0 > FixedwingModel_P.Saturation_UpperSat_b) {
    rtb_UniformRandomNumber4_j = FixedwingModel_P.Saturation_UpperSat_b;
  } else if (rtb_sincos_o1_idx_0 < FixedwingModel_P.Saturation_LowerSat_l) {
    rtb_UniformRandomNumber4_j = FixedwingModel_P.Saturation_LowerSat_l;
  } else {
    rtb_UniformRandomNumber4_j = rtb_sincos_o1_idx_0;
  }

  // End of Saturate: '<S390>/Saturation'

  // SignalConversion generated from: '<S379>/Product2' incorporates:
  //   Constant: '<S382>/chord'
  //   Constant: '<S382>/span'
  //   Constant: '<S386>/ClDa'
  //   Constant: '<S386>/ClDr'
  //   Constant: '<S386>/Clb'
  //   Constant: '<S388>/Constant'
  //   Constant: '<S388>/Constant1'
  //   Constant: '<S389>/Cmq1'
  //   Constant: '<S389>/Cmq2'
  //   Constant: '<S390>/Cmq3'
  //   Constant: '<S390>/Cmq4'
  //   Constant: '<S396>/Cm0'
  //   Constant: '<S396>/CmDe'
  //   Constant: '<S396>/CmDf'
  //   Constant: '<S396>/Cma'
  //   Constant: '<S396>/Cma1'
  //   Constant: '<S396>/chord'
  //   Constant: '<S396>/elarm'
  //   Product: '<S382>/Mx_a'
  //   Product: '<S382>/My_a'
  //   Product: '<S386>/Product1'
  //   Product: '<S386>/Product4'
  //   Product: '<S386>/Product5'
  //   Product: '<S388>/Product'
  //   Product: '<S388>/Product1'
  //   Product: '<S389>/Product'
  //   Product: '<S390>/Product1'
  //   Product: '<S396>/Product1'
  //   Product: '<S396>/Product2'
  //   Product: '<S396>/Product3'
  //   Product: '<S396>/Product4'
  //   SecondOrderIntegrator: '<S11>/Integrator, Second-Order'
  //   SecondOrderIntegrator: '<S12>/Integrator, Second-Order'
  //   SecondOrderIntegrator: '<S13>/Integrator, Second-Order'
  //   SecondOrderIntegrator: '<S14>/Integrator, Second-Order'
  //   Sum: '<S386>/Sum'
  //   Sum: '<S396>/Sum'

  rtb_DataTypeConversion2[0] = ((rtb_ZeroOrderHold[0] *
    FixedwingModel_P.Cmq1_Value * FixedwingModel_P.uav.geometry.span / Xe_idx_2 *
    FixedwingModel_P.uav.aero.Clp + ((FixedwingModel_P.uav.aero.Clb * rtb_jxi +
    FixedwingModel_P.uav.aero.ClDa *
    FixedwingModel_X.IntegratorSecondOrder_CSTATE_h[0]) +
    FixedwingModel_P.uav.aero.ClDr *
    FixedwingModel_X.IntegratorSecondOrder_CSTATE_a[0])) + rtb_ZeroOrderHold[2] *
    FixedwingModel_P.Cmq3_Value * FixedwingModel_P.uav.geometry.span /
    rtb_UniformRandomNumber4_j * FixedwingModel_P.uav.aero.Clr) * rtb_Gain9_d *
    FixedwingModel_P.uav.geometry.span;
  rtb_DataTypeConversion2[1] = (((FixedwingModel_P.uav.aero.CmDe *
    FixedwingModel_X.IntegratorSecondOrder_CSTATE_e[0] *
    FixedwingModel_P.uav.geometry.elarm / FixedwingModel_P.uav.geometry.chord +
    (FixedwingModel_P.uav.aero.Cma * FixedwingModel_B.Incidence +
     FixedwingModel_P.uav.aero.Cm0)) + FixedwingModel_P.uav.aero.CmDf *
    FixedwingModel_X.IntegratorSecondOrder_CSTATE_k[0]) +
    FixedwingModel_P.uav.aero.Cmq * rtb_ZeroOrderHold[1]) * rtb_Gain9_d *
    FixedwingModel_P.uav.geometry.chord;

  // Saturate: '<S392>/Saturation'
  if (rtb_sincos_o1_idx_0 > FixedwingModel_P.Saturation_UpperSat_i) {
    Xe_idx_2 = FixedwingModel_P.Saturation_UpperSat_i;
  } else if (rtb_sincos_o1_idx_0 < FixedwingModel_P.Saturation_LowerSat_cz) {
    Xe_idx_2 = FixedwingModel_P.Saturation_LowerSat_cz;
  } else {
    Xe_idx_2 = rtb_sincos_o1_idx_0;
  }

  // End of Saturate: '<S392>/Saturation'

  // Saturate: '<S393>/Saturation'
  if (rtb_sincos_o1_idx_0 > FixedwingModel_P.Saturation_UpperSat_m) {
    rtb_UniformRandomNumber4_j = FixedwingModel_P.Saturation_UpperSat_m;
  } else if (rtb_sincos_o1_idx_0 < FixedwingModel_P.Saturation_LowerSat_b) {
    rtb_UniformRandomNumber4_j = FixedwingModel_P.Saturation_LowerSat_b;
  } else {
    rtb_UniformRandomNumber4_j = rtb_sincos_o1_idx_0;
  }

  // End of Saturate: '<S393>/Saturation'

  // SignalConversion generated from: '<S379>/Product2' incorporates:
  //   Constant: '<S382>/span'
  //   Constant: '<S387>/CnDa'
  //   Constant: '<S387>/CnDr'
  //   Constant: '<S387>/Cnb'
  //   Constant: '<S391>/Constant'
  //   Constant: '<S391>/Constant1'
  //   Constant: '<S392>/Cmq1'
  //   Constant: '<S392>/Cmq2'
  //   Constant: '<S393>/Cmq3'
  //   Constant: '<S393>/Cmq4'
  //   Product: '<S382>/Mz_a'
  //   Product: '<S387>/Product1'
  //   Product: '<S387>/Product4'
  //   Product: '<S387>/Product5'
  //   Product: '<S391>/Product'
  //   Product: '<S391>/Product1'
  //   Product: '<S392>/Product'
  //   Product: '<S393>/Product1'
  //   SecondOrderIntegrator: '<S12>/Integrator, Second-Order'
  //   SecondOrderIntegrator: '<S13>/Integrator, Second-Order'
  //   Sum: '<S387>/Sum'

  rtb_DataTypeConversion2[2] = ((rtb_ZeroOrderHold[0] *
    FixedwingModel_P.Cmq1_Value_b * FixedwingModel_P.uav.geometry.span /
    Xe_idx_2 * FixedwingModel_P.uav.aero.Cnp + ((FixedwingModel_P.uav.aero.Cnb *
    rtb_jxi + FixedwingModel_P.uav.aero.CnDa *
    FixedwingModel_X.IntegratorSecondOrder_CSTATE_h[0]) +
    FixedwingModel_P.uav.aero.CnDr *
    FixedwingModel_X.IntegratorSecondOrder_CSTATE_a[0])) + rtb_ZeroOrderHold[2] *
    FixedwingModel_P.Cmq3_Value_c * FixedwingModel_P.uav.geometry.span /
    rtb_UniformRandomNumber4_j * FixedwingModel_P.uav.aero.Cnr) * rtb_Gain9_d *
    FixedwingModel_P.uav.geometry.span;

  // Product: '<S379>/Product2' incorporates:
  //   Math: '<S379>/RW2B'

  for (i = 0; i < 3; i++) {
    rtb_ubvbwb[i] = (rtb_RW2B[i + 3] * rtb_DataTypeConversion2[1] + rtb_RW2B[i] *
                     rtb_DataTypeConversion2[0]) + rtb_RW2B[i + 6] *
      rtb_DataTypeConversion2[2];
  }

  // End of Product: '<S379>/Product2'
  for (i = 0; i < 9; i++) {
    // Gain: '<S8>/Gain4' incorporates:
    //   Concatenate: '<S356>/Vector Concatenate'

    rtb_VectorConcatenate_g[i] *= FixedwingModel_P.Gain4_Gain;
  }

  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // Gain: '<S344>/Gain' incorporates:
    //   Constant: '<S344>/ModelParam.uavMass'

    rtb_Gain_d[2] = FixedwingModel_P.Gain_Gain_n[2] *
      FixedwingModel_P.uav.geometry.mass;
  }

  // Gain: '<S8>/Gain6'
  wb[0] = FixedwingModel_P.Gain6_Gain * rtb_ZeroOrderHold[0];

  // Gain: '<S8>/Gain2'
  rtb_LowAltitudeScaleLength = FixedwingModel_P.Gain2_Gain_o *
    FixedwingModel_B.xeyeze[0];

  // Gain: '<S8>/Gain'
  rtb_sigma_ugsigma_vg = FixedwingModel_P.Gain_Gain_oe *
    FixedwingModel_B.Product[0];

  // Gain: '<S8>/Gain6'
  wb[1] = FixedwingModel_P.Gain6_Gain * rtb_ZeroOrderHold[1];

  // Gain: '<S8>/Gain2'
  rtb_IntegratorSecondOrder_o2_e = FixedwingModel_P.Gain2_Gain_o *
    FixedwingModel_B.xeyeze[1];

  // Gain: '<S8>/Gain'
  rtb_Product2_g = FixedwingModel_P.Gain_Gain_oe * FixedwingModel_B.Product[1];

  // Gain: '<S8>/Gain6'
  wb[2] = FixedwingModel_P.Gain6_Gain * rtb_ZeroOrderHold[2];

  // Gain: '<S8>/Gain2'
  Xe_idx_2 = FixedwingModel_P.Gain2_Gain_o * FixedwingModel_B.xeyeze[2];

  // Gain: '<S8>/Gain'
  Ve_idx_2 = FixedwingModel_P.Gain_Gain_oe * FixedwingModel_B.Product[2];

  // Gain: '<S8>/Gain3' incorporates:
  //   Integrator: '<S346>/phi theta psi'

  rtb_Eularrad_idx_2 = FixedwingModel_P.Gain3_Gain *
    FixedwingModel_X.phithetapsi_CSTATE[2];

  // Trigonometry: '<S411>/sincos' incorporates:
  //   MATLAB Function: '<S344>/OnGroundFaceup'

  // MATLAB Function 'Small Fixed Wing UAV Dynamics/GroundModel/OnGroundFaceup': '<S413>:1' 
  // '<S413>:1:3' targetRoll = 0;
  //  if cos(EulerAng(1))<0
  //      targetRoll=pi;
  //  end
  // '<S413>:1:8' targetPitch = 0;
  //  if cos(EulerAng(2))<0
  //          targetPitch=pi;
  //  end
  // '<S413>:1:13' y = [targetRoll;targetPitch;EulerAng(3)];
  rtb_DataTypeConversion2[2] = std::sin(rtb_Eularrad_idx_2);
  rtb_IntegratorSecondOrderLimi_m[2] = std::cos(rtb_Eularrad_idx_2);

  // Product: '<S492>/u(5)*u(6)' incorporates:
  //   Concatenate: '<S501>/Vector Concatenate'

  rtb_VectorConcatenate_bz[0] = rtb_IntegratorSecondOrderLimi_m[2];

  // Sum: '<S495>/Sum' incorporates:
  //   Concatenate: '<S501>/Vector Concatenate'
  //   Product: '<S495>/u(3)*u(4)'
  //   Product: '<S495>/u(6)*u(1)*u(2)'

  rtb_VectorConcatenate_bz[1] = 0.0 * rtb_IntegratorSecondOrderLimi_m[2] * 0.0 -
    rtb_DataTypeConversion2[2];

  // Sum: '<S498>/Sum' incorporates:
  //   Concatenate: '<S501>/Vector Concatenate'
  //   Product: '<S498>/u(1)*u(3)'
  //   Product: '<S498>/u(2)*u(4)*u(6)'

  rtb_VectorConcatenate_bz[2] = 0.0 * rtb_DataTypeConversion2[2] + 0.0 *
    rtb_IntegratorSecondOrderLimi_m[2];

  // Product: '<S493>/u(3)*u(5)' incorporates:
  //   Concatenate: '<S501>/Vector Concatenate'

  rtb_VectorConcatenate_bz[3] = rtb_DataTypeConversion2[2];

  // Sum: '<S496>/Sum' incorporates:
  //   Concatenate: '<S501>/Vector Concatenate'
  //   Product: '<S496>/u(1)*u(2)*u(3)'
  //   Product: '<S496>/u(4)*u(6)'

  rtb_VectorConcatenate_bz[4] = 0.0 * rtb_DataTypeConversion2[2] +
    rtb_IntegratorSecondOrderLimi_m[2];

  // Sum: '<S499>/Sum' incorporates:
  //   Concatenate: '<S501>/Vector Concatenate'
  //   Product: '<S499>/u(1)*u(6)'
  //   Product: '<S499>/u(2)*u(3)*u(4)'

  rtb_VectorConcatenate_bz[5] = 0.0 * rtb_DataTypeConversion2[2] - 0.0 *
    rtb_IntegratorSecondOrderLimi_m[2];

  // UnaryMinus: '<S494>/Unary Minus' incorporates:
  //   Concatenate: '<S501>/Vector Concatenate'

  rtb_VectorConcatenate_bz[6] = -0.0;

  // Product: '<S497>/u(1)*u(5)' incorporates:
  //   Concatenate: '<S501>/Vector Concatenate'

  rtb_VectorConcatenate_bz[7] = 0.0;

  // Product: '<S500>/u(4)*u(5)' incorporates:
  //   Concatenate: '<S501>/Vector Concatenate'

  rtb_VectorConcatenate_bz[8] = 1.0;

  // Sum: '<S457>/Add' incorporates:
  //   Product: '<S492>/u(5)*u(6)'

  rtb_IntegratorSecondOrderLimi_m[0] = rtb_IntegratorSecondOrderLimi_m[2];
  rtb_Add = rtb_IntegratorSecondOrderLimi_m[0] + rtb_VectorConcatenate_bz[4];

  // If: '<S410>/If' incorporates:
  //   Merge: '<S410>/Merge'
  //   Sum: '<S457>/Add'

  if (rtsiIsModeUpdateTimeStep(&(&FixedwingModel_M)->solverInfo)) {
    rtAction = static_cast<int8_T>(!(rtb_Add + 1.0 > 0.0));
    FixedwingModel_DW.If_ActiveSubsystem = rtAction;
  } else {
    rtAction = FixedwingModel_DW.If_ActiveSubsystem;
  }

  switch (rtAction) {
   case 0:
    // Outputs for IfAction SubSystem: '<S410>/Positive Trace' incorporates:
    //   ActionPort: '<S455>/Action Port'

    FixedwingModel_PositiveTrace(rtb_Add + 1.0, rtb_VectorConcatenate_bz,
      &FixedwingModel_B.Merge_l[0], &FixedwingModel_B.Merge_l[1],
      &FixedwingModel_P.PositiveTrace_f);

    // End of Outputs for SubSystem: '<S410>/Positive Trace'
    break;

   case 1:
    // Outputs for IfAction SubSystem: '<S410>/Negative Trace' incorporates:
    //   ActionPort: '<S454>/Action Port'

    FixedwingModel_NegativeTrace(rtb_VectorConcatenate_bz,
      FixedwingModel_B.Merge_l, &FixedwingModel_DW.NegativeTrace_a,
      &FixedwingModel_P.NegativeTrace_a);

    // End of Outputs for SubSystem: '<S410>/Negative Trace'
    break;
  }

  // End of If: '<S410>/If'

  // Sum: '<S503>/Sum' incorporates:
  //   Product: '<S503>/Product'
  //   Product: '<S503>/Product1'
  //   Product: '<S503>/Product2'
  //   Product: '<S503>/Product3'

  rtb_jxi = ((FixedwingModel_B.Merge_l[0] * FixedwingModel_B.Merge_l[0] +
              FixedwingModel_B.Merge_l[1] * FixedwingModel_B.Merge_l[1]) +
             FixedwingModel_B.Merge_l[2] * FixedwingModel_B.Merge_l[2]) +
    FixedwingModel_B.Merge_l[3] * FixedwingModel_B.Merge_l[3];

  // Product: '<S414>/Divide'
  rtb_Add = FixedwingModel_B.Merge_l[0] / rtb_jxi;

  // Sum: '<S419>/Add' incorporates:
  //   Sum: '<S158>/Add'

  rtb_Add_m_tmp = (rtb_VectorConcatenate_g[0] + rtb_VectorConcatenate_g[4]) +
    rtb_VectorConcatenate_g[8];

  // If: '<S409>/If' incorporates:
  //   Merge: '<S409>/Merge'
  //   Sum: '<S419>/Add'

  if (rtsiIsModeUpdateTimeStep(&(&FixedwingModel_M)->solverInfo)) {
    rtAction = static_cast<int8_T>(!(rtb_Add_m_tmp > 0.0));
    FixedwingModel_DW.If_ActiveSubsystem_n = rtAction;
  } else {
    rtAction = FixedwingModel_DW.If_ActiveSubsystem_n;
  }

  switch (rtAction) {
   case 0:
    // Outputs for IfAction SubSystem: '<S409>/Positive Trace' incorporates:
    //   ActionPort: '<S417>/Action Port'

    FixedwingModel_PositiveTrace(rtb_Add_m_tmp, rtb_VectorConcatenate_g,
      &FixedwingModel_B.Merge_lc[0], &FixedwingModel_B.Merge_lc[1],
      &FixedwingModel_P.PositiveTrace_l);

    // End of Outputs for SubSystem: '<S409>/Positive Trace'
    break;

   case 1:
    // Outputs for IfAction SubSystem: '<S409>/Negative Trace' incorporates:
    //   ActionPort: '<S416>/Action Port'

    FixedwingModel_NegativeTrace(rtb_VectorConcatenate_g,
      FixedwingModel_B.Merge_lc, &FixedwingModel_DW.NegativeTrace_j,
      &FixedwingModel_P.NegativeTrace_j);

    // End of Outputs for SubSystem: '<S409>/Negative Trace'
    break;
  }

  // End of If: '<S409>/If'

  // Product: '<S414>/Divide1' incorporates:
  //   UnaryMinus: '<S502>/Unary Minus'

  rtb_jxi_d = -FixedwingModel_B.Merge_l[1] / rtb_jxi;

  // Product: '<S414>/Divide2' incorporates:
  //   UnaryMinus: '<S502>/Unary Minus1'

  rtb_Rn = -FixedwingModel_B.Merge_l[2] / rtb_jxi;

  // Product: '<S414>/Divide3' incorporates:
  //   UnaryMinus: '<S502>/Unary Minus2'

  rtb_jxi = -FixedwingModel_B.Merge_l[3] / rtb_jxi;

  // Product: '<S505>/Product2'
  rtb_UniformRandomNumber4_j = rtb_Rn * FixedwingModel_B.Merge_lc[3];

  // Sum: '<S505>/Sum' incorporates:
  //   Product: '<S505>/Product'
  //   Product: '<S505>/Product1'
  //   Product: '<S505>/Product3'

  Sum_l = ((rtb_Add * FixedwingModel_B.Merge_lc[1] + rtb_jxi_d *
            FixedwingModel_B.Merge_lc[0]) + rtb_UniformRandomNumber4_j) -
    rtb_jxi * FixedwingModel_B.Merge_lc[2];

  // Product: '<S506>/Product2'
  rtb_UniformRandomNumber4_j = rtb_Rn * FixedwingModel_B.Merge_lc[0];
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    for (i = 0; i < 20; i++) {
      // DataTypeConversion: '<Root>/Data Type Conversion1' incorporates:
      //   Inport: '<Root>/inFloatsCollision'

      FixedwingModel_B.DataTypeConversion1[i] =
        FixedwingModel_U.inFloatsCollision[i];
    }

    // MATLAB Function: '<Root>/CollisionDetection' incorporates:
    //   Constant: '<Root>/ModelParam.uavMass'
    //   Gain: '<S8>/Gain4'

    //  vect=[1;1;1;1;1;1;1;1];
    // �Ƿ���ײ��־λ
    // MATLAB Function 'CollisionDetection': '<S2>:1'
    // '<S2>:1:6' if isempty(isCol)
    // ������������ݴ�����
    // '<S2>:1:12' if isempty(fOut)
    // ��ײ��������
    // '<S2>:1:18' if isempty(mv0)
    // ��ײʱ��
    // '<S2>:1:24' if isempty(tColi)
    // ���û�з�����ײ
    // '<S2>:1:29' if isCol<0.5
    if ((FixedwingModel_DW.isCol < 0.5) && (std::abs
         (FixedwingModel_B.DataTypeConversion1[0] - 12345.0) < 1.0) &&
        (FixedwingModel_B.DataTypeConversion1[1] > 0.5)) {
      // ����յ���ײ��Ϣ���ұ���ײ����Ϊ��ŷɻ�����CopterID��ֵ����0��
      // '<S2>:1:31' if abs(uFloats(1)-12345)<1 && uFloats(2)>0.5
      // ����յ���ײ��Ϣ��12345������У��λ��uFloats(2)����ײ���ɻ���ID
      // '<S2>:1:32' isCol=int8(1);
      FixedwingModel_DW.isCol = 1;

      // ����Ϊ��ײģʽ
      // ����ײ�����ǻ�Ļ��ǹ̶���
      // '<S2>:1:34' if uFloats(3)>0
      if (FixedwingModel_B.DataTypeConversion1[2] > 0.0) {
        // ����ײ���뱾���������������ֵ��˵����ײ��Ҳ�Ƿɻ�����Ҫ�ó�������
        // '<S2>:1:35' massOb=mass*uFloats(3)^2;
        rtb_rgw_p_idx_1 = FixedwingModel_B.DataTypeConversion1[2] *
          FixedwingModel_B.DataTypeConversion1[2] *
          FixedwingModel_P.uav.geometry.mass;

        // '<S2>:1:36' veOb = uFloats(7:9);
        // '<S2>:1:37' veNew=(mass*ve+massOb*veOb)/(mass+massOb);
        mv0_tmp = FixedwingModel_P.uav.geometry.mass + rtb_rgw_p_idx_1;
        FixedwingModel_DW.mv0[0] = (FixedwingModel_P.uav.geometry.mass *
          rtb_sigma_ugsigma_vg + rtb_rgw_p_idx_1 *
          FixedwingModel_B.DataTypeConversion1[6]) / mv0_tmp;
        FixedwingModel_DW.mv0[1] = (FixedwingModel_P.uav.geometry.mass *
          rtb_Product2_g + rtb_rgw_p_idx_1 *
          FixedwingModel_B.DataTypeConversion1[7]) / mv0_tmp;
        FixedwingModel_DW.mv0[2] = (FixedwingModel_P.uav.geometry.mass *
          Ve_idx_2 + rtb_rgw_p_idx_1 * FixedwingModel_B.DataTypeConversion1[8]) /
          mv0_tmp;
      } else {
        // '<S2>:1:38' else
        // ����ײ��Ϊ�������ӵȹ̶����壬���������ֱ�ӷ�����ȥ��1/10���ٶȣ�
        // '<S2>:1:39' veNew=-ve/10.0;
        FixedwingModel_DW.mv0[0] = -rtb_sigma_ugsigma_vg / 10.0;
        FixedwingModel_DW.mv0[1] = -rtb_Product2_g / 10.0;
        FixedwingModel_DW.mv0[2] = -Ve_idx_2 / 10.0;
      }

      // '<S2>:1:42' mv0=mass*(veNew-ve);
      FixedwingModel_DW.mv0[0] = (FixedwingModel_DW.mv0[0] -
        rtb_sigma_ugsigma_vg) * FixedwingModel_P.uav.geometry.mass;
      FixedwingModel_DW.mv0[1] = (FixedwingModel_DW.mv0[1] - rtb_Product2_g) *
        FixedwingModel_P.uav.geometry.mass;
      FixedwingModel_DW.mv0[2] = (FixedwingModel_DW.mv0[2] - Ve_idx_2) *
        FixedwingModel_P.uav.geometry.mass;

      // '<S2>:1:43' tColi=t;
      FixedwingModel_DW.tColi = Sum_p;

      // ��¼��ײʱ��
    }

    // ����Ѿ�������ײ
    // '<S2>:1:48' if isCol>=0.5
    if (FixedwingModel_DW.isCol >= 0.5) {
      // '<S2>:1:49' if (t-tColi)>0.05
      if (Sum_p - FixedwingModel_DW.tColi > 0.05) {
        // '<S2>:1:50' fOut=[0;0;0;0;0;0];
        for (i = 0; i < 6; i++) {
          FixedwingModel_DW.fOut[i] = 0.0;
        }
      } else {
        // '<S2>:1:51' else
        // ��˲ʱ��������ģ��������ã�0.05s��
        // '<S2>:1:53' mv=DCM*mv0;
        for (i = 0; i < 3; i++) {
          rtb_IntegratorSecondOrderLimi_m[i] = (rtb_VectorConcatenate_g[i + 3] *
            FixedwingModel_DW.mv0[1] + rtb_VectorConcatenate_g[i] *
            FixedwingModel_DW.mv0[0]) + rtb_VectorConcatenate_g[i + 6] *
            FixedwingModel_DW.mv0[2];
        }

        // '<S2>:1:54' mv(1)=mv(1)*(0.7+0.3*rand());
        rtb_IntegratorSecondOrderLimi_m[0] *= 0.3 * FixedwingModel_rand() + 0.7;

        // '<S2>:1:55' mv(2)=mv(2)*(0.7+0.3*rand());
        rtb_IntegratorSecondOrderLimi_m[1] *= 0.3 * FixedwingModel_rand() + 0.7;

        // '<S2>:1:56' mv(3)=mv(3)*(0.7+0.3*rand());
        rtb_IntegratorSecondOrderLimi_m[2] *= 0.3 * FixedwingModel_rand() + 0.7;

        // '<S2>:1:57' fOut(1:3) = mv/0.05;
        FixedwingModel_DW.fOut[0] = rtb_IntegratorSecondOrderLimi_m[0] / 0.05;
        FixedwingModel_DW.fOut[1] = rtb_IntegratorSecondOrderLimi_m[1] / 0.05;
        FixedwingModel_DW.fOut[2] = rtb_IntegratorSecondOrderLimi_m[2] / 0.05;

        // ��������ʱ��õ���
        // '<S2>:1:58' fOut(4:6) = rand(3,1)*mass;
        FixedwingModel_rand_p(rtb_IntegratorSecondOrderLimi_m);
        FixedwingModel_DW.fOut[3] = rtb_IntegratorSecondOrderLimi_m[0] *
          FixedwingModel_P.uav.geometry.mass;
        FixedwingModel_DW.fOut[4] = rtb_IntegratorSecondOrderLimi_m[1] *
          FixedwingModel_P.uav.geometry.mass;
        FixedwingModel_DW.fOut[5] = rtb_IntegratorSecondOrderLimi_m[2] *
          FixedwingModel_P.uav.geometry.mass;
      }
    }

    // ���洦���ɻ��볡���̶�����֮�����ײ
    // '<S2>:1:63' fm = fOut;
    // tz�ֱ��ʾ�����߶Ⱥͷɻ�XYZ����
    // '<S2>:1:65' tz=[100;0;0;0];
    rtb_WhiteNoise_l_idx_0 = 100.0;
    rtb_WhiteNoise_l_idx_3 = 0.0;

    // '<S2>:1:66' ddm=[0;0;0;0;0;0];
    for (i = 0; i < 6; i++) {
      ddm[i] = 0.0;
    }

    // '<S2>:1:67' if abs(uFloats(1)-12345)<1
    if (std::abs(FixedwingModel_B.DataTypeConversion1[0] - 12345.0) < 1.0) {
      // ����յ���ײ��Ϣ
      // '<S2>:1:68' kRa=40;
      // '<S2>:1:69' kRaVe=5;
      // '<S2>:1:70' if uFloats(2)<0.5
      if (FixedwingModel_B.DataTypeConversion1[1] < 0.5) {
        // �����ײ���ǳ����̶�����
        // �����������߷��س���
        // '<S2>:1:72' tz(1)=uFloats(15);
        rtb_WhiteNoise_l_idx_0 = FixedwingModel_B.DataTypeConversion1[14];

        // �ɻ���UE4�е�����
        // '<S2>:1:74' tz(2:4)=uFloats(4:6);
        rtb_WhiteNoise_l_idx_3 = FixedwingModel_B.DataTypeConversion1[5];
      } else {
        // '<S2>:1:75' else
        // '<S2>:1:76' kRa=20;
      }

      // ǰ���������Ե�������ϵ�ı�����Ϊ׼
      // ǰ�ϰ�����ײ������
      // '<S2>:1:80' if uFloats(10)<0
      if (FixedwingModel_B.DataTypeConversion1[9] < 0.0) {
        // ��ǰǽ����룬С��0˵���Ѿ��Ӵ�
        // '<S2>:1:81' z=uFloats(10);
        // '<S2>:1:82' if z>-0.01
        if (FixedwingModel_B.DataTypeConversion1[9] > -0.01) {
          // '<S2>:1:83' ddm(1)=-10*ve(1);
          ddm[0] = -10.0 * rtb_sigma_ugsigma_vg;
        } else if (FixedwingModel_B.DataTypeConversion1[9] > -0.04) {
          // '<S2>:1:84' elseif z>-0.04
          // '<S2>:1:85' ddm(1)=200*z-20*ve(1);
          ddm[0] = 200.0 * FixedwingModel_B.DataTypeConversion1[9] - 20.0 *
            rtb_sigma_ugsigma_vg;
        } else {
          // '<S2>:1:86' else
          // '<S2>:1:87' ddm(1)=500*z-50*ve(1);
          ddm[0] = 500.0 * FixedwingModel_B.DataTypeConversion1[9] - 50.0 *
            rtb_sigma_ugsigma_vg;
        }
      }

      // ���ϰ�����ײ������
      // '<S2>:1:91' if uFloats(11)<0
      if (FixedwingModel_B.DataTypeConversion1[10] < 0.0) {
        //          ddm(1)=-uFloats(11)*mass*kRa;
        //          if ve(1)<0
        //              ddm(1)=ddm(1)-ve(1)*mass*kRaVe;
        //          end
        // '<S2>:1:96' z=uFloats(11);
        // '<S2>:1:97' if z>-0.01
        if (FixedwingModel_B.DataTypeConversion1[10] > -0.01) {
          // '<S2>:1:98' ddm(1)=-10*ve(1);
          ddm[0] = -10.0 * rtb_sigma_ugsigma_vg;
        } else if (FixedwingModel_B.DataTypeConversion1[10] > -0.04) {
          // '<S2>:1:99' elseif z>-0.04
          // '<S2>:1:100' ddm(1)=-200*z-20*ve(1);
          ddm[0] = -200.0 * FixedwingModel_B.DataTypeConversion1[10] - 20.0 *
            rtb_sigma_ugsigma_vg;
        } else {
          // '<S2>:1:101' else
          // '<S2>:1:102' ddm(1)=-500*z-50*ve(1);
          ddm[0] = -500.0 * FixedwingModel_B.DataTypeConversion1[10] - 50.0 *
            rtb_sigma_ugsigma_vg;
        }
      }

      // ���ϰ�����ײ������
      // '<S2>:1:107' if uFloats(12)<0
      if (FixedwingModel_B.DataTypeConversion1[11] < 0.0) {
        //          ddm(2)=-uFloats(12)*mass*kRa;
        //          if ve(2)<0
        //              ddm(2)=ddm(2)-ve(2)*mass*kRaVe;
        //          end
        // '<S2>:1:112' z=uFloats(12);
        // '<S2>:1:113' if z>-0.01
        if (FixedwingModel_B.DataTypeConversion1[11] > -0.01) {
          // '<S2>:1:114' ddm(2)=-10*ve(2);
          ddm[1] = -10.0 * rtb_Product2_g;
        } else if (FixedwingModel_B.DataTypeConversion1[11] > -0.04) {
          // '<S2>:1:115' elseif z>-0.04
          // '<S2>:1:116' ddm(2)=-200*z-20*ve(2);
          ddm[1] = -200.0 * FixedwingModel_B.DataTypeConversion1[11] - 20.0 *
            rtb_Product2_g;
        } else {
          // '<S2>:1:117' else
          // '<S2>:1:118' ddm(2)=-500*z-50*ve(2);
          ddm[1] = -500.0 * FixedwingModel_B.DataTypeConversion1[11] - 50.0 *
            rtb_Product2_g;
        }
      }

      // ���ϰ�����ײ������
      // '<S2>:1:122' if uFloats(13)<0
      if (FixedwingModel_B.DataTypeConversion1[12] < 0.0) {
        //          ddm(2)=uFloats(13)*mass*kRa;
        //          if ve(2)>0
        //              ddm(2)=ddm(2)-ve(2)*mass*kRaVe;
        //          end
        // '<S2>:1:127' z=uFloats(13);
        // '<S2>:1:128' if z>-0.01
        if (FixedwingModel_B.DataTypeConversion1[12] > -0.01) {
          // '<S2>:1:129' ddm(2)=-10*ve(2);
          ddm[1] = -10.0 * rtb_Product2_g;
        } else if (FixedwingModel_B.DataTypeConversion1[12] > -0.04) {
          // '<S2>:1:130' elseif z>-0.04
          // '<S2>:1:131' ddm(2)=200*z-20*ve(2);
          ddm[1] = 200.0 * FixedwingModel_B.DataTypeConversion1[12] - 20.0 *
            rtb_Product2_g;
        } else {
          // '<S2>:1:132' else
          // '<S2>:1:133' ddm(2)=500*z-50*ve(2);
          ddm[1] = 500.0 * FixedwingModel_B.DataTypeConversion1[12] - 50.0 *
            rtb_Product2_g;
        }
      }

      // ���ϰ�����ײ������
      // '<S2>:1:138' if uFloats(14)<0
      if (FixedwingModel_B.DataTypeConversion1[13] < 0.0) {
        //          ddm(3)=-uFloats(14)*mass*kRa;
        //          if ve(3)<0
        //              ddm(3)=ddm(3)-ve(3)*mass*kRaVe;
        //          end
        // '<S2>:1:144' z=uFloats(14);
        // '<S2>:1:145' if z>-0.01
        if (FixedwingModel_B.DataTypeConversion1[13] > -0.01) {
          // '<S2>:1:146' ddm(3)=-10*ve(3);
          ddm[2] = -10.0 * Ve_idx_2;
        } else if (FixedwingModel_B.DataTypeConversion1[13] > -0.04) {
          // '<S2>:1:147' elseif z>-0.04
          // '<S2>:1:148' ddm(3)=-200*z-20*ve(3);
          ddm[2] = -200.0 * FixedwingModel_B.DataTypeConversion1[13] - 20.0 *
            Ve_idx_2;
        } else {
          // '<S2>:1:149' else
          // '<S2>:1:150' ddm(3)=-500*z-50*ve(3);
          ddm[2] = -500.0 * FixedwingModel_B.DataTypeConversion1[13] - 50.0 *
            Ve_idx_2;
        }
      }
    }

    // ���ӵ�������ϵӳ���������ϵ
    // '<S2>:1:155' ddmm=DCM*ddm(1:3);
    // '<S2>:1:156' fm=fm+[ddmm;0;0;0];
    for (i = 0; i < 3; i++) {
      FixedwingModel_B.fm[i] = ((rtb_VectorConcatenate_g[i + 3] * ddm[1] +
        rtb_VectorConcatenate_g[i] * ddm[0]) + rtb_VectorConcatenate_g[i + 6] *
        ddm[2]) + FixedwingModel_DW.fOut[i];
    }

    FixedwingModel_B.fm[3] = FixedwingModel_DW.fOut[3];
    FixedwingModel_B.fm[4] = FixedwingModel_DW.fOut[4];
    FixedwingModel_B.fm[5] = FixedwingModel_DW.fOut[5];

    // End of MATLAB Function: '<Root>/CollisionDetection'

    // MATLAB Function: '<Root>/MATLAB Function' incorporates:
    //   Inport: '<Root>/TerrainZ'

    // '<S2>:1:158' isCrash=isCol;
    rtb_rgw_p_idx_1 = FixedwingModel_U.TerrainZ;

    // MATLAB Function 'MATLAB Function': '<S5>:1'
    // '<S5>:1:5' if isempty(lastZ)
    // '<S5>:1:8' y=TerrainZ;
    // '<S5>:1:9' if tz(1)<=99
    if (rtb_WhiteNoise_l_idx_0 <= 99.0) {
      // '<S5>:1:10' y=tz(4)+tz(1);
      rtb_rgw_p_idx_1 = rtb_WhiteNoise_l_idx_0 + rtb_WhiteNoise_l_idx_3;
    }

    // '<S5>:1:13' lastZ=0.6*lastZ+0.4*y;
    FixedwingModel_DW.lastZ = 0.6 * FixedwingModel_DW.lastZ + 0.4 *
      rtb_rgw_p_idx_1;

    // SignalConversion generated from: '<S412>/ SFunction ' incorporates:
    //   MATLAB Function: '<S344>/Ground Model'
    //   Product: '<S506>/Product'
    //   Product: '<S506>/Product1'
    //   Product: '<S506>/Product3'
    //   Product: '<S507>/Product'
    //   Product: '<S507>/Product1'
    //   Product: '<S507>/Product2'
    //   Product: '<S507>/Product3'
    //   Sum: '<S506>/Sum'
    //   Sum: '<S507>/Sum'

    // '<S5>:1:14' yy=lastZ;
    //  persistent last;
    //  if isempty(last)
    //      last=TerrainZ;
    //  end
    //  y=TerrainZ;
    //  if tz(1)<10
    //      if tz(1)<0
    //          y=last;
    //      else
    //          y=tz(3)+tz(1);
    //      end
    //  end
    rtb_WhiteNoise_l_idx_2 = ((rtb_Add * FixedwingModel_B.Merge_lc[2] -
      rtb_jxi_d * FixedwingModel_B.Merge_lc[3]) + rtb_UniformRandomNumber4_j) +
      rtb_jxi * FixedwingModel_B.Merge_lc[1];
    rtb_WhiteNoise_l_idx_3 = ((rtb_Add * FixedwingModel_B.Merge_lc[3] +
      rtb_jxi_d * FixedwingModel_B.Merge_lc[2]) - rtb_Rn *
      FixedwingModel_B.Merge_lc[1]) + rtb_jxi * FixedwingModel_B.Merge_lc[0];

    // MATLAB Function: '<S344>/Ground Model' incorporates:
    //   MATLAB Function: '<Root>/MATLAB Function'
    //   SignalConversion generated from: '<S412>/ SFunction '

    //  This is a ground model that can provides reaction force and reaction torque 
    // MATLAB Function 'Small Fixed Wing UAV Dynamics/GroundModel/Ground Model': '<S412>:1' 
    //  persistent z0;
    //  if isempty(z0)
    //       z0=0;
    //  end
    // '<S412>:1:10' if isempty(takeoffFlag)
    // '<S412>:1:15' if isempty(landFlag)
    // '<S412>:1:20' z=Xe(3)-terrainZ;
    rtb_Add = Xe_idx_2 - FixedwingModel_DW.lastZ;

    // '<S412>:1:22' if (z<-0.3)&&(Ve(3)<-0.1)&&(takeoffFlag<0.5)
    if ((rtb_Add < -0.3) && (Ve_idx_2 < -0.1) && (FixedwingModel_DW.takeoffFlag <
         0.5)) {
      // '<S412>:1:23' takeoffFlag=int8(1);
      FixedwingModel_DW.takeoffFlag = 1;

      // '<S412>:1:24' landFlag=int8(0);
      FixedwingModel_DW.landFlag = 0;
    }

    // '<S412>:1:27' if (z>-0.05)&&(Ve(3)>0.1)&&(landFlag<0.5)
    if ((rtb_Add > -0.05) && (Ve_idx_2 > 0.1) && (FixedwingModel_DW.landFlag <
         0.5)) {
      // '<S412>:1:28' landFlag=int8(1);
      FixedwingModel_DW.landFlag = 1;

      // '<S412>:1:29' takeoffFlag=int8(0);
      FixedwingModel_DW.takeoffFlag = 0;

      // z0=terrainZ;
    }

    // '<S412>:1:33' takeoff = takeoffFlag;
    // '<S412>:1:34' landed = landFlag;
    // '<S412>:1:37' F1=[0;0;0];
    // '<S412>:1:38' M1=[0;0;0];
    FixedwingModel_B.F1[0] = 0.0;
    FixedwingModel_B.M1[0] = 0.0;
    FixedwingModel_B.F1[1] = 0.0;
    FixedwingModel_B.M1[1] = 0.0;
    FixedwingModel_B.F1[2] = 0.0;
    FixedwingModel_B.M1[2] = 0.0;

    // '<S412>:1:40' if z>=0
    if (rtb_Add >= 0.0) {
      //      if z>=0.3
      //          if Ve(3)>=5
      //              F1(3)=-mg(3)-1000*Ve(3);
      //          else
      //              F1(3)=-mg(3)-500*z-100*Ve(3);
      //          end
      //      elseif z>=0.1
      //          if Ve(3)>=2
      //              F1(3)=-mg(3)-100*Ve(3);
      //          else
      //              F1(3)=-mg(3)-50*z-100*Ve(3);
      //          end
      //      else
      //           if Ve(3)>=1
      //              F1(3)=-mg(3)-50*Ve(3);
      //          else
      //              F1(3)=-mg(3)-5*z-50*Ve(3);
      //          end
      //      end
      // '<S412>:1:60' if z<0.05
      if (rtb_Add < 0.05) {
        // '<S412>:1:61' F1(3)=-mg(3)-10*Ve(3);
        FixedwingModel_B.F1[2] = -rtb_Gain_d[2] - 10.0 * Ve_idx_2;
      } else if (rtb_Add < 0.1) {
        // '<S412>:1:62' elseif z<0.1
        // '<S412>:1:63' F1(3)=-mg(3)-0.5*z-20*Ve(3);
        FixedwingModel_B.F1[2] = (-rtb_Gain_d[2] - 0.5 * rtb_Add) - 20.0 *
          Ve_idx_2;
      } else {
        // '<S412>:1:64' else
        // '<S412>:1:65' F1(3)=-mg(3)-1*z-50*Ve(3);
        FixedwingModel_B.F1[2] = (-rtb_Gain_d[2] - rtb_Add) - 50.0 * Ve_idx_2;
      }

      // '<S412>:1:69' F1(1)=-2*Ve(1);
      FixedwingModel_B.F1[0] = -2.0 * rtb_sigma_ugsigma_vg;

      // '<S412>:1:70' F1(2)=-50*Ve(2);
      FixedwingModel_B.F1[1] = -50.0 * rtb_Product2_g;

      // '<S412>:1:71' M1=-20*[Quet(2);Quet(3);Quet(4)]-5*wb;
      // '<S412>:1:72' M1 = M1 * abs(mg(3))*0.0333;
      rtb_Add = std::abs(rtb_Gain_d[2]);
      FixedwingModel_B.M1[0] = (-20.0 * Sum_l - 5.0 * wb[0]) * rtb_Add * 0.0333;
      FixedwingModel_B.M1[1] = (-20.0 * rtb_WhiteNoise_l_idx_2 - 5.0 * wb[1]) *
        rtb_Add * 0.0333;
      FixedwingModel_B.M1[2] = (-20.0 * rtb_WhiteNoise_l_idx_3 - 5.0 * wb[2]) *
        rtb_Add * 0.0333;
    }
  }

  // Gain: '<S148>/kg2N' incorporates:
  //   Fcn: '<S148>/Thrust Available (lbs)'

  if (rtb_sincos_o1_i_idx_0 < 0.0) {
    rtb_jxi = -std::sqrt(-rtb_sincos_o1_i_idx_0);
  } else {
    rtb_jxi = std::sqrt(rtb_sincos_o1_i_idx_0);
  }

  // Sum: '<S8>/Sum' incorporates:
  //   Constant: '<S6>/Constant1'
  //   Constant: '<S6>/Constant2'
  //   Constant: '<S6>/Constant3'
  //   Constant: '<S6>/Constant4'
  //   Constant: '<S6>/Constant5'
  //   Fcn: '<S148>/Thrust Available (lbs)'
  //   Gain: '<S148>/kg2N'
  //   UnitConversion: '<S150>/Unit Conversion'

  tmp[0] = (rtb_sincos_o1_i_idx_0 - 0.047 * rtb_jxi * rtb_sincos_o1_idx_0) *
    0.45359237 * FixedwingModel_P.env.ISA_g;
  tmp[1] = FixedwingModel_P.Constant1_Value_k;
  tmp[2] = FixedwingModel_P.Constant2_Value_c;
  tmp[3] = FixedwingModel_P.Constant3_Value_o;
  tmp[4] = FixedwingModel_P.Constant4_Value;
  tmp[5] = FixedwingModel_P.Constant5_Value;
  rtb_Sum4_a[0] = rtb_Sum4_p[0];
  rtb_Sum4_a[3] = rtb_ubvbwb[0];
  rtb_Sum4_a[1] = rtb_Sum4_p[1];
  rtb_Sum4_a[4] = rtb_ubvbwb[1];
  rtb_Sum4_a[2] = rtb_Sum4_p[2];
  rtb_Sum4_a[5] = rtb_ubvbwb[2];
  for (i = 0; i < 3; i++) {
    // Sum: '<S8>/Sum' incorporates:
    //   Gain: '<S8>/Gain4'
    //   Product: '<S344>/Product'

    rtb_VectorConcatenate_n[i] = (rtb_VectorConcatenate_g[i + 3] *
      FixedwingModel_B.F1[1] + rtb_VectorConcatenate_g[i] * FixedwingModel_B.F1
      [0]) + rtb_VectorConcatenate_g[i + 6] * FixedwingModel_B.F1[2];
    rtb_VectorConcatenate_n[i + 3] = FixedwingModel_B.M1[i];
  }

  // Sum: '<S8>/Sum1' incorporates:
  //   Sum: '<S8>/Sum'

  for (i = 0; i < 6; i++) {
    ddm[i] = ((tmp[i] + rtb_Sum4_a[i]) + rtb_VectorConcatenate_n[i]) +
      FixedwingModel_B.fm[i];
  }

  // End of Sum: '<S8>/Sum1'

  // Product: '<S8>/Divide' incorporates:
  //   Constant: '<S8>/Constant1'
  //   Product: '<S341>/Product'

  mv0_tmp = ddm[0] / FixedwingModel_P.uav.geometry.mass;

  // Gain: '<S8>/Gain8' incorporates:
  //   Product: '<S8>/Divide'

  rtb_DataTypeConversion2[0] = mv0_tmp * FixedwingModel_P.Gain8_Gain;

  // Product: '<S8>/Divide' incorporates:
  //   Constant: '<S8>/Constant1'
  //   Product: '<S341>/Product'

  rtb_DataTypeConversion2_tmp = ddm[1] / FixedwingModel_P.uav.geometry.mass;

  // Gain: '<S8>/Gain8' incorporates:
  //   Product: '<S8>/Divide'

  rtb_DataTypeConversion2[1] = rtb_DataTypeConversion2_tmp *
    FixedwingModel_P.Gain8_Gain;

  // Product: '<S8>/Divide' incorporates:
  //   Constant: '<S8>/Constant1'
  //   Product: '<S341>/Product'

  rtb_DataTypeConversion2_tmp_0 = ddm[2] / FixedwingModel_P.uav.geometry.mass;

  // Gain: '<S8>/Gain8' incorporates:
  //   Product: '<S8>/Divide'

  rtb_DataTypeConversion2[2] = rtb_DataTypeConversion2_tmp_0 *
    FixedwingModel_P.Gain8_Gain;
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // UnitConversion: '<S46>/Unit Conversion' incorporates:
    //   Constant: '<S24>/ref_rotation'

    // Unit Conversion - from: deg to: rad
    // Expression: output = (0.0174533*input) + (0)
    rtb_UniformRandomNumber4_j = 0.017453292519943295 *
      FixedwingModel_P.FlatEarthtoLLA_psi;

    // Trigonometry: '<S31>/SinCos'
    FixedwingModel_B.SinCos_o1 = std::sin(rtb_UniformRandomNumber4_j);

    // Trigonometry: '<S31>/SinCos'
    FixedwingModel_B.SinCos_o2 = std::cos(rtb_UniformRandomNumber4_j);

    // Sum: '<S49>/Sum' incorporates:
    //   Constant: '<S49>/Constant'
    //   Constant: '<S49>/f'

    rtb_UniformRandomNumber4_j = FixedwingModel_P.f_Value -
      FixedwingModel_P.Constant_Value_mj;

    // Sqrt: '<S50>/sqrt' incorporates:
    //   Constant: '<S50>/Constant'
    //   Product: '<S50>/Product1'
    //   Sum: '<S50>/Sum1'

    rtb_UniformRandomNumber4_j = std::sqrt(FixedwingModel_P.Constant_Value_d -
      rtb_UniformRandomNumber4_j * rtb_UniformRandomNumber4_j);

    // Switch: '<S42>/Switch' incorporates:
    //   Abs: '<S42>/Abs'
    //   Bias: '<S42>/Bias'
    //   Bias: '<S42>/Bias1'
    //   Constant: '<S24>/ref_position'
    //   Constant: '<S42>/Constant2'
    //   Constant: '<S43>/Constant'
    //   Math: '<S42>/Math Function1'
    //   RelationalOperator: '<S43>/Compare'

    if (std::abs(FixedwingModel_P.ModelParam_GPSLatLong[0]) >
        FixedwingModel_P.CompareToConstant_const) {
      rtb_Rn = rt_modd_snf(FixedwingModel_P.ModelParam_GPSLatLong[0] +
                           FixedwingModel_P.Bias_Bias_h,
                           FixedwingModel_P.Constant2_Value) +
        FixedwingModel_P.Bias1_Bias_ik;
    } else {
      rtb_Rn = FixedwingModel_P.ModelParam_GPSLatLong[0];
    }

    // End of Switch: '<S42>/Switch'

    // Abs: '<S39>/Abs1'
    rtb_Add = std::abs(rtb_Rn);

    // RelationalOperator: '<S41>/Compare' incorporates:
    //   Constant: '<S41>/Constant'

    rtb_DataTypeConversion2_e = (rtb_Add >
      FixedwingModel_P.CompareToConstant_const_j);

    // Switch: '<S39>/Switch'
    if (rtb_DataTypeConversion2_e) {
      // Signum: '<S39>/Sign1'
      if (!rtIsNaN(rtb_Rn)) {
        if (rtb_Rn < 0.0) {
          rtb_Rn = -1.0;
        } else {
          rtb_Rn = (rtb_Rn > 0.0);
        }
      }

      // End of Signum: '<S39>/Sign1'

      // Switch: '<S39>/Switch' incorporates:
      //   Bias: '<S39>/Bias'
      //   Bias: '<S39>/Bias1'
      //   Gain: '<S39>/Gain'
      //   Product: '<S39>/Divide1'

      FixedwingModel_B.Switch = ((rtb_Add + FixedwingModel_P.Bias_Bias_d) *
        FixedwingModel_P.Gain_Gain_l + FixedwingModel_P.Bias1_Bias_i) * rtb_Rn;
    } else {
      // Switch: '<S39>/Switch'
      FixedwingModel_B.Switch = rtb_Rn;
    }

    // End of Switch: '<S39>/Switch'

    // UnitConversion: '<S47>/Unit Conversion'
    // Unit Conversion - from: deg to: rad
    // Expression: output = (0.0174533*input) + (0)
    rtb_Rn = 0.017453292519943295 * FixedwingModel_B.Switch;

    // Trigonometry: '<S48>/Trigonometric Function1'
    rtb_jxi_d = std::sin(rtb_Rn);

    // Product: '<S48>/Product1' incorporates:
    //   Product: '<S45>/Product2'

    rtb_sincos_o1_i_idx_0 = rtb_UniformRandomNumber4_j *
      rtb_UniformRandomNumber4_j;

    // Sum: '<S48>/Sum1' incorporates:
    //   Constant: '<S48>/Constant'
    //   Product: '<S48>/Product1'

    rtb_jxi_d = FixedwingModel_P.Constant_Value_i2 - rtb_sincos_o1_i_idx_0 *
      rtb_jxi_d * rtb_jxi_d;

    // Product: '<S45>/Product1' incorporates:
    //   Constant: '<S45>/Constant1'
    //   Sqrt: '<S45>/sqrt'

    rtb_Sum_gz = FixedwingModel_P.Constant1_Value_p / std::sqrt(rtb_jxi_d);

    // Trigonometry: '<S45>/Trigonometric Function1' incorporates:
    //   Constant: '<S45>/Constant'
    //   Constant: '<S45>/Constant2'
    //   Product: '<S45>/Product3'
    //   Sum: '<S45>/Sum1'

    FixedwingModel_B.TrigonometricFunction1 = rt_atan2d_snf
      (FixedwingModel_P.Constant2_Value_g, (FixedwingModel_P.Constant_Value_es -
        rtb_sincos_o1_i_idx_0) * rtb_Sum_gz / rtb_jxi_d);

    // Trigonometry: '<S45>/Trigonometric Function2' incorporates:
    //   Constant: '<S45>/Constant3'
    //   Product: '<S45>/Product4'
    //   Trigonometry: '<S45>/Trigonometric Function'

    FixedwingModel_B.TrigonometricFunction2 = rt_atan2d_snf
      (FixedwingModel_P.Constant3_Value_e, rtb_Sum_gz * std::cos(rtb_Rn));

    // Switch: '<S30>/Switch1' incorporates:
    //   Constant: '<S30>/Constant'
    //   Constant: '<S30>/Constant1'

    if (rtb_DataTypeConversion2_e) {
      rtb_UniformRandomNumber4_j = FixedwingModel_P.Constant_Value;
    } else {
      rtb_UniformRandomNumber4_j = FixedwingModel_P.Constant1_Value;
    }

    // End of Switch: '<S30>/Switch1'

    // Sum: '<S30>/Sum' incorporates:
    //   Constant: '<S24>/ref_position'

    rtb_Add = rtb_UniformRandomNumber4_j +
      FixedwingModel_P.ModelParam_GPSLatLong[1];

    // Switch: '<S40>/Switch' incorporates:
    //   Abs: '<S40>/Abs'
    //   Constant: '<S44>/Constant'
    //   RelationalOperator: '<S44>/Compare'

    if (std::abs(rtb_Add) > FixedwingModel_P.CompareToConstant_const_jw) {
      // Switch: '<S40>/Switch' incorporates:
      //   Bias: '<S40>/Bias'
      //   Bias: '<S40>/Bias1'
      //   Constant: '<S40>/Constant2'
      //   Math: '<S40>/Math Function1'

      FixedwingModel_B.Switch_d = rt_modd_snf(rtb_Add +
        FixedwingModel_P.Bias_Bias_mo, FixedwingModel_P.Constant2_Value_k) +
        FixedwingModel_P.Bias1_Bias_m;
    } else {
      // Switch: '<S40>/Switch'
      FixedwingModel_B.Switch_d = rtb_Add;
    }

    // End of Switch: '<S40>/Switch'
  }

  // Sum: '<S24>/Sum' incorporates:
  //   Product: '<S31>/rad lat'
  //   Product: '<S31>/x*cos'
  //   Product: '<S31>/y*sin'
  //   Sum: '<S31>/Sum'
  //   UnitConversion: '<S32>/Unit Conversion'

  // Unit Conversion - from: rad to: deg
  // Expression: output = (57.2958*input) + (0)
  rtb_sincos_o1_i_idx_0 = (rtb_LowAltitudeScaleLength *
    FixedwingModel_B.SinCos_o2 - rtb_IntegratorSecondOrder_o2_e *
    FixedwingModel_B.SinCos_o1) * FixedwingModel_B.TrigonometricFunction1 *
    57.295779513082323 + FixedwingModel_B.Switch;

  // Switch: '<S36>/Switch' incorporates:
  //   Abs: '<S36>/Abs'
  //   Bias: '<S36>/Bias'
  //   Bias: '<S36>/Bias1'
  //   Constant: '<S36>/Constant2'
  //   Constant: '<S37>/Constant'
  //   Math: '<S36>/Math Function1'
  //   RelationalOperator: '<S37>/Compare'

  if (std::abs(rtb_sincos_o1_i_idx_0) >
      FixedwingModel_P.CompareToConstant_const_p) {
    rtb_sincos_o1_i_idx_0 = rt_modd_snf(rtb_sincos_o1_i_idx_0 +
      FixedwingModel_P.Bias_Bias_o, FixedwingModel_P.Constant2_Value_b) +
      FixedwingModel_P.Bias1_Bias_b;
  }

  // End of Switch: '<S36>/Switch'

  // Abs: '<S33>/Abs1'
  rtb_Add = std::abs(rtb_sincos_o1_i_idx_0);

  // Switch: '<S33>/Switch' incorporates:
  //   Bias: '<S33>/Bias'
  //   Bias: '<S33>/Bias1'
  //   Constant: '<S29>/Constant'
  //   Constant: '<S29>/Constant1'
  //   Constant: '<S35>/Constant'
  //   Gain: '<S33>/Gain'
  //   Product: '<S33>/Divide1'
  //   RelationalOperator: '<S35>/Compare'
  //   Switch: '<S29>/Switch1'

  if (rtb_Add > FixedwingModel_P.CompareToConstant_const_d) {
    // Signum: '<S33>/Sign1'
    if (!rtIsNaN(rtb_sincos_o1_i_idx_0)) {
      if (rtb_sincos_o1_i_idx_0 < 0.0) {
        rtb_sincos_o1_i_idx_0 = -1.0;
      } else {
        rtb_sincos_o1_i_idx_0 = (rtb_sincos_o1_i_idx_0 > 0.0);
      }
    }

    // End of Signum: '<S33>/Sign1'
    rtb_sincos_o1_i_idx_0 *= (rtb_Add + FixedwingModel_P.Bias_Bias) *
      FixedwingModel_P.Gain_Gain + FixedwingModel_P.Bias1_Bias;
    rtb_UniformRandomNumber4_j = FixedwingModel_P.Constant_Value_iz;
  } else {
    rtb_UniformRandomNumber4_j = FixedwingModel_P.Constant1_Value_jz;
  }

  // End of Switch: '<S33>/Switch'

  // Sum: '<S29>/Sum' incorporates:
  //   Product: '<S31>/rad long '
  //   Product: '<S31>/x*sin'
  //   Product: '<S31>/y*cos'
  //   Sum: '<S24>/Sum'
  //   Sum: '<S31>/Sum1'
  //   UnitConversion: '<S32>/Unit Conversion'

  rtb_jxi = ((rtb_LowAltitudeScaleLength * FixedwingModel_B.SinCos_o1 +
              rtb_IntegratorSecondOrder_o2_e * FixedwingModel_B.SinCos_o2) *
             FixedwingModel_B.TrigonometricFunction2 * 57.295779513082323 +
             FixedwingModel_B.Switch_d) + rtb_UniformRandomNumber4_j;

  // Switch: '<S34>/Switch' incorporates:
  //   Abs: '<S34>/Abs'
  //   Bias: '<S34>/Bias'
  //   Bias: '<S34>/Bias1'
  //   Constant: '<S34>/Constant2'
  //   Constant: '<S38>/Constant'
  //   Math: '<S34>/Math Function1'
  //   RelationalOperator: '<S38>/Compare'

  if (std::abs(rtb_jxi) > FixedwingModel_P.CompareToConstant_const_b) {
    rtb_jxi = rt_modd_snf(rtb_jxi + FixedwingModel_P.Bias_Bias_m,
                          FixedwingModel_P.Constant2_Value_k0) +
      FixedwingModel_P.Bias1_Bias_l;
  }

  // End of Switch: '<S34>/Switch'

  // Sum: '<S24>/Sum1' incorporates:
  //   Constant: '<S3>/ModelParam.envAltitude'
  //   UnaryMinus: '<S24>/Ze2height'

  rtb_Add = -Xe_idx_2 - FixedwingModel_P.ModelParam_envAltitude;

  // Saturate: '<S3>/Saturation_1'
  if (rtb_Add > FixedwingModel_P.Saturation_1_UpperSat) {
    rtb_Add = FixedwingModel_P.Saturation_1_UpperSat;
  } else if (rtb_Add < FixedwingModel_P.Saturation_1_LowerSat) {
    rtb_Add = FixedwingModel_P.Saturation_1_LowerSat;
  }

  // End of Saturate: '<S3>/Saturation_1'

  // UnitConversion: '<S52>/Unit Conversion' incorporates:
  //   SignalConversion generated from: '<S27>/Selector'

  // Unit Conversion - from: deg to: rad
  // Expression: output = (0.0174533*input) + (0)
  rtb_sincos_o1_idx_0 = 0.017453292519943295 * rtb_sincos_o1_i_idx_0;

  // UnitConversion: '<S54>/Unit Conversion' incorporates:
  //   SignalConversion generated from: '<S27>/Selector'

  // Unit Conversion - from: deg to: rad
  // Expression: output = (0.0174533*input) + (0)
  rtb_jxi_d = 0.017453292519943295 * rtb_jxi;

  // Selector: '<S27>/Selector' incorporates:
  //   SignalConversion generated from: '<S27>/Selector'

  rtb_UniformRandomNumber4_j = rtb_Add;

  // S-Function (saerogravity2): '<S27>/WGS84 Gravity S-Function' incorporates:
  //   Constant: '<S27>/Julian Date'


  // S-Function Block: <S27>/WGS84 Gravity S-Function
  {
    int_T i;
    real_T GM, opt_m2ft, deg2rad;
    real_T *phi_ptr, *height_ptr;
    boolean_T phi_wrapped = false;
    real_T *phi = (real_T *) &FixedwingModel_DW.WGS84GravitySFunction_phi;
    real_T *h = (real_T *) &FixedwingModel_DW.WGS84GravitySFunction_h;
    height_ptr = (real_T *) &rtb_UniformRandomNumber4_j;
    phi_ptr = (real_T *) &rtb_sincos_o1_idx_0;

    // get unit conversion factor
    opt_m2ft = 1.0;
    deg2rad = 1.0;

    // Use Earth's Atmosphere in Gravitational Const?
    GM = ( 1.0 == 0 ) ? WGS84_GM_DEF : WGS84_GM_PRM;

    // WGS84TAYLORSERIES
    {
      for (i = 0; i < 1; i++ ) {
        real_T fphi, pi_2;

        // create short variables for latitude (phi) and height (h)
        phi[i] = phi_ptr[i] * deg2rad;
        h[i] = height_ptr[i] / opt_m2ft;
        if (phi[i] > AERO_PI || phi[i] < -AERO_PI) {
          phi[i] = std::fmod(phi[i]+AERO_PI, 2.0*AERO_PI) - AERO_PI;
        }

        fphi = std::abs(phi[i]);
        pi_2 = AERO_PI/2.0;
        if (fphi > pi_2 ) {
          real_T sign = phi[i]/fphi;
          phi_wrapped = true;
          phi[i] = sign*(pi_2 - (fphi - pi_2));
        } else {
          phi_wrapped = false;
        }
      }

      wgs84_taylor_series(h, phi, opt_m2ft, &FixedwingModel_B.MatrixConcatenate
                          [2], 1);

      // north and east components are zero
      FixedwingModel_B.MatrixConcatenate[0] =
        FixedwingModel_DW.WGS84GravitySFunction_gamma_phi;
      FixedwingModel_B.MatrixConcatenate[1] =
        FixedwingModel_DW.WGS84GravitySFunction_gamma_phi;
    }
  }

  // Gain: '<S246>/Zero-Order Hold'
  rtb_ubvbwb[0] = FixedwingModel_P.ZeroOrderHold_Gain * wb[0];
  rtb_ubvbwb[1] = FixedwingModel_P.ZeroOrderHold_Gain * wb[1];
  rtb_ubvbwb[2] = FixedwingModel_P.ZeroOrderHold_Gain * wb[2];
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // Gain: '<S246>/Gain' incorporates:
    //   Constant: '<S226>/center of gravity'
    //   Constant: '<S246>/wl_ins'
    //   Gain: '<S246>/Zero-Order Hold4'
    //   Sum: '<S246>/Sum7'

    FixedwingModel_B.Gain[0] = (FixedwingModel_P.ZeroOrderHold4_Gain *
      FixedwingModel_P.centerofgravity_Value[0] -
      FixedwingModel_P.ThreeaxisInertialMeasurementU_p[0]) *
      FixedwingModel_P.Gain_Gain_i1[0];
    FixedwingModel_B.Gain[1] = (FixedwingModel_P.ZeroOrderHold4_Gain *
      FixedwingModel_P.centerofgravity_Value[1] -
      FixedwingModel_P.ThreeaxisInertialMeasurementU_p[1]) *
      FixedwingModel_P.Gain_Gain_i1[1];
    FixedwingModel_B.Gain[2] = (FixedwingModel_P.ZeroOrderHold4_Gain *
      FixedwingModel_P.centerofgravity_Value[2] -
      FixedwingModel_P.ThreeaxisInertialMeasurementU_p[2]) *
      FixedwingModel_P.Gain_Gain_i1[2];
    for (i = 0; i < 3; i++) {
      // Concatenate: '<S348>/Vector Concatenate' incorporates:
      //   Constant: '<S348>/Constant1'
      //   Constant: '<S348>/Constant2'
      //   Selector: '<S347>/Selector1'

      rtb_VectorConcatenate_c[6 * i] = FixedwingModel_P.uDOFEulerAngles_inertia
        [3 * i];
      s281_iter = 6 * i + 3;
      rtb_VectorConcatenate_c[s281_iter] = FixedwingModel_P.Constant2_Value_cn[3
        * i];

      // Selector: '<S347>/Selector1' incorporates:
      //   Concatenate: '<S348>/Vector Concatenate'

      FixedwingModel_B.Selector1[3 * i] = rtb_VectorConcatenate_c[s281_iter];

      // Selector: '<S347>/Selector' incorporates:
      //   Concatenate: '<S348>/Vector Concatenate'

      FixedwingModel_B.Selector[3 * i] = rtb_VectorConcatenate_c[6 * i];

      // Concatenate: '<S348>/Vector Concatenate' incorporates:
      //   Constant: '<S348>/Constant1'
      //   Constant: '<S348>/Constant2'
      //   Selector: '<S347>/Selector'
      //   Selector: '<S347>/Selector1'

      s281_iter = 3 * i + 1;
      s289_iter = 6 * i + 1;
      rtb_VectorConcatenate_c[s289_iter] =
        FixedwingModel_P.uDOFEulerAngles_inertia[s281_iter];
      rtb_VectorConcatenate_a_tmp = 6 * i + 4;
      rtb_VectorConcatenate_c[rtb_VectorConcatenate_a_tmp] =
        FixedwingModel_P.Constant2_Value_cn[s281_iter];

      // Selector: '<S347>/Selector1' incorporates:
      //   Concatenate: '<S348>/Vector Concatenate'

      FixedwingModel_B.Selector1[s281_iter] =
        rtb_VectorConcatenate_c[rtb_VectorConcatenate_a_tmp];

      // Selector: '<S347>/Selector' incorporates:
      //   Concatenate: '<S348>/Vector Concatenate'

      FixedwingModel_B.Selector[s281_iter] = rtb_VectorConcatenate_c[s289_iter];

      // Concatenate: '<S348>/Vector Concatenate' incorporates:
      //   Constant: '<S348>/Constant1'
      //   Constant: '<S348>/Constant2'
      //   Selector: '<S347>/Selector'
      //   Selector: '<S347>/Selector1'

      s281_iter = 3 * i + 2;
      s289_iter = 6 * i + 2;
      rtb_VectorConcatenate_c[s289_iter] =
        FixedwingModel_P.uDOFEulerAngles_inertia[s281_iter];
      rtb_VectorConcatenate_a_tmp = 6 * i + 5;
      rtb_VectorConcatenate_c[rtb_VectorConcatenate_a_tmp] =
        FixedwingModel_P.Constant2_Value_cn[s281_iter];

      // Selector: '<S347>/Selector1' incorporates:
      //   Concatenate: '<S348>/Vector Concatenate'

      FixedwingModel_B.Selector1[s281_iter] =
        rtb_VectorConcatenate_c[rtb_VectorConcatenate_a_tmp];

      // Selector: '<S347>/Selector' incorporates:
      //   Concatenate: '<S348>/Vector Concatenate'

      FixedwingModel_B.Selector[s281_iter] = rtb_VectorConcatenate_c[s289_iter];
    }
  }

  // Product: '<S257>/i x j'
  rtb_UniformRandomNumber4_j = rtb_ubvbwb[0] * FixedwingModel_B.Gain[1];

  // Sum: '<S254>/Sum' incorporates:
  //   Product: '<S257>/j x k'
  //   Product: '<S257>/k x i'
  //   Product: '<S258>/i x k'
  //   Product: '<S258>/j x i'
  //   Product: '<S258>/k x j'

  rtb_Sum4_p[0] = rtb_ubvbwb[1] * FixedwingModel_B.Gain[2] -
    FixedwingModel_B.Gain[1] * rtb_ubvbwb[2];
  rtb_Sum4_p[1] = FixedwingModel_B.Gain[0] * rtb_ubvbwb[2] - rtb_ubvbwb[0] *
    FixedwingModel_B.Gain[2];
  rtb_Sum4_p[2] = rtb_UniformRandomNumber4_j - FixedwingModel_B.Gain[0] *
    rtb_ubvbwb[1];

  // Product: '<S255>/i x j'
  rtb_UniformRandomNumber4_j = rtb_ubvbwb[0] * rtb_Sum4_p[1];

  // Product: '<S255>/j x k'
  rtb_sincos_o1_idx_0 = rtb_ubvbwb[1];

  // Product: '<S255>/k x i'
  rtb_IntegratorSecondOrderLim_ff = rtb_ubvbwb[2];

  // Product: '<S256>/k x j'
  rtb_rgw_p_idx_0 = rtb_ubvbwb[2];

  // Product: '<S256>/i x k'
  rtb_Rn = rtb_ubvbwb[0];

  // Product: '<S256>/j x i'
  rtb_jxi_d = rtb_ubvbwb[1];

  // Sum: '<S253>/Sum' incorporates:
  //   Product: '<S255>/j x k'
  //   Product: '<S255>/k x i'
  //   Product: '<S256>/i x k'
  //   Product: '<S256>/j x i'
  //   Product: '<S256>/k x j'

  rtb_ubvbwb[0] = rtb_sincos_o1_idx_0 * rtb_Sum4_p[2] - rtb_Sum4_p[1] *
    rtb_rgw_p_idx_0;
  rtb_ubvbwb[1] = rtb_Sum4_p[0] * rtb_IntegratorSecondOrderLim_ff - rtb_Rn *
    rtb_Sum4_p[2];
  rtb_ubvbwb[2] = rtb_UniformRandomNumber4_j - rtb_Sum4_p[0] * rtb_jxi_d;

  // Product: '<S358>/Product' incorporates:
  //   Gain: '<S345>/Zero-Order Hold'
  //   SecondOrderIntegrator: '<S263>/Integrator, Second-Order Limited'
  //   Selector: '<S347>/Selector'

  for (i = 0; i < 3; i++) {
    rtb_IntegratorSecondOrderLimi_m[i] = (FixedwingModel_B.Selector[i + 3] *
      rtb_ZeroOrderHold[1] + FixedwingModel_B.Selector[i] * rtb_ZeroOrderHold[0])
      + FixedwingModel_B.Selector[i + 6] * rtb_ZeroOrderHold[2];
  }

  // End of Product: '<S358>/Product'

  // Product: '<S360>/i x j'
  rtb_UniformRandomNumber4_j = rtb_ZeroOrderHold[0] *
    rtb_IntegratorSecondOrderLimi_m[1];

  // Product: '<S360>/j x k'
  rtb_IntegratorSecondOrderLim_ff = rtb_IntegratorSecondOrderLimi_m[2];

  // Product: '<S360>/k x i'
  rtb_sincos_o1_idx_0 = rtb_IntegratorSecondOrderLimi_m[0];

  // Product: '<S361>/k x j'
  rtb_rgw_p_idx_0 = rtb_IntegratorSecondOrderLimi_m[1];

  // Product: '<S361>/i x k'
  rtb_Rn = rtb_IntegratorSecondOrderLimi_m[2];

  // Product: '<S361>/j x i'
  rtb_jxi_d = rtb_IntegratorSecondOrderLimi_m[0];

  // Sum: '<S357>/Sum' incorporates:
  //   Product: '<S360>/j x k'
  //   Product: '<S360>/k x i'
  //   Product: '<S361>/i x k'
  //   Product: '<S361>/j x i'
  //   Product: '<S361>/k x j'

  rtb_IntegratorSecondOrderLimi_m[0] = rtb_ZeroOrderHold[1] *
    rtb_IntegratorSecondOrderLim_ff - rtb_rgw_p_idx_0 * rtb_ZeroOrderHold[2];
  rtb_IntegratorSecondOrderLimi_m[1] = rtb_sincos_o1_idx_0 * rtb_ZeroOrderHold[2]
    - rtb_ZeroOrderHold[0] * rtb_Rn;
  rtb_IntegratorSecondOrderLimi_m[2] = rtb_UniformRandomNumber4_j - rtb_jxi_d *
    rtb_ZeroOrderHold[1];
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    for (i = 0; i < 3; i++) {
      // Selector: '<S347>/Selector2' incorporates:
      //   Concatenate: '<S348>/Vector Concatenate'

      FixedwingModel_B.Selector2[3 * i] = rtb_VectorConcatenate_c[6 * i];
      FixedwingModel_B.Selector2[3 * i + 1] = rtb_VectorConcatenate_c[6 * i + 1];
      FixedwingModel_B.Selector2[3 * i + 2] = rtb_VectorConcatenate_c[6 * i + 2];
    }
  }

  for (i = 0; i < 3; i++) {
    // Sum: '<S347>/Sum2' incorporates:
    //   Gain: '<S345>/Zero-Order Hold'
    //   Product: '<S359>/Product'
    //   Selector: '<S347>/Selector1'

    rtb_Gain_d[i] = (ddm[i + 3] - ((FixedwingModel_B.Selector1[i + 3] *
      rtb_ZeroOrderHold[1] + FixedwingModel_B.Selector1[i] * rtb_ZeroOrderHold[0])
      + FixedwingModel_B.Selector1[i + 6] * rtb_ZeroOrderHold[2])) -
      rtb_IntegratorSecondOrderLimi_m[i];
  }

  // Product: '<S347>/Product2' incorporates:
  //   Selector: '<S347>/Selector2'

  rt_mrdivide_U1d1x3_U2d_9vOrDY9Z(rtb_Gain_d, FixedwingModel_B.Selector2,
    FixedwingModel_B.Product2);

  // Gain: '<S246>/Zero-Order Hold3' incorporates:
  //   Gain: '<S8>/Gain7'

  rtb_Sum4_p[0] = FixedwingModel_P.Gain7_Gain * FixedwingModel_B.Product2[0] *
    FixedwingModel_P.ZeroOrderHold3_Gain;
  rtb_Sum4_p[1] = FixedwingModel_P.Gain7_Gain * FixedwingModel_B.Product2[1] *
    FixedwingModel_P.ZeroOrderHold3_Gain;
  rtb_Sum4_p[2] = FixedwingModel_P.Gain7_Gain * FixedwingModel_B.Product2[2] *
    FixedwingModel_P.ZeroOrderHold3_Gain;

  // Sum: '<S250>/Sum' incorporates:
  //   Product: '<S259>/i x j'
  //   Product: '<S259>/j x k'
  //   Product: '<S259>/k x i'
  //   Product: '<S260>/i x k'
  //   Product: '<S260>/j x i'
  //   Product: '<S260>/k x j'

  rtb_Sum4_a_0[2] = rtb_Sum4_p[0] * FixedwingModel_B.Gain[1];
  rtb_Sum4_a_0[0] = rtb_Sum4_p[1] * FixedwingModel_B.Gain[2];
  rtb_Sum4_a_0[1] = FixedwingModel_B.Gain[0] * rtb_Sum4_p[2];
  rtb_UniformRandomNumber7[0] = FixedwingModel_B.Gain[1] * rtb_Sum4_p[2];
  rtb_UniformRandomNumber7[1] = rtb_Sum4_p[0] * FixedwingModel_B.Gain[2];
  rtb_UniformRandomNumber7[2] = FixedwingModel_B.Gain[0] * rtb_Sum4_p[1];
  for (i = 0; i < 3; i++) {
    // Sum: '<S246>/Sum' incorporates:
    //   Gain: '<S246>/Zero-Order Hold1'
    //   Gain: '<S246>/Zero-Order Hold2'
    //   Gain: '<S8>/Gain4'
    //   Product: '<S226>/Matrix Multiply1'
    //   Sum: '<S250>/Sum'

    rtb_IntegratorSecondOrderLimi_m[i] = ((FixedwingModel_P.ZeroOrderHold1_Gain *
      rtb_DataTypeConversion2[i] - ((rtb_VectorConcatenate_g[i + 3] *
      FixedwingModel_B.MatrixConcatenate[1] + rtb_VectorConcatenate_g[i] *
      FixedwingModel_B.MatrixConcatenate[0]) + rtb_VectorConcatenate_g[i + 6] *
      FixedwingModel_B.MatrixConcatenate[2]) *
      FixedwingModel_P.ZeroOrderHold2_Gain) + rtb_ubvbwb[i]) + (rtb_Sum4_a_0[i]
      - rtb_UniformRandomNumber7[i]);
  }

  // Sum: '<S246>/Sum4' incorporates:
  //   Constant: '<S246>/Measurement bias'
  //   Constant: '<S246>/Scale factors & Cross-coupling  errors'
  //   Product: '<S246>/Product'

  for (i = 0; i < 3; i++) {
    rtb_Sum4_p[i] = ((FixedwingModel_P.ThreeaxisInertialMeasurementU_l[i + 3] *
                      rtb_IntegratorSecondOrderLimi_m[1] +
                      FixedwingModel_P.ThreeaxisInertialMeasurementU_l[i] *
                      rtb_IntegratorSecondOrderLimi_m[0]) +
                     FixedwingModel_P.ThreeaxisInertialMeasurementU_l[i + 6] *
                     rtb_IntegratorSecondOrderLimi_m[2]) +
      FixedwingModel_P.ThreeaxisInertialMeasurementUni[i];
  }

  // End of Sum: '<S246>/Sum4'
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[2] == 0) {
    // Gain: '<S226>/Gain10' incorporates:
    //   UniformRandomNumber: '<S226>/Uniform Random Number5'

    FixedwingModel_B.Gain10[0] = FixedwingModel_P.Gain10_Gain *
      FixedwingModel_DW.UniformRandomNumber5_NextOutput[0];
    FixedwingModel_B.Gain10[1] = FixedwingModel_P.Gain10_Gain *
      FixedwingModel_DW.UniformRandomNumber5_NextOutput[1];
    FixedwingModel_B.Gain10[2] = FixedwingModel_P.Gain10_Gain *
      FixedwingModel_DW.UniformRandomNumber5_NextOutput[2];
  }

  for (i = 0; i < 20; i++) {
    // DataTypeConversion: '<Root>/Data Type Conversion3' incorporates:
    //   Inport: '<Root>/inSILFloats'

    inSILFloats[i] = FixedwingModel_U.inSILFloats[i];
  }

  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // MATLAB Function: '<S226>/FaultParamsExtract' incorporates:
    //   Constant: '<S226>/FaultID'
    //   Inport: '<Root>/inSILInts'

    // MATLAB Function 'SensorFault/FaultParamsExtract': '<S229>:1'
    // '<S229>:1:5' if isempty(hFault)
    // '<S229>:1:8' if isempty(fParam)
    // '<S229>:1:12' hFaultTmp=false;
    rtb_Compare_n = false;

    // '<S229>:1:13' fParamTmp=zeros(20,1);
    std::memset(&fParamTmp[0], 0, 20U * sizeof(real_T));

    // '<S229>:1:14' j=1;
    rtb_Rn = 1.0;

    // '<S229>:1:15' for i=1:8
    for (s281_iter = 0; s281_iter < 8; s281_iter++) {
      // '<S229>:1:16' if inInts(i) == FaultID
      if (FixedwingModel_U.inSILInts[s281_iter] ==
          FixedwingModel_P.FaultID_Value) {
        // '<S229>:1:17' hFaultTmp=true;
        rtb_Compare_n = true;

        // '<S229>:1:18' fParamTmp(2*j-1)=inFloats(2*i-1);
        s289_iter = (s281_iter + 1) << 1;
        fParamTmp[static_cast<int32_T>(2.0 * rtb_Rn - 1.0) - 1] =
          inSILFloats[s289_iter - 2];

        // '<S229>:1:19' fParamTmp(2*j)=inFloats(2*i);
        fParamTmp[static_cast<int32_T>(2.0 * rtb_Rn) - 1] =
          inSILFloats[s289_iter - 1];

        // '<S229>:1:20' j=j+1;
        rtb_Rn++;
      }
    }

    // '<S229>:1:23' if hFaultTmp
    if (rtb_Compare_n) {
      // '<S229>:1:24' hFault=hFaultTmp;
      FixedwingModel_DW.hFault_a = true;

      // '<S229>:1:25' fParamTmp(17:20) = inFloats(17:20);
      fParamTmp[16] = inSILFloats[16];
      fParamTmp[17] = inSILFloats[17];
      fParamTmp[18] = inSILFloats[18];
      fParamTmp[19] = inSILFloats[19];

      // '<S229>:1:26' fParam=fParamTmp;
      std::memcpy(&FixedwingModel_DW.fParam_o[0], &fParamTmp[0], 20U * sizeof
                  (real_T));
    }

    // MATLAB Function: '<S227>/Acc NoiseFun' incorporates:
    //   MATLAB Function: '<S226>/FaultParamsExtract'

    // '<S229>:1:29' hasFault_acc=hFault;
    // '<S229>:1:30' FaultParam=fParam;
    FixedwingModel_AccNoiseFun(FixedwingModel_B.Gain10,
      FixedwingModel_DW.hFault_a, FixedwingModel_DW.fParam_o,
      &FixedwingModel_B.sf_AccNoiseFun);
  }

  // Switch: '<S248>/Switch' incorporates:
  //   Constant: '<S248>/Constant'
  //   SecondOrderIntegrator: '<S252>/Integrator, Second-Order Limited'

  if (FixedwingModel_P.Constant_Value_b >= FixedwingModel_P.Switch_Threshold_d)
  {
    rtb_IntegratorSecondOrderLim_ff =
      FixedwingModel_X.IntegratorSecondOrderLimited_CS[0];
  } else {
    rtb_IntegratorSecondOrderLim_ff = rtb_Sum4_p[0];
  }

  // Saturate: '<S246>/Saturation'
  if (rtb_IntegratorSecondOrderLim_ff > FixedwingModel_P.Saturation_UpperSat_h[0])
  {
    rtb_IntegratorSecondOrderLim_ff = FixedwingModel_P.Saturation_UpperSat_h[0];
  } else if (rtb_IntegratorSecondOrderLim_ff <
             FixedwingModel_P.Saturation_LowerSat_cm[0]) {
    rtb_IntegratorSecondOrderLim_ff = FixedwingModel_P.Saturation_LowerSat_cm[0];
  }

  // Sum: '<S226>/Sum1'
  rtb_ubvbwb[0] = rtb_IntegratorSecondOrderLim_ff +
    FixedwingModel_B.sf_AccNoiseFun.y[0];

  // Switch: '<S248>/Switch' incorporates:
  //   Constant: '<S248>/Constant'
  //   SecondOrderIntegrator: '<S252>/Integrator, Second-Order Limited'

  if (FixedwingModel_P.Constant_Value_b >= FixedwingModel_P.Switch_Threshold_d)
  {
    rtb_IntegratorSecondOrderLim_ff =
      FixedwingModel_X.IntegratorSecondOrderLimited_CS[1];
  } else {
    rtb_IntegratorSecondOrderLim_ff = rtb_Sum4_p[1];
  }

  // Saturate: '<S246>/Saturation'
  if (rtb_IntegratorSecondOrderLim_ff > FixedwingModel_P.Saturation_UpperSat_h[1])
  {
    rtb_IntegratorSecondOrderLim_ff = FixedwingModel_P.Saturation_UpperSat_h[1];
  } else if (rtb_IntegratorSecondOrderLim_ff <
             FixedwingModel_P.Saturation_LowerSat_cm[1]) {
    rtb_IntegratorSecondOrderLim_ff = FixedwingModel_P.Saturation_LowerSat_cm[1];
  }

  // Sum: '<S226>/Sum1'
  rtb_ubvbwb[1] = rtb_IntegratorSecondOrderLim_ff +
    FixedwingModel_B.sf_AccNoiseFun.y[1];

  // Switch: '<S248>/Switch' incorporates:
  //   Constant: '<S248>/Constant'
  //   SecondOrderIntegrator: '<S252>/Integrator, Second-Order Limited'

  if (FixedwingModel_P.Constant_Value_b >= FixedwingModel_P.Switch_Threshold_d)
  {
    rtb_IntegratorSecondOrderLim_ff =
      FixedwingModel_X.IntegratorSecondOrderLimited_CS[2];
  } else {
    rtb_IntegratorSecondOrderLim_ff = rtb_Sum4_p[2];
  }

  // Saturate: '<S246>/Saturation'
  if (rtb_IntegratorSecondOrderLim_ff > FixedwingModel_P.Saturation_UpperSat_h[2])
  {
    rtb_IntegratorSecondOrderLim_ff = FixedwingModel_P.Saturation_UpperSat_h[2];
  } else if (rtb_IntegratorSecondOrderLim_ff <
             FixedwingModel_P.Saturation_LowerSat_cm[2]) {
    rtb_IntegratorSecondOrderLim_ff = FixedwingModel_P.Saturation_LowerSat_cm[2];
  }

  // Sum: '<S226>/Sum1'
  rtb_ubvbwb[2] = rtb_IntegratorSecondOrderLim_ff +
    FixedwingModel_B.sf_AccNoiseFun.y[2];

  // SecondOrderIntegrator: '<S263>/Integrator, Second-Order Limited'
  s281_iter = 3;

  // Unit Conversion - from: m/s^2 to: gn
  // Expression: output = (0.101972*input) + (0)
  for (i = 0; i < 3; i++) {
    // DataTypeConversion: '<S226>/Data Type Conversion2'
    rtb_AngEuler[i] = static_cast<real32_T>(rtb_ubvbwb[i]);

    // SecondOrderIntegrator: '<S263>/Integrator, Second-Order Limited'
    rtb_IntegratorSecondOrderLimi_m[i] =
      FixedwingModel_X.IntegratorSecondOrderLimited__d[s281_iter];
    s281_iter++;

    // Sum: '<S247>/Sum4' incorporates:
    //   Constant: '<S247>/Measurement bias'
    //   Constant: '<S247>/Scale factors & Cross-coupling  errors '
    //   Constant: '<S247>/g-sensitive bias'
    //   Gain: '<S247>/Zero-Order Hold'
    //   Gain: '<S247>/Zero-Order Hold1'
    //   Product: '<S247>/Product'
    //   Product: '<S247>/Product1'
    //   UnitConversion: '<S245>/Unit Conversion'

    rtb_Gain_d[i] = (((FixedwingModel_P.ZeroOrderHold_Gain_h * wb[0] *
                       FixedwingModel_P.ThreeaxisInertialMeasurementU_m[i] +
                       FixedwingModel_P.ThreeaxisInertialMeasurementU_m[i + 3] *
                       (FixedwingModel_P.ZeroOrderHold_Gain_h * wb[1])) +
                      FixedwingModel_P.ThreeaxisInertialMeasurementU_m[i + 6] *
                      (FixedwingModel_P.ZeroOrderHold_Gain_h * wb[2])) +
                     FixedwingModel_P.ThreeaxisInertialMeasurementU_b[i]) +
      0.10197162129779282 * rtb_DataTypeConversion2[i] *
      FixedwingModel_P.ZeroOrderHold1_Gain_k *
      FixedwingModel_P.ThreeaxisInertialMeasurement_b5[i];

    // SecondOrderIntegrator: '<S263>/Integrator, Second-Order Limited'
    rtb_ubvbwb[i] = FixedwingModel_X.IntegratorSecondOrderLimited__d[i];
  }

  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[2] == 0) {
    // Gain: '<S226>/Gain6' incorporates:
    //   UniformRandomNumber: '<S226>/Uniform Random Number1'

    FixedwingModel_B.Gain6[0] = FixedwingModel_P.Gain6_Gain_j *
      FixedwingModel_DW.UniformRandomNumber1_NextOutput[0];
    FixedwingModel_B.Gain6[1] = FixedwingModel_P.Gain6_Gain_j *
      FixedwingModel_DW.UniformRandomNumber1_NextOutput[1];
    FixedwingModel_B.Gain6[2] = FixedwingModel_P.Gain6_Gain_j *
      FixedwingModel_DW.UniformRandomNumber1_NextOutput[2];
  }

  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // MATLAB Function: '<S226>/FaultParamsExtract1' incorporates:
    //   Constant: '<S226>/FaultID1'
    //   Inport: '<Root>/inSILInts'

    // MATLAB Function 'SensorFault/FaultParamsExtract1': '<S230>:1'
    // '<S230>:1:5' if isempty(hFault)
    // '<S230>:1:8' if isempty(fParam)
    // '<S230>:1:12' hFaultTmp=false;
    rtb_Compare_n = false;

    // '<S230>:1:13' fParamTmp=zeros(20,1);
    std::memset(&fParamTmp[0], 0, 20U * sizeof(real_T));

    // '<S230>:1:14' j=1;
    rtb_Rn = 1.0;

    // '<S230>:1:15' for i=1:8
    for (s281_iter = 0; s281_iter < 8; s281_iter++) {
      // '<S230>:1:16' if inInts(i) == FaultID
      if (FixedwingModel_U.inSILInts[s281_iter] ==
          FixedwingModel_P.FaultID1_Value) {
        // '<S230>:1:17' hFaultTmp=true;
        rtb_Compare_n = true;

        // '<S230>:1:18' fParamTmp(2*j-1)=inFloats(2*i-1);
        s289_iter = (s281_iter + 1) << 1;
        fParamTmp[static_cast<int32_T>(2.0 * rtb_Rn - 1.0) - 1] =
          inSILFloats[s289_iter - 2];

        // '<S230>:1:19' fParamTmp(2*j)=inFloats(2*i);
        fParamTmp[static_cast<int32_T>(2.0 * rtb_Rn) - 1] =
          inSILFloats[s289_iter - 1];

        // '<S230>:1:20' j=j+1;
        rtb_Rn++;
      }
    }

    // '<S230>:1:23' if hFaultTmp
    if (rtb_Compare_n) {
      // '<S230>:1:24' hFault=hFaultTmp;
      FixedwingModel_DW.hFault_k = true;

      // '<S230>:1:25' fParamTmp(17:20) = inFloats(17:20);
      fParamTmp[16] = inSILFloats[16];
      fParamTmp[17] = inSILFloats[17];
      fParamTmp[18] = inSILFloats[18];
      fParamTmp[19] = inSILFloats[19];

      // '<S230>:1:26' fParam=fParamTmp;
      std::memcpy(&FixedwingModel_DW.fParam_e[0], &fParamTmp[0], 20U * sizeof
                  (real_T));
    }

    // MATLAB Function: '<S233>/Acc NoiseFun' incorporates:
    //   MATLAB Function: '<S226>/FaultParamsExtract1'

    // '<S230>:1:29' hasFault_gyro=hFault;
    // '<S230>:1:30' FaultParam=fParam;
    FixedwingModel_AccNoiseFun(FixedwingModel_B.Gain6,
      FixedwingModel_DW.hFault_k, FixedwingModel_DW.fParam_e,
      &FixedwingModel_B.sf_AccNoiseFun_p);
  }

  // Switch: '<S261>/Switch' incorporates:
  //   Constant: '<S261>/Constant'

  if (FixedwingModel_P.Constant_Value_g >= FixedwingModel_P.Switch_Threshold_p)
  {
    rtb_IntegratorSecondOrderLim_ff = rtb_ubvbwb[0];
  } else {
    rtb_IntegratorSecondOrderLim_ff = rtb_Gain_d[0];
  }

  // Saturate: '<S247>/Saturation'
  if (rtb_IntegratorSecondOrderLim_ff > FixedwingModel_P.Saturation_UpperSat_gx
      [0]) {
    y = FixedwingModel_P.Saturation_UpperSat_gx[0];
  } else if (rtb_IntegratorSecondOrderLim_ff <
             FixedwingModel_P.Saturation_LowerSat_a[0]) {
    y = FixedwingModel_P.Saturation_LowerSat_a[0];
  } else {
    y = rtb_IntegratorSecondOrderLim_ff;
  }

  // Switch: '<S261>/Switch' incorporates:
  //   Constant: '<S261>/Constant'

  if (FixedwingModel_P.Constant_Value_g >= FixedwingModel_P.Switch_Threshold_p)
  {
    rtb_IntegratorSecondOrderLim_ff = rtb_ubvbwb[1];
  } else {
    rtb_IntegratorSecondOrderLim_ff = rtb_Gain_d[1];
  }

  // Saturate: '<S247>/Saturation'
  if (rtb_IntegratorSecondOrderLim_ff > FixedwingModel_P.Saturation_UpperSat_gx
      [1]) {
    y_0 = FixedwingModel_P.Saturation_UpperSat_gx[1];
  } else if (rtb_IntegratorSecondOrderLim_ff <
             FixedwingModel_P.Saturation_LowerSat_a[1]) {
    y_0 = FixedwingModel_P.Saturation_LowerSat_a[1];
  } else {
    y_0 = rtb_IntegratorSecondOrderLim_ff;
  }

  // Switch: '<S261>/Switch' incorporates:
  //   Constant: '<S261>/Constant'

  if (FixedwingModel_P.Constant_Value_g >= FixedwingModel_P.Switch_Threshold_p)
  {
    rtb_IntegratorSecondOrderLim_ff = rtb_ubvbwb[2];
  } else {
    rtb_IntegratorSecondOrderLim_ff = rtb_Gain_d[2];
  }

  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // Sum: '<S273>/Sum' incorporates:
    //   Constant: '<S239>/Decimal Year'
    //   Constant: '<S273>/epoch'

    rtb_Sum_le = FixedwingModel_P.DecimalYear_Value -
      FixedwingModel_P.epoch_Value;

    // RelationalOperator: '<S287>/Relational Operator' incorporates:
    //   Constant: '<S239>/Decimal Year'
    //   Memory: '<S287>/otime'

    rtb_RelationalOperator = (FixedwingModel_P.DecimalYear_Value !=
      FixedwingModel_DW.otime_PreviousInput);
  }

  // Switch: '<S278>/Switch' incorporates:
  //   Abs: '<S278>/Abs'
  //   Bias: '<S278>/Bias'
  //   Bias: '<S278>/Bias1'
  //   Constant: '<S278>/Constant2'
  //   Constant: '<S279>/Constant'
  //   Math: '<S278>/Math Function1'
  //   RelationalOperator: '<S279>/Compare'

  if (std::abs(rtb_sincos_o1_i_idx_0) >
      FixedwingModel_P.CompareToConstant_const_e) {
    rtb_sincos_o1_idx_0 = rt_modd_snf(rtb_sincos_o1_i_idx_0 +
      FixedwingModel_P.Bias_Bias_je, FixedwingModel_P.Constant2_Value_h) +
      FixedwingModel_P.Bias1_Bias_g;
  } else {
    rtb_sincos_o1_idx_0 = rtb_sincos_o1_i_idx_0;
  }

  // End of Switch: '<S278>/Switch'

  // Abs: '<S275>/Abs1'
  rtb_rgw_p_idx_0 = std::abs(rtb_sincos_o1_idx_0);

  // RelationalOperator: '<S277>/Compare' incorporates:
  //   Constant: '<S277>/Constant'

  rtb_Compare_n = (rtb_rgw_p_idx_0 > FixedwingModel_P.CompareToConstant_const_h);

  // Switch: '<S269>/Switch1' incorporates:
  //   Constant: '<S269>/Constant'
  //   Constant: '<S269>/Constant1'

  if (rtb_Compare_n) {
    rtb_UniformRandomNumber4_j = FixedwingModel_P.Constant_Value_bw;
  } else {
    rtb_UniformRandomNumber4_j = FixedwingModel_P.Constant1_Value_ni;
  }

  // End of Switch: '<S269>/Switch1'

  // Sum: '<S269>/Sum'
  rtb_UniformRandomNumber4_j += rtb_jxi;

  // Switch: '<S276>/Switch' incorporates:
  //   Abs: '<S276>/Abs'
  //   Constant: '<S280>/Constant'
  //   RelationalOperator: '<S280>/Compare'

  if (std::abs(rtb_UniformRandomNumber4_j) >
      FixedwingModel_P.CompareToConstant_const_n) {
    // Switch: '<S276>/Switch' incorporates:
    //   Bias: '<S276>/Bias'
    //   Bias: '<S276>/Bias1'
    //   Constant: '<S276>/Constant2'
    //   Math: '<S276>/Math Function1'

    FixedwingModel_B.Switch_c = rt_modd_snf(rtb_UniformRandomNumber4_j +
      FixedwingModel_P.Bias_Bias_g, FixedwingModel_P.Constant2_Value_n) +
      FixedwingModel_P.Bias1_Bias_gb;
  } else {
    // Switch: '<S276>/Switch'
    FixedwingModel_B.Switch_c = rtb_UniformRandomNumber4_j;
  }

  // End of Switch: '<S276>/Switch'

  // Switch: '<S275>/Switch'
  if (rtb_Compare_n) {
    // Signum: '<S275>/Sign1'
    if (!rtIsNaN(rtb_sincos_o1_idx_0)) {
      if (rtb_sincos_o1_idx_0 < 0.0) {
        rtb_sincos_o1_idx_0 = -1.0;
      } else {
        rtb_sincos_o1_idx_0 = (rtb_sincos_o1_idx_0 > 0.0);
      }
    }

    // End of Signum: '<S275>/Sign1'

    // Switch: '<S275>/Switch' incorporates:
    //   Bias: '<S275>/Bias'
    //   Bias: '<S275>/Bias1'
    //   Gain: '<S275>/Gain'
    //   Product: '<S275>/Divide1'

    FixedwingModel_B.Switch_j = ((rtb_rgw_p_idx_0 + FixedwingModel_P.Bias_Bias_b)
      * FixedwingModel_P.Gain_Gain_en + FixedwingModel_P.Bias1_Bias_a) *
      rtb_sincos_o1_idx_0;
  } else {
    // Switch: '<S275>/Switch'
    FixedwingModel_B.Switch_j = rtb_sincos_o1_idx_0;
  }

  // End of Switch: '<S275>/Switch'

  // UnitConversion: '<S331>/Unit Conversion'
  // Unit Conversion - from: deg to: rad
  // Expression: output = (0.0174533*input) + (0)
  rtb_rgw_p_idx_0 = 0.017453292519943295 * FixedwingModel_B.Switch_c;
  rtb_rgw_p_idx_1 = 0.017453292519943295 * FixedwingModel_B.Switch_j;

  // Trigonometry: '<S284>/sincos'
  rtb_sincos_o1_idx_0 = std::sin(rtb_rgw_p_idx_0);
  rtb_Sum_gz = std::cos(rtb_rgw_p_idx_0);
  rtb_Rn = std::sin(rtb_rgw_p_idx_1);
  rtb_Gain9_d = std::cos(rtb_rgw_p_idx_1);
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // Outputs for Enabled SubSystem: '<S273>/Convert from geodetic to  spherical coordinates ' incorporates:
    //   EnablePort: '<S283>/Enable'

    if (rtsiIsModeUpdateTimeStep(&(&FixedwingModel_M)->solverInfo)) {
      // RelationalOperator: '<S286>/Relational Operator' incorporates:
      //   Memory: '<S286>/olon'

      FixedwingModel_DW.Convertfromgeodetictosphericalc =
        (FixedwingModel_B.Switch_c != FixedwingModel_DW.olon_PreviousInput);
    }

    // End of Outputs for SubSystem: '<S273>/Convert from geodetic to  spherical coordinates ' 

    // Memory: '<S285>/olat'
    FixedwingModel_B.olat = FixedwingModel_DW.olat_PreviousInput;
  }

  // Outputs for Enabled SubSystem: '<S273>/Convert from geodetic to  spherical coordinates ' incorporates:
  //   EnablePort: '<S283>/Enable'

  if (FixedwingModel_DW.Convertfromgeodetictosphericalc) {
    if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
        (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
      // Outputs for Iterator SubSystem: '<S283>/For Iterator Subsystem' incorporates:
      //   ForIterator: '<S330>/For Iterator'

      while (s330_iter <= FixedwingModel_P.ForIterator_IterationLimit) {
        // Switch: '<S330>/cp[m-1] sp[m-1]' incorporates:
        //   SignalConversion generated from: '<S283>/cp[2]'
        //   UnitDelay: '<S330>/Unit Delay1'

        if (s330_iter > FixedwingModel_P.cpm1spm1_Threshold) {
          rtb_rgw_p_idx_0 = FixedwingModel_DW.UnitDelay1_DSTATE[0];
          rtb_rgw_p_idx_1 = FixedwingModel_DW.UnitDelay1_DSTATE[1];
        } else {
          rtb_rgw_p_idx_0 = rtb_Sum_gz;
          rtb_rgw_p_idx_1 = rtb_sincos_o1_idx_0;
        }

        // End of Switch: '<S330>/cp[m-1] sp[m-1]'

        // Sum: '<S330>/Sum2' incorporates:
        //   Product: '<S330>/Product1'
        //   Product: '<S330>/Product2'
        //   SignalConversion generated from: '<S283>/cp[2]'

        rtb_UniformRandomNumber4_j = rtb_rgw_p_idx_0 * rtb_sincos_o1_idx_0 +
          rtb_rgw_p_idx_1 * rtb_Sum_gz;

        // Sum: '<S330>/Sum1' incorporates:
        //   Product: '<S330>/Product3'
        //   Product: '<S330>/Product8'
        //   SignalConversion generated from: '<S283>/cp[2]'

        rtb_jxi_d = rtb_rgw_p_idx_0 * rtb_Sum_gz - rtb_rgw_p_idx_1 *
          rtb_sincos_o1_idx_0;

        // Assignment: '<S330>/Assignment' incorporates:
        //   Assignment: '<S330>/Assignment1'
        //   Constant: '<S330>/Constant'
        //   Constant: '<S330>/Constant1'

        if (s330_iter == 1) {
          std::memcpy(&rtb_Assignment[0], &FixedwingModel_P.Constant_Value_ny[0],
                      11U * sizeof(real_T));
          std::memcpy(&rtb_Assignment1[0], &FixedwingModel_P.Constant1_Value_n[0],
                      11U * sizeof(real_T));
        }

        rtb_Assignment[s330_iter - 1] = rtb_UniformRandomNumber4_j;

        // End of Assignment: '<S330>/Assignment'

        // Assignment: '<S330>/Assignment1'
        rtb_Assignment1[s330_iter - 1] = rtb_jxi_d;

        // Update for UnitDelay: '<S330>/Unit Delay1'
        FixedwingModel_DW.UnitDelay1_DSTATE[0] = rtb_jxi_d;
        FixedwingModel_DW.UnitDelay1_DSTATE[1] = rtb_UniformRandomNumber4_j;
        s330_iter++;
      }

      // End of Outputs for SubSystem: '<S283>/For Iterator Subsystem'
      for (i = 0; i < 11; i++) {
        // Gain: '<S283>/Gain'
        FixedwingModel_B.Gain_d[i] = FixedwingModel_P.Gain_Gain_g *
          rtb_Assignment1[i];

        // Gain: '<S283>/Gain1'
        FixedwingModel_B.Gain1[i] = FixedwingModel_P.Gain1_Gain_n *
          rtb_Assignment[i];
      }
    }

    // SignalConversion generated from: '<S283>/cp[13]' incorporates:
    //   Constant: '<S283>/cp[1]'
    //   SignalConversion generated from: '<S283>/cp[2]'

    FixedwingModel_B.OutportBufferForcp13[0] = FixedwingModel_P.cp1_Value;
    FixedwingModel_B.OutportBufferForcp13[1] = rtb_Sum_gz;

    // SignalConversion generated from: '<S283>/sp[13]' incorporates:
    //   Constant: '<S283>/sp[1]'
    //   SignalConversion generated from: '<S283>/sp[2]'

    FixedwingModel_B.OutportBufferForsp13[0] = FixedwingModel_P.sp1_Value;
    FixedwingModel_B.OutportBufferForsp13[1] = rtb_sincos_o1_idx_0;

    // SignalConversion generated from: '<S283>/cp[13]'
    std::memcpy(&FixedwingModel_B.OutportBufferForcp13[2],
                &FixedwingModel_B.Gain_d[0], 11U * sizeof(real_T));

    // SignalConversion generated from: '<S283>/sp[13]'
    std::memcpy(&FixedwingModel_B.OutportBufferForsp13[2],
                &FixedwingModel_B.Gain1[0], 11U * sizeof(real_T));
  }

  // End of Outputs for SubSystem: '<S273>/Convert from geodetic to  spherical coordinates ' 

  // Gain: '<S239>/Gain'
  FixedwingModel_B.Gain_m = FixedwingModel_P.Gain_Gain_if * rtb_Add;
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // Memory: '<S285>/oalt'
    FixedwingModel_B.oalt = FixedwingModel_DW.oalt_PreviousInput;
  }

  // Logic: '<S285>/Logical Operator' incorporates:
  //   RelationalOperator: '<S285>/Relational Operator'
  //   RelationalOperator: '<S285>/Relational Operator1'

  rtb_Compare_n = ((FixedwingModel_B.Switch_j != FixedwingModel_B.olat) ||
                   (FixedwingModel_B.Gain_m != FixedwingModel_B.oalt));

  // Product: '<S284>/Product'
  rtb_sincos_o1_idx_0 = rtb_Rn * rtb_Rn;

  // Product: '<S284>/Product1'
  rtb_rgw_p_idx_0 = rtb_Gain9_d * rtb_Gain9_d;
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // Outputs for Enabled SubSystem: '<S273>/Convert from geodetic to  spherical coordinates' incorporates:
    //   EnablePort: '<S282>/Enable'

    if (rtsiIsModeUpdateTimeStep(&(&FixedwingModel_M)->solverInfo)) {
      // SignalConversion generated from: '<S282>/Enable'
      FixedwingModel_DW.Convertfromgeodetictospherica_f = rtb_Compare_n;
    }

    // End of Outputs for SubSystem: '<S273>/Convert from geodetic to  spherical coordinates' 
  }

  // Outputs for Enabled SubSystem: '<S273>/Convert from geodetic to  spherical coordinates' incorporates:
  //   EnablePort: '<S282>/Enable'

  if (FixedwingModel_DW.Convertfromgeodetictospherica_f) {
    if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
        (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
      // Product: '<S282>/b2' incorporates:
      //   Constant: '<S282>/b'

      FixedwingModel_B.b2 = FixedwingModel_P.b_Value * FixedwingModel_P.b_Value;

      // Product: '<S282>/a2' incorporates:
      //   Constant: '<S282>/a'

      FixedwingModel_B.a2 = FixedwingModel_P.a_Value * FixedwingModel_P.a_Value;

      // Sum: '<S325>/Sum1'
      FixedwingModel_B.c2 = FixedwingModel_B.a2 - FixedwingModel_B.b2;
    }

    // Sqrt: '<S325>/sqrt' incorporates:
    //   Product: '<S325>/Product'
    //   Sum: '<S325>/Sum'

    rtb_Sum_gz = std::sqrt(FixedwingModel_B.a2 - rtb_sincos_o1_idx_0 *
      FixedwingModel_B.c2);

    // Product: '<S282>/Product1'
    rtb_jxi_d = rtb_Sum_gz * FixedwingModel_B.Gain_m;

    // Sum: '<S324>/Sum7' incorporates:
    //   Product: '<S324>/Product10'
    //   Product: '<S324>/Product9'

    rtb_UniformRandomNumber4_j = rtb_rgw_p_idx_0 * FixedwingModel_B.a2 +
      FixedwingModel_B.b2 * rtb_sincos_o1_idx_0;

    // Sqrt: '<S324>/sqrt'
    rtb_UniformRandomNumber4_j = std::sqrt(rtb_UniformRandomNumber4_j);
    if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
        (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
      // Product: '<S327>/a4'
      FixedwingModel_B.a4 = FixedwingModel_B.a2 * FixedwingModel_B.a2;

      // Sum: '<S327>/Sum9' incorporates:
      //   Product: '<S327>/b4'

      FixedwingModel_B.c4 = FixedwingModel_B.a4 - FixedwingModel_B.b2 *
        FixedwingModel_B.b2;
    }

    // Sqrt: '<S282>/sqrt' incorporates:
    //   Gain: '<S327>/Gain'
    //   Product: '<S327>/Product1'
    //   Product: '<S327>/Product6'
    //   Product: '<S327>/Product7'
    //   Product: '<S327>/Product8'
    //   Sum: '<S327>/Sum5'
    //   Sum: '<S327>/Sum6'

    FixedwingModel_B.sqrt_d = std::sqrt((FixedwingModel_B.a4 -
      FixedwingModel_B.c4 * rtb_sincos_o1_idx_0) / (rtb_Sum_gz * rtb_Sum_gz) +
      (FixedwingModel_P.Gain_Gain_p * rtb_jxi_d + FixedwingModel_B.Gain_m *
       FixedwingModel_B.Gain_m));

    // Product: '<S322>/Product11' incorporates:
    //   Sum: '<S322>/Sum8'

    FixedwingModel_B.Product11 = (FixedwingModel_B.Gain_m +
      rtb_UniformRandomNumber4_j) / FixedwingModel_B.sqrt_d;

    // Sum: '<S326>/Sum2'
    rtb_Sum_gz = FixedwingModel_B.a2 + rtb_jxi_d;

    // Sum: '<S326>/Sum1'
    rtb_jxi_d += FixedwingModel_B.b2;

    // Product: '<S323>/Product4' incorporates:
    //   Product: '<S323>/Product3'
    //   Product: '<S326>/Product1'
    //   Product: '<S326>/Product2'
    //   Sqrt: '<S323>/sqrt'
    //   Sum: '<S323>/Sum3'

    FixedwingModel_B.Product4_a = rtb_Rn / std::sqrt(rtb_Sum_gz * rtb_Sum_gz /
      (rtb_jxi_d * rtb_jxi_d) * rtb_rgw_p_idx_0 + rtb_sincos_o1_idx_0);

    // Product: '<S328>/Product1'
    rtb_UniformRandomNumber4_j *= FixedwingModel_B.sqrt_d;
    if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
        (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
      // Sum: '<S328>/Sum1'
      FixedwingModel_B.c2_n = FixedwingModel_B.a2 - FixedwingModel_B.b2;
    }

    // Product: '<S328>/Product12'
    FixedwingModel_B.Product12 = FixedwingModel_B.c2_n /
      rtb_UniformRandomNumber4_j * rtb_Gain9_d * rtb_Rn;

    // Sqrt: '<S329>/sqrt' incorporates:
    //   Constant: '<S329>/Constant'
    //   Product: '<S329>/Product5'
    //   Sum: '<S329>/Sum4'

    FixedwingModel_B.sqrt_j = std::sqrt(FixedwingModel_P.Constant_Value_c -
      FixedwingModel_B.Product4_a * FixedwingModel_B.Product4_a);
  }

  // End of Outputs for SubSystem: '<S273>/Convert from geodetic to  spherical coordinates' 

  // Product: '<S273>/aor' incorporates:
  //   Constant: '<S273>/re'

  rtb_sincos_o1_idx_0 = FixedwingModel_P.re_Value / FixedwingModel_B.sqrt_d;
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    real_T rtb_WhiteNoise_l_idx_1;

    // Outputs for Iterator SubSystem: '<S273>/Compute magnetic vector in spherical coordinates' incorporates:
    //   ForIterator: '<S281>/For Iterator'

    // InitializeConditions for UnitDelay: '<S281>/Unit Delay'
    rtb_Sum_gz = FixedwingModel_P.UnitDelay_InitialCondition_n;

    // InitializeConditions for UnitDelay: '<S281>/Unit Delay2'
    rtb_WhiteNoise_l_idx_0 = FixedwingModel_P.UnitDelay2_InitialCondition_e[0];
    rtb_WhiteNoise_l_idx_1 = FixedwingModel_P.UnitDelay2_InitialCondition_e[1];
    rtb_WhiteNoise_l_idx_2 = FixedwingModel_P.UnitDelay2_InitialCondition_e[2];
    rtb_WhiteNoise_l_idx_3 = FixedwingModel_P.UnitDelay2_InitialCondition_e[3];
    for (s281_iter = 1; s281_iter <=
         FixedwingModel_P.ForIterator_IterationLimit_c; s281_iter++) {
      // Switch: '<S281>/ar(n)' incorporates:
      //   Product: '<S273>/ar'

      if (s281_iter <= FixedwingModel_P.arn_Threshold) {
        rtb_Sum_gz = rtb_sincos_o1_idx_0 * rtb_sincos_o1_idx_0;
      }

      // End of Switch: '<S281>/ar(n)'

      // Product: '<S281>/Product8'
      rtb_rgw_p_idx_0 = rtb_Sum_gz * rtb_sincos_o1_idx_0;

      // Sum: '<S281>/Sum' incorporates:
      //   Constant: '<S281>/Constant'

      if ((s281_iter < 0) && (FixedwingModel_P.Constant_Value_b5 < MIN_int32_T -
           s281_iter)) {
        s330_iter = MIN_int32_T;
      } else if ((s281_iter > 0) && (FixedwingModel_P.Constant_Value_b5 >
                  MAX_int32_T - s281_iter)) {
        s330_iter = MAX_int32_T;
      } else {
        s330_iter = s281_iter + FixedwingModel_P.Constant_Value_b5;
      }

      // Outputs for Iterator SubSystem: '<S281>/For Iterator Subsystem' incorporates:
      //   ForIterator: '<S289>/For Iterator'

      // InitializeConditions for UnitDelay: '<S290>/Unit Delay1'
      rtb_UniformRandomNumber4_j =
        FixedwingModel_P.UnitDelay1_InitialCondition_n;

      // InitializeConditions for UnitDelay: '<S290>/Unit Delay3'
      rtb_jxi_d = FixedwingModel_P.UnitDelay3_InitialCondition;

      // InitializeConditions for UnitDelay: '<S290>/Unit Delay2'
      Sum_l = FixedwingModel_P.UnitDelay2_InitialCondition;

      // InitializeConditions for UnitDelay: '<S290>/Unit Delay4'
      rtb_rgw_p_idx_1 = FixedwingModel_P.UnitDelay4_InitialCondition;
      for (i = 0; i < 6; i++) {
        ForIterator_IterationMarker[i] = 1U;
      }

      // Sum: '<S281>/Sum'
      if (s330_iter > 2147483646) {
        s330_iter = 2147483646;
      } else if (s330_iter < 0) {
        s330_iter = 0;
      }

      if (s330_iter >= 1) {
        // Selector: '<S290>/snorm[n+m*13]' incorporates:
        //   Constant: '<S294>/Constant'
        //   Sum: '<S294>/Sum1'

        if ((FixedwingModel_P.Constant_Value_ba < 0) && (s281_iter < MIN_int32_T
             - FixedwingModel_P.Constant_Value_ba)) {
          qY = MIN_int32_T;
        } else if ((FixedwingModel_P.Constant_Value_ba > 0) && (s281_iter >
                    MAX_int32_T - FixedwingModel_P.Constant_Value_ba)) {
          qY = MAX_int32_T;
        } else {
          qY = FixedwingModel_P.Constant_Value_ba + s281_iter;
        }

        // Sum: '<S290>/Sum' incorporates:
        //   Constant: '<S290>/Constant'

        if ((s281_iter < 0) && (FixedwingModel_P.Constant_Value_ct < MIN_int32_T
             - s281_iter)) {
          s281_iter_0 = MIN_int32_T;
        } else if ((s281_iter > 0) && (FixedwingModel_P.Constant_Value_ct >
                    MAX_int32_T - s281_iter)) {
          s281_iter_0 = MAX_int32_T;
        } else {
          s281_iter_0 = s281_iter + FixedwingModel_P.Constant_Value_ct;
        }

        // Sum: '<S290>/Sum4' incorporates:
        //   Constant: '<S290>/Constant1'

        if ((s281_iter < 0) && (FixedwingModel_P.Constant1_Value_d < MIN_int32_T
             - s281_iter)) {
          s281_iter_1 = MIN_int32_T;
        } else if ((s281_iter > 0) && (FixedwingModel_P.Constant1_Value_d >
                    MAX_int32_T - s281_iter)) {
          s281_iter_1 = MAX_int32_T;
        } else {
          s281_iter_1 = s281_iter + FixedwingModel_P.Constant1_Value_d;
        }
      }

      for (s289_iter = 1; s289_iter <= s330_iter; s289_iter++) {
        real_T rtb_Gain8_tmp;
        int32_T qY_0;
        int32_T qY_1;
        int32_T rtb_Sum1_my;

        // Sum: '<S289>/Sum1' incorporates:
        //   Constant: '<S289>/Constant'

        if (FixedwingModel_P.Constant_Value_lcx < s289_iter - MAX_int32_T) {
          rtb_VectorConcatenate_a_tmp = MAX_int32_T;
        } else {
          rtb_VectorConcatenate_a_tmp = s289_iter -
            FixedwingModel_P.Constant_Value_lcx;
        }

        // Outputs for Enabled SubSystem: '<S289>/Time adjust the gauss coefficients' incorporates:
        //   EnablePort: '<S292>/Enable'

        if (rtb_RelationalOperator) {
          // Outputs for Atomic SubSystem: '<S292>/If Action Subsystem'
          // Sum: '<S318>/Sum1' incorporates:
          //   Constant: '<S318>/Constant1'
          //   Sum: '<S289>/Sum1'

          if ((rtb_VectorConcatenate_a_tmp < 0) &&
              (FixedwingModel_P.Constant1_Value_ab < MIN_int32_T
               - rtb_VectorConcatenate_a_tmp)) {
            qY_1 = MIN_int32_T;
          } else if ((rtb_VectorConcatenate_a_tmp > 0) &&
                     (FixedwingModel_P.Constant1_Value_ab > MAX_int32_T
                      - rtb_VectorConcatenate_a_tmp)) {
            qY_1 = MAX_int32_T;
          } else {
            qY_1 = rtb_VectorConcatenate_a_tmp +
              FixedwingModel_P.Constant1_Value_ab;
          }

          // Sum: '<S318>/Sum2' incorporates:
          //   Constant: '<S318>/Constant'

          if ((s281_iter < 0) && (FixedwingModel_P.Constant_Value_mq <
                                  MIN_int32_T - s281_iter)) {
            qY_0 = MIN_int32_T;
          } else if ((s281_iter > 0) && (FixedwingModel_P.Constant_Value_mq >
                      MAX_int32_T - s281_iter)) {
            qY_0 = MAX_int32_T;
          } else {
            qY_0 = s281_iter + FixedwingModel_P.Constant_Value_mq;
          }

          // End of Outputs for SubSystem: '<S292>/If Action Subsystem'

          // Assignment: '<S292>/Assignment'
          if (ForIterator_IterationMarker[4] < 2) {
            ForIterator_IterationMarker[4] = 2U;

            // Assignment: '<S292>/Assignment' incorporates:
            //   UnitDelay: '<S292>/Unit Delay'

            std::memcpy(&FixedwingModel_B.Assignment[0],
                        &FixedwingModel_DW.UnitDelay_DSTATE_i[0], 169U * sizeof
                        (real_T));
          }

          // Outputs for Atomic SubSystem: '<S292>/If Action Subsystem'
          // Selector: '<S318>/c[m][n]' incorporates:
          //   Assignment: '<S292>/Assignment'
          //   Constant: '<S292>/cd[maxdef][maxdef]'
          //   Selector: '<S318>/cd[m][n]'
          //   Sum: '<S318>/Sum1'
          //   Sum: '<S318>/Sum2'

          qY_1 = ((qY_0 - 1) * 13 + qY_1) - 1;

          // Assignment: '<S292>/Assignment' incorporates:
          //   Constant: '<S292>/c[maxdef][maxdef]'
          //   Constant: '<S292>/cd[maxdef][maxdef]'
          //   Product: '<S318>/Product'
          //   Selector: '<S318>/c[m][n]'
          //   Selector: '<S318>/cd[m][n]'
          //   Sum: '<S318>/Sum'

          FixedwingModel_B.Assignment[qY_1] =
            FixedwingModel_P.cdmaxdefmaxdef_Value[qY_1] * rtb_Sum_le +
            FixedwingModel_P.cmaxdefmaxdef_Value[qY_1];

          // End of Outputs for SubSystem: '<S292>/If Action Subsystem'

          // Switch: '<S319>/tc_old' incorporates:
          //   Constant: '<S319>/zeros(maxdef+1,maxdef+1)'
          //   UnitDelay: '<S319>/Unit Delay'

          if (s281_iter > FixedwingModel_P.tc_old_Threshold) {
            std::memcpy(&rtb_tc_old[0], &FixedwingModel_DW.UnitDelay_DSTATE_k[0],
                        169U * sizeof(real_T));
          } else {
            std::memcpy(&rtb_tc_old[0],
                        &FixedwingModel_P.zerosmaxdef1maxdef1_Value[0], 169U *
                        sizeof(real_T));
          }

          // End of Switch: '<S319>/tc_old'

          // If: '<S319>/If' incorporates:
          //   Sum: '<S289>/Sum1'

          if (rtb_VectorConcatenate_a_tmp != 0) {
            // Outputs for IfAction SubSystem: '<S319>/If Action Subsystem1' incorporates:
            //   ActionPort: '<S320>/Action Port'

            // Sum: '<S320>/Sum2' incorporates:
            //   Constant: '<S320>/Constant'

            if ((s281_iter < 0) && (FixedwingModel_P.Constant_Value_khy <
                                    MIN_int32_T - s281_iter)) {
              qY_1 = MIN_int32_T;
            } else if ((s281_iter > 0) && (FixedwingModel_P.Constant_Value_khy >
                        MAX_int32_T - s281_iter)) {
              qY_1 = MAX_int32_T;
            } else {
              qY_1 = s281_iter + FixedwingModel_P.Constant_Value_khy;
            }

            // Assignment: '<S320>/Assignment2'
            if (ForIterator_IterationMarker[5] < 2) {
              ForIterator_IterationMarker[5] = 2U;

              // Assignment: '<S320>/Assignment2' incorporates:
              //   Switch: '<S319>/tc_old'

              std::memcpy(&FixedwingModel_B.Assignment2[0], &rtb_tc_old[0], 169U
                          * sizeof(real_T));
            }

            // Selector: '<S320>/c[m][n]' incorporates:
            //   Assignment: '<S320>/Assignment2'
            //   Constant: '<S292>/cd[maxdef][maxdef]'
            //   Selector: '<S320>/cd[m][n]'
            //   Sum: '<S320>/Sum2'

            qY_1 = ((rtb_VectorConcatenate_a_tmp - 1) * 13 + qY_1) - 1;

            // Assignment: '<S320>/Assignment2' incorporates:
            //   Constant: '<S292>/c[maxdef][maxdef]'
            //   Constant: '<S292>/cd[maxdef][maxdef]'
            //   Product: '<S320>/Product'
            //   Selector: '<S320>/c[m][n]'
            //   Selector: '<S320>/cd[m][n]'
            //   Sum: '<S320>/Sum'

            FixedwingModel_B.Assignment2[qY_1] =
              FixedwingModel_P.cdmaxdefmaxdef_Value[qY_1] * rtb_Sum_le +
              FixedwingModel_P.cmaxdefmaxdef_Value[qY_1];

            // Gain: '<S320>/Gain' incorporates:
            //   Assignment: '<S320>/Assignment2'
            //   Merge: '<S319>/Merge'

            for (i = 0; i < 169; i++) {
              rtb_tc_old[i] = FixedwingModel_P.Gain_Gain_f *
                FixedwingModel_B.Assignment2[i];
            }

            // End of Gain: '<S320>/Gain'
            // End of Outputs for SubSystem: '<S319>/If Action Subsystem1'
          }

          // End of If: '<S319>/If'
          for (i = 0; i < 169; i++) {
            // Sum: '<S292>/Sum2' incorporates:
            //   Merge: '<S319>/Merge'

            rtb_Rn = rtb_tc_old[i];

            // Sum: '<S292>/Sum2' incorporates:
            //   Assignment: '<S292>/Assignment'

            FixedwingModel_B.Sum2_gf[i] = FixedwingModel_B.Assignment[i] +
              rtb_Rn;

            // Update for UnitDelay: '<S292>/Unit Delay' incorporates:
            //   Assignment: '<S292>/Assignment'

            FixedwingModel_DW.UnitDelay_DSTATE_i[i] =
              FixedwingModel_B.Assignment[i];

            // Update for UnitDelay: '<S319>/Unit Delay'
            FixedwingModel_DW.UnitDelay_DSTATE_k[i] = rtb_Rn;
          }
        }

        // End of Outputs for SubSystem: '<S289>/Time adjust the gauss coefficients' 

        // Sum: '<S295>/Sum4' incorporates:
        //   Constant: '<S295>/Constant1'
        //   Sum: '<S289>/Sum1'

        rtb_Sum_gz = static_cast<real_T>(rtb_VectorConcatenate_a_tmp) +
          FixedwingModel_P.Constant1_Value_m;

        // If: '<S295>/If' incorporates:
        //   Sum: '<S289>/Sum1'

        if (rtb_VectorConcatenate_a_tmp == 0) {
          // Outputs for IfAction SubSystem: '<S295>/If Action Subsystem' incorporates:
          //   ActionPort: '<S301>/Action Port'

          // Product: '<S301>/Product' incorporates:
          //   Constant: '<S301>/Constant'
          //   Selector: '<S301>/Selector'
          //   Sum: '<S292>/Sum2'
          //   Sum: '<S301>/Sum'

          rtb_Gain9_d = FixedwingModel_B.Sum2_gf[((static_cast<int32_T>(
            static_cast<real_T>(s281_iter) + FixedwingModel_P.Constant_Value_nn)
            - 1) * 13 + static_cast<int32_T>(FixedwingModel_P.Constant_Value_nn))
            - 1];

          // Merge: '<S295>/Merge' incorporates:
          //   Gain: '<S301>/Gain1'
          //   Product: '<S301>/Product'
          //   Selector: '<S295>/cp[m+1]'
          //   Selector: '<S301>/Selector'

          rtb_Rn = FixedwingModel_B.OutportBufferForcp13[static_cast<int32_T>
            (rtb_Sum_gz) - 1] * rtb_Gain9_d * FixedwingModel_P.Gain1_Gain;

          // Merge: '<S295>/Merge1' incorporates:
          //   Gain: '<S301>/Gain2'
          //   Product: '<S301>/Product'
          //   Selector: '<S295>/cp[m+1]'
          //   Selector: '<S295>/sp[m+1]'

          rtb_Gain9_d = FixedwingModel_B.OutportBufferForsp13
            [static_cast<int32_T>(rtb_Sum_gz) - 1] * rtb_Gain9_d *
            FixedwingModel_P.Gain2_Gain;

          // End of Outputs for SubSystem: '<S295>/If Action Subsystem'
        } else {
          // Outputs for IfAction SubSystem: '<S295>/If Action Subsystem1' incorporates:
          //   ActionPort: '<S302>/Action Port'

          // Product: '<S302>/Product' incorporates:
          //   Constant: '<S303>/Constant'
          //   Selector: '<S302>/Selector'
          //   Sum: '<S292>/Sum2'
          //   Sum: '<S303>/Sum'

          rtb_Gain9_d = FixedwingModel_B.Sum2_gf[((static_cast<int32_T>(
            static_cast<real_T>(s281_iter) + FixedwingModel_P.Constant_Value_lc)
            - 1) * 13 + static_cast<int32_T>(static_cast<real_T>
            (rtb_VectorConcatenate_a_tmp) + FixedwingModel_P.Constant_Value_lc))
            - 1];

          // Product: '<S302>/Product1' incorporates:
          //   Constant: '<S304>/Constant'
          //   Selector: '<S302>/Selector1'
          //   Sum: '<S292>/Sum2'
          //   Sum: '<S304>/Sum'

          rtb_Gain8_tmp = FixedwingModel_B.Sum2_gf[((rtb_VectorConcatenate_a_tmp
            - 1) * 13 + static_cast<int32_T>(static_cast<real_T>(s281_iter) +
            FixedwingModel_P.Constant_Value_j)) - 1];

          // Merge: '<S295>/Merge' incorporates:
          //   Product: '<S302>/Product'
          //   Product: '<S302>/Product1'
          //   Selector: '<S295>/cp[m+1]'
          //   Selector: '<S295>/sp[m+1]'
          //   Selector: '<S302>/Selector'
          //   Selector: '<S302>/Selector1'
          //   Sum: '<S302>/Sum'

          rtb_Rn = FixedwingModel_B.OutportBufferForsp13[static_cast<int32_T>
            (rtb_Sum_gz) - 1] * rtb_Gain8_tmp +
            FixedwingModel_B.OutportBufferForcp13[static_cast<int32_T>
            (rtb_Sum_gz) - 1] * rtb_Gain9_d;

          // Merge: '<S295>/Merge1' incorporates:
          //   Product: '<S302>/Product'
          //   Product: '<S302>/Product1'
          //   Selector: '<S295>/cp[m+1]'
          //   Selector: '<S295>/sp[m+1]'
          //   Sum: '<S302>/Sum1'

          rtb_Gain9_d = FixedwingModel_B.OutportBufferForsp13
            [static_cast<int32_T>(rtb_Sum_gz) - 1] * rtb_Gain9_d -
            FixedwingModel_B.OutportBufferForcp13[static_cast<int32_T>
            (rtb_Sum_gz) - 1] * rtb_Gain8_tmp;

          // End of Outputs for SubSystem: '<S295>/If Action Subsystem1'
        }

        // End of If: '<S295>/If'

        // Outputs for Enabled SubSystem: '<S289>/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations' incorporates:
        //   EnablePort: '<S291>/Enable'

        // SignalConversion generated from: '<S291>/Enable'
        if (rtb_Compare_n) {
          // If: '<S291>/if n == m elseif (n==1&m==0) elseif (n>1&m~=n)' incorporates:
          //   Sum: '<S289>/Sum1'

          if (s281_iter == rtb_VectorConcatenate_a_tmp) {
            // Outputs for IfAction SubSystem: '<S291>/If Action Subsystem' incorporates:
            //   ActionPort: '<S305>/Action Port'

            // Selector: '<S305>/Selector' incorporates:
            //   Constant: '<S309>/Constant'
            //   Gain: '<S309>/Gain'
            //   Sum: '<S309>/Sum1'
            //   Sum: '<S309>/Sum2'

            if ((rtb_VectorConcatenate_a_tmp >= 0) &&
                (FixedwingModel_P.Constant_Value_e3 <
                 rtb_VectorConcatenate_a_tmp - MAX_int32_T)) {
              qY_1 = MAX_int32_T;
            } else if ((rtb_VectorConcatenate_a_tmp < 0) &&
                       (FixedwingModel_P.Constant_Value_e3 >
                        rtb_VectorConcatenate_a_tmp - MIN_int32_T)) {
              qY_1 = MIN_int32_T;
            } else {
              qY_1 = rtb_VectorConcatenate_a_tmp -
                FixedwingModel_P.Constant_Value_e3;
            }

            i = mul_s32_sat(FixedwingModel_P.Gain_Gain_ow, qY_1);
            if ((s281_iter < 0) && (i < MIN_int32_T - s281_iter)) {
              i = MIN_int32_T;
            } else if ((s281_iter > 0) && (i > MAX_int32_T - s281_iter)) {
              i = MAX_int32_T;
            } else {
              i += s281_iter;
            }

            // Merge: '<S291>/Merge' incorporates:
            //   Product: '<S305>/Product1'
            //   Selector: '<S305>/Selector'
            //   UnitDelay: '<S291>/Unit Delay1'

            FixedwingModel_B.Merge_h = FixedwingModel_DW.UnitDelay1_DSTATE_e[i -
              1] * FixedwingModel_B.sqrt_j;

            // Selector: '<S305>/Selector' incorporates:
            //   Constant: '<S309>/Constant'
            //   Gain: '<S309>/Gain'
            //   Sum: '<S309>/Sum1'
            //   Sum: '<S309>/Sum2'

            if ((rtb_VectorConcatenate_a_tmp >= 0) &&
                (FixedwingModel_P.Constant_Value_e3 <
                 rtb_VectorConcatenate_a_tmp - MAX_int32_T)) {
              qY_1 = MAX_int32_T;
            } else if ((rtb_VectorConcatenate_a_tmp < 0) &&
                       (FixedwingModel_P.Constant_Value_e3 >
                        rtb_VectorConcatenate_a_tmp - MIN_int32_T)) {
              qY_1 = MIN_int32_T;
            } else {
              qY_1 = rtb_VectorConcatenate_a_tmp -
                FixedwingModel_P.Constant_Value_e3;
            }

            i = mul_s32_sat(FixedwingModel_P.Gain_Gain_ow, qY_1);
            if ((s281_iter < 0) && (i < MIN_int32_T - s281_iter)) {
              i = MIN_int32_T;
            } else if ((s281_iter > 0) && (i > MAX_int32_T - s281_iter)) {
              i = MAX_int32_T;
            } else {
              i += s281_iter;
            }

            // Merge: '<S291>/Merge1' incorporates:
            //   Product: '<S305>/Product'
            //   Product: '<S305>/Product2'
            //   Selector: '<S305>/Selector'
            //   Selector: '<S305>/Selector1'
            //   Sum: '<S305>/Sum'
            //   UnitDelay: '<S291>/Unit Delay'
            //   UnitDelay: '<S291>/Unit Delay1'

            FixedwingModel_B.Merge1_o = FixedwingModel_DW.UnitDelay_DSTATE_h
              [((s281_iter - 1) * 13 + rtb_VectorConcatenate_a_tmp) - 1] *
              FixedwingModel_B.sqrt_j + FixedwingModel_DW.UnitDelay1_DSTATE_e[i
              - 1] * FixedwingModel_B.Product4_a;

            // End of Outputs for SubSystem: '<S291>/If Action Subsystem'
          } else if ((s281_iter == 1) && (rtb_VectorConcatenate_a_tmp == 0)) {
            // Outputs for IfAction SubSystem: '<S291>/If Action Subsystem1' incorporates:
            //   ActionPort: '<S306>/Action Port'

            // Selector: '<S306>/Selector' incorporates:
            //   Gain: '<S311>/Gain'
            //   Sum: '<S311>/Sum1'

            qY_1 = mul_s32_sat(FixedwingModel_P.Gain_Gain_kt, 0);
            if (qY_1 > 2147483646) {
              i = MAX_int32_T;
            } else {
              i = qY_1 + 1;
            }

            // Merge: '<S291>/Merge' incorporates:
            //   Product: '<S306>/Product3'
            //   Selector: '<S306>/Selector'
            //   UnitDelay: '<S291>/Unit Delay1'

            FixedwingModel_B.Merge_h = FixedwingModel_DW.UnitDelay1_DSTATE_e[i -
              1] * FixedwingModel_B.Product4_a;

            // Selector: '<S306>/Selector' incorporates:
            //   Sum: '<S311>/Sum1'

            if (qY_1 > 2147483646) {
              i = MAX_int32_T;
            } else {
              i = qY_1 + 1;
            }

            // Merge: '<S291>/Merge1' incorporates:
            //   Constant: '<S312>/Constant'
            //   Product: '<S306>/Product'
            //   Product: '<S306>/Product2'
            //   Selector: '<S306>/Selector'
            //   Selector: '<S306>/Selector1'
            //   Sum: '<S306>/Sum'
            //   UnitDelay: '<S291>/Unit Delay'
            //   UnitDelay: '<S291>/Unit Delay1'

            FixedwingModel_B.Merge1_o =
              FixedwingModel_DW.UnitDelay_DSTATE_h[FixedwingModel_P.Constant_Value_p
              - 1] * FixedwingModel_B.Product4_a -
              FixedwingModel_DW.UnitDelay1_DSTATE_e[i - 1] *
              FixedwingModel_B.sqrt_j;

            // End of Outputs for SubSystem: '<S291>/If Action Subsystem1'
          } else if ((s281_iter > 1) && (s281_iter !=
                      rtb_VectorConcatenate_a_tmp)) {
            int32_T qY_2;

            // Outputs for IfAction SubSystem: '<S291>/If Action Subsystem2' incorporates:
            //   ActionPort: '<S307>/Action Port'

            // Sum: '<S314>/Sum' incorporates:
            //   Constant: '<S314>/Constant'

            if (FixedwingModel_P.Constant_Value_kw > MAX_int32_T - s281_iter) {
              qY_1 = MAX_int32_T;
            } else {
              qY_1 = s281_iter + FixedwingModel_P.Constant_Value_kw;
            }

            if ((rtb_VectorConcatenate_a_tmp < 0) &&
                (FixedwingModel_P.Constant_Value_kw < MIN_int32_T
                 - rtb_VectorConcatenate_a_tmp)) {
              qY_0 = MIN_int32_T;
            } else if ((rtb_VectorConcatenate_a_tmp > 0) &&
                       (FixedwingModel_P.Constant_Value_kw > MAX_int32_T
                        - rtb_VectorConcatenate_a_tmp)) {
              qY_0 = MAX_int32_T;
            } else {
              qY_0 = rtb_VectorConcatenate_a_tmp +
                FixedwingModel_P.Constant_Value_kw;
            }

            // Gain: '<S313>/Gain'
            rtb_Sum1_my = mul_s32_sat(FixedwingModel_P.Gain_Gain_ai,
              rtb_VectorConcatenate_a_tmp);

            // Sum: '<S316>/Sum2' incorporates:
            //   Constant: '<S316>/Constant1'

            if (FixedwingModel_P.Constant1_Value_a < s281_iter - MAX_int32_T) {
              i = MAX_int32_T;
            } else {
              i = s281_iter - FixedwingModel_P.Constant1_Value_a;
            }

            // End of Sum: '<S316>/Sum2'

            // Switch: '<S307>/Switch' incorporates:
            //   Constant: '<S307>/Constant'
            //   RelationalOperator: '<S316>/Relational Operator'
            //   Selector: '<S307>/Selector1'
            //   UnitDelay: '<S291>/Unit Delay'

            if (i >= rtb_VectorConcatenate_a_tmp) {
              // Sum: '<S315>/Sum' incorporates:
              //   Constant: '<S315>/Constant'

              if ((rtb_VectorConcatenate_a_tmp < 0) &&
                  (FixedwingModel_P.Constant_Value_b4 < MIN_int32_T
                   - rtb_VectorConcatenate_a_tmp)) {
                qY_2 = MIN_int32_T;
              } else if ((rtb_VectorConcatenate_a_tmp > 0) &&
                         (FixedwingModel_P.Constant_Value_b4 > MAX_int32_T
                          - rtb_VectorConcatenate_a_tmp)) {
                qY_2 = MAX_int32_T;
              } else {
                qY_2 = rtb_VectorConcatenate_a_tmp +
                  FixedwingModel_P.Constant_Value_b4;
              }

              // Selector: '<S307>/Selector1' incorporates:
              //   Constant: '<S315>/Constant1'
              //   Sum: '<S315>/Sum2'

              if (FixedwingModel_P.Constant1_Value_e < s281_iter - MAX_int32_T)
              {
                i = MAX_int32_T;
              } else {
                i = s281_iter - FixedwingModel_P.Constant1_Value_e;
              }

              rtb_Sum_gz = FixedwingModel_DW.UnitDelay_DSTATE_h[((i - 1) * 13 +
                qY_2) - 1];
            } else {
              rtb_Sum_gz = FixedwingModel_P.Constant_Value_i;
            }

            // End of Switch: '<S307>/Switch'

            // Sum: '<S315>/Sum' incorporates:
            //   Constant: '<S315>/Constant'

            if ((rtb_VectorConcatenate_a_tmp < 0) &&
                (FixedwingModel_P.Constant_Value_b4 < MIN_int32_T
                 - rtb_VectorConcatenate_a_tmp)) {
              qY_2 = MIN_int32_T;
            } else if ((rtb_VectorConcatenate_a_tmp > 0) &&
                       (FixedwingModel_P.Constant_Value_b4 > MAX_int32_T
                        - rtb_VectorConcatenate_a_tmp)) {
              qY_2 = MAX_int32_T;
            } else {
              qY_2 = rtb_VectorConcatenate_a_tmp +
                FixedwingModel_P.Constant_Value_b4;
            }

            // Selector: '<S307>/Selector' incorporates:
            //   Sum: '<S313>/Sum1'

            if (rtb_Sum1_my > MAX_int32_T - s281_iter) {
              i = MAX_int32_T;
            } else {
              i = s281_iter + rtb_Sum1_my;
            }

            // Selector: '<S307>/Selector2' incorporates:
            //   Constant: '<S307>/k[13][13]'
            //   Sum: '<S314>/Sum'

            rtb_Gain8_tmp = FixedwingModel_P.k1313_Value_c[((qY_1 - 1) * 13 +
              qY_0) - 1];

            // Merge: '<S291>/Merge1' incorporates:
            //   Constant: '<S307>/k[13][13]'
            //   Product: '<S307>/Product'
            //   Product: '<S307>/Product1'
            //   Product: '<S307>/Product4'
            //   Selector: '<S307>/Selector'
            //   Selector: '<S307>/Selector1'
            //   Selector: '<S307>/Selector2'
            //   Sum: '<S307>/Sum'
            //   UnitDelay: '<S291>/Unit Delay'
            //   UnitDelay: '<S291>/Unit Delay1'

            FixedwingModel_B.Merge1_o = (FixedwingModel_DW.UnitDelay_DSTATE_h
              [((s281_iter - 1) * 13 + qY_2) - 1] * FixedwingModel_B.Product4_a
              - FixedwingModel_DW.UnitDelay1_DSTATE_e[i - 1] *
              FixedwingModel_B.sqrt_j) - rtb_Gain8_tmp * rtb_Sum_gz;

            // Sum: '<S317>/Sum2' incorporates:
            //   Constant: '<S317>/Constant1'

            if (FixedwingModel_P.Constant1_Value_ck < s281_iter - MAX_int32_T) {
              i = MAX_int32_T;
            } else {
              i = s281_iter - FixedwingModel_P.Constant1_Value_ck;
            }

            // End of Sum: '<S317>/Sum2'

            // Switch: '<S307>/Switch1' incorporates:
            //   Constant: '<S307>/Constant1'
            //   RelationalOperator: '<S317>/Relational Operator'
            //   Selector: '<S307>/Selector'
            //   UnitDelay: '<S291>/Unit Delay1'

            if (i >= rtb_VectorConcatenate_a_tmp) {
              // Selector: '<S307>/Selector' incorporates:
              //   Constant: '<S313>/Constant1'
              //   Sum: '<S313>/Sum1'
              //   Sum: '<S313>/Sum2'

              if (FixedwingModel_P.Constant1_Value_oh < s281_iter - MAX_int32_T)
              {
                qY_1 = MAX_int32_T;
              } else {
                qY_1 = s281_iter - FixedwingModel_P.Constant1_Value_oh;
              }

              if ((qY_1 < 0) && (rtb_Sum1_my < MIN_int32_T - qY_1)) {
                qY_1 = MIN_int32_T;
              } else if ((qY_1 > 0) && (rtb_Sum1_my > MAX_int32_T - qY_1)) {
                qY_1 = MAX_int32_T;
              } else {
                qY_1 += rtb_Sum1_my;
              }

              rtb_Sum_gz = FixedwingModel_DW.UnitDelay1_DSTATE_e[qY_1 - 1];
            } else {
              rtb_Sum_gz = FixedwingModel_P.Constant1_Value_l;
            }

            // End of Switch: '<S307>/Switch1'

            // Selector: '<S307>/Selector' incorporates:
            //   Sum: '<S313>/Sum1'

            if (rtb_Sum1_my > MAX_int32_T - s281_iter) {
              rtb_Sum1_my = MAX_int32_T;
            } else {
              rtb_Sum1_my += s281_iter;
            }

            // Merge: '<S291>/Merge' incorporates:
            //   Product: '<S307>/Product2'
            //   Product: '<S307>/Product3'
            //   Selector: '<S307>/Selector'
            //   Sum: '<S307>/Sum1'
            //   UnitDelay: '<S291>/Unit Delay1'

            FixedwingModel_B.Merge_h =
              FixedwingModel_DW.UnitDelay1_DSTATE_e[rtb_Sum1_my - 1] *
              FixedwingModel_B.Product4_a - rtb_Gain8_tmp * rtb_Sum_gz;

            // End of Outputs for SubSystem: '<S291>/If Action Subsystem2'
          }

          // End of If: '<S291>/if n == m elseif (n==1&m==0) elseif (n>1&m~=n)'

          // Sum: '<S291>/Sum' incorporates:
          //   Constant: '<S291>/Constant'
          //   Sum: '<S289>/Sum1'

          if ((s281_iter < 0) && (FixedwingModel_P.Constant_Value_o5 <
                                  MIN_int32_T - s281_iter)) {
            qY_1 = MIN_int32_T;
          } else if ((s281_iter > 0) && (FixedwingModel_P.Constant_Value_o5 >
                      MAX_int32_T - s281_iter)) {
            qY_1 = MAX_int32_T;
          } else {
            qY_1 = s281_iter + FixedwingModel_P.Constant_Value_o5;
          }

          if ((rtb_VectorConcatenate_a_tmp < 0) &&
              (FixedwingModel_P.Constant_Value_o5 < MIN_int32_T
               - rtb_VectorConcatenate_a_tmp)) {
            qY_0 = MIN_int32_T;
          } else if ((rtb_VectorConcatenate_a_tmp > 0) &&
                     (FixedwingModel_P.Constant_Value_o5 > MAX_int32_T
                      - rtb_VectorConcatenate_a_tmp)) {
            qY_0 = MAX_int32_T;
          } else {
            qY_0 = rtb_VectorConcatenate_a_tmp +
              FixedwingModel_P.Constant_Value_o5;
          }

          // Assignment: '<S291>/Assignment' incorporates:
          //   Sum: '<S291>/Sum'
          //   UnitDelay: '<S291>/Unit Delay'

          if (ForIterator_IterationMarker[2] < 2) {
            ForIterator_IterationMarker[2] = 2U;
            std::memcpy(&FixedwingModel_B.Assignment_p[0],
                        &FixedwingModel_DW.UnitDelay_DSTATE_h[0], 169U * sizeof
                        (real_T));
          }

          FixedwingModel_B.Assignment_p[(qY_0 + 13 * (qY_1 - 1)) - 1] =
            FixedwingModel_B.Merge1_o;

          // End of Assignment: '<S291>/Assignment'

          // Assignment: '<S291>/Assignment_snorm'
          if (ForIterator_IterationMarker[3] < 2) {
            ForIterator_IterationMarker[3] = 2U;

            // Assignment: '<S291>/Assignment_snorm' incorporates:
            //   UnitDelay: '<S291>/Unit Delay1'

            std::memcpy(&FixedwingModel_B.Assignment_snorm[0],
                        &FixedwingModel_DW.UnitDelay1_DSTATE_e[0], 169U * sizeof
                        (real_T));
          }

          // Sum: '<S308>/Sum2' incorporates:
          //   Constant: '<S308>/Constant'
          //   Sum: '<S291>/Sum'

          if ((qY_0 >= 0) && (FixedwingModel_P.Constant_Value_kn < qY_0 -
                              MAX_int32_T)) {
            qY_0 = MAX_int32_T;
          } else if ((qY_0 < 0) && (FixedwingModel_P.Constant_Value_kn > qY_0 -
                      MIN_int32_T)) {
            qY_0 = MIN_int32_T;
          } else {
            qY_0 -= FixedwingModel_P.Constant_Value_kn;
          }

          // End of Sum: '<S308>/Sum2'

          // Sum: '<S308>/Sum1' incorporates:
          //   Gain: '<S308>/Gain'
          //   Sum: '<S291>/Sum'

          i = mul_s32_sat(FixedwingModel_P.Gain_Gain_ag, qY_0);
          if ((qY_1 < 0) && (i < MIN_int32_T - qY_1)) {
            qY_1 = MIN_int32_T;
          } else if ((qY_1 > 0) && (i > MAX_int32_T - qY_1)) {
            qY_1 = MAX_int32_T;
          } else {
            qY_1 += i;
          }

          // End of Sum: '<S308>/Sum1'

          // Assignment: '<S291>/Assignment_snorm'
          FixedwingModel_B.Assignment_snorm[qY_1 - 1] = FixedwingModel_B.Merge_h;

          // Update for UnitDelay: '<S291>/Unit Delay' incorporates:
          //   Assignment: '<S291>/Assignment'

          std::memcpy(&FixedwingModel_DW.UnitDelay_DSTATE_h[0],
                      &FixedwingModel_B.Assignment_p[0], 169U * sizeof(real_T));

          // Update for UnitDelay: '<S291>/Unit Delay1'
          std::memcpy(&FixedwingModel_DW.UnitDelay1_DSTATE_e[0],
                      &FixedwingModel_B.Assignment_snorm[0], 169U * sizeof
                      (real_T));
        }

        // End of SignalConversion generated from: '<S291>/Enable'
        // End of Outputs for SubSystem: '<S289>/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations' 

        // Selector: '<S290>/snorm[n+m*13]' incorporates:
        //   Gain: '<S294>/Gain'
        //   Sum: '<S289>/Sum1'
        //   Sum: '<S294>/Sum1'

        i = mul_s32_sat(FixedwingModel_P.Gain_Gain_jb,
                        rtb_VectorConcatenate_a_tmp);
        if ((qY < 0) && (i < MIN_int32_T - qY)) {
          qY_1 = MIN_int32_T;
        } else if ((qY > 0) && (i > MAX_int32_T - qY)) {
          qY_1 = MAX_int32_T;
        } else {
          qY_1 = qY + i;
        }

        // Product: '<S290>/par' incorporates:
        //   Selector: '<S290>/snorm[n+m*13]'

        rtb_Sum_gz = FixedwingModel_B.Assignment_snorm[qY_1 - 1] *
          rtb_rgw_p_idx_0;

        // Outputs for Enabled SubSystem: '<S290>/Special case - North//South Geographic Pole' incorporates:
        //   EnablePort: '<S293>/Enable'

        // Logic: '<S296>/Logical Operator' incorporates:
        //   Constant: '<S296>/Constant'
        //   Constant: '<S296>/Constant1'
        //   RelationalOperator: '<S296>/Relational Operator'
        //   RelationalOperator: '<S296>/Relational Operator1'
        //   Sum: '<S289>/Sum1'

        if ((FixedwingModel_B.sqrt_j == FixedwingModel_P.Constant1_Value_b) &&
            (FixedwingModel_P.Constant_Value_mw == rtb_VectorConcatenate_a_tmp))
        {
          FixedwingModel_DW.SpecialcaseNorthSouthGeographic = true;

          // If: '<S293>/n ==1' incorporates:
          //   Assignment: '<S298>/Assignment2'

          if (s281_iter == 1) {
            // Outputs for IfAction SubSystem: '<S293>/If Action Subsystem1' incorporates:
            //   ActionPort: '<S297>/Action Port'

            // Assignment: '<S297>/Assignment2' incorporates:
            //   Constant: '<S297>/Constant'
            //   Selector: '<S297>/pp[n-1]'
            //   Sum: '<S297>/Sum2'
            //   UnitDelay: '<S293>/Unit Delay1'

            if (ForIterator_IterationMarker[0] < 2) {
              ForIterator_IterationMarker[0] = 2U;
              std::memcpy(&FixedwingModel_B.Assignment2_c[0],
                          &FixedwingModel_DW.UnitDelay1_DSTATE_h[0], 13U *
                          sizeof(real_T));
            }

            FixedwingModel_B.Assignment2_c[static_cast<int32_T>
              (FixedwingModel_P.Constant_Value_m + 1.0) - 1] =
              FixedwingModel_DW.UnitDelay1_DSTATE_h[0];

            // End of Assignment: '<S297>/Assignment2'
            // End of Outputs for SubSystem: '<S293>/If Action Subsystem1'
          } else {
            // Outputs for IfAction SubSystem: '<S293>/If Action Subsystem2' incorporates:
            //   ActionPort: '<S298>/Action Port'

            if (ForIterator_IterationMarker[1] < 2) {
              // Assignment: '<S298>/Assignment2'
              ForIterator_IterationMarker[1] = 2U;

              // Assignment: '<S298>/Assignment2' incorporates:
              //   UnitDelay: '<S293>/Unit Delay1'

              std::memcpy(&FixedwingModel_B.Assignment2_g[0],
                          &FixedwingModel_DW.UnitDelay1_DSTATE_h[0], 13U *
                          sizeof(real_T));
            }

            // Sum: '<S298>/Sum2' incorporates:
            //   Constant: '<S298>/Constant'

            if ((s281_iter < 0) && (FixedwingModel_P.Constant_Value_ce <
                                    MIN_int32_T - s281_iter)) {
              i = MIN_int32_T;
            } else if ((s281_iter > 0) && (FixedwingModel_P.Constant_Value_ce >
                        MAX_int32_T - s281_iter)) {
              i = MAX_int32_T;
            } else {
              i = s281_iter + FixedwingModel_P.Constant_Value_ce;
            }

            // End of Sum: '<S298>/Sum2'

            // Sum: '<S300>/Sum' incorporates:
            //   Constant: '<S300>/Constant'

            if ((rtb_VectorConcatenate_a_tmp < 0) &&
                (FixedwingModel_P.Constant_Value_mb < MIN_int32_T
                 - rtb_VectorConcatenate_a_tmp)) {
              qY_1 = MIN_int32_T;
            } else if ((rtb_VectorConcatenate_a_tmp > 0) &&
                       (FixedwingModel_P.Constant_Value_mb > MAX_int32_T
                        - rtb_VectorConcatenate_a_tmp)) {
              qY_1 = MAX_int32_T;
            } else {
              qY_1 = rtb_VectorConcatenate_a_tmp +
                FixedwingModel_P.Constant_Value_mb;
            }

            if ((s281_iter < 0) && (FixedwingModel_P.Constant_Value_mb <
                                    MIN_int32_T - s281_iter)) {
              qY_0 = MIN_int32_T;
            } else if ((s281_iter > 0) && (FixedwingModel_P.Constant_Value_mb >
                        MAX_int32_T - s281_iter)) {
              qY_0 = MAX_int32_T;
            } else {
              qY_0 = s281_iter + FixedwingModel_P.Constant_Value_mb;
            }

            // End of Sum: '<S300>/Sum'

            // Selector: '<S298>/pp[n-2] pp[n-1]' incorporates:
            //   Constant: '<S299>/Constant1'
            //   Sum: '<S299>/Sum2'

            if ((s281_iter >= 0) && (FixedwingModel_P.Constant1_Value_kv <
                 s281_iter - MAX_int32_T)) {
              rtb_Sum1_my = MAX_int32_T;
            } else if ((s281_iter < 0) && (FixedwingModel_P.Constant1_Value_kv >
                        s281_iter - MIN_int32_T)) {
              rtb_Sum1_my = MIN_int32_T;
            } else {
              rtb_Sum1_my = s281_iter - FixedwingModel_P.Constant1_Value_kv;
            }

            // Assignment: '<S298>/Assignment2' incorporates:
            //   Constant: '<S298>/k[13][13]'
            //   Product: '<S298>/Product1'
            //   Product: '<S298>/Product2'
            //   Selector: '<S298>/Selector2'
            //   Selector: '<S298>/pp[n-2] pp[n-1]'
            //   Sum: '<S298>/Sum1'
            //   UnitDelay: '<S293>/Unit Delay1'

            FixedwingModel_B.Assignment2_g[i - 1] =
              FixedwingModel_DW.UnitDelay1_DSTATE_h[s281_iter - 1] *
              FixedwingModel_B.Product4_a - FixedwingModel_P.k1313_Value[((qY_0
              - 1) * 13 + qY_1) - 1] *
              FixedwingModel_DW.UnitDelay1_DSTATE_h[rtb_Sum1_my - 1];

            // End of Outputs for SubSystem: '<S293>/If Action Subsystem2'
          }

          // End of If: '<S293>/n ==1'

          // SignalConversion generated from: '<S293>/pp[n]' incorporates:
          //   UnitDelay: '<S293>/Unit Delay1'

          rtb_TmpSignalConversionAtppnInp[0] =
            FixedwingModel_DW.UnitDelay1_DSTATE_h[0];
          rtb_TmpSignalConversionAtppnInp[1] = FixedwingModel_B.Assignment2_c[1];
          std::memcpy(&rtb_TmpSignalConversionAtppnInp[2],
                      &FixedwingModel_B.Assignment2_g[2], 11U * sizeof(real_T));

          // Product: '<S293>/Product2' incorporates:
          //   Constant: '<S293>/Constant'
          //   Constant: '<S293>/Constant1'
          //   Selector: '<S293>/pp[n]'
          //   Sum: '<S293>/Sum2'

          FixedwingModel_B.Product2_h = rtb_TmpSignalConversionAtppnInp[
            static_cast<int32_T>(static_cast<real_T>(s281_iter) +
            FixedwingModel_P.Constant1_Value_f) - 1] * rtb_rgw_p_idx_0 *
            FixedwingModel_P.Constant_Value_n * rtb_Gain9_d;

          // Update for UnitDelay: '<S293>/Unit Delay1'
          std::memcpy(&FixedwingModel_DW.UnitDelay1_DSTATE_h[0],
                      &rtb_TmpSignalConversionAtppnInp[0], 13U * sizeof(real_T));
        } else if (FixedwingModel_DW.SpecialcaseNorthSouthGeographic) {
          // Disable for Product: '<S293>/Product2' incorporates:
          //   Outport: '<S293>/bpp'

          FixedwingModel_B.Product2_h = FixedwingModel_P.bpp_Y0;
          FixedwingModel_DW.SpecialcaseNorthSouthGeographic = false;
        }

        // End of Logic: '<S296>/Logical Operator'
        // End of Outputs for SubSystem: '<S290>/Special case - North//South Geographic Pole' 

        // Sum: '<S290>/Sum' incorporates:
        //   Constant: '<S290>/Constant'
        //   Sum: '<S289>/Sum1'

        if ((rtb_VectorConcatenate_a_tmp < 0) &&
            (FixedwingModel_P.Constant_Value_ct < MIN_int32_T
             - rtb_VectorConcatenate_a_tmp)) {
          qY_1 = MIN_int32_T;
        } else if ((rtb_VectorConcatenate_a_tmp > 0) &&
                   (FixedwingModel_P.Constant_Value_ct > MAX_int32_T
                    - rtb_VectorConcatenate_a_tmp)) {
          qY_1 = MAX_int32_T;
        } else {
          qY_1 = rtb_VectorConcatenate_a_tmp +
            FixedwingModel_P.Constant_Value_ct;
        }

        // Sum: '<S290>/Sum1' incorporates:
        //   Assignment: '<S291>/Assignment'
        //   Product: '<S290>/Product'
        //   Selector: '<S290>/dp[n][m]'
        //   UnitDelay: '<S290>/Unit Delay1'

        FixedwingModel_B.Sum1_m = rtb_UniformRandomNumber4_j -
          FixedwingModel_B.Assignment_p[((s281_iter_0 - 1) * 13 + qY_1) - 1] *
          rtb_Rn * rtb_rgw_p_idx_0;

        // Sum: '<S290>/Sum4' incorporates:
        //   Constant: '<S290>/Constant1'
        //   Sum: '<S289>/Sum1'

        if ((rtb_VectorConcatenate_a_tmp < 0) &&
            (FixedwingModel_P.Constant1_Value_d < MIN_int32_T
             - rtb_VectorConcatenate_a_tmp)) {
          rtb_VectorConcatenate_a_tmp = MIN_int32_T;
        } else if ((rtb_VectorConcatenate_a_tmp > 0) &&
                   (FixedwingModel_P.Constant1_Value_d > MAX_int32_T
                    - rtb_VectorConcatenate_a_tmp)) {
          rtb_VectorConcatenate_a_tmp = MAX_int32_T;
        } else {
          rtb_VectorConcatenate_a_tmp += FixedwingModel_P.Constant1_Value_d;
        }

        // Sum: '<S290>/Sum2' incorporates:
        //   Constant: '<S290>/fm'
        //   Product: '<S290>/Product1'
        //   Selector: '<S290>/fm[m]'
        //   UnitDelay: '<S290>/Unit Delay3'

        FixedwingModel_B.Sum2_h =
          FixedwingModel_P.fm_Value[rtb_VectorConcatenate_a_tmp - 1] *
          rtb_Sum_gz * rtb_Gain9_d + rtb_jxi_d;

        // Sum: '<S290>/Sum3' incorporates:
        //   Constant: '<S290>/fn'
        //   Product: '<S290>/Product2'
        //   Selector: '<S290>/fn[m]'
        //   UnitDelay: '<S290>/Unit Delay2'

        FixedwingModel_B.Sum3 = FixedwingModel_P.fn_Value[s281_iter_1 - 1] *
          rtb_Sum_gz * rtb_Rn + Sum_l;

        // Sum: '<S290>/Sum5' incorporates:
        //   UnitDelay: '<S290>/Unit Delay4'

        FixedwingModel_B.Sum5 = rtb_rgw_p_idx_1 + FixedwingModel_B.Product2_h;

        // Update for UnitDelay: '<S290>/Unit Delay1'
        rtb_UniformRandomNumber4_j = FixedwingModel_B.Sum1_m;

        // Update for UnitDelay: '<S290>/Unit Delay3'
        rtb_jxi_d = FixedwingModel_B.Sum2_h;

        // Update for UnitDelay: '<S290>/Unit Delay2'
        Sum_l = FixedwingModel_B.Sum3;

        // Update for UnitDelay: '<S290>/Unit Delay4'
        rtb_rgw_p_idx_1 = FixedwingModel_B.Sum5;
      }

      // End of Outputs for SubSystem: '<S281>/For Iterator Subsystem'

      // Sum: '<S281>/Sum1' incorporates:
      //   UnitDelay: '<S281>/Unit Delay2'

      FixedwingModel_B.Sum1_k[0] = rtb_WhiteNoise_l_idx_0 +
        FixedwingModel_B.Sum1_m;
      FixedwingModel_B.Sum1_k[1] = rtb_WhiteNoise_l_idx_1 +
        FixedwingModel_B.Sum2_h;
      FixedwingModel_B.Sum1_k[2] = rtb_WhiteNoise_l_idx_2 +
        FixedwingModel_B.Sum3;
      FixedwingModel_B.Sum1_k[3] = rtb_WhiteNoise_l_idx_3 +
        FixedwingModel_B.Sum5;

      // Update for UnitDelay: '<S281>/Unit Delay'
      rtb_Sum_gz = rtb_rgw_p_idx_0;

      // Update for UnitDelay: '<S281>/Unit Delay2'
      rtb_WhiteNoise_l_idx_0 = FixedwingModel_B.Sum1_k[0];
      rtb_WhiteNoise_l_idx_1 = FixedwingModel_B.Sum1_k[1];
      rtb_WhiteNoise_l_idx_2 = FixedwingModel_B.Sum1_k[2];
      rtb_WhiteNoise_l_idx_3 = FixedwingModel_B.Sum1_k[3];
    }

    // End of Outputs for SubSystem: '<S273>/Compute magnetic vector in spherical coordinates' 
  }

  // Switch: '<S333>/Switch' incorporates:
  //   Product: '<S333>/Product'

  if (FixedwingModel_B.sqrt_j != 0.0) {
    rtb_Sum_gz = FixedwingModel_B.Sum1_k[1] / FixedwingModel_B.sqrt_j;
  } else {
    rtb_Sum_gz = FixedwingModel_B.Sum1_k[3];
  }

  // End of Switch: '<S333>/Switch'

  // Product: '<S332>/Product4'
  rtb_UniformRandomNumber4_j = FixedwingModel_B.Sum1_k[2] *
    FixedwingModel_B.Product12;

  // Sum: '<S332>/Sum1' incorporates:
  //   Product: '<S332>/Product1'

  rtb_jxi_d = (0.0 - FixedwingModel_B.Product11 * FixedwingModel_B.Sum1_k[0]) -
    rtb_UniformRandomNumber4_j;

  // Trigonometry: '<S335>/Trigonometric Function1'
  rtb_UniformRandomNumber4_j = rt_atan2d_snf(rtb_Sum_gz, rtb_jxi_d);

  // Sum: '<S334>/Sum1' incorporates:
  //   Product: '<S334>/Product1'
  //   Product: '<S334>/Product4'

  // Unit Conversion - from: rad to: deg
  // Expression: output = (57.2958*input) + (0)
  rtb_Rn = FixedwingModel_B.Product12 * FixedwingModel_B.Sum1_k[0] -
    FixedwingModel_B.Sum1_k[2] * FixedwingModel_B.Product11;

  // Sum: '<S335>/Sum' incorporates:
  //   Product: '<S335>/Product'
  //   Product: '<S335>/Product1'

  rtb_Sum_gz = rtb_Sum_gz * rtb_Sum_gz + rtb_jxi_d * rtb_jxi_d;

  // UnitConversion: '<S274>/Unit Conversion' incorporates:
  //   Sqrt: '<S335>/sqrt1'
  //   Trigonometry: '<S335>/Trigonometric Function'
  //   UnitConversion: '<S336>/Unit Conversion'
  //   UnitConversion: '<S337>/Unit Conversion'

  // Unit Conversion - from: rad to: deg
  // Expression: output = (57.2958*input) + (0)
  // Unit Conversion - from: deg to: rad
  // Expression: output = (0.0174533*input) + (0)
  rtb_rgw_p_idx_0 = 57.295779513082323 * rtb_UniformRandomNumber4_j *
    0.017453292519943295;
  rtb_rgw_p_idx_1 = 57.295779513082323 * rt_atan2d_snf(rtb_Rn, std::sqrt
    (rtb_Sum_gz)) * 0.017453292519943295;

  // Sqrt: '<S335>/sqrt' incorporates:
  //   Product: '<S335>/Product2'
  //   Sum: '<S335>/Sum1'

  rtb_Sum_gz = std::sqrt(rtb_Rn * rtb_Rn + rtb_Sum_gz);

  // Product: '<S267>/h1' incorporates:
  //   Trigonometry: '<S267>/sincos'

  rtb_jxi_d = std::cos(rtb_rgw_p_idx_1) * rtb_Sum_gz;

  // Product: '<S267>/x1' incorporates:
  //   Trigonometry: '<S267>/sincos'

  rtb_UniformRandomNumber4_j = std::cos(rtb_rgw_p_idx_0) * rtb_jxi_d;
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[2] == 0) {
    // Gain: '<S226>/Gain11' incorporates:
    //   UniformRandomNumber: '<S226>/Uniform Random Number7'

    FixedwingModel_B.Gain11[0] = FixedwingModel_P.Gain11_Gain *
      FixedwingModel_DW.UniformRandomNumber7_NextOutput[0];
    FixedwingModel_B.Gain11[1] = FixedwingModel_P.Gain11_Gain *
      FixedwingModel_DW.UniformRandomNumber7_NextOutput[1];
    FixedwingModel_B.Gain11[2] = FixedwingModel_P.Gain11_Gain *
      FixedwingModel_DW.UniformRandomNumber7_NextOutput[2];
  }

  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // MATLAB Function: '<S226>/FaultParamsExtract2' incorporates:
    //   Constant: '<S226>/FaultID2'
    //   Inport: '<Root>/inSILInts'

    // MATLAB Function 'SensorFault/FaultParamsExtract2': '<S231>:1'
    // '<S231>:1:5' if isempty(hFault)
    // '<S231>:1:8' if isempty(fParam)
    // '<S231>:1:12' hFaultTmp=false;
    rtb_Compare_n = false;

    // '<S231>:1:13' fParamTmp=zeros(20,1);
    std::memset(&fParamTmp[0], 0, 20U * sizeof(real_T));

    // '<S231>:1:14' j=1;
    rtb_Rn = 1.0;

    // '<S231>:1:15' for i=1:8
    for (s281_iter = 0; s281_iter < 8; s281_iter++) {
      // '<S231>:1:16' if inInts(i) == FaultID
      if (FixedwingModel_U.inSILInts[s281_iter] ==
          FixedwingModel_P.FaultID2_Value) {
        // '<S231>:1:17' hFaultTmp=true;
        rtb_Compare_n = true;

        // '<S231>:1:18' fParamTmp(2*j-1)=inFloats(2*i-1);
        s289_iter = (s281_iter + 1) << 1;
        fParamTmp[static_cast<int32_T>(2.0 * rtb_Rn - 1.0) - 1] =
          inSILFloats[s289_iter - 2];

        // '<S231>:1:19' fParamTmp(2*j)=inFloats(2*i);
        fParamTmp[static_cast<int32_T>(2.0 * rtb_Rn) - 1] =
          inSILFloats[s289_iter - 1];

        // '<S231>:1:20' j=j+1;
        rtb_Rn++;
      }
    }

    // '<S231>:1:23' if hFaultTmp
    if (rtb_Compare_n) {
      // '<S231>:1:24' hFault=hFaultTmp;
      FixedwingModel_DW.hFault_j = true;

      // '<S231>:1:25' fParamTmp(17:20) = inFloats(17:20);
      fParamTmp[16] = inSILFloats[16];
      fParamTmp[17] = inSILFloats[17];
      fParamTmp[18] = inSILFloats[18];
      fParamTmp[19] = inSILFloats[19];

      // '<S231>:1:26' fParam=fParamTmp;
      std::memcpy(&FixedwingModel_DW.fParam_g[0], &fParamTmp[0], 20U * sizeof
                  (real_T));
    }

    // MATLAB Function: '<S237>/Acc NoiseFun' incorporates:
    //   MATLAB Function: '<S226>/FaultParamsExtract2'

    // '<S231>:1:29' hasFault_mag=hFault;
    // '<S231>:1:30' FaultParam=fParam;
    FixedwingModel_AccNoiseFun(FixedwingModel_B.Gain11,
      FixedwingModel_DW.hFault_j, FixedwingModel_DW.fParam_g,
      &FixedwingModel_B.sf_AccNoiseFun_e);
  }

  // SignalConversion generated from: '<S226>/Matrix Multiply2' incorporates:
  //   Product: '<S267>/y1'
  //   Product: '<S267>/z1'
  //   Trigonometry: '<S267>/sincos'

  rtb_sincos_o1_idx_0 = std::sin(rtb_rgw_p_idx_0) * rtb_jxi_d;
  rtb_rgw_p_idx_0 = std::sin(rtb_rgw_p_idx_1) * rtb_Sum_gz;

  // Product: '<S226>/Matrix Multiply2' incorporates:
  //   Gain: '<S8>/Gain4'
  //   SignalConversion generated from: '<S226>/Matrix Multiply2'

  for (i = 0; i < 3; i++) {
    rtb_Sum4_a_0[i] = (rtb_VectorConcatenate_g[i + 3] * rtb_sincos_o1_idx_0 +
                       rtb_VectorConcatenate_g[i] * rtb_UniformRandomNumber4_j)
      + rtb_VectorConcatenate_g[i + 6] * rtb_rgw_p_idx_0;
  }

  // End of Product: '<S226>/Matrix Multiply2'

  // Sum: '<S345>/Sum' incorporates:
  //   Gain: '<S226>/Gain_Mag'
  //   Gain: '<S226>/nT2Gauss'
  //   Sum: '<S226>/Sum3'

  rtb_UniformRandomNumber7[0] = FixedwingModel_P.Gain_Mag_Gain * rtb_Sum4_a_0[0]
    * FixedwingModel_P.nT2Gauss_Gain + FixedwingModel_B.sf_AccNoiseFun_e.y[0];
  rtb_UniformRandomNumber7[1] = FixedwingModel_P.Gain_Mag_Gain * rtb_Sum4_a_0[1]
    * FixedwingModel_P.nT2Gauss_Gain + FixedwingModel_B.sf_AccNoiseFun_e.y[1];
  rtb_UniformRandomNumber7[2] = FixedwingModel_P.Gain_Mag_Gain * rtb_Sum4_a_0[2]
    * FixedwingModel_P.nT2Gauss_Gain + FixedwingModel_B.sf_AccNoiseFun_e.y[2];

  // Outport: '<Root>/MavHILSensor' incorporates:
  //   DataTypeConversion: '<S226>/Data Type Conversion4'

  FixedwingModel_Y.MavHILSensor.xmag = static_cast<real32_T>
    (rtb_UniformRandomNumber7[0]);
  FixedwingModel_Y.MavHILSensor.ymag = static_cast<real32_T>
    (rtb_UniformRandomNumber7[1]);
  FixedwingModel_Y.MavHILSensor.zmag = static_cast<real32_T>
    (rtb_UniformRandomNumber7[2]);
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[2] == 0) {
    // UniformRandomNumber: '<S28>/Uniform Random Number'
    FixedwingModel_B.UniformRandomNumber[0] =
      FixedwingModel_DW.UniformRandomNumber_NextOutput[0];
    FixedwingModel_B.UniformRandomNumber[1] =
      FixedwingModel_DW.UniformRandomNumber_NextOutput[1];
    FixedwingModel_B.UniformRandomNumber[2] =
      FixedwingModel_DW.UniformRandomNumber_NextOutput[2];
  }

  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // MATLAB Function: '<S28>/FaultParamsExtract4' incorporates:
    //   Constant: '<S28>/FaultID4'
    //   Inport: '<Root>/inSILInts'

    // MATLAB Function 'WindFault/FaultParamsExtract4': '<S61>:1'
    // '<S61>:1:5' if isempty(hFault)
    // '<S61>:1:8' if isempty(fParam)
    // '<S61>:1:12' hFaultTmp=false;
    rtb_Compare_n = false;

    // '<S61>:1:13' fParamTmp=zeros(20,1);
    std::memset(&fParamTmp[0], 0, 20U * sizeof(real_T));

    // '<S61>:1:14' j=1;
    rtb_Rn = 1.0;

    // '<S61>:1:15' for i=1:8
    for (s281_iter = 0; s281_iter < 8; s281_iter++) {
      // '<S61>:1:16' if inInts(i) == FaultID
      if (FixedwingModel_U.inSILInts[s281_iter] ==
          FixedwingModel_P.FaultID4_Value) {
        // '<S61>:1:17' hFaultTmp=true;
        rtb_Compare_n = true;

        // '<S61>:1:18' fParamTmp(2*j-1)=inFloats(2*i-1);
        fParamTmp[static_cast<int32_T>(2.0 * rtb_Rn - 1.0) - 1] = inSILFloats
          [((s281_iter + 1) << 1) - 2];

        // '<S61>:1:19' fParamTmp(2*j)=inFloats(2*i);
        fParamTmp[static_cast<int32_T>(2.0 * rtb_Rn) - 1] = inSILFloats
          [((s281_iter + 1) << 1) - 1];

        // '<S61>:1:20' j=j+1;
        rtb_Rn++;
      }
    }

    // '<S61>:1:23' if hFaultTmp
    if (rtb_Compare_n) {
      // '<S61>:1:24' hFault=hFaultTmp;
      FixedwingModel_DW.hFault_d = true;

      // '<S61>:1:25' fParamTmp(17:20) = inFloats(17:20);
      fParamTmp[16] = inSILFloats[16];
      fParamTmp[17] = inSILFloats[17];
      fParamTmp[18] = inSILFloats[18];
      fParamTmp[19] = inSILFloats[19];

      // '<S61>:1:26' fParam=fParamTmp;
      std::memcpy(&FixedwingModel_DW.fParam_p[0], &fParamTmp[0], 20U * sizeof
                  (real_T));
    }

    // '<S61>:1:29' hasFault_WindNoise=hFault;
    // '<S61>:1:30' FaultParam=fParam;
    std::memcpy(&fParamTmp[0], &FixedwingModel_DW.fParam_p[0], 20U * sizeof
                (real_T));

    // MATLAB Function: '<S28>/noiseUpperWindBodySwitch' incorporates:
    //   MATLAB Function: '<S28>/FaultParamsExtract4'

    // MATLAB Function 'WindFault/noiseUpperWindBodySwitch': '<S67>:1'
    // '<S67>:1:3' y = [0;0;0];
    rtb_y_j[0] = 0.0;
    rtb_y_j[1] = 0.0;
    rtb_y_j[2] = 0.0;

    // '<S67>:1:4' if isNoiseFault
    if (FixedwingModel_DW.hFault_d) {
      // '<S67>:1:5' Param_GlobalNoiseGainSwitch=NoiseParams(1);
      // '<S67>:1:6' y=Noise* Param_GlobalNoiseGainSwitch;
      rtb_y_j[0] = FixedwingModel_B.UniformRandomNumber[0] * fParamTmp[0];
      rtb_y_j[1] = fParamTmp[0] * FixedwingModel_B.UniformRandomNumber[1];
      rtb_y_j[2] = fParamTmp[0] * FixedwingModel_B.UniformRandomNumber[2];
    }

    // End of MATLAB Function: '<S28>/noiseUpperWindBodySwitch'

    // Sum: '<S28>/Sum1' incorporates:
    //   Constant: '<S28>/Constant_[1 1 1]'

    FixedwingModel_B.Sum1[0] = FixedwingModel_P.Constant_111_Value[0] + rtb_y_j
      [0];
    FixedwingModel_B.Sum1[1] = FixedwingModel_P.Constant_111_Value[1] + rtb_y_j
      [1];
    FixedwingModel_B.Sum1[2] = FixedwingModel_P.Constant_111_Value[2] + rtb_y_j
      [2];

    // MATLAB Function: '<S28>/FaultParamsExtract' incorporates:
    //   Constant: '<S28>/FaultID'
    //   Inport: '<Root>/inSILInts'

    // MATLAB Function 'WindFault/FaultParamsExtract': '<S57>:1'
    // '<S57>:1:5' if isempty(hFault)
    // '<S57>:1:8' if isempty(fParam)
    // '<S57>:1:12' hFaultTmp=false;
    rtb_Compare_n = false;

    // '<S57>:1:13' fParamTmp=zeros(20,1);
    std::memset(&fParamTmp[0], 0, 20U * sizeof(real_T));

    // '<S57>:1:14' j=1;
    rtb_Rn = 1.0;

    // '<S57>:1:15' for i=1:8
    for (s281_iter = 0; s281_iter < 8; s281_iter++) {
      // '<S57>:1:16' if inInts(i) == FaultID
      if (FixedwingModel_U.inSILInts[s281_iter] ==
          FixedwingModel_P.FaultID_Value_i) {
        // '<S57>:1:17' hFaultTmp=true;
        rtb_Compare_n = true;

        // '<S57>:1:18' fParamTmp(2*j-1)=inFloats(2*i-1);
        fParamTmp[static_cast<int32_T>(2.0 * rtb_Rn - 1.0) - 1] = inSILFloats
          [((s281_iter + 1) << 1) - 2];

        // '<S57>:1:19' fParamTmp(2*j)=inFloats(2*i);
        fParamTmp[static_cast<int32_T>(2.0 * rtb_Rn) - 1] = inSILFloats
          [((s281_iter + 1) << 1) - 1];

        // '<S57>:1:20' j=j+1;
        rtb_Rn++;
      }
    }

    // '<S57>:1:23' if hFaultTmp
    if (rtb_Compare_n) {
      // '<S57>:1:24' hFault=hFaultTmp;
      FixedwingModel_DW.hFault_b = true;

      // '<S57>:1:25' fParamTmp(17:20) = inFloats(17:20);
      fParamTmp[16] = inSILFloats[16];
      fParamTmp[17] = inSILFloats[17];
      fParamTmp[18] = inSILFloats[18];
      fParamTmp[19] = inSILFloats[19];

      // '<S57>:1:26' fParam=fParamTmp;
      std::memcpy(&FixedwingModel_DW.fParam_ou[0], &fParamTmp[0], 20U * sizeof
                  (real_T));
    }

    // '<S57>:1:29' hasFault_ConstWind=hFault;
    FixedwingModel_B.hasFault_ConstWind = FixedwingModel_DW.hFault_b;

    // MATLAB Function: '<S28>/FaultParamsExtract1'
    // '<S57>:1:30' FaultParam=fParam;
    // MATLAB Function 'WindFault/FaultParamsExtract1': '<S58>:1'
    // '<S58>:1:5' if isempty(hFault)
    // '<S58>:1:8' if isempty(fParam)
    // '<S58>:1:12' hFaultTmp=false;
    rtb_Compare_n = false;

    // '<S58>:1:13' fParamTmp=zeros(20,1);
    for (i = 0; i < 20; i++) {
      // MATLAB Function: '<S28>/FaultParamsExtract'
      FixedwingModel_B.FaultParam_af[i] = FixedwingModel_DW.fParam_ou[i];

      // MATLAB Function: '<S28>/FaultParamsExtract1'
      fParamTmp[i] = 0.0;
    }

    // MATLAB Function: '<S28>/FaultParamsExtract1' incorporates:
    //   Constant: '<S28>/FaultID1'
    //   Inport: '<Root>/inSILInts'

    // '<S58>:1:14' j=1;
    rtb_Rn = 1.0;

    // '<S58>:1:15' for i=1:8
    for (s281_iter = 0; s281_iter < 8; s281_iter++) {
      // '<S58>:1:16' if inInts(i) == FaultID
      if (FixedwingModel_U.inSILInts[s281_iter] ==
          FixedwingModel_P.FaultID1_Value_j) {
        // '<S58>:1:17' hFaultTmp=true;
        rtb_Compare_n = true;

        // '<S58>:1:18' fParamTmp(2*j-1)=inFloats(2*i-1);
        fParamTmp[static_cast<int32_T>(2.0 * rtb_Rn - 1.0) - 1] = inSILFloats
          [((s281_iter + 1) << 1) - 2];

        // '<S58>:1:19' fParamTmp(2*j)=inFloats(2*i);
        fParamTmp[static_cast<int32_T>(2.0 * rtb_Rn) - 1] = inSILFloats
          [((s281_iter + 1) << 1) - 1];

        // '<S58>:1:20' j=j+1;
        rtb_Rn++;
      }
    }

    // '<S58>:1:23' if hFaultTmp
    if (rtb_Compare_n) {
      // '<S58>:1:24' hFault=hFaultTmp;
      FixedwingModel_DW.hFault_m = true;

      // '<S58>:1:25' fParamTmp(17:20) = inFloats(17:20);
      fParamTmp[16] = inSILFloats[16];
      fParamTmp[17] = inSILFloats[17];
      fParamTmp[18] = inSILFloats[18];
      fParamTmp[19] = inSILFloats[19];

      // '<S58>:1:26' fParam=fParamTmp;
      std::memcpy(&FixedwingModel_DW.fParam_c[0], &fParamTmp[0], 20U * sizeof
                  (real_T));
    }

    // '<S58>:1:29' hasFault_GustWind=hFault;
    FixedwingModel_B.hasFault_GustWind = FixedwingModel_DW.hFault_m;

    // MATLAB Function: '<S28>/FaultParamsExtract2'
    // '<S58>:1:30' FaultParam=fParam;
    // MATLAB Function 'WindFault/FaultParamsExtract2': '<S59>:1'
    // '<S59>:1:5' if isempty(hFault)
    // '<S59>:1:8' if isempty(fParam)
    // '<S59>:1:12' hFaultTmp=false;
    rtb_Compare_n = false;

    // '<S59>:1:13' fParamTmp=zeros(20,1);
    for (i = 0; i < 20; i++) {
      // MATLAB Function: '<S28>/FaultParamsExtract1'
      FixedwingModel_B.FaultParam_d[i] = FixedwingModel_DW.fParam_c[i];

      // MATLAB Function: '<S28>/FaultParamsExtract2'
      fParamTmp[i] = 0.0;
    }

    // MATLAB Function: '<S28>/FaultParamsExtract2' incorporates:
    //   Constant: '<S28>/FaultID2'
    //   Inport: '<Root>/inSILInts'

    // '<S59>:1:14' j=1;
    rtb_Rn = 1.0;

    // '<S59>:1:15' for i=1:8
    for (s281_iter = 0; s281_iter < 8; s281_iter++) {
      // '<S59>:1:16' if inInts(i) == FaultID
      if (FixedwingModel_U.inSILInts[s281_iter] ==
          FixedwingModel_P.FaultID2_Value_i) {
        // '<S59>:1:17' hFaultTmp=true;
        rtb_Compare_n = true;

        // '<S59>:1:18' fParamTmp(2*j-1)=inFloats(2*i-1);
        fParamTmp[static_cast<int32_T>(2.0 * rtb_Rn - 1.0) - 1] = inSILFloats
          [((s281_iter + 1) << 1) - 2];

        // '<S59>:1:19' fParamTmp(2*j)=inFloats(2*i);
        fParamTmp[static_cast<int32_T>(2.0 * rtb_Rn) - 1] = inSILFloats
          [((s281_iter + 1) << 1) - 1];

        // '<S59>:1:20' j=j+1;
        rtb_Rn++;
      }
    }

    // '<S59>:1:23' if hFaultTmp
    if (rtb_Compare_n) {
      // '<S59>:1:24' hFault=hFaultTmp;
      FixedwingModel_DW.hFault_kb = true;

      // '<S59>:1:25' fParamTmp(17:20) = inFloats(17:20);
      fParamTmp[16] = inSILFloats[16];
      fParamTmp[17] = inSILFloats[17];
      fParamTmp[18] = inSILFloats[18];
      fParamTmp[19] = inSILFloats[19];

      // '<S59>:1:26' fParam=fParamTmp;
      std::memcpy(&FixedwingModel_DW.fParam_p1[0], &fParamTmp[0], 20U * sizeof
                  (real_T));
    }

    // '<S59>:1:29' hasFault_TurbWind=hFault;
    FixedwingModel_B.hasFault_TurbWind = FixedwingModel_DW.hFault_kb;

    // MATLAB Function: '<S28>/FaultParamsExtract3'
    // '<S59>:1:30' FaultParam=fParam;
    // MATLAB Function 'WindFault/FaultParamsExtract3': '<S60>:1'
    // '<S60>:1:5' if isempty(hFault)
    // '<S60>:1:8' if isempty(fParam)
    // '<S60>:1:12' hFaultTmp=false;
    rtb_Compare_n = false;

    // '<S60>:1:13' fParamTmp=zeros(20,1);
    for (i = 0; i < 20; i++) {
      // MATLAB Function: '<S28>/FaultParamsExtract2'
      FixedwingModel_B.FaultParam_a[i] = FixedwingModel_DW.fParam_p1[i];

      // MATLAB Function: '<S28>/FaultParamsExtract3'
      fParamTmp[i] = 0.0;
    }

    // MATLAB Function: '<S28>/FaultParamsExtract3' incorporates:
    //   Constant: '<S28>/FaultID3'
    //   Inport: '<Root>/inSILInts'

    // '<S60>:1:14' j=1;
    rtb_Rn = 1.0;

    // '<S60>:1:15' for i=1:8
    for (s281_iter = 0; s281_iter < 8; s281_iter++) {
      // '<S60>:1:16' if inInts(i) == FaultID
      if (FixedwingModel_U.inSILInts[s281_iter] ==
          FixedwingModel_P.FaultID3_Value) {
        // '<S60>:1:17' hFaultTmp=true;
        rtb_Compare_n = true;

        // '<S60>:1:18' fParamTmp(2*j-1)=inFloats(2*i-1);
        fParamTmp[static_cast<int32_T>(2.0 * rtb_Rn - 1.0) - 1] = inSILFloats
          [((s281_iter + 1) << 1) - 2];

        // '<S60>:1:19' fParamTmp(2*j)=inFloats(2*i);
        fParamTmp[static_cast<int32_T>(2.0 * rtb_Rn) - 1] = inSILFloats
          [((s281_iter + 1) << 1) - 1];

        // '<S60>:1:20' j=j+1;
        rtb_Rn++;
      }
    }

    // '<S60>:1:23' if hFaultTmp
    if (rtb_Compare_n) {
      // '<S60>:1:24' hFault=hFaultTmp;
      FixedwingModel_DW.hFault_f = true;

      // '<S60>:1:25' fParamTmp(17:20) = inFloats(17:20);
      fParamTmp[16] = inSILFloats[16];
      fParamTmp[17] = inSILFloats[17];
      fParamTmp[18] = inSILFloats[18];
      fParamTmp[19] = inSILFloats[19];

      // '<S60>:1:26' fParam=fParamTmp;
      std::memcpy(&FixedwingModel_DW.fParam_l[0], &fParamTmp[0], 20U * sizeof
                  (real_T));
    }

    // '<S60>:1:29' hasFault_SheerWind=hFault;
    FixedwingModel_B.hasFault_SheerWind = FixedwingModel_DW.hFault_f;

    // '<S60>:1:30' FaultParam=fParam;
    std::memcpy(&FixedwingModel_B.FaultParam[0], &FixedwingModel_DW.fParam_l[0],
                20U * sizeof(real_T));
  }

  // Gain: '<S28>/Gain_-1'
  rtb_Sum_gz = FixedwingModel_P.Gain_1_Gain * Xe_idx_2;

  // Saturate: '<S28>/Saturation_2'
  if (rtb_Sum_gz > FixedwingModel_P.Saturation_2_UpperSat) {
    rtb_Sum_gz = FixedwingModel_P.Saturation_2_UpperSat;
  } else if (rtb_Sum_gz < FixedwingModel_P.Saturation_2_LowerSat) {
    rtb_Sum_gz = FixedwingModel_P.Saturation_2_LowerSat;
  }

  // End of Saturate: '<S28>/Saturation_2'

  // UnitConversion: '<S110>/Unit Conversion' incorporates:
  //   UnitConversion: '<S147>/Unit Conversion'
  //   UnitConversion: '<S71>/Unit Conversion'

  // Unit Conversion - from: m to: ft
  // Expression: output = (3.28084*input) + (0)
  rtb_sincos_o1_idx_0 = 3.280839895013123 * rtb_Sum_gz;
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // UnitConversion: '<S116>/Unit Conversion' incorporates:
    //   Constant: '<S28>/Constant_V'

    // Unit Conversion - from: m/s to: ft/s
    // Expression: output = (3.28084*input) + (0)
    FixedwingModel_B.UnitConversion_g = 3.280839895013123 *
      FixedwingModel_P.Constant_V_Value;
  }

  // Saturate: '<S143>/Limit Function 10ft to 1000ft'
  if (rtb_sincos_o1_idx_0 > FixedwingModel_P.LimitFunction10ftto1000ft_Upp_d) {
    rtb_jxi_d = FixedwingModel_P.LimitFunction10ftto1000ft_Upp_d;
  } else if (rtb_sincos_o1_idx_0 <
             FixedwingModel_P.LimitFunction10ftto1000ft_Low_k) {
    rtb_jxi_d = FixedwingModel_P.LimitFunction10ftto1000ft_Low_k;
  } else {
    rtb_jxi_d = rtb_sincos_o1_idx_0;
  }

  // End of Saturate: '<S143>/Limit Function 10ft to 1000ft'

  // Fcn: '<S143>/Low Altitude Scale Length'
  rtb_UniformRandomNumber4_j = 0.000823 * rtb_jxi_d + 0.177;
  if (rtb_UniformRandomNumber4_j < 0.0) {
    rtb_UniformRandomNumber4_j = -rt_powd_snf(-rtb_UniformRandomNumber4_j, 1.2);
  } else {
    rtb_UniformRandomNumber4_j = rt_powd_snf(rtb_UniformRandomNumber4_j, 1.2);
  }

  // Fcn: '<S143>/Low Altitude Scale Length'
  Sum_l = rtb_jxi_d / rtb_UniformRandomNumber4_j;
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // UnitConversion: '<S145>/Unit Conversion' incorporates:
    //   Constant: '<S144>/Medium//High Altitude'

    // Unit Conversion - from: m to: ft
    // Expression: output = (3.28084*input) + (0)
    FixedwingModel_B.UnitConversion_d = 3.280839895013123 *
      FixedwingModel_P.DrydenWindTurbulenceModelDiscre;
  }

  // Saturate: '<S126>/Limit Height h<1000ft'
  if (rtb_sincos_o1_idx_0 > FixedwingModel_P.LimitHeighth1000ft_UpperSat_p) {
    rtb_UniformRandomNumber4_j = FixedwingModel_P.LimitHeighth1000ft_UpperSat_p;
  } else if (rtb_sincos_o1_idx_0 <
             FixedwingModel_P.LimitHeighth1000ft_LowerSat_f) {
    rtb_UniformRandomNumber4_j = FixedwingModel_P.LimitHeighth1000ft_LowerSat_f;
  } else {
    rtb_UniformRandomNumber4_j = rtb_sincos_o1_idx_0;
  }

  // End of Saturate: '<S126>/Limit Height h<1000ft'

  // Fcn: '<S126>/Low Altitude Intensity'
  rtb_UniformRandomNumber4_j = 0.000823 * rtb_UniformRandomNumber4_j + 0.177;
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // Gain: '<S126>/sigma_wg ' incorporates:
    //   Constant: '<S56>/Windspeed at 20ft (6m)'
    //   UnitConversion: '<S117>/Unit Conversion'

    // Unit Conversion - from: m/s to: ft/s
    // Expression: output = (3.28084*input) + (0)
    FixedwingModel_B.sigma_wg_o = 3.280839895013123 *
      FixedwingModel_P.FaultParamAPI.FaultInParams[7] *
      FixedwingModel_P.sigma_wg_Gain_a;
  }

  // Fcn: '<S126>/Low Altitude Intensity'
  if (rtb_UniformRandomNumber4_j < 0.0) {
    rtb_UniformRandomNumber4_j = -rt_powd_snf(-rtb_UniformRandomNumber4_j, 0.4);
  } else {
    rtb_UniformRandomNumber4_j = rt_powd_snf(rtb_UniformRandomNumber4_j, 0.4);
  }

  // Product: '<S126>/sigma_ug, sigma_vg' incorporates:
  //   Fcn: '<S126>/Low Altitude Intensity'

  rtb_rgw_p_idx_1 = 1.0 / rtb_UniformRandomNumber4_j *
    FixedwingModel_B.sigma_wg_o;

  // Interpolation_n-D: '<S125>/Medium//High Altitude Intensity' incorporates:
  //   PreLookup: '<S125>/PreLook-Up Index Search  (altitude)'

  bpIndex_0[0] = plook_bincpa(rtb_sincos_o1_idx_0,
    FixedwingModel_P.PreLookUpIndexSearchaltitude__i, 11U,
    &rtb_UniformRandomNumber4_j,
    &FixedwingModel_DW.PreLookUpIndexSearchaltitude__m);
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // PreLookup: '<S125>/PreLook-Up Index Search  (prob of exceed)' incorporates:
    //   Constant: '<S125>/Probability of  Exceedance'

    FixedwingModel_B.PreLookUpIndexSearchprobofex_ft = plook_bincpa
      (FixedwingModel_P.DrydenWindTurbulenceModelDisc_m,
       FixedwingModel_P.PreLookUpIndexSearchprobofexc_c, 6U,
       &FixedwingModel_B.PreLookUpIndexSearchprobofexc_f,
       &FixedwingModel_DW.PreLookUpIndexSearchprobofexc_k);
  }

  // Interpolation_n-D: '<S125>/Medium//High Altitude Intensity'
  frac_0[0] = rtb_UniformRandomNumber4_j;
  frac_0[1] = FixedwingModel_B.PreLookUpIndexSearchprobofexc_f;
  bpIndex_0[1] = FixedwingModel_B.PreLookUpIndexSearchprobofex_ft;

  // Interpolation_n-D: '<S125>/Medium//High Altitude Intensity'
  rtb_rgw_p_idx_0 = intrp2d_la_pw(bpIndex_0, frac_0,
    FixedwingModel_P.MediumHighAltitudeIntensity_T_g, 12U,
    FixedwingModel_P.MediumHighAltitudeIntensity_m_o);
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[3] == 0) {
    // Sqrt: '<S118>/Sqrt1' incorporates:
    //   Constant: '<S118>/Constant1'

    rtb_UniformRandomNumber4_j = std::sqrt(FixedwingModel_P.WhiteNoise_Ts_a);

    // Product: '<S118>/Product' incorporates:
    //   Constant: '<S118>/Constant'
    //   Product: '<S118>/Divide'
    //   RandomNumber: '<S118>/White Noise'
    //   Sqrt: '<S118>/Sqrt'

    FixedwingModel_B.Product_p[0] = std::sqrt(FixedwingModel_P.WhiteNoise_pwr_f
      [0]) / rtb_UniformRandomNumber4_j * FixedwingModel_DW.NextOutput_c[0];
    FixedwingModel_B.Product_p[1] = std::sqrt(FixedwingModel_P.WhiteNoise_pwr_f
      [1]) / rtb_UniformRandomNumber4_j * FixedwingModel_DW.NextOutput_c[1];
    FixedwingModel_B.Product_p[2] = std::sqrt(FixedwingModel_P.WhiteNoise_pwr_f
      [2]) / rtb_UniformRandomNumber4_j * FixedwingModel_DW.NextOutput_c[2];
    FixedwingModel_B.Product_p[3] = std::sqrt(FixedwingModel_P.WhiteNoise_pwr_f
      [3]) / rtb_UniformRandomNumber4_j * FixedwingModel_DW.NextOutput_c[3];
  }

  // Outputs for Enabled SubSystem: '<S109>/Hugw(z)'
  // Constant: '<S109>/Constant3'
  FixedwingModel_Hugwz(FixedwingModel_P.DrydenWindTurbulenceModelDisc_f,
                       FixedwingModel_B.UnitConversion_g, Sum_l,
                       FixedwingModel_B.UnitConversion_d, rtb_rgw_p_idx_1,
                       rtb_rgw_p_idx_0, FixedwingModel_B.Product_p[0],
                       &FixedwingModel_B.Hugwz_l, &FixedwingModel_DW.Hugwz_l,
                       &FixedwingModel_P.Hugwz_l);

  // End of Outputs for SubSystem: '<S109>/Hugw(z)'

  // Gain: '<S115>/Lv'
  rtb_pgw_p[0] = FixedwingModel_P.Lv_Gain_c * Sum_l;
  rtb_pgw_p[1] = FixedwingModel_P.Lv_Gain_c * FixedwingModel_B.UnitConversion_d;

  // Outputs for Enabled SubSystem: '<S109>/Hvgw(z)'
  // Constant: '<S109>/Constant3'
  FixedwingModel_Hvgwz(FixedwingModel_P.DrydenWindTurbulenceModelDisc_f,
                       rtb_rgw_p_idx_1, rtb_rgw_p_idx_0, rtb_pgw_p,
                       FixedwingModel_B.UnitConversion_g,
                       FixedwingModel_B.Product_p[1], &FixedwingModel_B.Hvgwz_o,
                       &FixedwingModel_DW.Hvgwz_o, &FixedwingModel_P.Hvgwz_o);

  // End of Outputs for SubSystem: '<S109>/Hvgw(z)'

  // Gain: '<S115>/Lw'
  rtb_pgw_p[0] = FixedwingModel_P.Lw_Gain_a * rtb_jxi_d;
  rtb_pgw_p[1] = FixedwingModel_P.Lw_Gain_a * FixedwingModel_B.UnitConversion_d;

  // Outputs for Enabled SubSystem: '<S109>/Hwgw(z)'
  // Constant: '<S109>/Constant3'
  FixedwingModel_Hwgwz(FixedwingModel_P.DrydenWindTurbulenceModelDisc_f,
                       FixedwingModel_B.UnitConversion_g, rtb_pgw_p,
                       FixedwingModel_B.sigma_wg_o, rtb_rgw_p_idx_0,
                       FixedwingModel_B.Product_p[2], &FixedwingModel_B.Hwgwz_j,
                       &FixedwingModel_DW.Hwgwz_j, &FixedwingModel_P.Hwgwz_j);

  // End of Outputs for SubSystem: '<S109>/Hwgw(z)'
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // UnitConversion: '<S107>/Unit Conversion' incorporates:
    //   Constant: '<S56>/Wind direction'

    // Unit Conversion - from: deg to: rad
    // Expression: output = (0.0174533*input) + (0)
    FixedwingModel_B.UnitConversion_kf = 0.017453292519943295 *
      FixedwingModel_P.FaultParamAPI.FaultInParams[8];
  }

  // If: '<S114>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' incorporates:
  //   Constant: '<S28>/Constant_DCM'

  if (rtsiIsModeUpdateTimeStep(&(&FixedwingModel_M)->solverInfo)) {
    if (rtb_sincos_o1_idx_0 <= 1000.0) {
      rtAction = 0;
    } else if (rtb_sincos_o1_idx_0 >= 2000.0) {
      rtAction = 1;
    } else {
      rtAction = 2;
    }

    FixedwingModel_DW.ifHeightMaxlowaltitudeelseifH_l = rtAction;
  } else {
    rtAction = FixedwingModel_DW.ifHeightMaxlowaltitudeelseifH_l;
  }

  switch (rtAction) {
   case 0:
    // Outputs for IfAction SubSystem: '<S114>/Low altitude  velocities' incorporates:
    //   ActionPort: '<S136>/Action Port'

    Fixedwing_Lowaltitudevelocities(FixedwingModel_P.Constant_DCM_Value,
      FixedwingModel_B.Hugwz_l.Sum, FixedwingModel_B.Hvgwz_o.Sum,
      FixedwingModel_B.Hwgwz_j.Sum, FixedwingModel_B.UnitConversion_kf,
      rtb_UniformRandomNumber7);

    // End of Outputs for SubSystem: '<S114>/Low altitude  velocities'
    break;

   case 1:
    // Outputs for IfAction SubSystem: '<S114>/Medium//High  altitude velocities' incorporates:
    //   ActionPort: '<S137>/Action Port'

    // Sum: '<S345>/Sum' incorporates:
    //   Gain: '<S137>/Gain'

    rtb_UniformRandomNumber7[0] = FixedwingModel_P.Gain_Gain_a *
      FixedwingModel_B.Hugwz_l.Sum[1];
    rtb_UniformRandomNumber7[1] = FixedwingModel_P.Gain_Gain_a *
      FixedwingModel_B.Hvgwz_o.Sum[1];
    rtb_UniformRandomNumber7[2] = FixedwingModel_P.Gain_Gain_a *
      FixedwingModel_B.Hwgwz_j.Sum[1];

    // End of Outputs for SubSystem: '<S114>/Medium//High  altitude velocities'
    break;

   case 2:
    // Outputs for IfAction SubSystem: '<S114>/Interpolate  velocities' incorporates:
    //   ActionPort: '<S135>/Action Port'

    Fixedwing_Interpolatevelocities(FixedwingModel_B.Hugwz_l.Sum,
      FixedwingModel_B.Hvgwz_o.Sum, FixedwingModel_B.Hwgwz_j.Sum,
      FixedwingModel_P.Constant_DCM_Value, FixedwingModel_B.UnitConversion_kf,
      rtb_sincos_o1_idx_0, rtb_UniformRandomNumber7,
      &FixedwingModel_P.Interpolatevelocities_n);

    // End of Outputs for SubSystem: '<S114>/Interpolate  velocities'
    break;
  }

  // End of If: '<S114>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 
  // Unit Conversion - from: ft/s to: m/s
  // Expression: output = (0.3048*input) + (0)
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // MATLAB Function: '<S28>/MATLAB Function' incorporates:
    //   UnitConversion: '<S56>/Unit Conversion'

    std::memcpy(&fParamTmp[0], &FixedwingModel_B.FaultParam_d[0], 20U * sizeof
                (real_T));

    // MATLAB Function 'WindFault/MATLAB Function': '<S62>:1'
    // '<S62>:1:3' if(GustWindParams(2)<1)
    if (FixedwingModel_B.FaultParam_d[1] < 1.0) {
      // '<S62>:1:4' GustWindParams(2)=1;
      fParamTmp[1] = 1.0;
    }

    // '<S62>:1:6' timeVel=60/GustWindParams(2);
    rtb_UniformRandomNumber4_j = 60.0 / fParamTmp[1];

    // '<S62>:1:8' vmax=GustWindParams(1);
    rtb_jxi_d = FixedwingModel_B.FaultParam_d[0];

    // '<S62>:1:11' if isempty(t0)
    // '<S62>:1:16' if isempty(isInGust)
    // '<S62>:1:21' if isempty(t1)
    // '<S62>:1:26' if isempty(a)
    // '<S62>:1:31' if isempty(ang)
    // '<S62>:1:36' if isempty(wlast)
    if (!FixedwingModel_DW.wlast_not_empty) {
      // '<S62>:1:37' wlast=vmax*0.5;
      FixedwingModel_DW.wlast = FixedwingModel_B.FaultParam_d[0] * 0.5;
      FixedwingModel_DW.wlast_not_empty = true;
    }

    // '<S62>:1:41' if isempty(wNow)
    if (!FixedwingModel_DW.wNow_not_empty) {
      // '<S62>:1:42' wNow=1.4*0.8*vmax;
      FixedwingModel_DW.wNow = 1.1199999999999999 *
        FixedwingModel_B.FaultParam_d[0];
      FixedwingModel_DW.wNow_not_empty = true;
    }

    // '<S62>:1:46' if isGustWind&&isInGust<0.5
    if (FixedwingModel_B.hasFault_GustWind && (FixedwingModel_DW.isInGust < 0.5))
    {
      // '<S62>:1:47' t0=t;
      FixedwingModel_DW.t0 = Sum_p;

      // '<S62>:1:48' t1=timeVel*(3/4+1/2*rand(1));
      FixedwingModel_DW.t1 = (0.5 * FixedwingModel_rand_f() + 0.75) *
        rtb_UniformRandomNumber4_j;

      // '<S62>:1:49' a=1/4+1/2*rand(1);
      FixedwingModel_DW.a = 0.5 * FixedwingModel_rand_f() + 0.25;

      // '<S62>:1:50' ang=pi*2*rand(1);
      FixedwingModel_DW.ang = 6.2831853071795862 * FixedwingModel_rand_f();

      // '<S62>:1:51' wlast=wNow;
      FixedwingModel_DW.wlast = FixedwingModel_DW.wNow;

      // '<S62>:1:52' wNow=1.2*(rand(1)*0.5+0.5)*vmax;
      FixedwingModel_DW.wNow = (FixedwingModel_rand_f() * 0.5 + 0.5) * 1.2 *
        rtb_jxi_d;

      // '<S62>:1:54' isInGust=1;
      FixedwingModel_DW.isInGust = 1.0;
    }

    // '<S62>:1:57' if ~isGustWind
    if (!FixedwingModel_B.hasFault_GustWind) {
      // '<S62>:1:58' isInGust=0;
      FixedwingModel_DW.isInGust = 0.0;
    }

    // '<S62>:1:61' gWind=[0;0;0];
    // '<S62>:1:63' if(t<t0+t1*a)
    rtb_WhiteNoise_l_idx_0 = FixedwingModel_DW.t1 * FixedwingModel_DW.a;
    if (Sum_p < rtb_WhiteNoise_l_idx_0 + FixedwingModel_DW.t0) {
      // '<S62>:1:64' gWindMag=(wNow-wlast)/2*(1-cos((t-t0)/(t1*a)*pi))+wlast;
      Sum_l = (1.0 - std::cos((Sum_p - FixedwingModel_DW.t0) /
                rtb_WhiteNoise_l_idx_0 * 3.1415926535897931)) *
        ((FixedwingModel_DW.wNow - FixedwingModel_DW.wlast) / 2.0) +
        FixedwingModel_DW.wlast;
    } else {
      // '<S62>:1:65' else
      // '<S62>:1:66' gWindMag=wNow;
      Sum_l = FixedwingModel_DW.wNow;
    }

    // '<S62>:1:69' if abs(t-(t0+t1))<0.05
    if (std::abs(Sum_p - (FixedwingModel_DW.t0 + FixedwingModel_DW.t1)) < 0.05)
    {
      uint32_T seed;

      // '<S62>:1:70' rng(t*1000);
      rtb_WhiteNoise_l_idx_0 = Sum_p * 1000.0;
      if (rtb_WhiteNoise_l_idx_0 < 4.294967296E+9) {
        if (rtb_WhiteNoise_l_idx_0 >= 0.0) {
          seed = static_cast<uint32_T>(rtb_WhiteNoise_l_idx_0);
        } else {
          seed = 0U;
        }
      } else {
        seed = MAX_uint32_T;
      }

      switch (FixedwingModel_DW.method) {
       case 7U:
        if (seed == 0U) {
          seed = 5489U;
        }

        FixedwingModel_DW.state_a[0] = seed;
        for (s281_iter = 0; s281_iter < 623; s281_iter++) {
          seed = ((seed >> 30U ^ seed) * 1812433253U + s281_iter) + 1U;
          FixedwingModel_DW.state_a[s281_iter + 1] = seed;
        }

        FixedwingModel_DW.state_a[624] = 624U;
        break;

       case 5U:
        FixedwingModel_DW.state_b[0] = 362436069U;
        FixedwingModel_DW.state_b[1] = seed;
        if (FixedwingModel_DW.state_b[1] == 0U) {
          FixedwingModel_DW.state_b[1] = 521288629U;
        }
        break;

       default:
        s281_iter = static_cast<int32_T>(seed >> 16U);
        s330_iter = static_cast<int32_T>(seed & 32768U);
        seed = ((((seed - (static_cast<uint32_T>(s281_iter) << 16U)) - s330_iter)
                 << 16U) + s330_iter) + s281_iter;
        if (seed < 1U) {
          seed = 1144108930U;
        } else if (seed > 2147483646U) {
          seed = 2147483646U;
        }

        FixedwingModel_DW.state = seed;
        break;
      }

      // '<S62>:1:71' t0=t;
      FixedwingModel_DW.t0 = Sum_p;

      // '<S62>:1:72' t1=timeVel*(3/4+1/2*rand(1));
      FixedwingModel_DW.t1 = (0.5 * FixedwingModel_rand_f() + 0.75) *
        rtb_UniformRandomNumber4_j;

      // '<S62>:1:73' a=1/4+1/2*rand(1);
      FixedwingModel_DW.a = 0.5 * FixedwingModel_rand_f() + 0.25;

      // '<S62>:1:74' ang=ang+0.1*pi*rand(1);
      FixedwingModel_DW.ang += 0.31415926535897931 * FixedwingModel_rand_f();

      // '<S62>:1:75' wlast=wNow;
      FixedwingModel_DW.wlast = FixedwingModel_DW.wNow;

      // '<S62>:1:76' wNow=1.2*(rand(1)*0.5+0.5)*vmax;
      FixedwingModel_DW.wNow = (FixedwingModel_rand_f() * 0.5 + 0.5) * 1.2 *
        rtb_jxi_d;
    }

    // '<S62>:1:79' gWind(1)=gWindMag*cos(ang)*0.8+turb(1)*0.4;
    FixedwingModel_B.gWind[0] = Sum_l * std::cos(FixedwingModel_DW.ang) * 0.8 +
      0.3048 * rtb_UniformRandomNumber7[0] * 0.4;

    // '<S62>:1:80' gWind(2)=gWindMag*sin(ang)*0.8+turb(2)*0.4;
    FixedwingModel_B.gWind[1] = Sum_l * std::sin(FixedwingModel_DW.ang) * 0.8 +
      0.3048 * rtb_UniformRandomNumber7[1] * 0.4;

    // '<S62>:1:81' gWind(3)=turb(3)*0.4;
    FixedwingModel_B.gWind[2] = 0.3048 * rtb_UniformRandomNumber7[2] * 0.4;

    // End of MATLAB Function: '<S28>/MATLAB Function'

    // UnitConversion: '<S77>/Unit Conversion' incorporates:
    //   Constant: '<S28>/Constant_V'

    // Unit Conversion - from: m/s to: ft/s
    // Expression: output = (3.28084*input) + (0)
    FixedwingModel_B.UnitConversion_i = 3.280839895013123 *
      FixedwingModel_P.Constant_V_Value;
  }

  // Saturate: '<S104>/Limit Function 10ft to 1000ft'
  // Unit Conversion - from: m to: ft
  // Expression: output = (3.28084*input) + (0)
  if (rtb_sincos_o1_idx_0 > FixedwingModel_P.LimitFunction10ftto1000ft_Upp_f) {
    rtb_jxi_d = FixedwingModel_P.LimitFunction10ftto1000ft_Upp_f;
  } else if (rtb_sincos_o1_idx_0 <
             FixedwingModel_P.LimitFunction10ftto1000ft_Low_d) {
    rtb_jxi_d = FixedwingModel_P.LimitFunction10ftto1000ft_Low_d;
  } else {
    rtb_jxi_d = rtb_sincos_o1_idx_0;
  }

  // End of Saturate: '<S104>/Limit Function 10ft to 1000ft'

  // Fcn: '<S104>/Low Altitude Scale Length'
  rtb_UniformRandomNumber4_j = 0.000823 * rtb_jxi_d + 0.177;
  if (rtb_UniformRandomNumber4_j < 0.0) {
    rtb_UniformRandomNumber4_j = -rt_powd_snf(-rtb_UniformRandomNumber4_j, 1.2);
  } else {
    rtb_UniformRandomNumber4_j = rt_powd_snf(rtb_UniformRandomNumber4_j, 1.2);
  }

  // Fcn: '<S104>/Low Altitude Scale Length'
  rtb_Rn = rtb_jxi_d / rtb_UniformRandomNumber4_j;
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // UnitConversion: '<S106>/Unit Conversion' incorporates:
    //   Constant: '<S105>/Medium//High Altitude'

    // Unit Conversion - from: m to: ft
    // Expression: output = (3.28084*input) + (0)
    FixedwingModel_B.UnitConversion_dt = 3.280839895013123 *
      FixedwingModel_P.DrydenWindTurbulenceModelDisc_h;
  }

  // Saturate: '<S87>/Limit Height h<1000ft'
  if (rtb_sincos_o1_idx_0 > FixedwingModel_P.LimitHeighth1000ft_UpperSat_n) {
    rtb_UniformRandomNumber4_j = FixedwingModel_P.LimitHeighth1000ft_UpperSat_n;
  } else if (rtb_sincos_o1_idx_0 <
             FixedwingModel_P.LimitHeighth1000ft_LowerSat_n) {
    rtb_UniformRandomNumber4_j = FixedwingModel_P.LimitHeighth1000ft_LowerSat_n;
  } else {
    rtb_UniformRandomNumber4_j = rtb_sincos_o1_idx_0;
  }

  // End of Saturate: '<S87>/Limit Height h<1000ft'

  // Fcn: '<S87>/Low Altitude Intensity'
  rtb_UniformRandomNumber4_j = 0.000823 * rtb_UniformRandomNumber4_j + 0.177;
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // Gain: '<S87>/sigma_wg ' incorporates:
    //   Constant: '<S55>/Windspeed at 20ft (6m)'
    //   UnitConversion: '<S78>/Unit Conversion'

    // Unit Conversion - from: m/s to: ft/s
    // Expression: output = (3.28084*input) + (0)
    FixedwingModel_B.sigma_wg_e = 3.280839895013123 *
      FixedwingModel_P.FaultParamAPI.FaultInParams[3] *
      FixedwingModel_P.sigma_wg_Gain_d;
  }

  // Fcn: '<S87>/Low Altitude Intensity'
  if (rtb_UniformRandomNumber4_j < 0.0) {
    rtb_UniformRandomNumber4_j = -rt_powd_snf(-rtb_UniformRandomNumber4_j, 0.4);
  } else {
    rtb_UniformRandomNumber4_j = rt_powd_snf(rtb_UniformRandomNumber4_j, 0.4);
  }

  // Product: '<S87>/sigma_ug, sigma_vg' incorporates:
  //   Fcn: '<S87>/Low Altitude Intensity'

  rtb_Gain9_d = 1.0 / rtb_UniformRandomNumber4_j * FixedwingModel_B.sigma_wg_e;

  // Interpolation_n-D: '<S86>/Medium//High Altitude Intensity' incorporates:
  //   PreLookup: '<S86>/PreLook-Up Index Search  (altitude)'

  bpIndex_1[0] = plook_bincpa(rtb_sincos_o1_idx_0,
    FixedwingModel_P.PreLookUpIndexSearchaltitude__n, 11U,
    &rtb_UniformRandomNumber4_j,
    &FixedwingModel_DW.PreLookUpIndexSearchaltitude__f);
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // PreLookup: '<S86>/PreLook-Up Index Search  (prob of exceed)' incorporates:
    //   Constant: '<S86>/Probability of  Exceedance'

    FixedwingModel_B.PreLookUpIndexSearchprobofex_f4 = plook_bincpa
      (FixedwingModel_P.DrydenWindTurbulenceModelDisc_l,
       FixedwingModel_P.PreLookUpIndexSearchprobofexc_e, 6U,
       &FixedwingModel_B.PreLookUpIndexSearchprobofexc_b,
       &FixedwingModel_DW.PreLookUpIndexSearchprobofexc_o);
  }

  // Interpolation_n-D: '<S86>/Medium//High Altitude Intensity'
  frac_1[0] = rtb_UniformRandomNumber4_j;
  frac_1[1] = FixedwingModel_B.PreLookUpIndexSearchprobofexc_b;
  bpIndex_1[1] = FixedwingModel_B.PreLookUpIndexSearchprobofex_f4;

  // Interpolation_n-D: '<S86>/Medium//High Altitude Intensity'
  rtb_rgw_p_idx_1 = intrp2d_la_pw(bpIndex_1, frac_1,
    FixedwingModel_P.MediumHighAltitudeIntensity_T_n, 12U,
    FixedwingModel_P.MediumHighAltitudeIntensity_m_h);
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[3] == 0) {
    // Sqrt: '<S79>/Sqrt1' incorporates:
    //   Constant: '<S79>/Constant1'

    rtb_UniformRandomNumber4_j = std::sqrt(FixedwingModel_P.WhiteNoise_Ts_h);

    // Product: '<S79>/Product' incorporates:
    //   Constant: '<S79>/Constant'
    //   Product: '<S79>/Divide'
    //   RandomNumber: '<S79>/White Noise'
    //   Sqrt: '<S79>/Sqrt'

    FixedwingModel_B.Product_a[0] = std::sqrt(FixedwingModel_P.WhiteNoise_pwr_a
      [0]) / rtb_UniformRandomNumber4_j * FixedwingModel_DW.NextOutput_b[0];
    FixedwingModel_B.Product_a[1] = std::sqrt(FixedwingModel_P.WhiteNoise_pwr_a
      [1]) / rtb_UniformRandomNumber4_j * FixedwingModel_DW.NextOutput_b[1];
    FixedwingModel_B.Product_a[2] = std::sqrt(FixedwingModel_P.WhiteNoise_pwr_a
      [2]) / rtb_UniformRandomNumber4_j * FixedwingModel_DW.NextOutput_b[2];
    FixedwingModel_B.Product_a[3] = std::sqrt(FixedwingModel_P.WhiteNoise_pwr_a
      [3]) / rtb_UniformRandomNumber4_j * FixedwingModel_DW.NextOutput_b[3];
  }

  // Outputs for Enabled SubSystem: '<S70>/Hugw(z)'
  // Constant: '<S70>/Constant3'
  FixedwingModel_Hugwz(FixedwingModel_P.DrydenWindTurbulenceModelDisc_e,
                       FixedwingModel_B.UnitConversion_i, rtb_Rn,
                       FixedwingModel_B.UnitConversion_dt, rtb_Gain9_d,
                       rtb_rgw_p_idx_1, FixedwingModel_B.Product_a[0],
                       &FixedwingModel_B.Hugwz, &FixedwingModel_DW.Hugwz,
                       &FixedwingModel_P.Hugwz);

  // End of Outputs for SubSystem: '<S70>/Hugw(z)'

  // Gain: '<S76>/Lv'
  frac_1[0] = FixedwingModel_P.Lv_Gain_i * rtb_Rn;
  frac_1[1] = FixedwingModel_P.Lv_Gain_i * FixedwingModel_B.UnitConversion_dt;

  // Outputs for Enabled SubSystem: '<S70>/Hvgw(z)'
  // Constant: '<S70>/Constant3'
  FixedwingModel_Hvgwz(FixedwingModel_P.DrydenWindTurbulenceModelDisc_e,
                       rtb_Gain9_d, rtb_rgw_p_idx_1, frac_1,
                       FixedwingModel_B.UnitConversion_i,
                       FixedwingModel_B.Product_a[1], &FixedwingModel_B.Hvgwz,
                       &FixedwingModel_DW.Hvgwz, &FixedwingModel_P.Hvgwz);

  // End of Outputs for SubSystem: '<S70>/Hvgw(z)'

  // Gain: '<S76>/Lw'
  frac_1[0] = FixedwingModel_P.Lw_Gain_m * rtb_jxi_d;
  frac_1[1] = FixedwingModel_P.Lw_Gain_m * FixedwingModel_B.UnitConversion_dt;

  // Outputs for Enabled SubSystem: '<S70>/Hwgw(z)'
  // Constant: '<S70>/Constant3'
  FixedwingModel_Hwgwz(FixedwingModel_P.DrydenWindTurbulenceModelDisc_e,
                       FixedwingModel_B.UnitConversion_i, frac_1,
                       FixedwingModel_B.sigma_wg_e, rtb_rgw_p_idx_1,
                       FixedwingModel_B.Product_a[2], &FixedwingModel_B.Hwgwz,
                       &FixedwingModel_DW.Hwgwz, &FixedwingModel_P.Hwgwz);

  // End of Outputs for SubSystem: '<S70>/Hwgw(z)'
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // UnitConversion: '<S68>/Unit Conversion' incorporates:
    //   Constant: '<S55>/Wind direction'

    // Unit Conversion - from: deg to: rad
    // Expression: output = (0.0174533*input) + (0)
    FixedwingModel_B.UnitConversion_c = 0.017453292519943295 *
      FixedwingModel_P.FaultParamAPI.FaultInParams[4];
  }

  // If: '<S75>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' incorporates:
  //   Constant: '<S28>/Constant_DCM'

  if (rtsiIsModeUpdateTimeStep(&(&FixedwingModel_M)->solverInfo)) {
    if (rtb_sincos_o1_idx_0 <= 1000.0) {
      rtAction = 0;
    } else if (rtb_sincos_o1_idx_0 >= 2000.0) {
      rtAction = 1;
    } else {
      rtAction = 2;
    }

    FixedwingModel_DW.ifHeightMaxlowaltitudeelseifH_h = rtAction;
  } else {
    rtAction = FixedwingModel_DW.ifHeightMaxlowaltitudeelseifH_h;
  }

  switch (rtAction) {
   case 0:
    // Outputs for IfAction SubSystem: '<S75>/Low altitude  velocities' incorporates:
    //   ActionPort: '<S97>/Action Port'

    Fixedwing_Lowaltitudevelocities(FixedwingModel_P.Constant_DCM_Value,
      FixedwingModel_B.Hugwz.Sum, FixedwingModel_B.Hvgwz.Sum,
      FixedwingModel_B.Hwgwz.Sum, FixedwingModel_B.UnitConversion_c,
      rtb_UniformRandomNumber7);

    // End of Outputs for SubSystem: '<S75>/Low altitude  velocities'
    break;

   case 1:
    // Outputs for IfAction SubSystem: '<S75>/Medium//High  altitude velocities' incorporates:
    //   ActionPort: '<S98>/Action Port'

    // Sum: '<S345>/Sum' incorporates:
    //   Gain: '<S98>/Gain'

    rtb_UniformRandomNumber7[0] = FixedwingModel_P.Gain_Gain_j *
      FixedwingModel_B.Hugwz.Sum[1];
    rtb_UniformRandomNumber7[1] = FixedwingModel_P.Gain_Gain_j *
      FixedwingModel_B.Hvgwz.Sum[1];
    rtb_UniformRandomNumber7[2] = FixedwingModel_P.Gain_Gain_j *
      FixedwingModel_B.Hwgwz.Sum[1];

    // End of Outputs for SubSystem: '<S75>/Medium//High  altitude velocities'
    break;

   case 2:
    // Outputs for IfAction SubSystem: '<S75>/Interpolate  velocities' incorporates:
    //   ActionPort: '<S96>/Action Port'

    Fixedwing_Interpolatevelocities(FixedwingModel_B.Hugwz.Sum,
      FixedwingModel_B.Hvgwz.Sum, FixedwingModel_B.Hwgwz.Sum,
      FixedwingModel_P.Constant_DCM_Value, FixedwingModel_B.UnitConversion_c,
      rtb_sincos_o1_idx_0, rtb_UniformRandomNumber7,
      &FixedwingModel_P.Interpolatevelocities);

    // End of Outputs for SubSystem: '<S75>/Interpolate  velocities'
    break;
  }

  // End of If: '<S75>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 
  // Unit Conversion - from: ft/s to: m/s
  // Expression: output = (0.3048*input) + (0)
  // MATLAB Function 'WindFault/TurbWindStrength_Dec_Switch': '<S65>:1'
  // '<S65>:1:3' TurbWind=vwind*TurbWindParams(1);
  // Unit Conversion - from: m to: ft
  // Expression: output = (3.28084*input) + (0)
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // Math: '<S66>/ln(ref_height//z0)' incorporates:
    //   Constant: '<S66>/ref_height//z0'
    //
    //  About '<S66>/ln(ref_height//z0)':
    //   Operator: log

    FixedwingModel_B.lnref_heightz0 = std::log
      (FixedwingModel_P.ref_heightz0_Value);
  }

  // Saturate: '<S66>/3ft-->inf'
  if (rtb_sincos_o1_idx_0 > FixedwingModel_P.uftinf_UpperSat) {
    Sum_l = FixedwingModel_P.uftinf_UpperSat;
  } else if (rtb_sincos_o1_idx_0 < FixedwingModel_P.uftinf_LowerSat) {
    Sum_l = FixedwingModel_P.uftinf_LowerSat;
  } else {
    Sum_l = rtb_sincos_o1_idx_0;
  }

  // End of Saturate: '<S66>/3ft-->inf'

  // Product: '<S66>/Product' incorporates:
  //   Gain: '<S66>/h//z0'
  //   Math: '<S66>/ln(h//z0)'
  //
  //  About '<S66>/ln(h//z0)':
  //   Operator: log

  rtb_UniformRandomNumber4_j = std::log(FixedwingModel_P.hz0_Gain * Sum_l) /
    FixedwingModel_B.lnref_heightz0;
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // UnitConversion: '<S146>/Unit Conversion' incorporates:
    //   Constant: '<S66>/Wind Direction'

    // Unit Conversion - from: deg to: rad
    // Expression: output = (0.0174533*input) + (0)
    rtb_Sum_gz = 0.017453292519943295 *
      FixedwingModel_P.FaultParamAPI.FaultInParams[6];

    // Gain: '<S66>/Wind speed at reference height' incorporates:
    //   Constant: '<S66>/Wdeg1'
    //   Trigonometry: '<S66>/SinCos'

    FixedwingModel_B.Windspeedatreferenceheight[0] =
      -FixedwingModel_P.FaultParamAPI.FaultInParams[5] * std::cos(rtb_Sum_gz);
    FixedwingModel_B.Windspeedatreferenceheight[1] =
      -FixedwingModel_P.FaultParamAPI.FaultInParams[5] * std::sin(rtb_Sum_gz);
    FixedwingModel_B.Windspeedatreferenceheight[2] =
      -FixedwingModel_P.FaultParamAPI.FaultInParams[5] *
      FixedwingModel_P.Wdeg1_Value_g;
  }

  // MATLAB Function: '<S28>/MATLAB Function1' incorporates:
  //   MATLAB Function: '<S28>/TurbWindStrength_Dec_Switch'
  //   UnitConversion: '<S55>/Unit Conversion'

  // MATLAB Function 'WindFault/SheerWindStrength_Dec_Switch': '<S64>:1'
  // '<S64>:1:2' SheerWind=vwind*SheerWindParams(1);
  // MATLAB Function 'WindFault/MATLAB Function1': '<S63>:1'
  // '<S63>:1:2' wind=[0;0;0];
  rtb_y_j[0] = 0.0;
  rtb_y_j[1] = 0.0;
  rtb_y_j[2] = 0.0;

  // '<S63>:1:3' if isConstWind
  if (FixedwingModel_B.hasFault_ConstWind) {
    // '<S63>:1:4' wind=[ConstWind(1);ConstWind(2);ConstWind(3)];
    rtb_y_j[0] = FixedwingModel_B.FaultParam_af[0];
    rtb_y_j[1] = FixedwingModel_B.FaultParam_af[1];
    rtb_y_j[2] = FixedwingModel_B.FaultParam_af[2];
  } else if (FixedwingModel_B.hasFault_GustWind) {
    // '<S63>:1:5' elseif isGustWind
    // '<S63>:1:6' wind=GustWind;
    rtb_y_j[0] = FixedwingModel_B.gWind[0];
    rtb_y_j[1] = FixedwingModel_B.gWind[1];
    rtb_y_j[2] = FixedwingModel_B.gWind[2];
  } else if (FixedwingModel_B.hasFault_TurbWind) {
    // '<S63>:1:7' elseif isTurbWind
    // '<S63>:1:8' wind=TurbWind;
    rtb_y_j[0] = 0.3048 * rtb_UniformRandomNumber7[0] *
      FixedwingModel_B.FaultParam_a[0];
    rtb_y_j[1] = 0.3048 * rtb_UniformRandomNumber7[1] *
      FixedwingModel_B.FaultParam_a[0];
    rtb_y_j[2] = 0.3048 * rtb_UniformRandomNumber7[2] *
      FixedwingModel_B.FaultParam_a[0];
  } else if (FixedwingModel_B.hasFault_SheerWind) {
    // MATLAB Function: '<S28>/SheerWindStrength_Dec_Switch'
    // '<S63>:1:9' elseif isSheerWind
    // '<S63>:1:10' wind=SheerWind;
    rtb_WhiteNoise_l_idx_0 = FixedwingModel_B.FaultParam[0];

    // Product: '<S66>/Transform from Inertial to Body axes' incorporates:
    //   Constant: '<S28>/Constant_DCM'
    //   MATLAB Function: '<S28>/SheerWindStrength_Dec_Switch'
    //   Product: '<S66>/Product1'

    for (i = 0; i < 3; i++) {
      rtb_y_j[i] = ((FixedwingModel_P.Constant_DCM_Value[i + 3] *
                     (rtb_UniformRandomNumber4_j *
                      FixedwingModel_B.Windspeedatreferenceheight[1]) +
                     rtb_UniformRandomNumber4_j *
                     FixedwingModel_B.Windspeedatreferenceheight[0] *
                     FixedwingModel_P.Constant_DCM_Value[i]) +
                    FixedwingModel_P.Constant_DCM_Value[i + 6] *
                    (rtb_UniformRandomNumber4_j *
                     FixedwingModel_B.Windspeedatreferenceheight[2])) *
        rtb_WhiteNoise_l_idx_0;
    }

    // End of Product: '<S66>/Transform from Inertial to Body axes'
  }

  // End of MATLAB Function: '<S28>/MATLAB Function1'
  for (i = 0; i < 3; i++) {
    // Sum: '<S345>/Sum' incorporates:
    //   Gain: '<S8>/Gain4'
    //   Gain: '<S8>/Gain5'
    //   Integrator: '<S341>/ub,vb,wb'
    //   Product: '<S28>/Product'
    //   Product: '<S28>/Product1'
    //   Sum: '<S28>/Sum'
    //   Sum: '<S28>/Sum1'

    rtb_UniformRandomNumber7[i] = (FixedwingModel_P.Gain5_Gain *
      FixedwingModel_X.ubvbwb_CSTATE[i] - ((rtb_VectorConcatenate_g[i + 3] *
      rtb_y_j[1] + rtb_VectorConcatenate_g[i] * rtb_y_j[0]) +
      rtb_VectorConcatenate_g[i + 6] * rtb_y_j[2])) * FixedwingModel_B.Sum1[i];
  }

  // Product: '<S242>/Product2'
  rtb_UniformRandomNumber4_j = rtb_UniformRandomNumber7[2] *
    rtb_UniformRandomNumber7[2];

  // Sum: '<S242>/Sum' incorporates:
  //   Product: '<S242>/Product'
  //   Product: '<S242>/Product1'

  rtb_Rn = (rtb_UniformRandomNumber7[0] * rtb_UniformRandomNumber7[0] +
            rtb_UniformRandomNumber7[1] * rtb_UniformRandomNumber7[1]) +
    rtb_UniformRandomNumber4_j;

  // Saturate: '<S25>/Limit  altitude  to troposhere'
  if (rtb_Add > FixedwingModel_P.Limitaltitudetotroposhere_Upper) {
    rtb_UniformRandomNumber4_j =
      FixedwingModel_P.Limitaltitudetotroposhere_Upper;
  } else if (rtb_Add < FixedwingModel_P.Limitaltitudetotroposhere_Lower) {
    rtb_UniformRandomNumber4_j =
      FixedwingModel_P.Limitaltitudetotroposhere_Lower;
  } else {
    rtb_UniformRandomNumber4_j = rtb_Add;
  }

  // End of Saturate: '<S25>/Limit  altitude  to troposhere'

  // Sum: '<S25>/Sum1' incorporates:
  //   Constant: '<S25>/Sea Level  Temperature'
  //   Gain: '<S25>/Lapse Rate'

  rtb_Sum_gz = FixedwingModel_P.SeaLevelTemperature_Value_m -
    FixedwingModel_P.LapseRate_Gain * rtb_UniformRandomNumber4_j;

  // Gain: '<S25>/1//T0'
  rtb_jxi_d = FixedwingModel_P.uT0_Gain * rtb_Sum_gz;

  // Math: '<S25>/(T//T0)^(g//LR) ' incorporates:
  //   Constant: '<S25>/Constant'

  if ((rtb_jxi_d < 0.0) && (FixedwingModel_P.Constant_Value_o > std::floor
       (FixedwingModel_P.Constant_Value_o))) {
    rtb_UniformRandomNumber4_j = -rt_powd_snf(-rtb_jxi_d,
      FixedwingModel_P.Constant_Value_o);
  } else {
    rtb_UniformRandomNumber4_j = rt_powd_snf(rtb_jxi_d,
      FixedwingModel_P.Constant_Value_o);
  }

  // End of Math: '<S25>/(T//T0)^(g//LR) '

  // Sum: '<S25>/Sum' incorporates:
  //   Constant: '<S25>/Altitude of Troposphere'

  Sum_l = FixedwingModel_P.AltitudeofTroposphere_Value - rtb_Add;

  // Saturate: '<S25>/Limit  altitude  to Stratosphere'
  if (Sum_l > FixedwingModel_P.LimitaltitudetoStratosphere_U_h) {
    Sum_l = FixedwingModel_P.LimitaltitudetoStratosphere_U_h;
  } else if (Sum_l < FixedwingModel_P.LimitaltitudetoStratosphere_Low) {
    Sum_l = FixedwingModel_P.LimitaltitudetoStratosphere_Low;
  }

  // End of Saturate: '<S25>/Limit  altitude  to Stratosphere'

  // Gain: '<S228>/1//2rhoV^2' incorporates:
  //   Gain: '<S25>/g//R'
  //   Gain: '<S25>/rho0'
  //   Math: '<S25>/Stratosphere Model'
  //   Product: '<S228>/Product2'
  //   Product: '<S25>/Product'
  //   Product: '<S25>/Product1'
  //   Product: '<S25>/Product3'
  //
  //  About '<S25>/Stratosphere Model':
  //   Operator: exp

  rtb_jxi_d = rtb_UniformRandomNumber4_j / rtb_jxi_d *
    FixedwingModel_P.rho0_Gain * std::exp(1.0 / rtb_Sum_gz *
    (FixedwingModel_P.gR_Gain * Sum_l)) * rtb_Rn *
    FixedwingModel_P.u2rhoV2_Gain_o;
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // MATLAB Function: '<S226>/FaultParamsExtract3' incorporates:
    //   Constant: '<S226>/FaultID3'
    //   Inport: '<Root>/inSILInts'

    // MATLAB Function 'SensorFault/FaultParamsExtract3': '<S232>:1'
    // '<S232>:1:5' if isempty(hFault)
    // '<S232>:1:8' if isempty(fParam)
    // '<S232>:1:12' hFaultTmp=false;
    rtb_Compare_n = false;

    // '<S232>:1:13' fParamTmp=zeros(20,1);
    std::memset(&fParamTmp[0], 0, 20U * sizeof(real_T));

    // '<S232>:1:14' j=1;
    rtb_Rn = 1.0;

    // '<S232>:1:15' for i=1:8
    for (s281_iter = 0; s281_iter < 8; s281_iter++) {
      // '<S232>:1:16' if inInts(i) == FaultID
      if (FixedwingModel_U.inSILInts[s281_iter] ==
          FixedwingModel_P.FaultID3_Value_h) {
        // '<S232>:1:17' hFaultTmp=true;
        rtb_Compare_n = true;

        // '<S232>:1:18' fParamTmp(2*j-1)=inFloats(2*i-1);
        s289_iter = (s281_iter + 1) << 1;
        fParamTmp[static_cast<int32_T>(2.0 * rtb_Rn - 1.0) - 1] =
          inSILFloats[s289_iter - 2];

        // '<S232>:1:19' fParamTmp(2*j)=inFloats(2*i);
        fParamTmp[static_cast<int32_T>(2.0 * rtb_Rn) - 1] =
          inSILFloats[s289_iter - 1];

        // '<S232>:1:20' j=j+1;
        rtb_Rn++;
      }
    }

    // '<S232>:1:23' if hFaultTmp
    if (rtb_Compare_n) {
      // '<S232>:1:24' hFault=hFaultTmp;
      FixedwingModel_DW.hFault = true;

      // '<S232>:1:25' fParamTmp(17:20) = inFloats(17:20);
      fParamTmp[16] = inSILFloats[16];
      fParamTmp[17] = inSILFloats[17];
      fParamTmp[18] = inSILFloats[18];
      fParamTmp[19] = inSILFloats[19];

      // '<S232>:1:26' fParam=fParamTmp;
      std::memcpy(&FixedwingModel_DW.fParam[0], &fParamTmp[0], 20U * sizeof
                  (real_T));
    }

    // MATLAB Function: '<S226>/baro NoiseFun' incorporates:
    //   MATLAB Function: '<S226>/FaultParamsExtract3'

    // '<S232>:1:29' hasFault_baro=hFault;
    // '<S232>:1:30' FaultParam=fParam;
    // MATLAB Function 'SensorFault/baro NoiseFun': '<S240>:1'
    // '<S240>:1:3' y = 0;
    FixedwingModel_B.y = 0.0;

    // '<S240>:1:4' if isbyroFault
    if (FixedwingModel_DW.hFault) {
      // '<S240>:1:5' y = baroFaultParam(1);
      FixedwingModel_B.y = FixedwingModel_DW.fParam[0];
    }

    // End of MATLAB Function: '<S226>/baro NoiseFun'
  }

  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[3] == 0) {
    // Product: '<S234>/Product4' incorporates:
    //   Constant: '<S234>/Constant2'
    //   Gain: '<S226>/Gain5'
    //   UniformRandomNumber: '<S226>/Uniform Random Number'

    FixedwingModel_B.Product4 = FixedwingModel_P.Gain5_Gain_l *
      FixedwingModel_DW.UniformRandomNumber_NextOutpu_a *
      FixedwingModel_P.Constant2_Value_h0;
  }

  // Sum: '<S226>/Add2' incorporates:
  //   Product: '<S226>/Product'

  rtb_UniformRandomNumber4_j = (rtb_jxi_d * FixedwingModel_B.y + rtb_Add) +
    FixedwingModel_B.Product4;

  // Saturate: '<S236>/Limit  altitude  to troposhere'
  if (rtb_UniformRandomNumber4_j >
      FixedwingModel_P.Limitaltitudetotroposhere_Upp_j) {
    rtb_Rn = FixedwingModel_P.Limitaltitudetotroposhere_Upp_j;
  } else if (rtb_UniformRandomNumber4_j <
             FixedwingModel_P.Limitaltitudetotroposhere_Low_g) {
    rtb_Rn = FixedwingModel_P.Limitaltitudetotroposhere_Low_g;
  } else {
    rtb_Rn = rtb_UniformRandomNumber4_j;
  }

  // End of Saturate: '<S236>/Limit  altitude  to troposhere'

  // Sum: '<S236>/Sum1' incorporates:
  //   Constant: '<S236>/Sea Level  Temperature'
  //   Gain: '<S236>/Lapse Rate'

  rtb_Rn = FixedwingModel_P.SeaLevelTemperature_Value -
    FixedwingModel_P.LapseRate_Gain_m * rtb_Rn;

  // Gain: '<S236>/1//T0'
  rtb_Gain9_d = FixedwingModel_P.uT0_Gain_g * rtb_Rn;
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[3] == 0) {
    // Product: '<S235>/Product4' incorporates:
    //   Constant: '<S235>/Constant'
    //   Constant: '<S235>/Constant2'
    //   Gain: '<S226>/Gain9'
    //   Gain: '<S235>/Gain2'
    //   Sum: '<S235>/Sum'
    //   UniformRandomNumber: '<S226>/Uniform Random Number4'

    FixedwingModel_B.Product4_l = (FixedwingModel_P.Gain2_Gain_l *
      FixedwingModel_P.Constant_Value_oe + FixedwingModel_P.Constant2_Value_d) *
      (FixedwingModel_P.Gain9_Gain *
       FixedwingModel_DW.UniformRandomNumber4_NextOutput);
  }

  // Sum: '<S236>/Sum' incorporates:
  //   Constant: '<S236>/Altitude of Troposphere'

  // Unit Conversion - from: K to: degC
  // Expression: output = (1*input) + (-273.15)
  Sum_l = FixedwingModel_P.AltitudeofTroposphere_Value_k -
    rtb_UniformRandomNumber4_j;
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // DataTypeConversion: '<S153>/Data Type Conversion6' incorporates:
    //   Constant: '<S153>/Constant'

    rtb_WhiteNoise_l_idx_0 = std::floor(FixedwingModel_P.Constant_Value_e0);
    if (rtIsNaN(rtb_WhiteNoise_l_idx_0) || rtIsInf(rtb_WhiteNoise_l_idx_0)) {
      rtb_WhiteNoise_l_idx_0 = 0.0;
    } else {
      rtb_WhiteNoise_l_idx_0 = std::fmod(rtb_WhiteNoise_l_idx_0, 4.294967296E+9);
    }

    // DataTypeConversion: '<S153>/Data Type Conversion6'
    FixedwingModel_B.fields_updated = rtb_WhiteNoise_l_idx_0 < 0.0 ?
      static_cast<uint32_T>(-static_cast<int32_T>(static_cast<uint32_T>
      (-rtb_WhiteNoise_l_idx_0))) : static_cast<uint32_T>(rtb_WhiteNoise_l_idx_0);
  }

  // Outport: '<Root>/MavHILSensor' incorporates:
  //   BusCreator: '<S153>/Bus Creator'
  //   DataTypeConversion: '<S226>/Data Type Conversion3'
  //   Sum: '<S226>/Sum2'

  FixedwingModel_Y.MavHILSensor.time_usec = rtb_time_usec;
  FixedwingModel_Y.MavHILSensor.xacc = rtb_AngEuler[0];
  FixedwingModel_Y.MavHILSensor.yacc = rtb_AngEuler[1];
  FixedwingModel_Y.MavHILSensor.zacc = rtb_AngEuler[2];
  FixedwingModel_Y.MavHILSensor.xgyro = static_cast<real32_T>(y +
    FixedwingModel_B.sf_AccNoiseFun_p.y[0]);
  FixedwingModel_Y.MavHILSensor.ygyro = static_cast<real32_T>(y_0 +
    FixedwingModel_B.sf_AccNoiseFun_p.y[1]);

  // Saturate: '<S247>/Saturation'
  if (rtb_IntegratorSecondOrderLim_ff > FixedwingModel_P.Saturation_UpperSat_gx
      [2]) {
    rtb_IntegratorSecondOrderLim_ff = FixedwingModel_P.Saturation_UpperSat_gx[2];
  } else if (rtb_IntegratorSecondOrderLim_ff <
             FixedwingModel_P.Saturation_LowerSat_a[2]) {
    rtb_IntegratorSecondOrderLim_ff = FixedwingModel_P.Saturation_LowerSat_a[2];
  }

  // Outport: '<Root>/MavHILSensor' incorporates:
  //   DataTypeConversion: '<S226>/Data Type Conversion3'
  //   Sum: '<S226>/Sum2'

  FixedwingModel_Y.MavHILSensor.zgyro = static_cast<real32_T>
    (rtb_IntegratorSecondOrderLim_ff + FixedwingModel_B.sf_AccNoiseFun_p.y[2]);

  // Math: '<S236>/(T//T0)^(g//LR) ' incorporates:
  //   Constant: '<S236>/Constant'

  if ((rtb_Gain9_d < 0.0) && (FixedwingModel_P.Constant_Value_ij > std::floor
       (FixedwingModel_P.Constant_Value_ij))) {
    rtb_Gain9_d = -rt_powd_snf(-rtb_Gain9_d, FixedwingModel_P.Constant_Value_ij);
  } else {
    rtb_Gain9_d = rt_powd_snf(rtb_Gain9_d, FixedwingModel_P.Constant_Value_ij);
  }

  // End of Math: '<S236>/(T//T0)^(g//LR) '

  // Saturate: '<S236>/Limit  altitude  to Stratosphere'
  if (Sum_l > FixedwingModel_P.LimitaltitudetoStratosphere_U_m) {
    Sum_l = FixedwingModel_P.LimitaltitudetoStratosphere_U_m;
  } else if (Sum_l < FixedwingModel_P.LimitaltitudetoStratosphere_L_o) {
    Sum_l = FixedwingModel_P.LimitaltitudetoStratosphere_L_o;
  }

  // End of Saturate: '<S236>/Limit  altitude  to Stratosphere'

  // Outport: '<Root>/MavHILSensor' incorporates:
  //   BusCreator: '<S153>/Bus Creator'
  //   Constant: '<S3>/Constant1'
  //   DataTypeConversion: '<S226>/Data Type Conversion5'
  //   Gain: '<S226>/Gain'
  //   Gain: '<S226>/Gain1'
  //   Gain: '<S236>/P0'
  //   Gain: '<S236>/g//R'
  //   Math: '<S236>/Stratosphere Model'
  //   Product: '<S236>/Product1'
  //   Product: '<S236>/Product2'
  //   Sum: '<S226>/Sum'
  //   Sum: '<S3>/Sum2'
  //   UnitConversion: '<S26>/Unit Conversion'
  //
  //  About '<S236>/Stratosphere Model':
  //   Operator: exp

  FixedwingModel_Y.MavHILSensor.abs_pressure = static_cast<real32_T>(std::exp
    (1.0 / rtb_Rn * (FixedwingModel_P.gR_Gain_k * Sum_l)) *
    (FixedwingModel_P.P0_Gain * rtb_Gain9_d) * FixedwingModel_P.Gain_Gain_ku);
  FixedwingModel_Y.MavHILSensor.diff_pressure = static_cast<real32_T>
    (FixedwingModel_P.Gain1_Gain_a * rtb_jxi_d + FixedwingModel_B.Product4_l);
  FixedwingModel_Y.MavHILSensor.pressure_alt = static_cast<real32_T>
    (rtb_UniformRandomNumber4_j);
  FixedwingModel_Y.MavHILSensor.temperature = static_cast<real32_T>((rtb_Sum_gz
    + -273.15000000000003) + FixedwingModel_P.Constant1_Value_c);
  FixedwingModel_Y.MavHILSensor.fields_updated = FixedwingModel_B.fields_updated;
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[5] == 0) {
    // Gain: '<S194>/BiasGain2' incorporates:
    //   UniformRandomNumber: '<S194>/Uniform Random Number5'

    FixedwingModel_B.BiasGain2[0] = FixedwingModel_P.BiasGain2_Gain *
      FixedwingModel_DW.UniformRandomNumber5_NextOutp_j[0];
    FixedwingModel_B.BiasGain2[1] = FixedwingModel_P.BiasGain2_Gain *
      FixedwingModel_DW.UniformRandomNumber5_NextOutp_j[1];
    FixedwingModel_B.BiasGain2[2] = FixedwingModel_P.BiasGain2_Gain *
      FixedwingModel_DW.UniformRandomNumber5_NextOutp_j[2];
  }

  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // MATLAB Function: '<S194>/FaultParamsExtract' incorporates:
    //   Constant: '<S194>/FaultID'
    //   Inport: '<Root>/inSILInts'

    FixedwingMod_FaultParamsExtract(FixedwingModel_P.FaultID_Value_m,
      FixedwingModel_U.inSILInts, inSILFloats,
      &FixedwingModel_B.sf_FaultParamsExtract_d,
      &FixedwingModel_DW.sf_FaultParamsExtract_d);

    // MATLAB Function: '<S199>/MATLAB Function'
    // MATLAB Function 'GPSFault/GPSFaultModel/MATLAB Function': '<S222>:1'
    // '<S222>:1:3' yNoise = 0.3*u;
    FixedwingModel_B.yNoise[0] = 0.3 * FixedwingModel_B.BiasGain2[0];
    FixedwingModel_B.yNoise[1] = 0.3 * FixedwingModel_B.BiasGain2[1];
    FixedwingModel_B.yNoise[2] = 0.3 * FixedwingModel_B.BiasGain2[2];

    // '<S222>:1:4' y3DFix = 3;
    rtb_y3DFix = 3.0;

    // '<S222>:1:5' ySats = 10;
    rtb_ySats = 10.0;

    // '<S222>:1:7' if isGPSFault
    if (FixedwingModel_B.sf_FaultParamsExtract_d.hasFault) {
      // '<S222>:1:8' yNoise = (GPSFaultParams(1))*u;
      FixedwingModel_B.yNoise[0] =
        FixedwingModel_B.sf_FaultParamsExtract_d.FaultParam[0] *
        FixedwingModel_B.BiasGain2[0];
      FixedwingModel_B.yNoise[1] =
        FixedwingModel_B.sf_FaultParamsExtract_d.FaultParam[0] *
        FixedwingModel_B.BiasGain2[1];
      FixedwingModel_B.yNoise[2] =
        FixedwingModel_B.sf_FaultParamsExtract_d.FaultParam[0] *
        FixedwingModel_B.BiasGain2[2];

      // '<S222>:1:9' y3DFix = GPSFaultParams(2);
      rtb_y3DFix = FixedwingModel_B.sf_FaultParamsExtract_d.FaultParam[1];

      // '<S222>:1:10' ySats = GPSFaultParams(3);
      rtb_ySats = FixedwingModel_B.sf_FaultParamsExtract_d.FaultParam[2];
    }

    // End of MATLAB Function: '<S199>/MATLAB Function'

    // UnitConversion: '<S217>/Unit Conversion' incorporates:
    //   Constant: '<S198>/ref_rotation'

    // Unit Conversion - from: deg to: rad
    // Expression: output = (0.0174533*input) + (0)
    rtb_Sum_gz = 0.017453292519943295 * FixedwingModel_P.FlatEarthtoLLA_psi_i;

    // Trigonometry: '<S202>/SinCos'
    FixedwingModel_B.SinCos_o1_o = std::sin(rtb_Sum_gz);

    // Trigonometry: '<S202>/SinCos'
    FixedwingModel_B.SinCos_o2_c = std::cos(rtb_Sum_gz);

    // Sum: '<S220>/Sum' incorporates:
    //   Constant: '<S220>/Constant'
    //   Constant: '<S220>/f'

    rtb_Sum_gz = FixedwingModel_P.f_Value_b - FixedwingModel_P.Constant_Value_eq;

    // Sqrt: '<S221>/sqrt' incorporates:
    //   Constant: '<S221>/Constant'
    //   Product: '<S221>/Product1'
    //   Sum: '<S221>/Sum1'

    rtb_Sum_gz = std::sqrt(FixedwingModel_P.Constant_Value_kh - rtb_Sum_gz *
      rtb_Sum_gz);

    // Switch: '<S213>/Switch' incorporates:
    //   Abs: '<S213>/Abs'
    //   Bias: '<S213>/Bias'
    //   Bias: '<S213>/Bias1'
    //   Constant: '<S198>/ref_position'
    //   Constant: '<S213>/Constant2'
    //   Constant: '<S214>/Constant'
    //   Math: '<S213>/Math Function1'
    //   RelationalOperator: '<S214>/Compare'

    if (std::abs(FixedwingModel_P.ModelParam_GPSLatLong[0]) >
        FixedwingModel_P.CompareToConstant_const_o) {
      rtb_Rn = rt_modd_snf(FixedwingModel_P.ModelParam_GPSLatLong[0] +
                           FixedwingModel_P.Bias_Bias_jv,
                           FixedwingModel_P.Constant2_Value_k5) +
        FixedwingModel_P.Bias1_Bias_lz;
    } else {
      rtb_Rn = FixedwingModel_P.ModelParam_GPSLatLong[0];
    }

    // End of Switch: '<S213>/Switch'

    // Abs: '<S210>/Abs1'
    rtb_jxi_d = std::abs(rtb_Rn);

    // RelationalOperator: '<S212>/Compare' incorporates:
    //   Constant: '<S212>/Constant'

    rtb_DataTypeConversion2_e = (rtb_jxi_d >
      FixedwingModel_P.CompareToConstant_const_c);

    // Switch: '<S210>/Switch'
    if (rtb_DataTypeConversion2_e) {
      // Signum: '<S210>/Sign1'
      if (!rtIsNaN(rtb_Rn)) {
        if (rtb_Rn < 0.0) {
          rtb_Rn = -1.0;
        } else {
          rtb_Rn = (rtb_Rn > 0.0);
        }
      }

      // End of Signum: '<S210>/Sign1'

      // Switch: '<S210>/Switch' incorporates:
      //   Bias: '<S210>/Bias'
      //   Bias: '<S210>/Bias1'
      //   Gain: '<S210>/Gain'
      //   Product: '<S210>/Divide1'

      FixedwingModel_B.Switch_l = ((rtb_jxi_d + FixedwingModel_P.Bias_Bias_j) *
        FixedwingModel_P.Gain_Gain_o + FixedwingModel_P.Bias1_Bias_e) * rtb_Rn;
    } else {
      // Switch: '<S210>/Switch'
      FixedwingModel_B.Switch_l = rtb_Rn;
    }

    // End of Switch: '<S210>/Switch'

    // UnitConversion: '<S218>/Unit Conversion'
    // Unit Conversion - from: deg to: rad
    // Expression: output = (0.0174533*input) + (0)
    rtb_jxi_d = 0.017453292519943295 * FixedwingModel_B.Switch_l;

    // Trigonometry: '<S219>/Trigonometric Function1'
    rtb_UniformRandomNumber4_j = std::sin(rtb_jxi_d);

    // Product: '<S219>/Product1' incorporates:
    //   Product: '<S216>/Product2'

    rtb_IntegratorSecondOrderLim_ff = rtb_Sum_gz * rtb_Sum_gz;

    // Sum: '<S219>/Sum1' incorporates:
    //   Constant: '<S219>/Constant'
    //   Product: '<S219>/Product1'

    rtb_UniformRandomNumber4_j = FixedwingModel_P.Constant_Value_k -
      rtb_IntegratorSecondOrderLim_ff * rtb_UniformRandomNumber4_j *
      rtb_UniformRandomNumber4_j;

    // Product: '<S216>/Product1' incorporates:
    //   Constant: '<S216>/Constant1'
    //   Sqrt: '<S216>/sqrt'

    rtb_Rn = FixedwingModel_P.Constant1_Value_cs / std::sqrt
      (rtb_UniformRandomNumber4_j);

    // Trigonometry: '<S216>/Trigonometric Function1' incorporates:
    //   Constant: '<S216>/Constant'
    //   Constant: '<S216>/Constant2'
    //   Product: '<S216>/Product3'
    //   Sum: '<S216>/Sum1'

    FixedwingModel_B.TrigonometricFunction1_m = rt_atan2d_snf
      (FixedwingModel_P.Constant2_Value_hi, (FixedwingModel_P.Constant_Value_ea
        - rtb_IntegratorSecondOrderLim_ff) * rtb_Rn / rtb_UniformRandomNumber4_j);

    // Trigonometry: '<S216>/Trigonometric Function2' incorporates:
    //   Constant: '<S216>/Constant3'
    //   Product: '<S216>/Product4'
    //   Trigonometry: '<S216>/Trigonometric Function'

    FixedwingModel_B.TrigonometricFunction2_n = rt_atan2d_snf
      (FixedwingModel_P.Constant3_Value_i, rtb_Rn * std::cos(rtb_jxi_d));
  }

  // Sum: '<S345>/Sum' incorporates:
  //   Sum: '<S194>/Sum'

  rtb_UniformRandomNumber7[0] = rtb_LowAltitudeScaleLength +
    FixedwingModel_B.yNoise[0];
  rtb_UniformRandomNumber7[1] = rtb_IntegratorSecondOrder_o2_e +
    FixedwingModel_B.yNoise[1];

  // Product: '<S202>/y*cos'
  rtb_UniformRandomNumber4_j = rtb_UniformRandomNumber7[1] *
    FixedwingModel_B.SinCos_o2_c;

  // Product: '<S202>/rad long ' incorporates:
  //   Product: '<S202>/x*sin'
  //   Sum: '<S202>/Sum1'

  rtb_jxi_d = (rtb_UniformRandomNumber7[0] * FixedwingModel_B.SinCos_o1_o +
               rtb_UniformRandomNumber4_j) *
    FixedwingModel_B.TrigonometricFunction2_n;

  // Unit Conversion - from: rad to: deg
  // Expression: output = (57.2958*input) + (0)
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // Switch: '<S201>/Switch1' incorporates:
    //   Constant: '<S201>/Constant'
    //   Constant: '<S201>/Constant1'

    if (rtb_DataTypeConversion2_e) {
      rtb_UniformRandomNumber4_j = FixedwingModel_P.Constant_Value_l;
    } else {
      rtb_UniformRandomNumber4_j = FixedwingModel_P.Constant1_Value_o;
    }

    // End of Switch: '<S201>/Switch1'

    // Sum: '<S201>/Sum' incorporates:
    //   Constant: '<S198>/ref_position'

    rtb_Rn = rtb_UniformRandomNumber4_j +
      FixedwingModel_P.ModelParam_GPSLatLong[1];

    // Switch: '<S211>/Switch' incorporates:
    //   Abs: '<S211>/Abs'
    //   Constant: '<S215>/Constant'
    //   RelationalOperator: '<S215>/Compare'

    if (std::abs(rtb_Rn) > FixedwingModel_P.CompareToConstant_const_f) {
      // Switch: '<S211>/Switch' incorporates:
      //   Bias: '<S211>/Bias'
      //   Bias: '<S211>/Bias1'
      //   Constant: '<S211>/Constant2'
      //   Math: '<S211>/Math Function1'

      FixedwingModel_B.Switch_h = rt_modd_snf(rtb_Rn +
        FixedwingModel_P.Bias_Bias_i, FixedwingModel_P.Constant2_Value_p) +
        FixedwingModel_P.Bias1_Bias_dh;
    } else {
      // Switch: '<S211>/Switch'
      FixedwingModel_B.Switch_h = rtb_Rn;
    }

    // End of Switch: '<S211>/Switch'
  }

  // Sum: '<S198>/Sum' incorporates:
  //   Product: '<S202>/rad lat'
  //   Product: '<S202>/x*cos'
  //   Product: '<S202>/y*sin'
  //   Sum: '<S202>/Sum'
  //   UnitConversion: '<S203>/Unit Conversion'

  frac_0[0] = (rtb_UniformRandomNumber7[0] * FixedwingModel_B.SinCos_o2_c -
               rtb_UniformRandomNumber7[1] * FixedwingModel_B.SinCos_o1_o) *
    FixedwingModel_B.TrigonometricFunction1_m * 57.295779513082323 +
    FixedwingModel_B.Switch_l;

  // Switch: '<S207>/Switch' incorporates:
  //   Abs: '<S207>/Abs'
  //   Bias: '<S207>/Bias'
  //   Bias: '<S207>/Bias1'
  //   Constant: '<S207>/Constant2'
  //   Constant: '<S208>/Constant'
  //   Math: '<S207>/Math Function1'
  //   RelationalOperator: '<S208>/Compare'

  if (std::abs(frac_0[0]) > FixedwingModel_P.CompareToConstant_const_l) {
    rtb_Sum_gz = rt_modd_snf(frac_0[0] + FixedwingModel_P.Bias_Bias_l,
      FixedwingModel_P.Constant2_Value_a) + FixedwingModel_P.Bias1_Bias_k;
  } else {
    rtb_Sum_gz = frac_0[0];
  }

  // End of Switch: '<S207>/Switch'

  // Abs: '<S204>/Abs1'
  rtb_Rn = std::abs(rtb_Sum_gz);

  // RelationalOperator: '<S206>/Compare' incorporates:
  //   Constant: '<S206>/Constant'

  rtb_Compare_n = (rtb_Rn > FixedwingModel_P.CompareToConstant_const_a);

  // Switch: '<S204>/Switch' incorporates:
  //   Bias: '<S204>/Bias'
  //   Bias: '<S204>/Bias1'
  //   Gain: '<S204>/Gain'
  //   Product: '<S204>/Divide1'

  if (rtb_Compare_n) {
    // Signum: '<S204>/Sign1'
    if (!rtIsNaN(rtb_Sum_gz)) {
      if (rtb_Sum_gz < 0.0) {
        rtb_Sum_gz = -1.0;
      } else {
        rtb_Sum_gz = (rtb_Sum_gz > 0.0);
      }
    }

    // End of Signum: '<S204>/Sign1'
    rtb_Sum_gz *= (rtb_Rn + FixedwingModel_P.Bias_Bias_c) *
      FixedwingModel_P.Gain_Gain_m + FixedwingModel_P.Bias1_Bias_bq;
  }

  // End of Switch: '<S204>/Switch'

  // DataTypeConversion: '<S152>/Data Type Conversion4' incorporates:
  //   Gain: '<S152>/latScale'

  rtb_IntegratorSecondOrderLim_ff = rt_roundd_snf(FixedwingModel_P.latScale_Gain
    * rtb_Sum_gz);
  if (rtIsNaN(rtb_IntegratorSecondOrderLim_ff) || rtIsInf
      (rtb_IntegratorSecondOrderLim_ff)) {
    rtb_IntegratorSecondOrderLim_ff = 0.0;
  } else {
    rtb_IntegratorSecondOrderLim_ff = std::fmod(rtb_IntegratorSecondOrderLim_ff,
      4.294967296E+9);
  }

  // Outport: '<Root>/MavHILGPS' incorporates:
  //   DataTypeConversion: '<S152>/Data Type Conversion4'

  FixedwingModel_Y.MavHILGPS.lat = rtb_IntegratorSecondOrderLim_ff < 0.0 ? -
    static_cast<int32_T>(static_cast<uint32_T>(-rtb_IntegratorSecondOrderLim_ff))
    : static_cast<int32_T>(static_cast<uint32_T>(rtb_IntegratorSecondOrderLim_ff));

  // Switch: '<S200>/Switch1' incorporates:
  //   Constant: '<S200>/Constant'
  //   Constant: '<S200>/Constant1'

  if (rtb_Compare_n) {
    rtb_UniformRandomNumber4_j = FixedwingModel_P.Constant_Value_bh;
  } else {
    rtb_UniformRandomNumber4_j = FixedwingModel_P.Constant1_Value_i;
  }

  // End of Switch: '<S200>/Switch1'

  // Sum: '<S200>/Sum' incorporates:
  //   Sum: '<S198>/Sum'
  //   UnitConversion: '<S203>/Unit Conversion'

  rtb_Sum_gz = (57.295779513082323 * rtb_jxi_d + FixedwingModel_B.Switch_h) +
    rtb_UniformRandomNumber4_j;

  // Switch: '<S205>/Switch' incorporates:
  //   Abs: '<S205>/Abs'
  //   Bias: '<S205>/Bias'
  //   Bias: '<S205>/Bias1'
  //   Constant: '<S205>/Constant2'
  //   Constant: '<S209>/Constant'
  //   Math: '<S205>/Math Function1'
  //   RelationalOperator: '<S209>/Compare'

  if (std::abs(rtb_Sum_gz) > FixedwingModel_P.CompareToConstant_const_k) {
    rtb_Sum_gz = rt_modd_snf(rtb_Sum_gz + FixedwingModel_P.Bias_Bias_os,
      FixedwingModel_P.Constant2_Value_n2) + FixedwingModel_P.Bias1_Bias_d;
  }

  // End of Switch: '<S205>/Switch'

  // DataTypeConversion: '<S152>/Data Type Conversion5' incorporates:
  //   Gain: '<S152>/lonScale'

  rtb_IntegratorSecondOrderLim_ff = rt_roundd_snf(FixedwingModel_P.lonScale_Gain
    * rtb_Sum_gz);
  if (rtIsNaN(rtb_IntegratorSecondOrderLim_ff) || rtIsInf
      (rtb_IntegratorSecondOrderLim_ff)) {
    rtb_IntegratorSecondOrderLim_ff = 0.0;
  } else {
    rtb_IntegratorSecondOrderLim_ff = std::fmod(rtb_IntegratorSecondOrderLim_ff,
      4.294967296E+9);
  }

  // Outport: '<Root>/MavHILGPS' incorporates:
  //   DataTypeConversion: '<S152>/Data Type Conversion5'

  FixedwingModel_Y.MavHILGPS.lon = rtb_IntegratorSecondOrderLim_ff < 0.0 ? -
    static_cast<int32_T>(static_cast<uint32_T>(-rtb_IntegratorSecondOrderLim_ff))
    : static_cast<int32_T>(static_cast<uint32_T>(rtb_IntegratorSecondOrderLim_ff));

  // Sum: '<S198>/Sum1' incorporates:
  //   Constant: '<S194>/ModelParam.envAltitude'
  //   Sum: '<S194>/Sum'
  //   UnaryMinus: '<S198>/Ze2height'

  Sum_l = -(Xe_idx_2 + FixedwingModel_B.yNoise[2]) -
    FixedwingModel_P.ModelParam_envAltitude;

  // Saturate: '<S194>/Saturation'
  if (Sum_l > FixedwingModel_P.Saturation_UpperSat_k) {
    Sum_l = FixedwingModel_P.Saturation_UpperSat_k;
  } else if (Sum_l < FixedwingModel_P.Saturation_LowerSat_bp) {
    Sum_l = FixedwingModel_P.Saturation_LowerSat_bp;
  }

  // End of Saturate: '<S194>/Saturation'

  // DataTypeConversion: '<S152>/Data Type Conversion6' incorporates:
  //   Gain: '<S152>/altScale'

  rtb_IntegratorSecondOrderLim_ff = rt_roundd_snf(FixedwingModel_P.altScale_Gain
    * Sum_l);
  if (rtIsNaN(rtb_IntegratorSecondOrderLim_ff) || rtIsInf
      (rtb_IntegratorSecondOrderLim_ff)) {
    rtb_IntegratorSecondOrderLim_ff = 0.0;
  } else {
    rtb_IntegratorSecondOrderLim_ff = std::fmod(rtb_IntegratorSecondOrderLim_ff,
      4.294967296E+9);
  }

  // Outport: '<Root>/MavHILGPS' incorporates:
  //   DataTypeConversion: '<S152>/Data Type Conversion6'

  FixedwingModel_Y.MavHILGPS.alt = rtb_IntegratorSecondOrderLim_ff < 0.0 ? -
    static_cast<int32_T>(static_cast<uint32_T>(-rtb_IntegratorSecondOrderLim_ff))
    : static_cast<int32_T>(static_cast<uint32_T>(rtb_IntegratorSecondOrderLim_ff));
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // DataTypeConversion: '<S152>/Data Type Conversion8' incorporates:
    //   Constant: '<S152>/ModelParam.GPSEphFinal'
    //   Gain: '<S152>/Gain6'

    rtb_IntegratorSecondOrderLim_ff = rt_roundd_snf
      (FixedwingModel_P.Gain6_Gain_f * FixedwingModel_P.ModelParam_GPSEphFinal);
    if (rtIsNaN(rtb_IntegratorSecondOrderLim_ff) || rtIsInf
        (rtb_IntegratorSecondOrderLim_ff)) {
      rtb_IntegratorSecondOrderLim_ff = 0.0;
    } else {
      rtb_IntegratorSecondOrderLim_ff = std::fmod
        (rtb_IntegratorSecondOrderLim_ff, 65536.0);
    }

    // DataTypeConversion: '<S152>/Data Type Conversion8'
    FixedwingModel_B.eph = static_cast<uint16_T>(rtb_IntegratorSecondOrderLim_ff
      < 0.0 ? static_cast<int32_T>(static_cast<uint16_T>(-static_cast<int16_T>(
      static_cast<uint16_T>(-rtb_IntegratorSecondOrderLim_ff)))) :
      static_cast<int32_T>(static_cast<uint16_T>(rtb_IntegratorSecondOrderLim_ff)));

    // DataTypeConversion: '<S152>/Data Type Conversion9' incorporates:
    //   Constant: '<S152>/ModelParam.GPSEpvFinal'
    //   Gain: '<S152>/Gain8'

    rtb_IntegratorSecondOrderLim_ff = rt_roundd_snf
      (FixedwingModel_P.Gain8_Gain_e * FixedwingModel_P.ModelParam_GPSEpvFinal);
    if (rtIsNaN(rtb_IntegratorSecondOrderLim_ff) || rtIsInf
        (rtb_IntegratorSecondOrderLim_ff)) {
      rtb_IntegratorSecondOrderLim_ff = 0.0;
    } else {
      rtb_IntegratorSecondOrderLim_ff = std::fmod
        (rtb_IntegratorSecondOrderLim_ff, 65536.0);
    }

    // DataTypeConversion: '<S152>/Data Type Conversion9'
    FixedwingModel_B.epv = static_cast<uint16_T>(rtb_IntegratorSecondOrderLim_ff
      < 0.0 ? static_cast<int32_T>(static_cast<uint16_T>(-static_cast<int16_T>(
      static_cast<uint16_T>(-rtb_IntegratorSecondOrderLim_ff)))) :
      static_cast<int32_T>(static_cast<uint16_T>(rtb_IntegratorSecondOrderLim_ff)));
  }

  // TransferFcn: '<S196>/Transfer Fcn1'
  rtb_jxi_d = FixedwingModel_P.TransferFcn1_C *
    FixedwingModel_X.TransferFcn1_CSTATE;

  // TransferFcn: '<S196>/Transfer Fcn2'
  rtb_UniformRandomNumber4_j = FixedwingModel_P.TransferFcn2_C *
    FixedwingModel_X.TransferFcn2_CSTATE;

  // Sum: '<S152>/Sum3' incorporates:
  //   TransferFcn: '<S196>/Transfer Fcn4'

  rtb_UniformRandomNumber7[0] = FixedwingModel_P.TransferFcn4_C *
    FixedwingModel_X.TransferFcn4_CSTATE + rtb_sigma_ugsigma_vg;
  rtb_UniformRandomNumber7[1] = rtb_Product2_g + rtb_jxi_d;
  rtb_UniformRandomNumber7[2] = Ve_idx_2 + rtb_UniformRandomNumber4_j;

  // MATLAB Function: '<S152>/GenCogVel'
  // MATLAB Function 'OutputPort/HILGPSModel/GenCogVel': '<S195>:1'
  // '<S195>:1:2' v=norm(u(1:2));
  rtb_jxi_d = 3.3121686421112381E-170;
  rtb_Sum_gz = std::abs(rtb_UniformRandomNumber7[0]);
  if (rtb_Sum_gz > 3.3121686421112381E-170) {
    rtb_Rn = 1.0;
    rtb_jxi_d = rtb_Sum_gz;
  } else {
    rtb_UniformRandomNumber4_j = rtb_Sum_gz / 3.3121686421112381E-170;
    rtb_Rn = rtb_UniformRandomNumber4_j * rtb_UniformRandomNumber4_j;
  }

  rtb_Sum_gz = std::abs(rtb_UniformRandomNumber7[1]);
  if (rtb_Sum_gz > rtb_jxi_d) {
    rtb_UniformRandomNumber4_j = rtb_jxi_d / rtb_Sum_gz;
    rtb_Rn = rtb_Rn * rtb_UniformRandomNumber4_j * rtb_UniformRandomNumber4_j +
      1.0;
    rtb_jxi_d = rtb_Sum_gz;
  } else {
    rtb_UniformRandomNumber4_j = rtb_Sum_gz / rtb_jxi_d;
    rtb_Rn += rtb_UniformRandomNumber4_j * rtb_UniformRandomNumber4_j;
  }

  rtb_Rn = rtb_jxi_d * std::sqrt(rtb_Rn);

  // '<S195>:1:4' if v < 1
  if (rtb_Rn < 1.0) {
    // '<S195>:1:5' cot = 0;
    rtb_jxi_d = 0.0;
  } else {
    // '<S195>:1:6' else
    // '<S195>:1:7' cot=atan2d(u(2),u(1));
    rtb_jxi_d = 57.295779513082323 * rt_atan2d_snf(rtb_UniformRandomNumber7[1],
      rtb_UniformRandomNumber7[0]);
  }

  // '<S195>:1:10' if cot<0
  if (rtb_jxi_d < 0.0) {
    // '<S195>:1:11' cot=cot+360;
    rtb_jxi_d += 360.0;
  }

  // DataTypeConversion: '<S152>/Data Type Conversion3' incorporates:
  //   Gain: '<S152>/VeScale'

  rtb_IntegratorSecondOrderLim_ff = rt_roundd_snf(FixedwingModel_P.VeScale_Gain *
    rtb_UniformRandomNumber7[0]);
  if (rtIsNaN(rtb_IntegratorSecondOrderLim_ff) || rtIsInf
      (rtb_IntegratorSecondOrderLim_ff)) {
    rtb_IntegratorSecondOrderLim_ff = 0.0;
  } else {
    rtb_IntegratorSecondOrderLim_ff = std::fmod(rtb_IntegratorSecondOrderLim_ff,
      65536.0);
  }

  rtb_WhiteNoise_l_idx_0 = rt_roundd_snf(FixedwingModel_P.VeScale_Gain *
    rtb_UniformRandomNumber7[1]);
  if (rtIsNaN(rtb_WhiteNoise_l_idx_0) || rtIsInf(rtb_WhiteNoise_l_idx_0)) {
    rtb_WhiteNoise_l_idx_0 = 0.0;
  } else {
    rtb_WhiteNoise_l_idx_0 = std::fmod(rtb_WhiteNoise_l_idx_0, 65536.0);
  }

  rtb_UniformRandomNumber4_j = rt_roundd_snf(FixedwingModel_P.VeScale_Gain *
    rtb_UniformRandomNumber7[2]);
  if (rtIsNaN(rtb_UniformRandomNumber4_j) || rtIsInf(rtb_UniformRandomNumber4_j))
  {
    rtb_UniformRandomNumber4_j = 0.0;
  } else {
    rtb_UniformRandomNumber4_j = std::fmod(rtb_UniformRandomNumber4_j, 65536.0);
  }

  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // DataTypeConversion: '<S152>/Data Type Conversion10'
    rtb_y3DFix = rt_roundd_snf(rtb_y3DFix);
    if (rtIsNaN(rtb_y3DFix) || rtIsInf(rtb_y3DFix)) {
      rtb_y3DFix = 0.0;
    } else {
      rtb_y3DFix = std::fmod(rtb_y3DFix, 256.0);
    }

    // DataTypeConversion: '<S152>/Data Type Conversion10'
    FixedwingModel_B.fix_type = static_cast<uint8_T>(rtb_y3DFix < 0.0 ?
      static_cast<int32_T>(static_cast<uint8_T>(-static_cast<int8_T>(
      static_cast<uint8_T>(-rtb_y3DFix)))) : static_cast<int32_T>
      (static_cast<uint8_T>(rtb_y3DFix)));

    // DataTypeConversion: '<S152>/Data Type Conversion11'
    rtb_y3DFix = rt_roundd_snf(rtb_ySats);
    if (rtIsNaN(rtb_y3DFix) || rtIsInf(rtb_y3DFix)) {
      rtb_y3DFix = 0.0;
    } else {
      rtb_y3DFix = std::fmod(rtb_y3DFix, 256.0);
    }

    // DataTypeConversion: '<S152>/Data Type Conversion11'
    FixedwingModel_B.satellites_visible = static_cast<uint8_T>(rtb_y3DFix < 0.0 ?
      static_cast<int32_T>(static_cast<uint8_T>(-static_cast<int8_T>(
      static_cast<uint8_T>(-rtb_y3DFix)))) : static_cast<int32_T>
      (static_cast<uint8_T>(rtb_y3DFix)));
  }

  // Outport: '<Root>/MavHILGPS' incorporates:
  //   BusCreator: '<S152>/Bus Creator'

  FixedwingModel_Y.MavHILGPS.time_usec = rtb_time_usec;
  FixedwingModel_Y.MavHILGPS.eph = FixedwingModel_B.eph;
  FixedwingModel_Y.MavHILGPS.epv = FixedwingModel_B.epv;

  // DataTypeConversion: '<S152>/Data Type Conversion2' incorporates:
  //   Gain: '<S152>/VelScale'
  //   MATLAB Function: '<S152>/GenCogVel'

  rtb_y3DFix = rt_roundd_snf(FixedwingModel_P.VelScale_Gain * rtb_Rn);
  if (rtIsNaN(rtb_y3DFix) || rtIsInf(rtb_y3DFix)) {
    rtb_y3DFix = 0.0;
  } else {
    rtb_y3DFix = std::fmod(rtb_y3DFix, 65536.0);
  }

  // Outport: '<Root>/MavHILGPS' incorporates:
  //   DataTypeConversion: '<S152>/Data Type Conversion2'
  //   DataTypeConversion: '<S152>/Data Type Conversion3'

  FixedwingModel_Y.MavHILGPS.vel = static_cast<uint16_T>(rtb_y3DFix < 0.0 ?
    static_cast<int32_T>(static_cast<uint16_T>(-static_cast<int16_T>(
    static_cast<uint16_T>(-rtb_y3DFix)))) : static_cast<int32_T>
    (static_cast<uint16_T>(rtb_y3DFix)));
  FixedwingModel_Y.MavHILGPS.vn = static_cast<int16_T>
    (rtb_IntegratorSecondOrderLim_ff < 0.0 ? static_cast<int32_T>
     (static_cast<int16_T>(-static_cast<int16_T>(static_cast<uint16_T>
        (-rtb_IntegratorSecondOrderLim_ff)))) : static_cast<int32_T>(
      static_cast<int16_T>(static_cast<uint16_T>(rtb_IntegratorSecondOrderLim_ff))));
  FixedwingModel_Y.MavHILGPS.ve = static_cast<int16_T>(rtb_WhiteNoise_l_idx_0 <
    0.0 ? static_cast<int32_T>(static_cast<int16_T>(-static_cast<int16_T>(
    static_cast<uint16_T>(-rtb_WhiteNoise_l_idx_0)))) : static_cast<int32_T>(
    static_cast<int16_T>(static_cast<uint16_T>(rtb_WhiteNoise_l_idx_0))));
  FixedwingModel_Y.MavHILGPS.vd = static_cast<int16_T>
    (rtb_UniformRandomNumber4_j < 0.0 ? static_cast<int32_T>(static_cast<int16_T>
      (-static_cast<int16_T>(static_cast<uint16_T>(-rtb_UniformRandomNumber4_j))))
     : static_cast<int32_T>(static_cast<int16_T>(static_cast<uint16_T>
       (rtb_UniformRandomNumber4_j))));

  // DataTypeConversion: '<S152>/Data Type Conversion7' incorporates:
  //   Gain: '<S152>/AngleScale'
  //   MATLAB Function: '<S152>/GenCogVel'

  rtb_IntegratorSecondOrderLim_ff = rt_roundd_snf
    (FixedwingModel_P.AngleScale_Gain * rtb_jxi_d);
  if (rtIsNaN(rtb_IntegratorSecondOrderLim_ff) || rtIsInf
      (rtb_IntegratorSecondOrderLim_ff)) {
    rtb_IntegratorSecondOrderLim_ff = 0.0;
  } else {
    rtb_IntegratorSecondOrderLim_ff = std::fmod(rtb_IntegratorSecondOrderLim_ff,
      65536.0);
  }

  // Outport: '<Root>/MavHILGPS' incorporates:
  //   BusCreator: '<S152>/Bus Creator'
  //   DataTypeConversion: '<S152>/Data Type Conversion7'

  FixedwingModel_Y.MavHILGPS.cog = static_cast<uint16_T>
    (rtb_IntegratorSecondOrderLim_ff < 0.0 ? static_cast<int32_T>
     (static_cast<uint16_T>(-static_cast<int16_T>(static_cast<uint16_T>
        (-rtb_IntegratorSecondOrderLim_ff)))) : static_cast<int32_T>(
      static_cast<uint16_T>(rtb_IntegratorSecondOrderLim_ff)));
  FixedwingModel_Y.MavHILGPS.fix_type = FixedwingModel_B.fix_type;
  FixedwingModel_Y.MavHILGPS.satellites_visible =
    FixedwingModel_B.satellites_visible;
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // DataTypeConversion: '<S7>/Data Type Conversion' incorporates:
    //   Constant: '<S7>/CopterID'

    rtb_IntegratorSecondOrderLim_ff = std::floor(FixedwingModel_P.CopterID_Value);
    if (rtIsNaN(rtb_IntegratorSecondOrderLim_ff) || rtIsInf
        (rtb_IntegratorSecondOrderLim_ff)) {
      rtb_IntegratorSecondOrderLim_ff = 0.0;
    } else {
      rtb_IntegratorSecondOrderLim_ff = std::fmod
        (rtb_IntegratorSecondOrderLim_ff, 4.294967296E+9);
    }

    // DataTypeConversion: '<S7>/Data Type Conversion'
    FixedwingModel_B.copterID = rtb_IntegratorSecondOrderLim_ff < 0.0 ? -
      static_cast<int32_T>(static_cast<uint32_T>
      (-rtb_IntegratorSecondOrderLim_ff)) : static_cast<int32_T>
      (static_cast<uint32_T>(rtb_IntegratorSecondOrderLim_ff));

    // DataTypeConversion: '<S7>/Data Type Conversion2' incorporates:
    //   Constant: '<S7>/UAVType'

    FixedwingModel_B.vehicleType = FixedwingModel_P.ModelParam_uavType;
  }

  // Sum: '<S158>/Add'
  s289_iter = 0;

  // If: '<S151>/If' incorporates:
  //   Merge: '<S151>/Merge'

  if (rtsiIsModeUpdateTimeStep(&(&FixedwingModel_M)->solverInfo)) {
    rtAction = static_cast<int8_T>(!(rtb_Add_m_tmp > 0.0));
    FixedwingModel_DW.If_ActiveSubsystem_j = rtAction;
  } else {
    rtAction = FixedwingModel_DW.If_ActiveSubsystem_j;
  }

  switch (rtAction) {
   case 0:
    // Outputs for IfAction SubSystem: '<S151>/Positive Trace' incorporates:
    //   ActionPort: '<S156>/Action Port'

    FixedwingModel_PositiveTrace(rtb_Add_m_tmp, rtb_VectorConcatenate_g,
      &FixedwingModel_B.Merge_m[0], &FixedwingModel_B.Merge_m[1],
      &FixedwingModel_P.PositiveTrace);

    // End of Outputs for SubSystem: '<S151>/Positive Trace'
    break;

   case 1:
    // Outputs for IfAction SubSystem: '<S151>/Negative Trace' incorporates:
    //   ActionPort: '<S155>/Action Port'

    FixedwingModel_NegativeTrace(rtb_VectorConcatenate_g,
      FixedwingModel_B.Merge_m, &FixedwingModel_DW.NegativeTrace,
      &FixedwingModel_P.NegativeTrace);

    // End of Outputs for SubSystem: '<S151>/Negative Trace'
    break;
  }

  // End of If: '<S151>/If'

  // Gain: '<S1>/Gain6' incorporates:
  //   Gain: '<S1>/Gain2'
  //   SecondOrderIntegrator: '<S14>/Integrator, Second-Order'

  rtb_Sum_gz = FixedwingModel_P.Gain2_Gain_lu *
    FixedwingModel_X.IntegratorSecondOrder_CSTATE_e[0] *
    FixedwingModel_P.Gain6_Gain_jk;

  // Gain: '<S1>/Gain7' incorporates:
  //   Gain: '<S1>/Gain3'
  //   SecondOrderIntegrator: '<S13>/Integrator, Second-Order'

  rtb_jxi_d = FixedwingModel_P.Gain3_Gain_c *
    FixedwingModel_X.IntegratorSecondOrder_CSTATE_h[0] *
    FixedwingModel_P.Gain7_Gain_o;

  // Gain: '<S1>/Gain10'
  rtb_UniformRandomNumber4_j = FixedwingModel_P.Gain10_Gain_g * rtb_jxi_d;

  // Gain: '<S1>/Gain9' incorporates:
  //   Gain: '<S1>/Gain5'
  //   SecondOrderIntegrator: '<S11>/Integrator, Second-Order'

  rtb_Gain9_d = FixedwingModel_P.Gain5_Gain_n *
    FixedwingModel_X.IntegratorSecondOrder_CSTATE_k[0] *
    FixedwingModel_P.Gain9_Gain_b;

  // Outport: '<Root>/MavVehile3DInfo' incorporates:
  //   BusCreator generated from: '<Root>/MavVehile3DInfo'
  //   Clock: '<S7>/Clock1'
  //   DataTypeConversion: '<S7>/Data Type Conversion10'
  //   DataTypeConversion: '<S7>/Data Type Conversion4'
  //   DataTypeConversion: '<S7>/Data Type Conversion5'
  //   DataTypeConversion: '<S7>/Data Type Conversion6'
  //   DataTypeConversion: '<S7>/Data Type Conversion7'
  //   DataTypeConversion: '<S7>/Data Type Conversion8'
  //   DataTypeConversion: '<S7>/Data Type Conversion9'
  //   Gain: '<S1>/Gain'
  //   Gain: '<S1>/Gain1'
  //   Gain: '<S1>/Gain4'
  //   Gain: '<S1>/Gain8'
  //   Gain: '<S8>/Gain3'
  //   Integrator: '<S346>/phi theta psi'
  //   SecondOrderIntegrator: '<S10>/Integrator, Second-Order'
  //   SecondOrderIntegrator: '<S12>/Integrator, Second-Order'

  FixedwingModel_Y.MavVehile3DInfo.copterID = FixedwingModel_B.copterID;
  FixedwingModel_Y.MavVehile3DInfo.vehicleType = FixedwingModel_B.vehicleType;
  FixedwingModel_Y.MavVehile3DInfo.runnedTime = Sum_p;
  FixedwingModel_Y.MavVehile3DInfo.VelE[0] = static_cast<real32_T>
    (rtb_sigma_ugsigma_vg);
  FixedwingModel_Y.MavVehile3DInfo.PosE[0] = static_cast<real32_T>
    (rtb_LowAltitudeScaleLength);
  FixedwingModel_Y.MavVehile3DInfo.AngEuler[0] = static_cast<real32_T>
    (FixedwingModel_P.Gain3_Gain * FixedwingModel_X.phithetapsi_CSTATE[0]);
  FixedwingModel_Y.MavVehile3DInfo.VelE[1] = static_cast<real32_T>
    (rtb_Product2_g);
  FixedwingModel_Y.MavVehile3DInfo.PosE[1] = static_cast<real32_T>
    (rtb_IntegratorSecondOrder_o2_e);
  FixedwingModel_Y.MavVehile3DInfo.AngEuler[1] = static_cast<real32_T>
    (FixedwingModel_P.Gain3_Gain * FixedwingModel_X.phithetapsi_CSTATE[1]);
  FixedwingModel_Y.MavVehile3DInfo.VelE[2] = static_cast<real32_T>(Ve_idx_2);
  FixedwingModel_Y.MavVehile3DInfo.PosE[2] = static_cast<real32_T>(Xe_idx_2);
  FixedwingModel_Y.MavVehile3DInfo.AngEuler[2] = static_cast<real32_T>
    (rtb_Eularrad_idx_2);
  FixedwingModel_Y.MavVehile3DInfo.AngQuatern[0] = static_cast<real32_T>
    (FixedwingModel_B.Merge_m[0]);
  FixedwingModel_Y.MavVehile3DInfo.AngQuatern[1] = static_cast<real32_T>
    (FixedwingModel_B.Merge_m[1]);
  FixedwingModel_Y.MavVehile3DInfo.AngQuatern[2] = static_cast<real32_T>
    (FixedwingModel_B.Merge_m[2]);
  FixedwingModel_Y.MavVehile3DInfo.AngQuatern[3] = static_cast<real32_T>
    (FixedwingModel_B.Merge_m[3]);
  FixedwingModel_Y.MavVehile3DInfo.MotorRPMS[0] = static_cast<real32_T>
    (FixedwingModel_P.Gain_Gain_k2 *
     FixedwingModel_X.IntegratorSecondOrder_CSTATE[0] *
     FixedwingModel_P.Gain1_Gain_e);
  FixedwingModel_Y.MavVehile3DInfo.MotorRPMS[1] = static_cast<real32_T>
    (rtb_Sum_gz);
  FixedwingModel_Y.MavVehile3DInfo.MotorRPMS[2] = static_cast<real32_T>
    (rtb_Sum_gz);
  FixedwingModel_Y.MavVehile3DInfo.MotorRPMS[3] = static_cast<real32_T>
    (rtb_jxi_d);
  FixedwingModel_Y.MavVehile3DInfo.MotorRPMS[4] = static_cast<real32_T>
    (rtb_UniformRandomNumber4_j);
  FixedwingModel_Y.MavVehile3DInfo.MotorRPMS[5] = static_cast<real32_T>
    (FixedwingModel_P.Gain4_Gain_d *
     FixedwingModel_X.IntegratorSecondOrder_CSTATE_a[0] *
     FixedwingModel_P.Gain8_Gain_d);
  FixedwingModel_Y.MavVehile3DInfo.MotorRPMS[6] = static_cast<real32_T>
    (rtb_Gain9_d);
  FixedwingModel_Y.MavVehile3DInfo.MotorRPMS[7] = static_cast<real32_T>
    (rtb_Gain9_d);
  FixedwingModel_Y.MavVehile3DInfo.AccB[0] = static_cast<real32_T>
    (rtb_DataTypeConversion2[0]);
  FixedwingModel_Y.MavVehile3DInfo.RateB[0] = static_cast<real32_T>(wb[0]);
  FixedwingModel_Y.MavVehile3DInfo.PosGPS[0] = rtb_LowAltitudeScaleLength;
  FixedwingModel_Y.MavVehile3DInfo.AccB[1] = static_cast<real32_T>
    (rtb_DataTypeConversion2[1]);
  FixedwingModel_Y.MavVehile3DInfo.RateB[1] = static_cast<real32_T>(wb[1]);
  FixedwingModel_Y.MavVehile3DInfo.PosGPS[1] = rtb_IntegratorSecondOrder_o2_e;
  FixedwingModel_Y.MavVehile3DInfo.AccB[2] = static_cast<real32_T>
    (rtb_DataTypeConversion2[2]);
  FixedwingModel_Y.MavVehile3DInfo.RateB[2] = static_cast<real32_T>(wb[2]);
  FixedwingModel_Y.MavVehile3DInfo.PosGPS[2] = Xe_idx_2;
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // MATLAB Function: '<S15>/FaultParamsExtract' incorporates:
    //   Constant: '<S15>/FaultID'
    //   Inport: '<Root>/inSILInts'

    FixedwingMod_FaultParamsExtract(FixedwingModel_P.FaultID_Value_b,
      FixedwingModel_U.inSILInts, inSILFloats,
      &FixedwingModel_B.sf_FaultParamsExtract,
      &FixedwingModel_DW.sf_FaultParamsExtract);

    // DataTypeConversion: '<Root>/Data Type Conversion2' incorporates:
    //   Inport: '<Root>/inCopterData'

    if (FixedwingModel_U.inCopterData[0] != 0.0) {
      // Switch: '<Root>/Switch' incorporates:
      //   Inport: '<Root>/inPWMs'

      rtb_Switch_j_0 = &FixedwingModel_U.inPWMs[0];
    } else {
      // Switch: '<Root>/Switch' incorporates:
      //   Constant: '<Root>/InitinputNoArmed'

      rtb_Switch_j_0 = &FixedwingModel_P.ModelInit_Inputs[0];
    }

    // End of DataTypeConversion: '<Root>/Data Type Conversion2'

    // Gain: '<Root>/Gain1'
    rtb_elevatorCmd = FixedwingModel_P.uav.elevator.max * rtb_Switch_j_0[1];

    // Gain: '<Root>/Gain'
    rtb_aileronCmd = FixedwingModel_P.uav.aileron.max * rtb_Switch_j_0[0];

    // Gain: '<Root>/Gain3' incorporates:
    //   Gain: '<Root>/Gain4'

    rtb_rudderCmd = FixedwingModel_P.Gain4_Gain_a * rtb_Switch_j_0[3] *
      FixedwingModel_P.uav.rudder.max;

    // Gain: '<Root>/Gain2' incorporates:
    //   Constant: '<Root>/Constant1'
    //   Sum: '<Root>/Sum'

    rtb_throttleCmd = (rtb_Switch_j_0[2] + FixedwingModel_P.Constant1_Value_pt) *
      FixedwingModel_P.Gain2_Gain_b;
  }

  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[4] == 0) {
    // Gain: '<S15>/Gain' incorporates:
    //   Gain: '<S16>/Output'
    //   RandomNumber: '<S16>/White Noise'

    FixedwingModel_B.Gain_l = std::sqrt
      (FixedwingModel_P.BandLimitedWhiteNoise_Cov) / 0.31622776601683794 *
      FixedwingModel_DW.NextOutput_p * FixedwingModel_P.Gain_Gain_g0;
  }

  // RelationalOperator: '<S17>/Gust Start' incorporates:
  //   Constant: '<S17>/Gust start time'

  rtb_Sum_gz = (Sum_p >= FixedwingModel_P.DiscreteWindGustModel_t_0);
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // Outputs for Enabled SubSystem: '<S17>/Distance into gust (x)' incorporates:
    //   EnablePort: '<S20>/Enable'

    if (rtsiIsModeUpdateTimeStep(&(&FixedwingModel_M)->solverInfo)) {
      // Logic: '<S17>/Logical Operator2' incorporates:
      //   Constant: '<S17>/Constant'

      if ((rtb_Sum_gz != 0.0) && FixedwingModel_P.DiscreteWindGustModel_Gx) {
        if (!FixedwingModel_DW.Distanceintogustx_MODE) {
          // InitializeConditions for Integrator: '<S20>/Distance into Gust (x) (Limited to gust length d)' 
          FixedwingModel_X.DistanceintoGustxLimitedtogus_i =
            FixedwingModel_P.DistanceintoGustxLimitedtogustl;
          FixedwingModel_DW.Distanceintogustx_MODE = true;
        }
      } else {
        FixedwingModel_DW.Distanceintogustx_MODE = false;
      }

      // End of Logic: '<S17>/Logical Operator2'
    }

    // End of Outputs for SubSystem: '<S17>/Distance into gust (x)'

    // SignalConversion generated from: '<S21>/Enable' incorporates:
    //   Constant: '<S17>/Constant1'
    //   Logic: '<S17>/Logical Operator1'

    FixedwingModel_B.HiddenBuf_InsertedFor_Distanc_b = ((rtb_Sum_gz != 0.0) &&
      FixedwingModel_P.DiscreteWindGustModel_Gy);
  }

  // Outputs for Enabled SubSystem: '<S17>/Distance into gust (x)' incorporates:
  //   EnablePort: '<S20>/Enable'

  if (FixedwingModel_DW.Distanceintogustx_MODE) {
    // Outputs for Enabled SubSystem: '<S17>/Distance into gust (x)'
    // Integrator: '<S20>/Distance into Gust (x) (Limited to gust length d)'
    // Limited  Integrator
    if (FixedwingModel_X.DistanceintoGustxLimitedtogus_i >=
        FixedwingModel_P.Distanceintogustx_d_m) {
      FixedwingModel_X.DistanceintoGustxLimitedtogus_i =
        FixedwingModel_P.Distanceintogustx_d_m;
    } else if (FixedwingModel_X.DistanceintoGustxLimitedtogus_i <=
               FixedwingModel_P.DistanceintoGustxLimitedtogus_g) {
      FixedwingModel_X.DistanceintoGustxLimitedtogus_i =
        FixedwingModel_P.DistanceintoGustxLimitedtogus_g;
    }

    // End of Outputs for SubSystem: '<S17>/Distance into gust (x)'

    // Integrator: '<S20>/Distance into Gust (x) (Limited to gust length d)'
    FixedwingModel_B.DistanceintoGustxLimitedtogustl =
      FixedwingModel_X.DistanceintoGustxLimitedtogus_i;
  }

  // End of Outputs for SubSystem: '<S17>/Distance into gust (x)'

  // Outputs for Enabled SubSystem: '<S17>/Distance into gust (y)'
  // Outputs for Enabled SubSystem: '<S17>/Distance into gust (y)'
  FixedwingMode_Distanceintogusty
    (FixedwingModel_B.HiddenBuf_InsertedFor_Distanc_b,
     FixedwingModel_P.Distanceintogusty_d_m, &FixedwingModel_B.Distanceintogusty,
     &FixedwingModel_DW.Distanceintogusty, &FixedwingModel_P.Distanceintogusty,
     &FixedwingModel_X.Distanceintogusty);

  // End of Outputs for SubSystem: '<S17>/Distance into gust (y)'
  // End of Outputs for SubSystem: '<S17>/Distance into gust (y)'
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // SignalConversion generated from: '<S22>/Enable' incorporates:
    //   Constant: '<S17>/Constant2'
    //   Logic: '<S17>/Logical Operator3'

    FixedwingModel_B.HiddenBuf_InsertedFor_Distanc_a = ((rtb_Sum_gz != 0.0) &&
      FixedwingModel_P.DiscreteWindGustModel_Gz);
  }

  // Outputs for Enabled SubSystem: '<S17>/Distance into gust (z)'
  // Outputs for Enabled SubSystem: '<S17>/Distance into gust (z)'
  FixedwingMode_Distanceintogusty
    (FixedwingModel_B.HiddenBuf_InsertedFor_Distanc_a,
     FixedwingModel_P.Distanceintogustz_d_m, &FixedwingModel_B.Distanceintogustz,
     &FixedwingModel_DW.Distanceintogustz, &FixedwingModel_P.Distanceintogustz,
     &FixedwingModel_X.Distanceintogustz);

  // End of Outputs for SubSystem: '<S17>/Distance into gust (z)'
  // End of Outputs for SubSystem: '<S17>/Distance into gust (z)'

  // Sum: '<S15>/Sum' incorporates:
  //   Constant: '<S17>/2'
  //   Gain: '<S17>/Gust magnitude//2.0'
  //   Gain: '<S17>/pi//Gust length'
  //   Sum: '<S17>/Sum1'
  //   Trigonometry: '<S17>/cos(pi*x//dm)'

  Sum_p = (FixedwingModel_P.u_Value - std::cos(3.1415926535897931 /
            FixedwingModel_P.DiscreteWindGustModel_d_m[0] *
            FixedwingModel_B.DistanceintoGustxLimitedtogustl)) *
    (FixedwingModel_P.DiscreteWindGustModel_v_m[0] / 2.0) +
    FixedwingModel_B.Gain_l;
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // SignalConversion generated from: '<S19>/ SFunction ' incorporates:
    //   Constant: '<Root>/flap'
    //   MATLAB Function: '<S15>/SteerEngineFaultModel'

    rtb_TmpSignalConversionAtSFunct[0] = rtb_elevatorCmd;
    rtb_TmpSignalConversionAtSFunct[1] = rtb_aileronCmd;
    rtb_TmpSignalConversionAtSFunct[2] = rtb_rudderCmd;
    rtb_TmpSignalConversionAtSFunct[3] = FixedwingModel_P.flap_Value;
    rtb_TmpSignalConversionAtSFunct[4] = rtb_throttleCmd;

    // MATLAB Function: '<S15>/SteerEngineFaultModel' incorporates:
    //   Constant: '<S15>/SteerNum'

    s330_iter = FixedwingModel_P.SteerEngineFault.SteerNum;

    //  ��ģ����Ҫ�õ�8άFaultParam������
    // ��˹���ID�ĸ�ʽӦ���ǣ�
    // inSILInts=[FaultID FaultID FaultID FaultID ...]
    // inSILInts=[param1 param2 param3 param4 param5 param6 param7 param8 ...] -> FaultParam 
    //  param��ÿһλ��ʾ������Ľ���ϵ����0��1����ʵ���Ͼ���pwm_out = pwm_in * param 
    //  ���param1=0������1ֱ�ӻ�����ʼ�����0
    // MATLAB Function 'Steering EngineFault/SteerEngineFaultModel': '<S19>:1'
    // '<S19>:1:9' y=inCmds;
    for (i = 0; i < 5; i++) {
      FixedwingModel_B.y_f[i] = rtb_TmpSignalConversionAtSFunct[i];
    }

    // Ĭ������²�ע����ϣ�ֱ�ӽ��������
    // '<S19>:1:11' if motNum<1
    if (FixedwingModel_P.SteerEngineFault.SteerNum < 1) {
      // '<S19>:1:12' motNum=int32(1);
      s330_iter = 1;
    }

    // '<S19>:1:15' if motNum>8
    if (s330_iter > 8) {
      // '<S19>:1:16' motNum=int32(8);
      s330_iter = 8;
    }

    // '<S19>:1:19' if hasFault
    if (FixedwingModel_B.sf_FaultParamsExtract.hasFault) {
      // ���ע���˹���
      // '<S19>:1:20' for i=1:motNum
      while (s289_iter <= s330_iter - 1) {
        // '<S19>:1:21' y(i) = inCmds(i) * FaultParams(i)+ noise* FaultParams(6); 
        FixedwingModel_B.y_f[s289_iter] =
          rtb_TmpSignalConversionAtSFunct[s289_iter] *
          FixedwingModel_B.sf_FaultParamsExtract.FaultParam[s289_iter] + Sum_p *
          FixedwingModel_B.sf_FaultParamsExtract.FaultParam[5];
        s289_iter++;
      }
    }
  }

  // Outport: '<Root>/outCopterData' incorporates:
  //   Constant: '<S4>/Constant'
  //   DataTypeConversion: '<S7>/Data Type Conversion10'
  //   DataTypeConversion: '<S7>/Data Type Conversion4'
  //   DataTypeConversion: '<S7>/Data Type Conversion9'

  FixedwingModel_Y.outCopterData[0] = static_cast<real32_T>
    (rtb_DataTypeConversion2[0]);
  FixedwingModel_Y.outCopterData[3] = static_cast<real32_T>(wb[0]);
  FixedwingModel_Y.outCopterData[6] = static_cast<real32_T>(rtb_sigma_ugsigma_vg);
  FixedwingModel_Y.outCopterData[1] = static_cast<real32_T>
    (rtb_DataTypeConversion2[1]);
  FixedwingModel_Y.outCopterData[4] = static_cast<real32_T>(wb[1]);
  FixedwingModel_Y.outCopterData[7] = static_cast<real32_T>(rtb_Product2_g);
  FixedwingModel_Y.outCopterData[2] = static_cast<real32_T>
    (rtb_DataTypeConversion2[2]);
  FixedwingModel_Y.outCopterData[5] = static_cast<real32_T>(wb[2]);
  FixedwingModel_Y.outCopterData[8] = static_cast<real32_T>(Ve_idx_2);
  for (i = 0; i < 5; i++) {
    FixedwingModel_Y.outCopterData[i + 9] = FixedwingModel_B.y_f[i];
  }

  std::memcpy(&FixedwingModel_Y.outCopterData[14],
              &FixedwingModel_P.Constant_Value_ki[0], 18U * sizeof(real_T));

  // End of Outport: '<Root>/outCopterData'

  // Sum: '<S10>/Sum2' incorporates:
  //   Gain: '<S10>/2*zeta * wn'
  //   Gain: '<S10>/wn^2'
  //   SecondOrderIntegrator: '<S10>/Integrator, Second-Order'
  //   Sum: '<S10>/Sum3'

  FixedwingModel_B.Sum2 = FixedwingModel_P.LinearSecondOrderActuators_wn_f *
    FixedwingModel_P.LinearSecondOrderActuators_wn_f * (FixedwingModel_B.y_f[4]
    - FixedwingModel_X.IntegratorSecondOrder_CSTATE[0]) - 2.0 *
    FixedwingModel_P.LinearSecondOrderActuators_z_fi *
    FixedwingModel_P.LinearSecondOrderActuators_wn_f *
    FixedwingModel_X.IntegratorSecondOrder_CSTATE[1];

  // Sum: '<S11>/Sum2' incorporates:
  //   Gain: '<S11>/2*zeta * wn'
  //   Gain: '<S11>/wn^2'
  //   SecondOrderIntegrator: '<S11>/Integrator, Second-Order'
  //   Sum: '<S11>/Sum3'

  FixedwingModel_B.Sum2_k = FixedwingModel_P.LinearSecondOrderActuator1_wn_f *
    FixedwingModel_P.LinearSecondOrderActuator1_wn_f * (FixedwingModel_B.y_f[3]
    - FixedwingModel_X.IntegratorSecondOrder_CSTATE_k[0]) - 2.0 *
    FixedwingModel_P.LinearSecondOrderActuator1_z_fi *
    FixedwingModel_P.LinearSecondOrderActuator1_wn_f *
    FixedwingModel_X.IntegratorSecondOrder_CSTATE_k[1];

  // Sum: '<S12>/Sum2' incorporates:
  //   Gain: '<S12>/2*zeta * wn'
  //   Gain: '<S12>/wn^2'
  //   SecondOrderIntegrator: '<S12>/Integrator, Second-Order'
  //   Sum: '<S12>/Sum3'

  FixedwingModel_B.Sum2_p = FixedwingModel_P.LinearSecondOrderActuator2_wn_f *
    FixedwingModel_P.LinearSecondOrderActuator2_wn_f * (FixedwingModel_B.y_f[2]
    - FixedwingModel_X.IntegratorSecondOrder_CSTATE_a[0]) - 2.0 *
    FixedwingModel_P.LinearSecondOrderActuator2_z_fi *
    FixedwingModel_P.LinearSecondOrderActuator2_wn_f *
    FixedwingModel_X.IntegratorSecondOrder_CSTATE_a[1];

  // Sum: '<S13>/Sum2' incorporates:
  //   Gain: '<S13>/2*zeta * wn'
  //   Gain: '<S13>/wn^2'
  //   SecondOrderIntegrator: '<S13>/Integrator, Second-Order'
  //   Sum: '<S13>/Sum3'

  FixedwingModel_B.Sum2_g = FixedwingModel_P.LinearSecondOrderActuator3_wn_f *
    FixedwingModel_P.LinearSecondOrderActuator3_wn_f * (FixedwingModel_B.y_f[1]
    - FixedwingModel_X.IntegratorSecondOrder_CSTATE_h[0]) - 2.0 *
    FixedwingModel_P.LinearSecondOrderActuator3_z_fi *
    FixedwingModel_P.LinearSecondOrderActuator3_wn_f *
    FixedwingModel_X.IntegratorSecondOrder_CSTATE_h[1];

  // Sum: '<S14>/Sum2' incorporates:
  //   Gain: '<S14>/2*zeta * wn'
  //   Gain: '<S14>/wn^2'
  //   SecondOrderIntegrator: '<S14>/Integrator, Second-Order'
  //   Sum: '<S14>/Sum3'

  FixedwingModel_B.Sum2_l = FixedwingModel_P.LinearSecondOrderActuator4_wn_f *
    FixedwingModel_P.LinearSecondOrderActuator4_wn_f * (FixedwingModel_B.y_f[0]
    - FixedwingModel_X.IntegratorSecondOrder_CSTATE_e[0]) - 2.0 *
    FixedwingModel_P.LinearSecondOrderActuator4_z_fi *
    FixedwingModel_P.LinearSecondOrderActuator4_wn_f *
    FixedwingModel_X.IntegratorSecondOrder_CSTATE_e[1];
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // UnitConversion: '<S72>/Unit Conversion' incorporates:
    //   Constant: '<S55>/Wingspan'

    // Unit Conversion - from: m to: ft
    // Expression: output = (3.28084*input) + (0)
    FixedwingModel_B.UnitConversion_ck = 3.280839895013123 *
      FixedwingModel_P.DrydenWindTurbulenceModelDisc_b;
  }

  // Outputs for Enabled SubSystem: '<S69>/Hpgw'
  // Constant: '<S69>/Constant1'
  FixedwingModel_Hpgw(FixedwingModel_P.DrydenWindTurbulenceModelDisc_e, frac_1,
                      FixedwingModel_B.sigma_wg_e, rtb_rgw_p_idx_1,
                      FixedwingModel_B.Product_a[3],
                      FixedwingModel_B.UnitConversion_ck, &FixedwingModel_B.Hpgw,
                      &FixedwingModel_DW.Hpgw, &FixedwingModel_P.Hpgw);

  // End of Outputs for SubSystem: '<S69>/Hpgw'

  // Outputs for Enabled SubSystem: '<S69>/Hqgw'
  // Constant: '<S69>/Constant2'
  FixedwingModel_Hqgw(FixedwingModel_P.DrydenWindTurbulenceModelDisc_e,
                      FixedwingModel_B.UnitConversion_i,
                      FixedwingModel_B.Hwgwz.Sum,
                      FixedwingModel_B.UnitConversion_ck, &FixedwingModel_B.Hqgw,
                      &FixedwingModel_DW.Hqgw, &FixedwingModel_P.Hqgw);

  // End of Outputs for SubSystem: '<S69>/Hqgw'

  // Outputs for Enabled SubSystem: '<S69>/Hrgw'
  // Constant: '<S69>/Constant3'
  FixedwingModel_Hrgw(FixedwingModel_P.DrydenWindTurbulenceModelDisc_e,
                      FixedwingModel_B.UnitConversion_i,
                      FixedwingModel_B.Hvgwz.Sum,
                      FixedwingModel_B.UnitConversion_ck, &FixedwingModel_B.Hrgw,
                      &FixedwingModel_DW.Hrgw, &FixedwingModel_P.Hrgw);

  // End of Outputs for SubSystem: '<S69>/Hrgw'

  // If: '<S74>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' incorporates:
  //   Constant: '<S28>/Constant_DCM'

  if (rtsiIsModeUpdateTimeStep(&(&FixedwingModel_M)->solverInfo)) {
    if (rtb_sincos_o1_idx_0 <= 1000.0) {
      rtAction = 0;
    } else if (rtb_sincos_o1_idx_0 >= 2000.0) {
      rtAction = 1;
    } else {
      rtAction = 2;
    }

    FixedwingModel_DW.ifHeightMaxlowaltitudeelseifH_j = rtAction;
  } else {
    rtAction = FixedwingModel_DW.ifHeightMaxlowaltitudeelseifH_j;
  }

  switch (rtAction) {
   case 0:
    // Outputs for IfAction SubSystem: '<S74>/Low altitude  rates' incorporates:
    //   ActionPort: '<S89>/Action Port'

    FixedwingModel_Lowaltituderates(FixedwingModel_P.Constant_DCM_Value,
      FixedwingModel_B.Hpgw.Sum, FixedwingModel_B.Hqgw.Sum1,
      FixedwingModel_B.Hrgw.Sum1, FixedwingModel_B.UnitConversion_c, wb);

    // End of Outputs for SubSystem: '<S74>/Low altitude  rates'
    break;

   case 1:
    break;

   case 2:
    // Outputs for IfAction SubSystem: '<S74>/Interpolate  rates' incorporates:
    //   ActionPort: '<S88>/Action Port'

    FixedwingModel_Interpolaterates(FixedwingModel_B.Hpgw.Sum,
      FixedwingModel_B.Hqgw.Sum1, FixedwingModel_B.Hrgw.Sum1,
      FixedwingModel_P.Constant_DCM_Value, FixedwingModel_B.UnitConversion_c,
      rtb_sincos_o1_idx_0, wb, &FixedwingModel_P.Interpolaterates);

    // End of Outputs for SubSystem: '<S74>/Interpolate  rates'
    break;
  }

  // End of If: '<S74>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // UnitConversion: '<S111>/Unit Conversion' incorporates:
    //   Constant: '<S56>/Wingspan'

    // Unit Conversion - from: m to: ft
    // Expression: output = (3.28084*input) + (0)
    FixedwingModel_B.UnitConversion_m = 3.280839895013123 *
      FixedwingModel_P.DrydenWindTurbulenceModelDis_bc;
  }

  // Outputs for Enabled SubSystem: '<S108>/Hpgw'
  // Constant: '<S108>/Constant1'
  FixedwingModel_Hpgw(FixedwingModel_P.DrydenWindTurbulenceModelDisc_f,
                      rtb_pgw_p, FixedwingModel_B.sigma_wg_o, rtb_rgw_p_idx_0,
                      FixedwingModel_B.Product_p[3],
                      FixedwingModel_B.UnitConversion_m,
                      &FixedwingModel_B.Hpgw_h, &FixedwingModel_DW.Hpgw_h,
                      &FixedwingModel_P.Hpgw_h);

  // End of Outputs for SubSystem: '<S108>/Hpgw'

  // Outputs for Enabled SubSystem: '<S108>/Hqgw'
  // Constant: '<S108>/Constant2'
  FixedwingModel_Hqgw(FixedwingModel_P.DrydenWindTurbulenceModelDisc_f,
                      FixedwingModel_B.UnitConversion_g,
                      FixedwingModel_B.Hwgwz_j.Sum,
                      FixedwingModel_B.UnitConversion_m,
                      &FixedwingModel_B.Hqgw_p, &FixedwingModel_DW.Hqgw_p,
                      &FixedwingModel_P.Hqgw_p);

  // End of Outputs for SubSystem: '<S108>/Hqgw'

  // Outputs for Enabled SubSystem: '<S108>/Hrgw'
  // Constant: '<S108>/Constant3'
  FixedwingModel_Hrgw(FixedwingModel_P.DrydenWindTurbulenceModelDisc_f,
                      FixedwingModel_B.UnitConversion_g,
                      FixedwingModel_B.Hvgwz_o.Sum,
                      FixedwingModel_B.UnitConversion_m,
                      &FixedwingModel_B.Hrgw_a, &FixedwingModel_DW.Hrgw_a,
                      &FixedwingModel_P.Hrgw_a);

  // End of Outputs for SubSystem: '<S108>/Hrgw'

  // If: '<S113>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' incorporates:
  //   Constant: '<S28>/Constant_DCM'

  if (rtsiIsModeUpdateTimeStep(&(&FixedwingModel_M)->solverInfo)) {
    if (rtb_sincos_o1_idx_0 <= 1000.0) {
      rtAction = 0;
    } else if (rtb_sincos_o1_idx_0 >= 2000.0) {
      rtAction = 1;
    } else {
      rtAction = 2;
    }

    FixedwingModel_DW.ifHeightMaxlowaltitudeelseifH_g = rtAction;
  } else {
    rtAction = FixedwingModel_DW.ifHeightMaxlowaltitudeelseifH_g;
  }

  switch (rtAction) {
   case 0:
    // Outputs for IfAction SubSystem: '<S113>/Low altitude  rates' incorporates:
    //   ActionPort: '<S128>/Action Port'

    FixedwingModel_Lowaltituderates(FixedwingModel_P.Constant_DCM_Value,
      FixedwingModel_B.Hpgw_h.Sum, FixedwingModel_B.Hqgw_p.Sum1,
      FixedwingModel_B.Hrgw_a.Sum1, FixedwingModel_B.UnitConversion_kf, wb);

    // End of Outputs for SubSystem: '<S113>/Low altitude  rates'
    break;

   case 1:
    break;

   case 2:
    // Outputs for IfAction SubSystem: '<S113>/Interpolate  rates' incorporates:
    //   ActionPort: '<S127>/Action Port'

    FixedwingModel_Interpolaterates(FixedwingModel_B.Hpgw_h.Sum,
      FixedwingModel_B.Hqgw_p.Sum1, FixedwingModel_B.Hrgw_a.Sum1,
      FixedwingModel_P.Constant_DCM_Value, FixedwingModel_B.UnitConversion_kf,
      rtb_sincos_o1_idx_0, wb, &FixedwingModel_P.Interpolaterates_a);

    // End of Outputs for SubSystem: '<S113>/Interpolate  rates'
    break;
  }

  // End of If: '<S113>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // If: '<S157>/If1' incorporates:
    //   Constant: '<S157>/Constant'

    rtAction = -1;
    if (rtsiIsModeUpdateTimeStep(&(&FixedwingModel_M)->solverInfo)) {
      if (FixedwingModel_P.DirectionCosineMatrixtoQuaterni != 1.0) {
        rtAction = 0;
      }

      FixedwingModel_DW.If1_ActiveSubsystem = rtAction;
    } else {
      rtAction = FixedwingModel_DW.If1_ActiveSubsystem;
    }

    if (rtAction == 0) {
      // Outputs for IfAction SubSystem: '<S157>/If Warning//Error' incorporates:
      //   ActionPort: '<S181>/if'

      FixedwingModel_IfWarningError(rtb_VectorConcatenate_g,
        FixedwingModel_P.DirectionCosineMatrixtoQuaterni,
        FixedwingModel_P.DirectionCosineMatrixtoQuate_o3,
        &FixedwingModel_P.IfWarningError);

      // End of Outputs for SubSystem: '<S157>/If Warning//Error'
    }

    // End of If: '<S157>/If1'
  }

  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[5] == 0) {
    // Gain: '<S152>/BiasGain1' incorporates:
    //   UniformRandomNumber: '<S152>/Uniform Random Number4'

    FixedwingModel_B.BiasGain1[0] = FixedwingModel_P.BiasGain1_Gain *
      FixedwingModel_DW.UniformRandomNumber4_NextOutp_l[0];
    FixedwingModel_B.BiasGain1[1] = FixedwingModel_P.BiasGain1_Gain *
      FixedwingModel_DW.UniformRandomNumber4_NextOutp_l[1];
    FixedwingModel_B.BiasGain1[2] = FixedwingModel_P.BiasGain1_Gain *
      FixedwingModel_DW.UniformRandomNumber4_NextOutp_l[2];
  }

  // Gain: '<S252>/2*zeta * wn'
  // //rad
  // MATLAB Function 'OutputPort/HILGPSModel/-pi-pi---->0-2pi': '<S193>:1'
  // '<S193>:1:3' if yaw180>0
  rtb_UniformRandomNumber4_j = 2.0 *
    FixedwingModel_P.FaultParamAPI.FaultInParams[9] *
    FixedwingModel_P.ThreeaxisInertialMeasurement_mp;

  // Gain: '<S252>/wn^2'
  Sum_p = FixedwingModel_P.ThreeaxisInertialMeasurement_mp *
    FixedwingModel_P.ThreeaxisInertialMeasurement_mp;

  // Sum: '<S252>/Sum2' incorporates:
  //   Gain: '<S252>/2*zeta * wn'
  //   Gain: '<S252>/wn^2'
  //   SecondOrderIntegrator: '<S252>/Integrator, Second-Order Limited'
  //   Sum: '<S252>/Sum3'

  FixedwingModel_B.Sum2_o[0] = (rtb_Sum4_p[0] -
    FixedwingModel_X.IntegratorSecondOrderLimited_CS[0]) * Sum_p -
    rtb_UniformRandomNumber4_j *
    FixedwingModel_X.IntegratorSecondOrderLimited_CS[3];
  FixedwingModel_B.Sum2_o[1] = (rtb_Sum4_p[1] -
    FixedwingModel_X.IntegratorSecondOrderLimited_CS[1]) * Sum_p -
    rtb_UniformRandomNumber4_j *
    FixedwingModel_X.IntegratorSecondOrderLimited_CS[4];
  FixedwingModel_B.Sum2_o[2] = (rtb_Sum4_p[2] -
    FixedwingModel_X.IntegratorSecondOrderLimited_CS[2]) * Sum_p -
    rtb_UniformRandomNumber4_j *
    FixedwingModel_X.IntegratorSecondOrderLimited_CS[5];

  // Gain: '<S263>/2*zeta * wn'
  rtb_UniformRandomNumber4_j = 2.0 *
    FixedwingModel_P.FaultParamAPI.FaultInParams[13] *
    FixedwingModel_P.ThreeaxisInertialMeasurementU_e;

  // Gain: '<S263>/wn^2'
  Sum_p = FixedwingModel_P.ThreeaxisInertialMeasurementU_e *
    FixedwingModel_P.ThreeaxisInertialMeasurementU_e;

  // Sum: '<S263>/Sum2' incorporates:
  //   Gain: '<S263>/2*zeta * wn'
  //   Gain: '<S263>/wn^2'
  //   Sum: '<S263>/Sum3'

  FixedwingModel_B.Sum2_pq[0] = (rtb_Gain_d[0] - rtb_ubvbwb[0]) * Sum_p -
    rtb_UniformRandomNumber4_j * rtb_IntegratorSecondOrderLimi_m[0];
  FixedwingModel_B.Sum2_pq[1] = (rtb_Gain_d[1] - rtb_ubvbwb[1]) * Sum_p -
    rtb_UniformRandomNumber4_j * rtb_IntegratorSecondOrderLimi_m[1];
  FixedwingModel_B.Sum2_pq[2] = (rtb_Gain_d[2] - rtb_ubvbwb[2]) * Sum_p -
    rtb_UniformRandomNumber4_j * rtb_IntegratorSecondOrderLimi_m[2];
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // Assertion: '<S264>/Assertion' incorporates:
    //   Constant: '<S264>/max_val'
    //   Constant: '<S264>/min_val'
    //   Logic: '<S264>/conjunction'
    //   RelationalOperator: '<S264>/max_relop'
    //   RelationalOperator: '<S264>/min_relop'

    utAssert((FixedwingModel_P.CheckAltitude_min <= rtb_Add) && (rtb_Add <=
              FixedwingModel_P.CheckAltitude_max));

    // Assertion: '<S265>/Assertion' incorporates:
    //   Constant: '<S265>/max_val'
    //   Constant: '<S265>/min_val'
    //   Logic: '<S265>/conjunction'
    //   RelationalOperator: '<S265>/max_relop'
    //   RelationalOperator: '<S265>/min_relop'

    utAssert((FixedwingModel_P.CheckLatitude_min <= rtb_sincos_o1_i_idx_0) &&
             (rtb_sincos_o1_i_idx_0 <= FixedwingModel_P.CheckLatitude_max));

    // Assertion: '<S266>/Assertion' incorporates:
    //   Constant: '<S266>/max_val'
    //   Constant: '<S266>/min_val'
    //   Logic: '<S266>/conjunction'
    //   RelationalOperator: '<S266>/max_relop'
    //   RelationalOperator: '<S266>/min_relop'

    utAssert((FixedwingModel_P.CheckLongitude_min <= rtb_jxi) && (rtb_jxi <=
              FixedwingModel_P.CheckLongitude_max));

    // Assertion: '<S268>/Assertion' incorporates:
    //   Constant: '<S268>/max_val'
    //   Constant: '<S268>/min_val'
    //   Logic: '<S268>/conjunction'
    //   RelationalOperator: '<S268>/max_relop'
    //   RelationalOperator: '<S268>/min_relop'

    utAssert((FixedwingModel_P.Istimewithinmodellimits_min <= rtb_Sum_le) &&
             (rtb_Sum_le <= FixedwingModel_P.Istimewithinmodellimits_max));
  }

  // Fcn: '<S355>/phidot' incorporates:
  //   Fcn: '<S355>/psidot'

  // MATLAB Function 'OutputPort/HILSensorMavModel/AccelNoiseGainFunction': '<S223>:1' 
  // '<S223>:1:3' if theta>0.1
  // MATLAB Function 'OutputPort/HILSensorMavModel/GyroNoiseGainFunction': '<S224>:1' 
  // '<S224>:1:3' if theta>0.1
  // MATLAB Function 'OutputPort/HILSensorMavModel/MagNoiseGainFunction': '<S225>:1' 
  // '<S225>:1:3' if theta>0.1
  rtb_Sum_le = rtb_Sum4_a_tmp_0 * rtb_ZeroOrderHold[1] + rtb_ubvbwb_tmp_0 *
    rtb_ZeroOrderHold[2];

  // SignalConversion generated from: '<S346>/phi theta psi' incorporates:
  //   Fcn: '<S355>/phidot'
  //   Fcn: '<S355>/psidot'
  //   Fcn: '<S355>/thetadot'

  FixedwingModel_B.TmpSignalConversionAtphithetaps[0] = rtb_Sum4_a_tmp /
    rtb_ubvbwb_tmp * rtb_Sum_le + rtb_ZeroOrderHold[0];
  FixedwingModel_B.TmpSignalConversionAtphithetaps[1] = rtb_ubvbwb_tmp_0 *
    rtb_ZeroOrderHold[1] - rtb_Sum4_a_tmp_0 * rtb_ZeroOrderHold[2];
  FixedwingModel_B.TmpSignalConversionAtphithetaps[2] = rtb_Sum_le /
    rtb_ubvbwb_tmp;

  // Sum: '<S341>/Sum' incorporates:
  //   Integrator: '<S341>/ub,vb,wb'
  //   Product: '<S362>/i x j'
  //   Product: '<S362>/j x k'
  //   Product: '<S362>/k x i'
  //   Product: '<S363>/i x k'
  //   Product: '<S363>/j x i'
  //   Product: '<S363>/k x j'
  //   Sum: '<S349>/Sum'

  FixedwingModel_B.Sum_c[0] = (FixedwingModel_X.ubvbwb_CSTATE[1] *
    rtb_ZeroOrderHold[2] - rtb_ZeroOrderHold[1] *
    FixedwingModel_X.ubvbwb_CSTATE[2]) + mv0_tmp;
  FixedwingModel_B.Sum_c[1] = (rtb_ZeroOrderHold[0] *
    FixedwingModel_X.ubvbwb_CSTATE[2] - FixedwingModel_X.ubvbwb_CSTATE[0] *
    rtb_ZeroOrderHold[2]) + rtb_DataTypeConversion2_tmp;
  FixedwingModel_B.Sum_c[2] = (FixedwingModel_X.ubvbwb_CSTATE[0] *
    rtb_ZeroOrderHold[1] - rtb_ZeroOrderHold[0] *
    FixedwingModel_X.ubvbwb_CSTATE[1]) + rtb_DataTypeConversion2_tmp_0;
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // If: '<S418>/If1' incorporates:
    //   Constant: '<S418>/Constant'

    rtAction = -1;
    if (rtsiIsModeUpdateTimeStep(&(&FixedwingModel_M)->solverInfo)) {
      if (FixedwingModel_P.DirectionCosineMatrixtoQuater_o != 1.0) {
        rtAction = 0;
      }

      FixedwingModel_DW.If1_ActiveSubsystem_o = rtAction;
    } else {
      rtAction = FixedwingModel_DW.If1_ActiveSubsystem_o;
    }

    if (rtAction == 0) {
      // Outputs for IfAction SubSystem: '<S418>/If Warning//Error' incorporates:
      //   ActionPort: '<S442>/if'

      FixedwingModel_IfWarningError(rtb_VectorConcatenate_g,
        FixedwingModel_P.DirectionCosineMatrixtoQuater_o,
        FixedwingModel_P.DirectionCosineMatrixtoQuater_p,
        &FixedwingModel_P.IfWarningError_g);

      // End of Outputs for SubSystem: '<S418>/If Warning//Error'
    }

    // End of If: '<S418>/If1'

    // If: '<S456>/If1' incorporates:
    //   Constant: '<S456>/Constant'

    rtAction = -1;
    if (rtsiIsModeUpdateTimeStep(&(&FixedwingModel_M)->solverInfo)) {
      if (FixedwingModel_P.DirectionCosineMatrixtoQuater_c != 1.0) {
        rtAction = 0;
      }

      FixedwingModel_DW.If1_ActiveSubsystem_oz = rtAction;
    } else {
      rtAction = FixedwingModel_DW.If1_ActiveSubsystem_oz;
    }

    if (rtAction == 0) {
      // Outputs for IfAction SubSystem: '<S456>/If Warning//Error' incorporates:
      //   ActionPort: '<S480>/if'

      FixedwingModel_IfWarningError(rtb_VectorConcatenate_bz,
        FixedwingModel_P.DirectionCosineMatrixtoQuater_c,
        FixedwingModel_P.DirectionCosineMatrixtoQuater_k,
        &FixedwingModel_P.IfWarningError_j);

      // End of Outputs for SubSystem: '<S456>/If Warning//Error'
    }

    // End of If: '<S456>/If1'

    // Gain: '<S345>/Zero-Order Hold2'
    FixedwingModel_B.ZeroOrderHold2 = FixedwingModel_P.ZeroOrderHold2_Gain_n *
      0.0;
  }

  // Gain: '<S512>/2*zeta * wn'
  rtb_UniformRandomNumber4_j = 2.0 * FixedwingModel_P.SecondorderDynamics_zn *
    FixedwingModel_P.SecondorderDynamics_wn;

  // SecondOrderIntegrator: '<S512>/Integrator, Second-Order Limited'
  rtb_DataTypeConversion2[0] = FixedwingModel_X.IntegratorSecondOrderLimited__o
    [0];

  // Gain: '<S512>/2*zeta * wn' incorporates:
  //   SecondOrderIntegrator: '<S512>/Integrator, Second-Order Limited'

  rtb_IntegratorSecondOrderLimite[0] = rtb_UniformRandomNumber4_j *
    FixedwingModel_X.IntegratorSecondOrderLimited__o[3];

  // SecondOrderIntegrator: '<S512>/Integrator, Second-Order Limited'
  rtb_DataTypeConversion2[1] = FixedwingModel_X.IntegratorSecondOrderLimited__o
    [1];

  // Gain: '<S512>/2*zeta * wn' incorporates:
  //   SecondOrderIntegrator: '<S512>/Integrator, Second-Order Limited'

  rtb_IntegratorSecondOrderLimite[1] = rtb_UniformRandomNumber4_j *
    FixedwingModel_X.IntegratorSecondOrderLimited__o[4];

  // SecondOrderIntegrator: '<S512>/Integrator, Second-Order Limited'
  rtb_DataTypeConversion2[2] = FixedwingModel_X.IntegratorSecondOrderLimited__o
    [2];

  // Gain: '<S512>/2*zeta * wn' incorporates:
  //   SecondOrderIntegrator: '<S512>/Integrator, Second-Order Limited'

  rtb_IntegratorSecondOrderLimite[2] = rtb_UniformRandomNumber4_j *
    FixedwingModel_X.IntegratorSecondOrderLimited__o[5];

  // Gain: '<S345>/Zero-Order Hold'
  rtb_ZeroOrderHold[0] *= FixedwingModel_P.ZeroOrderHold_Gain_l;
  rtb_ZeroOrderHold[1] *= FixedwingModel_P.ZeroOrderHold_Gain_l;
  rtb_ZeroOrderHold[2] *= FixedwingModel_P.ZeroOrderHold_Gain_l;
  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // Gain: '<S345>/Gain' incorporates:
    //   Constant: '<S345>/wl_ins'
    //   Constant: '<S8>/Constant'
    //   Gain: '<S345>/Zero-Order Hold4'
    //   Sum: '<S345>/Sum7'

    FixedwingModel_B.Gain_c[0] = (FixedwingModel_P.ZeroOrderHold4_Gain_j *
      FixedwingModel_P.Constant_Value_nk[0] -
      FixedwingModel_P.ThreeaxisAccelerometer_acc[0]) *
      FixedwingModel_P.Gain_Gain_il[0];
    FixedwingModel_B.Gain_c[1] = (FixedwingModel_P.ZeroOrderHold4_Gain_j *
      FixedwingModel_P.Constant_Value_nk[1] -
      FixedwingModel_P.ThreeaxisAccelerometer_acc[1]) *
      FixedwingModel_P.Gain_Gain_il[1];
    FixedwingModel_B.Gain_c[2] = (FixedwingModel_P.ZeroOrderHold4_Gain_j *
      FixedwingModel_P.Constant_Value_nk[2] -
      FixedwingModel_P.ThreeaxisAccelerometer_acc[2]) *
      FixedwingModel_P.Gain_Gain_il[2];
  }

  // Sum: '<S345>/Sum' incorporates:
  //   Product: '<S517>/i x j'
  //   Product: '<S517>/j x k'
  //   Product: '<S517>/k x i'
  //   Product: '<S518>/i x k'
  //   Product: '<S518>/j x i'
  //   Product: '<S518>/k x j'
  //   Sum: '<S514>/Sum'

  rtb_UniformRandomNumber7[0] = rtb_ZeroOrderHold[1] * FixedwingModel_B.Gain_c[2]
    - FixedwingModel_B.Gain_c[1] * rtb_ZeroOrderHold[2];
  rtb_UniformRandomNumber7[1] = FixedwingModel_B.Gain_c[0] * rtb_ZeroOrderHold[2]
    - rtb_ZeroOrderHold[0] * FixedwingModel_B.Gain_c[2];
  rtb_UniformRandomNumber7[2] = rtb_ZeroOrderHold[0] * FixedwingModel_B.Gain_c[1]
    - FixedwingModel_B.Gain_c[0] * rtb_ZeroOrderHold[1];

  // Gain: '<S345>/Zero-Order Hold3'
  rtb_Gain_d[0] = FixedwingModel_P.ZeroOrderHold3_Gain_b *
    FixedwingModel_B.Product2[0];
  rtb_Gain_d[1] = FixedwingModel_P.ZeroOrderHold3_Gain_b *
    FixedwingModel_B.Product2[1];
  rtb_Gain_d[2] = FixedwingModel_P.ZeroOrderHold3_Gain_b *
    FixedwingModel_B.Product2[2];

  // Gain: '<S512>/wn^2'
  rtb_UniformRandomNumber4_j = FixedwingModel_P.SecondorderDynamics_wn *
    FixedwingModel_P.SecondorderDynamics_wn;

  // Sum: '<S345>/Sum' incorporates:
  //   Gain: '<S345>/Zero-Order Hold1'
  //   Product: '<S515>/i x j'
  //   Product: '<S515>/j x k'
  //   Product: '<S515>/k x i'
  //   Product: '<S516>/i x k'
  //   Product: '<S516>/j x i'
  //   Product: '<S516>/k x j'
  //   Product: '<S519>/i x j'
  //   Product: '<S519>/j x k'
  //   Product: '<S519>/k x i'
  //   Product: '<S520>/i x k'
  //   Product: '<S520>/j x i'
  //   Product: '<S520>/k x j'
  //   Sum: '<S510>/Sum'
  //   Sum: '<S513>/Sum'

  rtb_Product2_g = ((FixedwingModel_P.ZeroOrderHold1_Gain_f *
                     FixedwingModel_B.Sum_c[0] - FixedwingModel_B.ZeroOrderHold2)
                    + (rtb_ZeroOrderHold[1] * rtb_UniformRandomNumber7[2] -
                       rtb_UniformRandomNumber7[1] * rtb_ZeroOrderHold[2])) +
    (rtb_Gain_d[1] * FixedwingModel_B.Gain_c[2] - FixedwingModel_B.Gain_c[1] *
     rtb_Gain_d[2]);
  Xe_idx_2 = ((FixedwingModel_P.ZeroOrderHold1_Gain_f * FixedwingModel_B.Sum_c[1]
               - FixedwingModel_B.ZeroOrderHold2) + (rtb_UniformRandomNumber7[0]
    * rtb_ZeroOrderHold[2] - rtb_ZeroOrderHold[0] * rtb_UniformRandomNumber7[2]))
    + (FixedwingModel_B.Gain_c[0] * rtb_Gain_d[2] - rtb_Gain_d[0] *
       FixedwingModel_B.Gain_c[2]);
  Ve_idx_2 = ((FixedwingModel_P.ZeroOrderHold1_Gain_f * FixedwingModel_B.Sum_c[2]
               - FixedwingModel_B.ZeroOrderHold2) + (rtb_ZeroOrderHold[0] *
    rtb_UniformRandomNumber7[1] - rtb_UniformRandomNumber7[0] *
    rtb_ZeroOrderHold[1])) + (rtb_Gain_d[0] * FixedwingModel_B.Gain_c[1] -
    FixedwingModel_B.Gain_c[0] * rtb_Gain_d[1]);
  for (i = 0; i < 3; i++) {
    // Sum: '<S512>/Sum2' incorporates:
    //   Constant: '<S345>/Measurement bias'
    //   Constant: '<S345>/Scale factors & Cross-coupling  errors'
    //   Gain: '<S512>/wn^2'
    //   Product: '<S345>/Product'
    //   Sum: '<S345>/Sum4'
    //   Sum: '<S512>/Sum3'

    FixedwingModel_B.Sum2_j[i] =
      ((((FixedwingModel_P.ThreeaxisAccelerometer_a_sf_cc[i + 3] * Xe_idx_2 +
          FixedwingModel_P.ThreeaxisAccelerometer_a_sf_cc[i] * rtb_Product2_g) +
         FixedwingModel_P.ThreeaxisAccelerometer_a_sf_cc[i + 6] * Ve_idx_2) +
        FixedwingModel_P.ThreeaxisAccelerometer_a_bias[i]) -
       rtb_DataTypeConversion2[i]) * rtb_UniformRandomNumber4_j -
      rtb_IntegratorSecondOrderLimite[i];
  }

  // Outputs for Enabled SubSystem: '<S527>/Hqgw' incorporates:
  //   EnablePort: '<S539>/Enable'

  if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
      (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
    // UnitConversion: '<S530>/Unit Conversion' incorporates:
    //   Constant: '<S522>/Wingspan'

    // Unit Conversion - from: m to: ft
    // Expression: output = (3.28084*input) + (0)
    FixedwingModel_B.UnitConversion_i3 = 3.280839895013123 *
      FixedwingModel_P.uav.geometry.span;

    // Outputs for Enabled SubSystem: '<S527>/Hpgw' incorporates:
    //   EnablePort: '<S538>/Enable'

    if (rtsiIsModeUpdateTimeStep(&(&FixedwingModel_M)->solverInfo)) {
      // Constant: '<S527>/Constant1'
      if (FixedwingModel_P.DrydenWindTurbulenceModel_T_on > 0.0) {
        if (!FixedwingModel_DW.Hpgw_MODE) {
          // InitializeConditions for Integrator: '<S538>/pgw_p'
          FixedwingModel_X.pgw_p_CSTATE[0] = FixedwingModel_P.pgw_p_IC;
          FixedwingModel_X.pgw_p_CSTATE[1] = FixedwingModel_P.pgw_p_IC;
          FixedwingModel_DW.Hpgw_MODE = true;
        }
      } else if (FixedwingModel_DW.Hpgw_MODE) {
        // Disable for Product: '<S538>/sigma_w' incorporates:
        //   Outport: '<S538>/pgw'

        FixedwingModel_B.sigma_w[0] = FixedwingModel_P.pgw_Y0;
        FixedwingModel_B.sigma_w[1] = FixedwingModel_P.pgw_Y0;
        FixedwingModel_DW.Hpgw_MODE = false;
      }

      // End of Constant: '<S527>/Constant1'
    }

    // End of Outputs for SubSystem: '<S527>/Hpgw'
    if (rtsiIsModeUpdateTimeStep(&(&FixedwingModel_M)->solverInfo)) {
      // Constant: '<S527>/Constant2'
      if (FixedwingModel_P.DrydenWindTurbulenceModel_T_on > 0.0) {
        if (!FixedwingModel_DW.Hqgw_MODE) {
          // InitializeConditions for Integrator: '<S539>/qgw_p'
          FixedwingModel_X.qgw_p_CSTATE[0] = FixedwingModel_P.qgw_p_IC;
          FixedwingModel_X.qgw_p_CSTATE[1] = FixedwingModel_P.qgw_p_IC;
          FixedwingModel_DW.Hqgw_MODE = true;
        }
      } else if (FixedwingModel_DW.Hqgw_MODE) {
        // Disable for Product: '<S539>/w' incorporates:
        //   Outport: '<S539>/qgw'

        FixedwingModel_B.w_d0[0] = FixedwingModel_P.qgw_Y0;
        FixedwingModel_B.w_d0[1] = FixedwingModel_P.qgw_Y0;
        FixedwingModel_DW.Hqgw_MODE = false;
      }

      // End of Constant: '<S527>/Constant2'
    }
  }

  // End of Outputs for SubSystem: '<S527>/Hqgw'

  // Outputs for Enabled SubSystem: '<S527>/Hpgw' incorporates:
  //   EnablePort: '<S538>/Enable'

  if (FixedwingModel_DW.Hpgw_MODE) {
    if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
        (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
      // Product: '<S538>/w4' incorporates:
      //   Constant: '<S538>/Constant3'

      FixedwingModel_B.w4 = FixedwingModel_P.Constant3_Value /
        FixedwingModel_B.UnitConversion_i3;

      // Math: '<S538>/u^1//6' incorporates:
      //   Constant: '<S538>/Constant2'

      if ((FixedwingModel_B.w4 < 0.0) && (FixedwingModel_P.Constant2_Value_pn >
           std::floor(FixedwingModel_P.Constant2_Value_pn))) {
        // Math: '<S538>/u^1//6'
        FixedwingModel_B.u16 = -rt_powd_snf(-FixedwingModel_B.w4,
          FixedwingModel_P.Constant2_Value_pn);
      } else {
        // Math: '<S538>/u^1//6'
        FixedwingModel_B.u16 = rt_powd_snf(FixedwingModel_B.w4,
          FixedwingModel_P.Constant2_Value_pn);
      }

      // End of Math: '<S538>/u^1//6'
    }

    // Fcn: '<S538>/sqrt(0.8//V)'
    rtb_UniformRandomNumber4_j = 0.8 / rtb_UnitConversion_a;
    if (rtb_UniformRandomNumber4_j < 0.0) {
      rtb_UniformRandomNumber4_j = -std::sqrt(-rtb_UniformRandomNumber4_j);
    } else {
      rtb_UniformRandomNumber4_j = std::sqrt(rtb_UniformRandomNumber4_j);
    }

    // Product: '<S538>/sigma_w' incorporates:
    //   Integrator: '<S538>/pgw_p'

    FixedwingModel_B.sigma_w[0] = FixedwingModel_B.sigma_wg *
      FixedwingModel_X.pgw_p_CSTATE[0];
    FixedwingModel_B.sigma_w[1] = rtb_MediumHighAltitudeIntensity *
      FixedwingModel_X.pgw_p_CSTATE[1];

    // Product: '<S538>/w3'
    rtb_MediumHighAltitudeIntensity = rtb_UnitConversion_a * FixedwingModel_B.w4;

    // Math: '<S538>/L^1//3' incorporates:
    //   Constant: '<S538>/Constant1'

    rtb_IntegratorSecondOrderLim_ff = std::floor
      (FixedwingModel_P.Constant1_Value_j);
    if ((frac[0] < 0.0) && (FixedwingModel_P.Constant1_Value_j >
                            rtb_IntegratorSecondOrderLim_ff)) {
      rtb_Sum4_a_tmp = -rt_powd_snf(-frac[0], FixedwingModel_P.Constant1_Value_j);
    } else {
      rtb_Sum4_a_tmp = rt_powd_snf(frac[0], FixedwingModel_P.Constant1_Value_j);
    }

    // Product: '<S538>/w' incorporates:
    //   Fcn: '<S538>/sqrt(0.8//V)'
    //   Integrator: '<S538>/pgw_p'
    //   Product: '<S538>/Lug//V1'
    //   Product: '<S538>/w1'
    //   Product: '<S538>/w2'
    //   Sum: '<S538>/Sum'

    FixedwingModel_B.w_e[0] = (rtb_UniformRandomNumber4_j / rtb_Sum4_a_tmp *
      FixedwingModel_B.u16 * FixedwingModel_B.Product_m[3] -
      FixedwingModel_X.pgw_p_CSTATE[0]) * rtb_MediumHighAltitudeIntensity;

    // Math: '<S538>/L^1//3' incorporates:
    //   Constant: '<S538>/Constant1'

    if ((frac[1] < 0.0) && (FixedwingModel_P.Constant1_Value_j >
                            rtb_IntegratorSecondOrderLim_ff)) {
      rtb_Sum4_a_tmp = -rt_powd_snf(-frac[1], FixedwingModel_P.Constant1_Value_j);
    } else {
      rtb_Sum4_a_tmp = rt_powd_snf(frac[1], FixedwingModel_P.Constant1_Value_j);
    }

    // Product: '<S538>/w' incorporates:
    //   Fcn: '<S538>/sqrt(0.8//V)'
    //   Integrator: '<S538>/pgw_p'
    //   Product: '<S538>/Lug//V1'
    //   Product: '<S538>/w1'
    //   Product: '<S538>/w2'
    //   Sum: '<S538>/Sum'

    FixedwingModel_B.w_e[1] = (rtb_UniformRandomNumber4_j / rtb_Sum4_a_tmp *
      FixedwingModel_B.u16 * FixedwingModel_B.Product_m[3] -
      FixedwingModel_X.pgw_p_CSTATE[1]) * rtb_MediumHighAltitudeIntensity;
  }

  // End of Outputs for SubSystem: '<S527>/Hpgw'

  // Outputs for Enabled SubSystem: '<S527>/Hqgw' incorporates:
  //   EnablePort: '<S539>/Enable'

  if (FixedwingModel_DW.Hqgw_MODE) {
    // Product: '<S539>/w' incorporates:
    //   Gain: '<S539>/pi//4'

    rtb_Sum4_a_tmp = FixedwingModel_P.pi4_Gain * rtb_UnitConversion_a /
      FixedwingModel_B.UnitConversion_i3;

    // Product: '<S539>/w' incorporates:
    //   Integrator: '<S539>/qgw_p'
    //   Product: '<S539>/wg//V'
    //   Sum: '<S539>/Sum'

    FixedwingModel_B.w_d0[0] = (FixedwingModel_B.LwgV1[0] / rtb_UnitConversion_a
      - FixedwingModel_X.qgw_p_CSTATE[0]) * rtb_Sum4_a_tmp;
    FixedwingModel_B.w_d0[1] = (FixedwingModel_B.LwgV1[1] / rtb_UnitConversion_a
      - FixedwingModel_X.qgw_p_CSTATE[1]) * rtb_Sum4_a_tmp;
  }

  // End of Outputs for SubSystem: '<S527>/Hqgw'

  // Outputs for Enabled SubSystem: '<S527>/Hrgw' incorporates:
  //   EnablePort: '<S540>/Enable'

  if ((rtmIsMajorTimeStep((&FixedwingModel_M)) &&
       (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) &&
      rtsiIsModeUpdateTimeStep(&(&FixedwingModel_M)->solverInfo)) {
    // Constant: '<S527>/Constant3'
    if (FixedwingModel_P.DrydenWindTurbulenceModel_T_on > 0.0) {
      if (!FixedwingModel_DW.Hrgw_MODE) {
        // InitializeConditions for Integrator: '<S540>/rgw_p'
        FixedwingModel_X.rgw_p_CSTATE[0] = FixedwingModel_P.rgw_p_IC;
        FixedwingModel_X.rgw_p_CSTATE[1] = FixedwingModel_P.rgw_p_IC;
        FixedwingModel_DW.Hrgw_MODE = true;
      }
    } else if (FixedwingModel_DW.Hrgw_MODE) {
      // Disable for UnaryMinus: '<S540>/Unary Minus' incorporates:
      //   Outport: '<S540>/rgw'

      FixedwingModel_B.UnaryMinus[0] = FixedwingModel_P.rgw_Y0;
      FixedwingModel_B.UnaryMinus[1] = FixedwingModel_P.rgw_Y0;
      FixedwingModel_DW.Hrgw_MODE = false;
    }

    // End of Constant: '<S527>/Constant3'
  }

  if (FixedwingModel_DW.Hrgw_MODE) {
    // Product: '<S540>/w' incorporates:
    //   Gain: '<S540>/pi//3'

    rtb_Sum4_a_tmp = FixedwingModel_P.pi3_Gain * rtb_UnitConversion_a /
      FixedwingModel_B.UnitConversion_i3;

    // Product: '<S540>/w' incorporates:
    //   Integrator: '<S540>/rgw_p'
    //   Product: '<S540>/vg//V'
    //   Sum: '<S540>/Sum'

    FixedwingModel_B.w_b[0] = (FixedwingModel_B.w1[0] / rtb_UnitConversion_a -
      FixedwingModel_X.rgw_p_CSTATE[0]) * rtb_Sum4_a_tmp;

    // UnaryMinus: '<S540>/Unary Minus'
    FixedwingModel_B.UnaryMinus[0] = -FixedwingModel_B.w_b[0];

    // Product: '<S540>/w' incorporates:
    //   Integrator: '<S540>/rgw_p'
    //   Product: '<S540>/vg//V'
    //   Sum: '<S540>/Sum'

    FixedwingModel_B.w_b[1] = (FixedwingModel_B.w1[1] / rtb_UnitConversion_a -
      FixedwingModel_X.rgw_p_CSTATE[1]) * rtb_Sum4_a_tmp;

    // UnaryMinus: '<S540>/Unary Minus'
    FixedwingModel_B.UnaryMinus[1] = -FixedwingModel_B.w_b[1];
  }

  // End of Outputs for SubSystem: '<S527>/Hrgw'

  // If: '<S532>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 
  if (rtsiIsModeUpdateTimeStep(&(&FixedwingModel_M)->solverInfo)) {
    if (rtb_UnitConversion <= 1000.0) {
      rtAction = 0;
    } else if (rtb_UnitConversion >= 2000.0) {
      rtAction = 1;
    } else {
      rtAction = 2;
    }

    FixedwingModel_DW.ifHeightMaxlowaltitudeelseif_j4 = rtAction;
  } else {
    rtAction = FixedwingModel_DW.ifHeightMaxlowaltitudeelseif_j4;
  }

  switch (rtAction) {
   case 0:
    // Outputs for IfAction SubSystem: '<S532>/Low altitude  rates' incorporates:
    //   ActionPort: '<S547>/Action Port'

    FixedwingModel_Lowaltituderates(rtb_VectorConcatenate,
      FixedwingModel_B.sigma_w, FixedwingModel_B.w_d0,
      FixedwingModel_B.UnaryMinus, FixedwingModel_B.UnitConversion_k,
      rtb_IntegratorSecondOrderLimite);

    // End of Outputs for SubSystem: '<S532>/Low altitude  rates'
    break;

   case 1:
    break;

   case 2:
    // Outputs for IfAction SubSystem: '<S532>/Interpolate  rates' incorporates:
    //   ActionPort: '<S546>/Action Port'

    FixedwingModel_Interpolaterates(FixedwingModel_B.sigma_w,
      FixedwingModel_B.w_d0, FixedwingModel_B.UnaryMinus, rtb_VectorConcatenate,
      FixedwingModel_B.UnitConversion_k, rtb_UnitConversion,
      rtb_IntegratorSecondOrderLimite, &FixedwingModel_P.Interpolaterates_c);

    // End of Outputs for SubSystem: '<S532>/Interpolate  rates'
    break;
  }

  // End of If: '<S532>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 
  if (rtmIsMajorTimeStep((&FixedwingModel_M))) {
    if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
        (&FixedwingModel_M)->Timing.TaskCounters.TID[3] == 0) {
      // Update for RandomNumber: '<S537>/White Noise'
      FixedwingModel_DW.NextOutput[0] = rt_nrand_Upu32_Yd_f_pw_snf
        (&FixedwingModel_DW.RandSeed[0]) * FixedwingModel_P.WhiteNoise_StdDev +
        FixedwingModel_P.WhiteNoise_Mean;
      FixedwingModel_DW.NextOutput[1] = rt_nrand_Upu32_Yd_f_pw_snf
        (&FixedwingModel_DW.RandSeed[1]) * FixedwingModel_P.WhiteNoise_StdDev +
        FixedwingModel_P.WhiteNoise_Mean;
      FixedwingModel_DW.NextOutput[2] = rt_nrand_Upu32_Yd_f_pw_snf
        (&FixedwingModel_DW.RandSeed[2]) * FixedwingModel_P.WhiteNoise_StdDev +
        FixedwingModel_P.WhiteNoise_Mean;
      FixedwingModel_DW.NextOutput[3] = rt_nrand_Upu32_Yd_f_pw_snf
        (&FixedwingModel_DW.RandSeed[3]) * FixedwingModel_P.WhiteNoise_StdDev +
        FixedwingModel_P.WhiteNoise_Mean;
    }

    if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
        (&FixedwingModel_M)->Timing.TaskCounters.TID[2] == 0) {
      // Update for UniformRandomNumber: '<S226>/Uniform Random Number5'
      FixedwingModel_DW.UniformRandomNumber5_NextOutput[0] =
        (FixedwingModel_P.UniformRandomNumber5_Maximum[0] -
         FixedwingModel_P.UniformRandomNumber5_Minimum[0]) *
        rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_a[0]) +
        FixedwingModel_P.UniformRandomNumber5_Minimum[0];

      // Update for UniformRandomNumber: '<S226>/Uniform Random Number1'
      FixedwingModel_DW.UniformRandomNumber1_NextOutput[0] =
        (FixedwingModel_P.UniformRandomNumber1_Maximum[0] -
         FixedwingModel_P.UniformRandomNumber1_Minimum[0]) *
        rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_j[0]) +
        FixedwingModel_P.UniformRandomNumber1_Minimum[0];

      // Update for UniformRandomNumber: '<S226>/Uniform Random Number5'
      FixedwingModel_DW.UniformRandomNumber5_NextOutput[1] =
        (FixedwingModel_P.UniformRandomNumber5_Maximum[1] -
         FixedwingModel_P.UniformRandomNumber5_Minimum[1]) *
        rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_a[1]) +
        FixedwingModel_P.UniformRandomNumber5_Minimum[1];

      // Update for UniformRandomNumber: '<S226>/Uniform Random Number1'
      FixedwingModel_DW.UniformRandomNumber1_NextOutput[1] =
        (FixedwingModel_P.UniformRandomNumber1_Maximum[1] -
         FixedwingModel_P.UniformRandomNumber1_Minimum[1]) *
        rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_j[1]) +
        FixedwingModel_P.UniformRandomNumber1_Minimum[1];

      // Update for UniformRandomNumber: '<S226>/Uniform Random Number5'
      FixedwingModel_DW.UniformRandomNumber5_NextOutput[2] =
        (FixedwingModel_P.UniformRandomNumber5_Maximum[2] -
         FixedwingModel_P.UniformRandomNumber5_Minimum[2]) *
        rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_a[2]) +
        FixedwingModel_P.UniformRandomNumber5_Minimum[2];

      // Update for UniformRandomNumber: '<S226>/Uniform Random Number1'
      FixedwingModel_DW.UniformRandomNumber1_NextOutput[2] =
        (FixedwingModel_P.UniformRandomNumber1_Maximum[2] -
         FixedwingModel_P.UniformRandomNumber1_Minimum[2]) *
        rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_j[2]) +
        FixedwingModel_P.UniformRandomNumber1_Minimum[2];

      // Update for UniformRandomNumber: '<S226>/Uniform Random Number7'
      FixedwingModel_DW.UniformRandomNumber7_NextOutput[0] =
        (FixedwingModel_P.UniformRandomNumber7_Maximum[0] -
         FixedwingModel_P.UniformRandomNumber7_Minimum[0]) *
        rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_p[0]) +
        FixedwingModel_P.UniformRandomNumber7_Minimum[0];

      // Update for UniformRandomNumber: '<S28>/Uniform Random Number'
      FixedwingModel_DW.UniformRandomNumber_NextOutput[0] =
        (FixedwingModel_P.UniformRandomNumber_Maximum[0] -
         FixedwingModel_P.UniformRandomNumber_Minimum[0]) *
        rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_h[0]) +
        FixedwingModel_P.UniformRandomNumber_Minimum[0];

      // Update for UniformRandomNumber: '<S226>/Uniform Random Number7'
      FixedwingModel_DW.UniformRandomNumber7_NextOutput[1] =
        (FixedwingModel_P.UniformRandomNumber7_Maximum[1] -
         FixedwingModel_P.UniformRandomNumber7_Minimum[1]) *
        rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_p[1]) +
        FixedwingModel_P.UniformRandomNumber7_Minimum[1];

      // Update for UniformRandomNumber: '<S28>/Uniform Random Number'
      FixedwingModel_DW.UniformRandomNumber_NextOutput[1] =
        (FixedwingModel_P.UniformRandomNumber_Maximum[1] -
         FixedwingModel_P.UniformRandomNumber_Minimum[1]) *
        rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_h[1]) +
        FixedwingModel_P.UniformRandomNumber_Minimum[1];

      // Update for UniformRandomNumber: '<S226>/Uniform Random Number7'
      FixedwingModel_DW.UniformRandomNumber7_NextOutput[2] =
        (FixedwingModel_P.UniformRandomNumber7_Maximum[2] -
         FixedwingModel_P.UniformRandomNumber7_Minimum[2]) *
        rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_p[2]) +
        FixedwingModel_P.UniformRandomNumber7_Minimum[2];

      // Update for UniformRandomNumber: '<S28>/Uniform Random Number'
      FixedwingModel_DW.UniformRandomNumber_NextOutput[2] =
        (FixedwingModel_P.UniformRandomNumber_Maximum[2] -
         FixedwingModel_P.UniformRandomNumber_Minimum[2]) *
        rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_h[2]) +
        FixedwingModel_P.UniformRandomNumber_Minimum[2];
    }

    if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
        (&FixedwingModel_M)->Timing.TaskCounters.TID[1] == 0) {
      // Update for Memory: '<S287>/otime' incorporates:
      //   Constant: '<S239>/Decimal Year'

      FixedwingModel_DW.otime_PreviousInput = FixedwingModel_P.DecimalYear_Value;

      // Update for Memory: '<S286>/olon'
      FixedwingModel_DW.olon_PreviousInput = FixedwingModel_B.Switch_c;

      // Update for Memory: '<S285>/olat'
      FixedwingModel_DW.olat_PreviousInput = FixedwingModel_B.Switch_j;

      // Update for Memory: '<S285>/oalt'
      FixedwingModel_DW.oalt_PreviousInput = FixedwingModel_B.Gain_m;
    }

    if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
        (&FixedwingModel_M)->Timing.TaskCounters.TID[3] == 0) {
      // Update for RandomNumber: '<S118>/White Noise'
      FixedwingModel_DW.NextOutput_c[0] = rt_nrand_Upu32_Yd_f_pw_snf
        (&FixedwingModel_DW.RandSeed_ab[0]) *
        FixedwingModel_P.WhiteNoise_StdDev_a +
        FixedwingModel_P.WhiteNoise_Mean_l;
      FixedwingModel_DW.NextOutput_c[1] = rt_nrand_Upu32_Yd_f_pw_snf
        (&FixedwingModel_DW.RandSeed_ab[1]) *
        FixedwingModel_P.WhiteNoise_StdDev_a +
        FixedwingModel_P.WhiteNoise_Mean_l;
      FixedwingModel_DW.NextOutput_c[2] = rt_nrand_Upu32_Yd_f_pw_snf
        (&FixedwingModel_DW.RandSeed_ab[2]) *
        FixedwingModel_P.WhiteNoise_StdDev_a +
        FixedwingModel_P.WhiteNoise_Mean_l;
      FixedwingModel_DW.NextOutput_c[3] = rt_nrand_Upu32_Yd_f_pw_snf
        (&FixedwingModel_DW.RandSeed_ab[3]) *
        FixedwingModel_P.WhiteNoise_StdDev_a +
        FixedwingModel_P.WhiteNoise_Mean_l;
    }

    // Update for Enabled SubSystem: '<S109>/Hugw(z)'
    FixedwingModel_Hugwz_Update(&FixedwingModel_B.Hugwz_l,
      &FixedwingModel_DW.Hugwz_l);

    // End of Update for SubSystem: '<S109>/Hugw(z)'

    // Update for Enabled SubSystem: '<S109>/Hvgw(z)'
    FixedwingModel_Hvgwz_Update(&FixedwingModel_B.Hvgwz_o,
      &FixedwingModel_DW.Hvgwz_o);

    // End of Update for SubSystem: '<S109>/Hvgw(z)'

    // Update for Enabled SubSystem: '<S109>/Hwgw(z)'
    FixedwingModel_Hwgwz_Update(&FixedwingModel_B.Hwgwz_j,
      &FixedwingModel_DW.Hwgwz_j);

    // End of Update for SubSystem: '<S109>/Hwgw(z)'
    if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
        (&FixedwingModel_M)->Timing.TaskCounters.TID[3] == 0) {
      // Update for RandomNumber: '<S79>/White Noise'
      FixedwingModel_DW.NextOutput_b[0] = rt_nrand_Upu32_Yd_f_pw_snf
        (&FixedwingModel_DW.RandSeed_ah[0]) *
        FixedwingModel_P.WhiteNoise_StdDev_h +
        FixedwingModel_P.WhiteNoise_Mean_e;
      FixedwingModel_DW.NextOutput_b[1] = rt_nrand_Upu32_Yd_f_pw_snf
        (&FixedwingModel_DW.RandSeed_ah[1]) *
        FixedwingModel_P.WhiteNoise_StdDev_h +
        FixedwingModel_P.WhiteNoise_Mean_e;
      FixedwingModel_DW.NextOutput_b[2] = rt_nrand_Upu32_Yd_f_pw_snf
        (&FixedwingModel_DW.RandSeed_ah[2]) *
        FixedwingModel_P.WhiteNoise_StdDev_h +
        FixedwingModel_P.WhiteNoise_Mean_e;
      FixedwingModel_DW.NextOutput_b[3] = rt_nrand_Upu32_Yd_f_pw_snf
        (&FixedwingModel_DW.RandSeed_ah[3]) *
        FixedwingModel_P.WhiteNoise_StdDev_h +
        FixedwingModel_P.WhiteNoise_Mean_e;
    }

    // Update for Enabled SubSystem: '<S70>/Hugw(z)'
    FixedwingModel_Hugwz_Update(&FixedwingModel_B.Hugwz,
      &FixedwingModel_DW.Hugwz);

    // End of Update for SubSystem: '<S70>/Hugw(z)'

    // Update for Enabled SubSystem: '<S70>/Hvgw(z)'
    FixedwingModel_Hvgwz_Update(&FixedwingModel_B.Hvgwz,
      &FixedwingModel_DW.Hvgwz);

    // End of Update for SubSystem: '<S70>/Hvgw(z)'

    // Update for Enabled SubSystem: '<S70>/Hwgw(z)'
    FixedwingModel_Hwgwz_Update(&FixedwingModel_B.Hwgwz,
      &FixedwingModel_DW.Hwgwz);

    // End of Update for SubSystem: '<S70>/Hwgw(z)'
    if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
        (&FixedwingModel_M)->Timing.TaskCounters.TID[3] == 0) {
      // Update for UniformRandomNumber: '<S226>/Uniform Random Number'
      FixedwingModel_DW.UniformRandomNumber_NextOutpu_a =
        (FixedwingModel_P.UniformRandomNumber_Maximum_n -
         FixedwingModel_P.UniformRandomNumber_Minimum_m) *
        rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_c) +
        FixedwingModel_P.UniformRandomNumber_Minimum_m;

      // Update for UniformRandomNumber: '<S226>/Uniform Random Number4'
      FixedwingModel_DW.UniformRandomNumber4_NextOutput =
        (FixedwingModel_P.UniformRandomNumber4_Maximum -
         FixedwingModel_P.UniformRandomNumber4_Minimum) *
        rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_m) +
        FixedwingModel_P.UniformRandomNumber4_Minimum;
    }

    if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
        (&FixedwingModel_M)->Timing.TaskCounters.TID[5] == 0) {
      // Update for UniformRandomNumber: '<S194>/Uniform Random Number5'
      FixedwingModel_DW.UniformRandomNumber5_NextOutp_j[0] =
        (FixedwingModel_P.UniformRandomNumber5_Maximum_f[0] -
         FixedwingModel_P.UniformRandomNumber5_Minimum_n[0]) *
        rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_d[0]) +
        FixedwingModel_P.UniformRandomNumber5_Minimum_n[0];
      FixedwingModel_DW.UniformRandomNumber5_NextOutp_j[1] =
        (FixedwingModel_P.UniformRandomNumber5_Maximum_f[1] -
         FixedwingModel_P.UniformRandomNumber5_Minimum_n[1]) *
        rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_d[1]) +
        FixedwingModel_P.UniformRandomNumber5_Minimum_n[1];
      FixedwingModel_DW.UniformRandomNumber5_NextOutp_j[2] =
        (FixedwingModel_P.UniformRandomNumber5_Maximum_f[2] -
         FixedwingModel_P.UniformRandomNumber5_Minimum_n[2]) *
        rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_d[2]) +
        FixedwingModel_P.UniformRandomNumber5_Minimum_n[2];
    }

    if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
        (&FixedwingModel_M)->Timing.TaskCounters.TID[4] == 0) {
      // Update for RandomNumber: '<S16>/White Noise'
      FixedwingModel_DW.NextOutput_p = rt_nrand_Upu32_Yd_f_pw_snf
        (&FixedwingModel_DW.RandSeed_ph) * FixedwingModel_P.WhiteNoise_StdDev_k
        + FixedwingModel_P.WhiteNoise_Mean_f;
    }

    // Update for Enabled SubSystem: '<S69>/Hpgw'
    FixedwingModel_Hpgw_Update(&FixedwingModel_B.Hpgw, &FixedwingModel_DW.Hpgw);

    // End of Update for SubSystem: '<S69>/Hpgw'

    // Update for Enabled SubSystem: '<S69>/Hqgw'
    FixedwingModel_Hqgw_Update(FixedwingModel_B.Hwgwz.Sum,
      &FixedwingModel_B.Hqgw, &FixedwingModel_DW.Hqgw);

    // End of Update for SubSystem: '<S69>/Hqgw'

    // Update for Enabled SubSystem: '<S69>/Hrgw'
    FixedwingModel_Hrgw_Update(FixedwingModel_B.Hvgwz.Sum,
      &FixedwingModel_B.Hrgw, &FixedwingModel_DW.Hrgw);

    // End of Update for SubSystem: '<S69>/Hrgw'

    // Update for Enabled SubSystem: '<S108>/Hpgw'
    FixedwingModel_Hpgw_Update(&FixedwingModel_B.Hpgw_h,
      &FixedwingModel_DW.Hpgw_h);

    // End of Update for SubSystem: '<S108>/Hpgw'

    // Update for Enabled SubSystem: '<S108>/Hqgw'
    FixedwingModel_Hqgw_Update(FixedwingModel_B.Hwgwz_j.Sum,
      &FixedwingModel_B.Hqgw_p, &FixedwingModel_DW.Hqgw_p);

    // End of Update for SubSystem: '<S108>/Hqgw'

    // Update for Enabled SubSystem: '<S108>/Hrgw'
    FixedwingModel_Hrgw_Update(FixedwingModel_B.Hvgwz_o.Sum,
      &FixedwingModel_B.Hrgw_a, &FixedwingModel_DW.Hrgw_a);

    // End of Update for SubSystem: '<S108>/Hrgw'
    if (rtmIsMajorTimeStep((&FixedwingModel_M)) &&
        (&FixedwingModel_M)->Timing.TaskCounters.TID[5] == 0) {
      // Update for UniformRandomNumber: '<S152>/Uniform Random Number4'
      FixedwingModel_DW.UniformRandomNumber4_NextOutp_l[0] =
        (FixedwingModel_P.UniformRandomNumber4_Maximum_a[0] -
         FixedwingModel_P.UniformRandomNumber4_Minimum_o[0]) *
        rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_as[0]) +
        FixedwingModel_P.UniformRandomNumber4_Minimum_o[0];
      FixedwingModel_DW.UniformRandomNumber4_NextOutp_l[1] =
        (FixedwingModel_P.UniformRandomNumber4_Maximum_a[1] -
         FixedwingModel_P.UniformRandomNumber4_Minimum_o[1]) *
        rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_as[1]) +
        FixedwingModel_P.UniformRandomNumber4_Minimum_o[1];
      FixedwingModel_DW.UniformRandomNumber4_NextOutp_l[2] =
        (FixedwingModel_P.UniformRandomNumber4_Maximum_a[2] -
         FixedwingModel_P.UniformRandomNumber4_Minimum_o[2]) *
        rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_as[2]) +
        FixedwingModel_P.UniformRandomNumber4_Minimum_o[2];
    }
  }                                    // end MajorTimeStep

  if (rtmIsMajorTimeStep((&FixedwingModel_M))) {
    rt_ertODEUpdateContinuousStates(&(&FixedwingModel_M)->solverInfo);

    // Update absolute time for base rate
    // The "clockTick0" counts the number of times the code of this task has
    //  been executed. The absolute time is the multiplication of "clockTick0"
    //  and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
    //  overflow during the application lifespan selected.

    ++(&FixedwingModel_M)->Timing.clockTick0;
    (&FixedwingModel_M)->Timing.t[0] = rtsiGetSolverStopTime(&(&FixedwingModel_M)
      ->solverInfo);

    {
      // Update absolute timer for sample time: [0.001s, 0.0s]
      // The "clockTick1" counts the number of times the code of this task has
      //  been executed. The resolution of this integer timer is 0.001, which is the step size
      //  of the task. Size of "clockTick1" ensures timer will not overflow during the
      //  application lifespan selected.

      (&FixedwingModel_M)->Timing.clockTick1++;
    }

    rate_scheduler((&FixedwingModel_M));
  }                                    // end MajorTimeStep
}

// Derivatives for root system: '<Root>'
void MulticopterModelClass::FixedwingModel_derivatives()
{
  XDot_FixedwingModel_T *_rtXdot;
  _rtXdot = ((XDot_FixedwingModel_T *) (&FixedwingModel_M)->derivs);

  // Derivatives for SecondOrderIntegrator: '<S252>/Integrator, Second-Order Limited' 
  if (FixedwingModel_DW.IntegratorSecondOrderLimited_MO[0] == 0) {
    _rtXdot->IntegratorSecondOrderLimited_CS[0] =
      FixedwingModel_X.IntegratorSecondOrderLimited_CS[3];
    _rtXdot->IntegratorSecondOrderLimited_CS[3] = FixedwingModel_B.Sum2_o[0];
  }

  if (FixedwingModel_DW.IntegratorSecondOrderLimited_MO[1] == 0) {
    _rtXdot->IntegratorSecondOrderLimited_CS[1] =
      FixedwingModel_X.IntegratorSecondOrderLimited_CS[4];
    _rtXdot->IntegratorSecondOrderLimited_CS[4] = FixedwingModel_B.Sum2_o[1];
  }

  if (FixedwingModel_DW.IntegratorSecondOrderLimited_MO[2] == 0) {
    _rtXdot->IntegratorSecondOrderLimited_CS[2] =
      FixedwingModel_X.IntegratorSecondOrderLimited_CS[5];
    _rtXdot->IntegratorSecondOrderLimited_CS[5] = FixedwingModel_B.Sum2_o[2];
  }

  // End of Derivatives for SecondOrderIntegrator: '<S252>/Integrator, Second-Order Limited' 

  // Derivatives for SecondOrderIntegrator: '<S10>/Integrator, Second-Order'
  if (FixedwingModel_DW.IntegratorSecondOrder_MODE == 0) {
    _rtXdot->IntegratorSecondOrder_CSTATE[0] =
      FixedwingModel_X.IntegratorSecondOrder_CSTATE[1];
    _rtXdot->IntegratorSecondOrder_CSTATE[1] = FixedwingModel_B.Sum2;
  }

  // End of Derivatives for SecondOrderIntegrator: '<S10>/Integrator, Second-Order' 

  // Derivatives for Integrator: '<S346>/phi theta psi'
  _rtXdot->phithetapsi_CSTATE[0] =
    FixedwingModel_B.TmpSignalConversionAtphithetaps[0];

  // Derivatives for Integrator: '<S341>/ub,vb,wb'
  _rtXdot->ubvbwb_CSTATE[0] = FixedwingModel_B.Sum_c[0];

  // Derivatives for Integrator: '<S341>/xe,ye,ze'
  _rtXdot->xeyeze_CSTATE[0] = FixedwingModel_B.Product[0];

  // Derivatives for Integrator: '<S346>/phi theta psi'
  _rtXdot->phithetapsi_CSTATE[1] =
    FixedwingModel_B.TmpSignalConversionAtphithetaps[1];

  // Derivatives for Integrator: '<S341>/ub,vb,wb'
  _rtXdot->ubvbwb_CSTATE[1] = FixedwingModel_B.Sum_c[1];

  // Derivatives for Integrator: '<S341>/xe,ye,ze'
  _rtXdot->xeyeze_CSTATE[1] = FixedwingModel_B.Product[1];

  // Derivatives for Integrator: '<S346>/phi theta psi'
  _rtXdot->phithetapsi_CSTATE[2] =
    FixedwingModel_B.TmpSignalConversionAtphithetaps[2];

  // Derivatives for Integrator: '<S341>/ub,vb,wb'
  _rtXdot->ubvbwb_CSTATE[2] = FixedwingModel_B.Sum_c[2];

  // Derivatives for Integrator: '<S341>/xe,ye,ze'
  _rtXdot->xeyeze_CSTATE[2] = FixedwingModel_B.Product[2];

  // Derivatives for Enabled SubSystem: '<S528>/Hugw(s)'
  if (FixedwingModel_DW.Hugws_MODE) {
    // Derivatives for Integrator: '<S541>/ug_p'
    _rtXdot->ug_p_CSTATE[0] = FixedwingModel_B.w_a[0];
    _rtXdot->ug_p_CSTATE[1] = FixedwingModel_B.w_a[1];
  } else {
    {
      real_T *dx;
      int_T i;
      dx = &(((XDot_FixedwingModel_T *) (&FixedwingModel_M)->derivs)
             ->ug_p_CSTATE[0]);
      for (i=0; i < 2; i++) {
        dx[i] = 0.0;
      }
    }
  }

  // End of Derivatives for SubSystem: '<S528>/Hugw(s)'

  // Derivatives for Enabled SubSystem: '<S528>/Hvgw(s)'
  if (FixedwingModel_DW.Hvgws_MODE) {
    // Derivatives for Integrator: '<S542>/vg_p1'
    _rtXdot->vg_p1_CSTATE[0] = FixedwingModel_B.w_f[0];

    // Derivatives for Integrator: '<S542>/vgw_p2'
    _rtXdot->vgw_p2_CSTATE[0] = FixedwingModel_B.w_d[0];

    // Derivatives for Integrator: '<S542>/vg_p1'
    _rtXdot->vg_p1_CSTATE[1] = FixedwingModel_B.w_f[1];

    // Derivatives for Integrator: '<S542>/vgw_p2'
    _rtXdot->vgw_p2_CSTATE[1] = FixedwingModel_B.w_d[1];
  } else {
    {
      real_T *dx;
      int_T i;
      dx = &(((XDot_FixedwingModel_T *) (&FixedwingModel_M)->derivs)
             ->vg_p1_CSTATE[0]);
      for (i=0; i < 4; i++) {
        dx[i] = 0.0;
      }
    }
  }

  // End of Derivatives for SubSystem: '<S528>/Hvgw(s)'

  // Derivatives for Enabled SubSystem: '<S528>/Hwgw(s)'
  if (FixedwingModel_DW.Hwgws_MODE) {
    // Derivatives for Integrator: '<S543>/wg_p1'
    _rtXdot->wg_p1_CSTATE[0] = FixedwingModel_B.w[0];

    // Derivatives for Integrator: '<S543>/wg_p2'
    _rtXdot->wg_p2_CSTATE[0] = FixedwingModel_B.w_m[0];

    // Derivatives for Integrator: '<S543>/wg_p1'
    _rtXdot->wg_p1_CSTATE[1] = FixedwingModel_B.w[1];

    // Derivatives for Integrator: '<S543>/wg_p2'
    _rtXdot->wg_p2_CSTATE[1] = FixedwingModel_B.w_m[1];
  } else {
    {
      real_T *dx;
      int_T i;
      dx = &(((XDot_FixedwingModel_T *) (&FixedwingModel_M)->derivs)
             ->wg_p1_CSTATE[0]);
      for (i=0; i < 4; i++) {
        dx[i] = 0.0;
      }
    }
  }

  // End of Derivatives for SubSystem: '<S528>/Hwgw(s)'

  // Derivatives for TransferFcn: '<S366>/Transfer Fcn'
  _rtXdot->TransferFcn_CSTATE = 0.0;
  _rtXdot->TransferFcn_CSTATE += FixedwingModel_P.TransferFcn_A *
    FixedwingModel_X.TransferFcn_CSTATE;
  _rtXdot->TransferFcn_CSTATE += FixedwingModel_B.xeyeze[2];

  // Derivatives for TransferFcn: '<S384>/Transfer Fcn'
  _rtXdot->TransferFcn_CSTATE_n = 0.0;
  _rtXdot->TransferFcn_CSTATE_n += FixedwingModel_P.TransferFcn_A_p *
    FixedwingModel_X.TransferFcn_CSTATE_n;
  _rtXdot->TransferFcn_CSTATE_n += FixedwingModel_B.Incidence;

  // Derivatives for SecondOrderIntegrator: '<S14>/Integrator, Second-Order'
  if (FixedwingModel_DW.IntegratorSecondOrder_MODE_j == 0) {
    _rtXdot->IntegratorSecondOrder_CSTATE_e[0] =
      FixedwingModel_X.IntegratorSecondOrder_CSTATE_e[1];
    _rtXdot->IntegratorSecondOrder_CSTATE_e[1] = FixedwingModel_B.Sum2_l;
  }

  // End of Derivatives for SecondOrderIntegrator: '<S14>/Integrator, Second-Order' 

  // Derivatives for SecondOrderIntegrator: '<S11>/Integrator, Second-Order'
  if (FixedwingModel_DW.IntegratorSecondOrder_MODE_d == 0) {
    _rtXdot->IntegratorSecondOrder_CSTATE_k[0] =
      FixedwingModel_X.IntegratorSecondOrder_CSTATE_k[1];
    _rtXdot->IntegratorSecondOrder_CSTATE_k[1] = FixedwingModel_B.Sum2_k;
  }

  // End of Derivatives for SecondOrderIntegrator: '<S11>/Integrator, Second-Order' 

  // Derivatives for Integrator: '<S341>/p,q,r '
  _rtXdot->pqr_CSTATE[0] = FixedwingModel_B.Product2[0];
  _rtXdot->pqr_CSTATE[1] = FixedwingModel_B.Product2[1];
  _rtXdot->pqr_CSTATE[2] = FixedwingModel_B.Product2[2];

  // Derivatives for SecondOrderIntegrator: '<S12>/Integrator, Second-Order'
  if (FixedwingModel_DW.IntegratorSecondOrder_MODE_c == 0) {
    _rtXdot->IntegratorSecondOrder_CSTATE_a[0] =
      FixedwingModel_X.IntegratorSecondOrder_CSTATE_a[1];
    _rtXdot->IntegratorSecondOrder_CSTATE_a[1] = FixedwingModel_B.Sum2_p;
  }

  // End of Derivatives for SecondOrderIntegrator: '<S12>/Integrator, Second-Order' 

  // Derivatives for SecondOrderIntegrator: '<S13>/Integrator, Second-Order'
  if (FixedwingModel_DW.IntegratorSecondOrder_MODE_p == 0) {
    _rtXdot->IntegratorSecondOrder_CSTATE_h[0] =
      FixedwingModel_X.IntegratorSecondOrder_CSTATE_h[1];
    _rtXdot->IntegratorSecondOrder_CSTATE_h[1] = FixedwingModel_B.Sum2_g;
  }

  // End of Derivatives for SecondOrderIntegrator: '<S13>/Integrator, Second-Order' 

  // Derivatives for SecondOrderIntegrator: '<S263>/Integrator, Second-Order Limited' 
  if (FixedwingModel_DW.IntegratorSecondOrderLimited__o[0] == 0) {
    _rtXdot->IntegratorSecondOrderLimited__d[0] =
      FixedwingModel_X.IntegratorSecondOrderLimited__d[3];
    _rtXdot->IntegratorSecondOrderLimited__d[3] = FixedwingModel_B.Sum2_pq[0];
  }

  if (FixedwingModel_DW.IntegratorSecondOrderLimited__o[1] == 0) {
    _rtXdot->IntegratorSecondOrderLimited__d[1] =
      FixedwingModel_X.IntegratorSecondOrderLimited__d[4];
    _rtXdot->IntegratorSecondOrderLimited__d[4] = FixedwingModel_B.Sum2_pq[1];
  }

  if (FixedwingModel_DW.IntegratorSecondOrderLimited__o[2] == 0) {
    _rtXdot->IntegratorSecondOrderLimited__d[2] =
      FixedwingModel_X.IntegratorSecondOrderLimited__d[5];
    _rtXdot->IntegratorSecondOrderLimited__d[5] = FixedwingModel_B.Sum2_pq[2];
  }

  // End of Derivatives for SecondOrderIntegrator: '<S263>/Integrator, Second-Order Limited' 

  // Derivatives for TransferFcn: '<S196>/Transfer Fcn4'
  _rtXdot->TransferFcn4_CSTATE = 0.0;
  _rtXdot->TransferFcn4_CSTATE += FixedwingModel_P.TransferFcn4_A *
    FixedwingModel_X.TransferFcn4_CSTATE;
  _rtXdot->TransferFcn4_CSTATE += FixedwingModel_B.BiasGain1[0];

  // Derivatives for TransferFcn: '<S196>/Transfer Fcn1'
  _rtXdot->TransferFcn1_CSTATE = 0.0;
  _rtXdot->TransferFcn1_CSTATE += FixedwingModel_P.TransferFcn1_A *
    FixedwingModel_X.TransferFcn1_CSTATE;
  _rtXdot->TransferFcn1_CSTATE += FixedwingModel_B.BiasGain1[1];

  // Derivatives for TransferFcn: '<S196>/Transfer Fcn2'
  _rtXdot->TransferFcn2_CSTATE = 0.0;
  _rtXdot->TransferFcn2_CSTATE += FixedwingModel_P.TransferFcn2_A *
    FixedwingModel_X.TransferFcn2_CSTATE;
  _rtXdot->TransferFcn2_CSTATE += FixedwingModel_B.BiasGain1[2];

  // Derivatives for Enabled SubSystem: '<S17>/Distance into gust (x)'
  if (FixedwingModel_DW.Distanceintogustx_MODE) {
    boolean_T lsat;
    boolean_T usat;

    // Derivatives for Integrator: '<S20>/Distance into Gust (x) (Limited to gust length d)' incorporates:
    //   Constant: '<S15>/Constant'

    lsat = (FixedwingModel_X.DistanceintoGustxLimitedtogus_i <=
            FixedwingModel_P.DistanceintoGustxLimitedtogus_g);

    // Derivatives for Enabled SubSystem: '<S17>/Distance into gust (x)'
    usat = (FixedwingModel_X.DistanceintoGustxLimitedtogus_i >=
            FixedwingModel_P.Distanceintogustx_d_m);

    // End of Derivatives for SubSystem: '<S17>/Distance into gust (x)'
    if (((!lsat) && (!usat)) || (lsat && (FixedwingModel_P.Constant_Value_lt >
          0.0)) || (usat && (FixedwingModel_P.Constant_Value_lt < 0.0))) {
      _rtXdot->DistanceintoGustxLimitedtogus_i =
        FixedwingModel_P.Constant_Value_lt;
    } else {
      // in saturation
      _rtXdot->DistanceintoGustxLimitedtogus_i = 0.0;
    }

    // End of Derivatives for Integrator: '<S20>/Distance into Gust (x) (Limited to gust length d)' 
  } else {
    ((XDot_FixedwingModel_T *) (&FixedwingModel_M)->derivs)
      ->DistanceintoGustxLimitedtogus_i = 0.0;
  }

  // End of Derivatives for SubSystem: '<S17>/Distance into gust (x)'

  // Derivatives for Enabled SubSystem: '<S17>/Distance into gust (y)'
  // Derivatives for Enabled SubSystem: '<S17>/Distance into gust (y)'
  // Constant: '<S15>/Constant'
  Fixedwi_Distanceintogusty_Deriv(FixedwingModel_P.Constant_Value_lt,
    FixedwingModel_P.Distanceintogusty_d_m, &FixedwingModel_DW.Distanceintogusty,
    &FixedwingModel_P.Distanceintogusty, &FixedwingModel_X.Distanceintogusty,
    &_rtXdot->Distanceintogusty);

  // End of Derivatives for SubSystem: '<S17>/Distance into gust (y)'
  // End of Derivatives for SubSystem: '<S17>/Distance into gust (y)'

  // Derivatives for Enabled SubSystem: '<S17>/Distance into gust (z)'
  // Derivatives for Enabled SubSystem: '<S17>/Distance into gust (z)'
  Fixedwi_Distanceintogusty_Deriv(FixedwingModel_P.Constant_Value_lt,
    FixedwingModel_P.Distanceintogustz_d_m, &FixedwingModel_DW.Distanceintogustz,
    &FixedwingModel_P.Distanceintogustz, &FixedwingModel_X.Distanceintogustz,
    &_rtXdot->Distanceintogustz);

  // End of Derivatives for SubSystem: '<S17>/Distance into gust (z)'
  // End of Derivatives for SubSystem: '<S17>/Distance into gust (z)'

  // Derivatives for SecondOrderIntegrator: '<S512>/Integrator, Second-Order Limited' 
  if (FixedwingModel_DW.IntegratorSecondOrderLimited__c[0] == 0) {
    _rtXdot->IntegratorSecondOrderLimited__o[0] =
      FixedwingModel_X.IntegratorSecondOrderLimited__o[3];
    _rtXdot->IntegratorSecondOrderLimited__o[3] = FixedwingModel_B.Sum2_j[0];
  }

  if (FixedwingModel_DW.IntegratorSecondOrderLimited__c[1] == 0) {
    _rtXdot->IntegratorSecondOrderLimited__o[1] =
      FixedwingModel_X.IntegratorSecondOrderLimited__o[4];
    _rtXdot->IntegratorSecondOrderLimited__o[4] = FixedwingModel_B.Sum2_j[1];
  }

  if (FixedwingModel_DW.IntegratorSecondOrderLimited__c[2] == 0) {
    _rtXdot->IntegratorSecondOrderLimited__o[2] =
      FixedwingModel_X.IntegratorSecondOrderLimited__o[5];
    _rtXdot->IntegratorSecondOrderLimited__o[5] = FixedwingModel_B.Sum2_j[2];
  }

  // End of Derivatives for SecondOrderIntegrator: '<S512>/Integrator, Second-Order Limited' 

  // Derivatives for Enabled SubSystem: '<S527>/Hpgw'
  if (FixedwingModel_DW.Hpgw_MODE) {
    // Derivatives for Integrator: '<S538>/pgw_p'
    _rtXdot->pgw_p_CSTATE[0] = FixedwingModel_B.w_e[0];
    _rtXdot->pgw_p_CSTATE[1] = FixedwingModel_B.w_e[1];
  } else {
    {
      real_T *dx;
      int_T i;
      dx = &(((XDot_FixedwingModel_T *) (&FixedwingModel_M)->derivs)
             ->pgw_p_CSTATE[0]);
      for (i=0; i < 2; i++) {
        dx[i] = 0.0;
      }
    }
  }

  // End of Derivatives for SubSystem: '<S527>/Hpgw'

  // Derivatives for Enabled SubSystem: '<S527>/Hqgw'
  if (FixedwingModel_DW.Hqgw_MODE) {
    // Derivatives for Integrator: '<S539>/qgw_p'
    _rtXdot->qgw_p_CSTATE[0] = FixedwingModel_B.w_d0[0];
    _rtXdot->qgw_p_CSTATE[1] = FixedwingModel_B.w_d0[1];
  } else {
    {
      real_T *dx;
      int_T i;
      dx = &(((XDot_FixedwingModel_T *) (&FixedwingModel_M)->derivs)
             ->qgw_p_CSTATE[0]);
      for (i=0; i < 2; i++) {
        dx[i] = 0.0;
      }
    }
  }

  // End of Derivatives for SubSystem: '<S527>/Hqgw'

  // Derivatives for Enabled SubSystem: '<S527>/Hrgw'
  if (FixedwingModel_DW.Hrgw_MODE) {
    // Derivatives for Integrator: '<S540>/rgw_p'
    _rtXdot->rgw_p_CSTATE[0] = FixedwingModel_B.w_b[0];
    _rtXdot->rgw_p_CSTATE[1] = FixedwingModel_B.w_b[1];
  } else {
    {
      real_T *dx;
      int_T i;
      dx = &(((XDot_FixedwingModel_T *) (&FixedwingModel_M)->derivs)
             ->rgw_p_CSTATE[0]);
      for (i=0; i < 2; i++) {
        dx[i] = 0.0;
      }
    }
  }

  // End of Derivatives for SubSystem: '<S527>/Hrgw'
}

// Model initialize function
void MulticopterModelClass::initialize()
{
  // Registration code

  // initialize non-finites
  rt_InitInfAndNaN(sizeof(real_T));

  // non-finite (run-time) assignments
  FixedwingModel_P.ZeroBound_UpperSat = rtInf;
  FixedwingModel_P.Saturation_UpperSat_a = rtInf;
  FixedwingModel_P.Saturation_LowerSat_p = rtMinusInf;
  FixedwingModel_P.Saturation_UpperSat_n = rtInf;
  FixedwingModel_P.Saturation_UpperSat_b = rtInf;
  FixedwingModel_P.Saturation_UpperSat_i = rtInf;
  FixedwingModel_P.Saturation_UpperSat_m = rtInf;
  FixedwingModel_P.uftinf_UpperSat = rtInf;

  {
    // Setup solver object
    rtsiSetSimTimeStepPtr(&(&FixedwingModel_M)->solverInfo, &(&FixedwingModel_M
                          )->Timing.simTimeStep);
    rtsiSetTPtr(&(&FixedwingModel_M)->solverInfo, &rtmGetTPtr((&FixedwingModel_M)));
    rtsiSetStepSizePtr(&(&FixedwingModel_M)->solverInfo, &(&FixedwingModel_M)
                       ->Timing.stepSize0);
    rtsiSetdXPtr(&(&FixedwingModel_M)->solverInfo, &(&FixedwingModel_M)->derivs);
    rtsiSetContStatesPtr(&(&FixedwingModel_M)->solverInfo, (real_T **)
                         &(&FixedwingModel_M)->contStates);
    rtsiSetNumContStatesPtr(&(&FixedwingModel_M)->solverInfo,
      &(&FixedwingModel_M)->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&(&FixedwingModel_M)->solverInfo,
      &(&FixedwingModel_M)->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&(&FixedwingModel_M)->solverInfo,
      &(&FixedwingModel_M)->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&(&FixedwingModel_M)->solverInfo,
      &(&FixedwingModel_M)->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&(&FixedwingModel_M)->solverInfo, (&rtmGetErrorStatus
      ((&FixedwingModel_M))));
    rtsiSetRTModelPtr(&(&FixedwingModel_M)->solverInfo, (&FixedwingModel_M));
  }

  rtsiSetSimTimeStep(&(&FixedwingModel_M)->solverInfo, MAJOR_TIME_STEP);
  (&FixedwingModel_M)->intgData.y = (&FixedwingModel_M)->odeY;
  (&FixedwingModel_M)->intgData.f[0] = (&FixedwingModel_M)->odeF[0];
  (&FixedwingModel_M)->intgData.f[1] = (&FixedwingModel_M)->odeF[1];
  (&FixedwingModel_M)->intgData.f[2] = (&FixedwingModel_M)->odeF[2];
  (&FixedwingModel_M)->intgData.f[3] = (&FixedwingModel_M)->odeF[3];
  (&FixedwingModel_M)->contStates = ((X_FixedwingModel_T *) &FixedwingModel_X);
  (&FixedwingModel_M)->periodicContStateIndices = ((int_T*)
    FixedwingModel_PeriodicIndX);
  (&FixedwingModel_M)->periodicContStateRanges = ((real_T*)
    FixedwingModel_PeriodicRngX);
  rtsiSetSolverData(&(&FixedwingModel_M)->solverInfo, static_cast<void *>
                    (&(&FixedwingModel_M)->intgData));
  rtsiSetIsMinorTimeStepWithModeChange(&(&FixedwingModel_M)->solverInfo, false);
  rtsiSetSolverName(&(&FixedwingModel_M)->solverInfo,"ode4");
  rtmSetTPtr((&FixedwingModel_M), &(&FixedwingModel_M)->Timing.tArray[0]);
  (&FixedwingModel_M)->Timing.stepSize0 = 0.001;

  {
    real_T tmp;
    int32_T i;
    int32_T t;
    uint32_T tseed;
    static const uint32_T tmp_0[625] = { 5489U, 1301868182U, 2938499221U,
      2950281878U, 1875628136U, 751856242U, 944701696U, 2243192071U, 694061057U,
      219885934U, 2066767472U, 3182869408U, 485472502U, 2336857883U, 1071588843U,
      3418470598U, 951210697U, 3693558366U, 2923482051U, 1793174584U,
      2982310801U, 1586906132U, 1951078751U, 1808158765U, 1733897588U,
      431328322U, 4202539044U, 530658942U, 1714810322U, 3025256284U, 3342585396U,
      1937033938U, 2640572511U, 1654299090U, 3692403553U, 4233871309U,
      3497650794U, 862629010U, 2943236032U, 2426458545U, 1603307207U,
      1133453895U, 3099196360U, 2208657629U, 2747653927U, 931059398U, 761573964U,
      3157853227U, 785880413U, 730313442U, 124945756U, 2937117055U, 3295982469U,
      1724353043U, 3021675344U, 3884886417U, 4010150098U, 4056961966U,
      699635835U, 2681338818U, 1339167484U, 720757518U, 2800161476U, 2376097373U,
      1532957371U, 3902664099U, 1238982754U, 3725394514U, 3449176889U,
      3570962471U, 4287636090U, 4087307012U, 3603343627U, 202242161U,
      2995682783U, 1620962684U, 3704723357U, 371613603U, 2814834333U,
      2111005706U, 624778151U, 2094172212U, 4284947003U, 1211977835U, 991917094U,
      1570449747U, 2962370480U, 1259410321U, 170182696U, 146300961U, 2836829791U,
      619452428U, 2723670296U, 1881399711U, 1161269684U, 1675188680U,
      4132175277U, 780088327U, 3409462821U, 1036518241U, 1834958505U,
      3048448173U, 161811569U, 618488316U, 44795092U, 3918322701U, 1924681712U,
      3239478144U, 383254043U, 4042306580U, 2146983041U, 3992780527U,
      3518029708U, 3545545436U, 3901231469U, 1896136409U, 2028528556U,
      2339662006U, 501326714U, 2060962201U, 2502746480U, 561575027U, 581893337U,
      3393774360U, 1778912547U, 3626131687U, 2175155826U, 319853231U, 986875531U,
      819755096U, 2915734330U, 2688355739U, 3482074849U, 2736559U, 2296975761U,
      1029741190U, 2876812646U, 690154749U, 579200347U, 4027461746U, 1285330465U,
      2701024045U, 4117700889U, 759495121U, 3332270341U, 2313004527U,
      2277067795U, 4131855432U, 2722057515U, 1264804546U, 3848622725U,
      2211267957U, 4100593547U, 959123777U, 2130745407U, 3194437393U, 486673947U,
      1377371204U, 17472727U, 352317554U, 3955548058U, 159652094U, 1232063192U,
      3835177280U, 49423123U, 3083993636U, 733092U, 2120519771U, 2573409834U,
      1112952433U, 3239502554U, 761045320U, 1087580692U, 2540165110U, 641058802U,
      1792435497U, 2261799288U, 1579184083U, 627146892U, 2165744623U,
      2200142389U, 2167590760U, 2381418376U, 1793358889U, 3081659520U,
      1663384067U, 2009658756U, 2689600308U, 739136266U, 2304581039U,
      3529067263U, 591360555U, 525209271U, 3131882996U, 294230224U, 2076220115U,
      3113580446U, 1245621585U, 1386885462U, 3203270426U, 123512128U, 12350217U,
      354956375U, 4282398238U, 3356876605U, 3888857667U, 157639694U, 2616064085U,
      1563068963U, 2762125883U, 4045394511U, 4180452559U, 3294769488U,
      1684529556U, 1002945951U, 3181438866U, 22506664U, 691783457U, 2685221343U,
      171579916U, 3878728600U, 2475806724U, 2030324028U, 3331164912U,
      1708711359U, 1970023127U, 2859691344U, 2588476477U, 2748146879U,
      136111222U, 2967685492U, 909517429U, 2835297809U, 3206906216U, 3186870716U,
      341264097U, 2542035121U, 3353277068U, 548223577U, 3170936588U, 1678403446U,
      297435620U, 2337555430U, 466603495U, 1132321815U, 1208589219U, 696392160U,
      894244439U, 2562678859U, 470224582U, 3306867480U, 201364898U, 2075966438U,
      1767227936U, 2929737987U, 3674877796U, 2654196643U, 3692734598U,
      3528895099U, 2796780123U, 3048728353U, 842329300U, 191554730U, 2922459673U,
      3489020079U, 3979110629U, 1022523848U, 2202932467U, 3583655201U,
      3565113719U, 587085778U, 4176046313U, 3013713762U, 950944241U, 396426791U,
      3784844662U, 3477431613U, 3594592395U, 2782043838U, 3392093507U,
      3106564952U, 2829419931U, 1358665591U, 2206918825U, 3170783123U, 31522386U,
      2988194168U, 1782249537U, 1105080928U, 843500134U, 1225290080U,
      1521001832U, 3605886097U, 2802786495U, 2728923319U, 3996284304U,
      903417639U, 1171249804U, 1020374987U, 2824535874U, 423621996U, 1988534473U,
      2493544470U, 1008604435U, 1756003503U, 1488867287U, 1386808992U,
      732088248U, 1780630732U, 2482101014U, 976561178U, 1543448953U, 2602866064U,
      2021139923U, 1952599828U, 2360242564U, 2117959962U, 2753061860U,
      2388623612U, 4138193781U, 2962920654U, 2284970429U, 766920861U,
      3457264692U, 2879611383U, 815055854U, 2332929068U, 1254853997U,
      3740375268U, 3799380844U, 4091048725U, 2006331129U, 1982546212U,
      686850534U, 1907447564U, 2682801776U, 2780821066U, 998290361U, 1342433871U,
      4195430425U, 607905174U, 3902331779U, 2454067926U, 1708133115U,
      1170874362U, 2008609376U, 3260320415U, 2211196135U, 433538229U,
      2728786374U, 2189520818U, 262554063U, 1182318347U, 3710237267U,
      1221022450U, 715966018U, 2417068910U, 2591870721U, 2870691989U,
      3418190842U, 4238214053U, 1540704231U, 1575580968U, 2095917976U,
      4078310857U, 2313532447U, 2110690783U, 4056346629U, 4061784526U,
      1123218514U, 551538993U, 597148360U, 4120175196U, 3581618160U, 3181170517U,
      422862282U, 3227524138U, 1713114790U, 662317149U, 1230418732U, 928171837U,
      1324564878U, 1928816105U, 1786535431U, 2878099422U, 3290185549U,
      539474248U, 1657512683U, 552370646U, 1671741683U, 3655312128U, 1552739510U,
      2605208763U, 1441755014U, 181878989U, 3124053868U, 1447103986U,
      3183906156U, 1728556020U, 3502241336U, 3055466967U, 1013272474U,
      818402132U, 1715099063U, 2900113506U, 397254517U, 4194863039U, 1009068739U,
      232864647U, 2540223708U, 2608288560U, 2415367765U, 478404847U, 3455100648U,
      3182600021U, 2115988978U, 434269567U, 4117179324U, 3461774077U, 887256537U,
      3545801025U, 286388911U, 3451742129U, 1981164769U, 786667016U, 3310123729U,
      3097811076U, 2224235657U, 2959658883U, 3370969234U, 2514770915U,
      3345656436U, 2677010851U, 2206236470U, 271648054U, 2342188545U,
      4292848611U, 3646533909U, 3754009956U, 3803931226U, 4160647125U,
      1477814055U, 4043852216U, 1876372354U, 3133294443U, 3871104810U,
      3177020907U, 2074304428U, 3479393793U, 759562891U, 164128153U, 1839069216U,
      2114162633U, 3989947309U, 3611054956U, 1333547922U, 835429831U, 494987340U,
      171987910U, 1252001001U, 370809172U, 3508925425U, 2535703112U, 1276855041U,
      1922855120U, 835673414U, 3030664304U, 613287117U, 171219893U, 3423096126U,
      3376881639U, 2287770315U, 1658692645U, 1262815245U, 3957234326U,
      1168096164U, 2968737525U, 2655813712U, 2132313144U, 3976047964U,
      326516571U, 353088456U, 3679188938U, 3205649712U, 2654036126U, 1249024881U,
      880166166U, 691800469U, 2229503665U, 1673458056U, 4032208375U, 1851778863U,
      2563757330U, 376742205U, 1794655231U, 340247333U, 1505873033U, 396524441U,
      879666767U, 3335579166U, 3260764261U, 3335999539U, 506221798U, 4214658741U,
      975887814U, 2080536343U, 3360539560U, 571586418U, 138896374U, 4234352651U,
      2737620262U, 3928362291U, 1516365296U, 38056726U, 3599462320U, 3585007266U,
      3850961033U, 471667319U, 1536883193U, 2310166751U, 1861637689U,
      2530999841U, 4139843801U, 2710569485U, 827578615U, 2012334720U,
      2907369459U, 3029312804U, 2820112398U, 1965028045U, 35518606U, 2478379033U,
      643747771U, 1924139484U, 4123405127U, 3811735531U, 3429660832U,
      3285177704U, 1948416081U, 1311525291U, 1183517742U, 1739192232U,
      3979815115U, 2567840007U, 4116821529U, 213304419U, 4125718577U,
      1473064925U, 2442436592U, 1893310111U, 4195361916U, 3747569474U,
      828465101U, 2991227658U, 750582866U, 1205170309U, 1409813056U, 678418130U,
      1171531016U, 3821236156U, 354504587U, 4202874632U, 3882511497U,
      1893248677U, 1903078632U, 26340130U, 2069166240U, 3657122492U, 3725758099U,
      831344905U, 811453383U, 3447711422U, 2434543565U, 4166886888U, 3358210805U,
      4142984013U, 2988152326U, 3527824853U, 982082992U, 2809155763U, 190157081U,
      3340214818U, 2365432395U, 2548636180U, 2894533366U, 3474657421U,
      2372634704U, 2845748389U, 43024175U, 2774226648U, 1987702864U, 3186502468U,
      453610222U, 4204736567U, 1392892630U, 2471323686U, 2470534280U,
      3541393095U, 4269885866U, 3909911300U, 759132955U, 1482612480U, 667715263U,
      1795580598U, 2337923983U, 3390586366U, 581426223U, 1515718634U, 476374295U,
      705213300U, 363062054U, 2084697697U, 2407503428U, 2292957699U, 2426213835U,
      2199989172U, 1987356470U, 4026755612U, 2147252133U, 270400031U,
      1367820199U, 2369854699U, 2844269403U, 79981964U, 624U };

    // Start for If: '<S533>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 
    FixedwingModel_DW.ifHeightMaxlowaltitudeelseifHei = -1;

    // Start for If: '<S410>/If'
    FixedwingModel_DW.If_ActiveSubsystem = -1;

    // Start for If: '<S409>/If'
    FixedwingModel_DW.If_ActiveSubsystem_n = -1;

    // Start for If: '<S114>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 
    FixedwingModel_DW.ifHeightMaxlowaltitudeelseifH_l = -1;

    // Start for If: '<S75>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 
    FixedwingModel_DW.ifHeightMaxlowaltitudeelseifH_h = -1;

    // Start for If: '<S151>/If'
    FixedwingModel_DW.If_ActiveSubsystem_j = -1;

    // Start for If: '<S74>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 
    FixedwingModel_DW.ifHeightMaxlowaltitudeelseifH_j = -1;

    // Start for If: '<S113>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 
    FixedwingModel_DW.ifHeightMaxlowaltitudeelseifH_g = -1;

    // Start for If: '<S157>/If1'
    FixedwingModel_DW.If1_ActiveSubsystem = -1;

    // Start for If: '<S418>/If1'
    FixedwingModel_DW.If1_ActiveSubsystem_o = -1;

    // Start for If: '<S456>/If1'
    FixedwingModel_DW.If1_ActiveSubsystem_oz = -1;

    // Start for If: '<S532>/if Height < Max low altitude  elseif Height > Min isotropic altitude ' 
    FixedwingModel_DW.ifHeightMaxlowaltitudeelseif_j4 = -1;

    // InitializeConditions for SecondOrderIntegrator: '<S252>/Integrator, Second-Order Limited' 
    FixedwingModel_X.IntegratorSecondOrderLimited_CS[0] =
      FixedwingModel_P.IntegratorSecondOrderLimited_IC;
    FixedwingModel_X.IntegratorSecondOrderLimited_CS[1] =
      FixedwingModel_P.IntegratorSecondOrderLimited_IC;
    FixedwingModel_X.IntegratorSecondOrderLimited_CS[2] =
      FixedwingModel_P.IntegratorSecondOrderLimited_IC;
    FixedwingModel_X.IntegratorSecondOrderLimited_CS[3] =
      FixedwingModel_P.IntegratorSecondOrderLimited__j;

    // InitializeConditions for Integrator: '<S346>/phi theta psi'
    FixedwingModel_X.phithetapsi_CSTATE[0] =
      FixedwingModel_P.ModelInit_AngEuler[0];

    // InitializeConditions for Integrator: '<S341>/ub,vb,wb'
    FixedwingModel_X.ubvbwb_CSTATE[0] = FixedwingModel_P.ModelInit_VelB[0];

    // InitializeConditions for Integrator: '<S341>/xe,ye,ze'
    FixedwingModel_X.xeyeze_CSTATE[0] = FixedwingModel_P.ModelInit_PosE[0];

    // InitializeConditions for SecondOrderIntegrator: '<S252>/Integrator, Second-Order Limited' 
    FixedwingModel_X.IntegratorSecondOrderLimited_CS[4] =
      FixedwingModel_P.IntegratorSecondOrderLimited__j;

    // InitializeConditions for Integrator: '<S346>/phi theta psi'
    FixedwingModel_X.phithetapsi_CSTATE[1] =
      FixedwingModel_P.ModelInit_AngEuler[1];

    // InitializeConditions for Integrator: '<S341>/ub,vb,wb'
    FixedwingModel_X.ubvbwb_CSTATE[1] = FixedwingModel_P.ModelInit_VelB[1];

    // InitializeConditions for Integrator: '<S341>/xe,ye,ze'
    FixedwingModel_X.xeyeze_CSTATE[1] = FixedwingModel_P.ModelInit_PosE[1];

    // InitializeConditions for SecondOrderIntegrator: '<S252>/Integrator, Second-Order Limited' 
    FixedwingModel_X.IntegratorSecondOrderLimited_CS[5] =
      FixedwingModel_P.IntegratorSecondOrderLimited__j;

    // InitializeConditions for Integrator: '<S346>/phi theta psi'
    FixedwingModel_X.phithetapsi_CSTATE[2] =
      FixedwingModel_P.ModelInit_AngEuler[2];

    // InitializeConditions for Integrator: '<S341>/ub,vb,wb'
    FixedwingModel_X.ubvbwb_CSTATE[2] = FixedwingModel_P.ModelInit_VelB[2];

    // InitializeConditions for Integrator: '<S341>/xe,ye,ze'
    FixedwingModel_X.xeyeze_CSTATE[2] = FixedwingModel_P.ModelInit_PosE[2];

    // InitializeConditions for SecondOrderIntegrator: '<S10>/Integrator, Second-Order' 
    FixedwingModel_X.IntegratorSecondOrder_CSTATE[0] =
      FixedwingModel_P.LinearSecondOrderActuators_fin_;
    FixedwingModel_X.IntegratorSecondOrder_CSTATE[1] =
      FixedwingModel_P.LinearSecondOrderActuators_fi_e;

    // InitializeConditions for RandomNumber: '<S537>/White Noise'
    tmp = std::floor(FixedwingModel_P.DrydenWindTurbulenceModel_Seed[0]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed[0] = tseed;
    FixedwingModel_DW.NextOutput[0] = rt_nrand_Upu32_Yd_f_pw_snf
      (&FixedwingModel_DW.RandSeed[0]) * FixedwingModel_P.WhiteNoise_StdDev +
      FixedwingModel_P.WhiteNoise_Mean;
    tmp = std::floor(FixedwingModel_P.DrydenWindTurbulenceModel_Seed[1]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed[1] = tseed;
    FixedwingModel_DW.NextOutput[1] = rt_nrand_Upu32_Yd_f_pw_snf
      (&FixedwingModel_DW.RandSeed[1]) * FixedwingModel_P.WhiteNoise_StdDev +
      FixedwingModel_P.WhiteNoise_Mean;
    tmp = std::floor(FixedwingModel_P.DrydenWindTurbulenceModel_Seed[2]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed[2] = tseed;
    FixedwingModel_DW.NextOutput[2] = rt_nrand_Upu32_Yd_f_pw_snf
      (&FixedwingModel_DW.RandSeed[2]) * FixedwingModel_P.WhiteNoise_StdDev +
      FixedwingModel_P.WhiteNoise_Mean;
    tmp = std::floor(FixedwingModel_P.DrydenWindTurbulenceModel_Seed[3]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed[3] = tseed;
    FixedwingModel_DW.NextOutput[3] = rt_nrand_Upu32_Yd_f_pw_snf
      (&FixedwingModel_DW.RandSeed[3]) * FixedwingModel_P.WhiteNoise_StdDev +
      FixedwingModel_P.WhiteNoise_Mean;

    // End of InitializeConditions for RandomNumber: '<S537>/White Noise'

    // InitializeConditions for TransferFcn: '<S366>/Transfer Fcn'
    FixedwingModel_X.TransferFcn_CSTATE = 0.0;

    // InitializeConditions for TransferFcn: '<S384>/Transfer Fcn'
    FixedwingModel_X.TransferFcn_CSTATE_n = 0.0;

    // InitializeConditions for SecondOrderIntegrator: '<S14>/Integrator, Second-Order' 
    FixedwingModel_X.IntegratorSecondOrder_CSTATE_e[0] =
      FixedwingModel_P.LinearSecondOrderActuator4_fin_;
    FixedwingModel_X.IntegratorSecondOrder_CSTATE_e[1] =
      FixedwingModel_P.LinearSecondOrderActuator4_fi_c;

    // InitializeConditions for SecondOrderIntegrator: '<S11>/Integrator, Second-Order' 
    FixedwingModel_X.IntegratorSecondOrder_CSTATE_k[0] =
      FixedwingModel_P.LinearSecondOrderActuator1_fin_;
    FixedwingModel_X.IntegratorSecondOrder_CSTATE_k[1] =
      FixedwingModel_P.LinearSecondOrderActuator1_fi_e;

    // InitializeConditions for SecondOrderIntegrator: '<S12>/Integrator, Second-Order' 
    FixedwingModel_X.IntegratorSecondOrder_CSTATE_a[0] =
      FixedwingModel_P.LinearSecondOrderActuator2_fin_;
    FixedwingModel_X.IntegratorSecondOrder_CSTATE_a[1] =
      FixedwingModel_P.LinearSecondOrderActuator2_fi_c;

    // InitializeConditions for SecondOrderIntegrator: '<S13>/Integrator, Second-Order' 
    FixedwingModel_X.IntegratorSecondOrder_CSTATE_h[0] =
      FixedwingModel_P.LinearSecondOrderActuator3_fin_;
    FixedwingModel_X.IntegratorSecondOrder_CSTATE_h[1] =
      FixedwingModel_P.LinearSecondOrderActuator3_fi_l;

    // InitializeConditions for Integrator: '<S341>/p,q,r '
    FixedwingModel_X.pqr_CSTATE[0] = FixedwingModel_P.ModelInit_RateB[0];

    // InitializeConditions for UniformRandomNumber: '<S226>/Uniform Random Number5' 
    tmp = std::floor(FixedwingModel_P.UniformRandomNumber5_Seed[0]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed_a[0] = tseed;
    FixedwingModel_DW.UniformRandomNumber5_NextOutput[0] =
      (FixedwingModel_P.UniformRandomNumber5_Maximum[0] -
       FixedwingModel_P.UniformRandomNumber5_Minimum[0]) *
      rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_a[0]) +
      FixedwingModel_P.UniformRandomNumber5_Minimum[0];

    // InitializeConditions for SecondOrderIntegrator: '<S263>/Integrator, Second-Order Limited' 
    FixedwingModel_X.IntegratorSecondOrderLimited__d[0] =
      FixedwingModel_P.IntegratorSecondOrderLimited__n;

    // InitializeConditions for Integrator: '<S341>/p,q,r '
    FixedwingModel_X.pqr_CSTATE[1] = FixedwingModel_P.ModelInit_RateB[1];

    // InitializeConditions for UniformRandomNumber: '<S226>/Uniform Random Number5' 
    tmp = std::floor(FixedwingModel_P.UniformRandomNumber5_Seed[1]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed_a[1] = tseed;
    FixedwingModel_DW.UniformRandomNumber5_NextOutput[1] =
      (FixedwingModel_P.UniformRandomNumber5_Maximum[1] -
       FixedwingModel_P.UniformRandomNumber5_Minimum[1]) *
      rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_a[1]) +
      FixedwingModel_P.UniformRandomNumber5_Minimum[1];

    // InitializeConditions for SecondOrderIntegrator: '<S263>/Integrator, Second-Order Limited' 
    FixedwingModel_X.IntegratorSecondOrderLimited__d[1] =
      FixedwingModel_P.IntegratorSecondOrderLimited__n;

    // InitializeConditions for Integrator: '<S341>/p,q,r '
    FixedwingModel_X.pqr_CSTATE[2] = FixedwingModel_P.ModelInit_RateB[2];

    // InitializeConditions for UniformRandomNumber: '<S226>/Uniform Random Number5' 
    tmp = std::floor(FixedwingModel_P.UniformRandomNumber5_Seed[2]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed_a[2] = tseed;
    FixedwingModel_DW.UniformRandomNumber5_NextOutput[2] =
      (FixedwingModel_P.UniformRandomNumber5_Maximum[2] -
       FixedwingModel_P.UniformRandomNumber5_Minimum[2]) *
      rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_a[2]) +
      FixedwingModel_P.UniformRandomNumber5_Minimum[2];

    // InitializeConditions for SecondOrderIntegrator: '<S263>/Integrator, Second-Order Limited' 
    FixedwingModel_X.IntegratorSecondOrderLimited__d[2] =
      FixedwingModel_P.IntegratorSecondOrderLimited__n;

    // InitializeConditions for Memory: '<S287>/otime'
    FixedwingModel_DW.otime_PreviousInput =
      FixedwingModel_P.otime_InitialCondition;

    // InitializeConditions for Memory: '<S286>/olon'
    FixedwingModel_DW.olon_PreviousInput =
      FixedwingModel_P.olon_InitialCondition;

    // InitializeConditions for Memory: '<S285>/olat'
    FixedwingModel_DW.olat_PreviousInput =
      FixedwingModel_P.olat_InitialCondition;

    // InitializeConditions for Memory: '<S285>/oalt'
    FixedwingModel_DW.oalt_PreviousInput =
      FixedwingModel_P.oalt_InitialCondition;

    // InitializeConditions for SecondOrderIntegrator: '<S263>/Integrator, Second-Order Limited' 
    FixedwingModel_X.IntegratorSecondOrderLimited__d[3] =
      FixedwingModel_P.IntegratorSecondOrderLimited__l;

    // InitializeConditions for UniformRandomNumber: '<S226>/Uniform Random Number1' 
    tmp = std::floor(FixedwingModel_P.UniformRandomNumber1_Seed[0]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed_j[0] = tseed;
    FixedwingModel_DW.UniformRandomNumber1_NextOutput[0] =
      (FixedwingModel_P.UniformRandomNumber1_Maximum[0] -
       FixedwingModel_P.UniformRandomNumber1_Minimum[0]) *
      rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_j[0]) +
      FixedwingModel_P.UniformRandomNumber1_Minimum[0];

    // InitializeConditions for UniformRandomNumber: '<S226>/Uniform Random Number7' 
    tmp = std::floor(FixedwingModel_P.UniformRandomNumber7_Seed[0]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed_p[0] = tseed;
    FixedwingModel_DW.UniformRandomNumber7_NextOutput[0] =
      (FixedwingModel_P.UniformRandomNumber7_Maximum[0] -
       FixedwingModel_P.UniformRandomNumber7_Minimum[0]) *
      rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_p[0]) +
      FixedwingModel_P.UniformRandomNumber7_Minimum[0];

    // InitializeConditions for UniformRandomNumber: '<S28>/Uniform Random Number' 
    tmp = std::floor(FixedwingModel_P.UniformRandomNumber_Seed[0]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed_h[0] = tseed;
    FixedwingModel_DW.UniformRandomNumber_NextOutput[0] =
      (FixedwingModel_P.UniformRandomNumber_Maximum[0] -
       FixedwingModel_P.UniformRandomNumber_Minimum[0]) *
      rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_h[0]) +
      FixedwingModel_P.UniformRandomNumber_Minimum[0];

    // InitializeConditions for SecondOrderIntegrator: '<S263>/Integrator, Second-Order Limited' 
    FixedwingModel_X.IntegratorSecondOrderLimited__d[4] =
      FixedwingModel_P.IntegratorSecondOrderLimited__l;

    // InitializeConditions for UniformRandomNumber: '<S226>/Uniform Random Number1' 
    tmp = std::floor(FixedwingModel_P.UniformRandomNumber1_Seed[1]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed_j[1] = tseed;
    FixedwingModel_DW.UniformRandomNumber1_NextOutput[1] =
      (FixedwingModel_P.UniformRandomNumber1_Maximum[1] -
       FixedwingModel_P.UniformRandomNumber1_Minimum[1]) *
      rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_j[1]) +
      FixedwingModel_P.UniformRandomNumber1_Minimum[1];

    // InitializeConditions for UniformRandomNumber: '<S226>/Uniform Random Number7' 
    tmp = std::floor(FixedwingModel_P.UniformRandomNumber7_Seed[1]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed_p[1] = tseed;
    FixedwingModel_DW.UniformRandomNumber7_NextOutput[1] =
      (FixedwingModel_P.UniformRandomNumber7_Maximum[1] -
       FixedwingModel_P.UniformRandomNumber7_Minimum[1]) *
      rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_p[1]) +
      FixedwingModel_P.UniformRandomNumber7_Minimum[1];

    // InitializeConditions for UniformRandomNumber: '<S28>/Uniform Random Number' 
    tmp = std::floor(FixedwingModel_P.UniformRandomNumber_Seed[1]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed_h[1] = tseed;
    FixedwingModel_DW.UniformRandomNumber_NextOutput[1] =
      (FixedwingModel_P.UniformRandomNumber_Maximum[1] -
       FixedwingModel_P.UniformRandomNumber_Minimum[1]) *
      rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_h[1]) +
      FixedwingModel_P.UniformRandomNumber_Minimum[1];

    // InitializeConditions for SecondOrderIntegrator: '<S263>/Integrator, Second-Order Limited' 
    FixedwingModel_X.IntegratorSecondOrderLimited__d[5] =
      FixedwingModel_P.IntegratorSecondOrderLimited__l;

    // InitializeConditions for UniformRandomNumber: '<S226>/Uniform Random Number1' 
    tmp = std::floor(FixedwingModel_P.UniformRandomNumber1_Seed[2]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed_j[2] = tseed;
    FixedwingModel_DW.UniformRandomNumber1_NextOutput[2] =
      (FixedwingModel_P.UniformRandomNumber1_Maximum[2] -
       FixedwingModel_P.UniformRandomNumber1_Minimum[2]) *
      rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_j[2]) +
      FixedwingModel_P.UniformRandomNumber1_Minimum[2];

    // InitializeConditions for UniformRandomNumber: '<S226>/Uniform Random Number7' 
    tmp = std::floor(FixedwingModel_P.UniformRandomNumber7_Seed[2]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed_p[2] = tseed;
    FixedwingModel_DW.UniformRandomNumber7_NextOutput[2] =
      (FixedwingModel_P.UniformRandomNumber7_Maximum[2] -
       FixedwingModel_P.UniformRandomNumber7_Minimum[2]) *
      rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_p[2]) +
      FixedwingModel_P.UniformRandomNumber7_Minimum[2];

    // InitializeConditions for UniformRandomNumber: '<S28>/Uniform Random Number' 
    tmp = std::floor(FixedwingModel_P.UniformRandomNumber_Seed[2]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed_h[2] = tseed;
    FixedwingModel_DW.UniformRandomNumber_NextOutput[2] =
      (FixedwingModel_P.UniformRandomNumber_Maximum[2] -
       FixedwingModel_P.UniformRandomNumber_Minimum[2]) *
      rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_h[2]) +
      FixedwingModel_P.UniformRandomNumber_Minimum[2];

    // InitializeConditions for RandomNumber: '<S118>/White Noise'
    tmp = std::floor(FixedwingModel_P.DrydenWindTurbulenceModelDisc_o[0]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed_ab[0] = tseed;
    FixedwingModel_DW.NextOutput_c[0] = rt_nrand_Upu32_Yd_f_pw_snf
      (&FixedwingModel_DW.RandSeed_ab[0]) * FixedwingModel_P.WhiteNoise_StdDev_a
      + FixedwingModel_P.WhiteNoise_Mean_l;

    // InitializeConditions for RandomNumber: '<S79>/White Noise'
    tmp = std::floor(FixedwingModel_P.DrydenWindTurbulenceModelDis_o3[0]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>
      (static_cast<uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed_ah[0] = tseed;
    FixedwingModel_DW.NextOutput_b[0] = rt_nrand_Upu32_Yd_f_pw_snf
      (&FixedwingModel_DW.RandSeed_ah[0]) * FixedwingModel_P.WhiteNoise_StdDev_h
      + FixedwingModel_P.WhiteNoise_Mean_e;

    // InitializeConditions for RandomNumber: '<S118>/White Noise'
    tmp = std::floor(FixedwingModel_P.DrydenWindTurbulenceModelDisc_o[1]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>
      (static_cast<uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed_ab[1] = tseed;
    FixedwingModel_DW.NextOutput_c[1] = rt_nrand_Upu32_Yd_f_pw_snf
      (&FixedwingModel_DW.RandSeed_ab[1]) * FixedwingModel_P.WhiteNoise_StdDev_a
      + FixedwingModel_P.WhiteNoise_Mean_l;

    // InitializeConditions for RandomNumber: '<S79>/White Noise'
    tmp = std::floor(FixedwingModel_P.DrydenWindTurbulenceModelDis_o3[1]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>
      (static_cast<uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed_ah[1] = tseed;
    FixedwingModel_DW.NextOutput_b[1] = rt_nrand_Upu32_Yd_f_pw_snf
      (&FixedwingModel_DW.RandSeed_ah[1]) * FixedwingModel_P.WhiteNoise_StdDev_h
      + FixedwingModel_P.WhiteNoise_Mean_e;

    // InitializeConditions for RandomNumber: '<S118>/White Noise'
    tmp = std::floor(FixedwingModel_P.DrydenWindTurbulenceModelDisc_o[2]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>
      (static_cast<uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed_ab[2] = tseed;
    FixedwingModel_DW.NextOutput_c[2] = rt_nrand_Upu32_Yd_f_pw_snf
      (&FixedwingModel_DW.RandSeed_ab[2]) * FixedwingModel_P.WhiteNoise_StdDev_a
      + FixedwingModel_P.WhiteNoise_Mean_l;

    // InitializeConditions for RandomNumber: '<S79>/White Noise'
    tmp = std::floor(FixedwingModel_P.DrydenWindTurbulenceModelDis_o3[2]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>
      (static_cast<uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed_ah[2] = tseed;
    FixedwingModel_DW.NextOutput_b[2] = rt_nrand_Upu32_Yd_f_pw_snf
      (&FixedwingModel_DW.RandSeed_ah[2]) * FixedwingModel_P.WhiteNoise_StdDev_h
      + FixedwingModel_P.WhiteNoise_Mean_e;

    // InitializeConditions for RandomNumber: '<S118>/White Noise'
    tmp = std::floor(FixedwingModel_P.DrydenWindTurbulenceModelDisc_o[3]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>
      (static_cast<uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed_ab[3] = tseed;
    FixedwingModel_DW.NextOutput_c[3] = rt_nrand_Upu32_Yd_f_pw_snf
      (&FixedwingModel_DW.RandSeed_ab[3]) * FixedwingModel_P.WhiteNoise_StdDev_a
      + FixedwingModel_P.WhiteNoise_Mean_l;

    // InitializeConditions for RandomNumber: '<S79>/White Noise'
    tmp = std::floor(FixedwingModel_P.DrydenWindTurbulenceModelDis_o3[3]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>
      (static_cast<uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed_ah[3] = tseed;
    FixedwingModel_DW.NextOutput_b[3] = rt_nrand_Upu32_Yd_f_pw_snf
      (&FixedwingModel_DW.RandSeed_ah[3]) * FixedwingModel_P.WhiteNoise_StdDev_h
      + FixedwingModel_P.WhiteNoise_Mean_e;

    // InitializeConditions for UniformRandomNumber: '<S226>/Uniform Random Number' 
    tmp = std::floor(FixedwingModel_P.UniformRandomNumber_Seed_m);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>
      (static_cast<uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed_c = tseed;
    FixedwingModel_DW.UniformRandomNumber_NextOutpu_a =
      (FixedwingModel_P.UniformRandomNumber_Maximum_n -
       FixedwingModel_P.UniformRandomNumber_Minimum_m) *
      rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_c) +
      FixedwingModel_P.UniformRandomNumber_Minimum_m;

    // End of InitializeConditions for UniformRandomNumber: '<S226>/Uniform Random Number' 

    // InitializeConditions for UniformRandomNumber: '<S226>/Uniform Random Number4' 
    tmp = std::floor(FixedwingModel_P.UniformRandomNumber4_Seed);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed_m = tseed;
    FixedwingModel_DW.UniformRandomNumber4_NextOutput =
      (FixedwingModel_P.UniformRandomNumber4_Maximum -
       FixedwingModel_P.UniformRandomNumber4_Minimum) *
      rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_m) +
      FixedwingModel_P.UniformRandomNumber4_Minimum;

    // End of InitializeConditions for UniformRandomNumber: '<S226>/Uniform Random Number4' 

    // InitializeConditions for UniformRandomNumber: '<S194>/Uniform Random Number5' 
    tmp = std::floor(FixedwingModel_P.UniformRandomNumber5_Seed_e[0]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed_d[0] = tseed;
    FixedwingModel_DW.UniformRandomNumber5_NextOutp_j[0] =
      (FixedwingModel_P.UniformRandomNumber5_Maximum_f[0] -
       FixedwingModel_P.UniformRandomNumber5_Minimum_n[0]) *
      rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_d[0]) +
      FixedwingModel_P.UniformRandomNumber5_Minimum_n[0];
    tmp = std::floor(FixedwingModel_P.UniformRandomNumber5_Seed_e[1]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed_d[1] = tseed;
    FixedwingModel_DW.UniformRandomNumber5_NextOutp_j[1] =
      (FixedwingModel_P.UniformRandomNumber5_Maximum_f[1] -
       FixedwingModel_P.UniformRandomNumber5_Minimum_n[1]) *
      rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_d[1]) +
      FixedwingModel_P.UniformRandomNumber5_Minimum_n[1];
    tmp = std::floor(FixedwingModel_P.UniformRandomNumber5_Seed_e[2]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed_d[2] = tseed;
    FixedwingModel_DW.UniformRandomNumber5_NextOutp_j[2] =
      (FixedwingModel_P.UniformRandomNumber5_Maximum_f[2] -
       FixedwingModel_P.UniformRandomNumber5_Minimum_n[2]) *
      rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_d[2]) +
      FixedwingModel_P.UniformRandomNumber5_Minimum_n[2];

    // End of InitializeConditions for UniformRandomNumber: '<S194>/Uniform Random Number5' 

    // InitializeConditions for TransferFcn: '<S196>/Transfer Fcn4'
    FixedwingModel_X.TransferFcn4_CSTATE = 0.0;

    // InitializeConditions for TransferFcn: '<S196>/Transfer Fcn1'
    FixedwingModel_X.TransferFcn1_CSTATE = 0.0;

    // InitializeConditions for TransferFcn: '<S196>/Transfer Fcn2'
    FixedwingModel_X.TransferFcn2_CSTATE = 0.0;

    // InitializeConditions for RandomNumber: '<S16>/White Noise'
    tmp = std::floor(FixedwingModel_P.BandLimitedWhiteNoise_seed);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed_ph = tseed;
    FixedwingModel_DW.NextOutput_p = rt_nrand_Upu32_Yd_f_pw_snf
      (&FixedwingModel_DW.RandSeed_ph) * FixedwingModel_P.WhiteNoise_StdDev_k +
      FixedwingModel_P.WhiteNoise_Mean_f;

    // End of InitializeConditions for RandomNumber: '<S16>/White Noise'

    // InitializeConditions for UniformRandomNumber: '<S152>/Uniform Random Number4' 
    tmp = std::floor(FixedwingModel_P.UniformRandomNumber4_Seed_g[0]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed_as[0] = tseed;
    FixedwingModel_DW.UniformRandomNumber4_NextOutp_l[0] =
      (FixedwingModel_P.UniformRandomNumber4_Maximum_a[0] -
       FixedwingModel_P.UniformRandomNumber4_Minimum_o[0]) *
      rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_as[0]) +
      FixedwingModel_P.UniformRandomNumber4_Minimum_o[0];

    // InitializeConditions for SecondOrderIntegrator: '<S512>/Integrator, Second-Order Limited' 
    FixedwingModel_X.IntegratorSecondOrderLimited__o[0] =
      FixedwingModel_P.IntegratorSecondOrderLimited__g;

    // InitializeConditions for UniformRandomNumber: '<S152>/Uniform Random Number4' 
    tmp = std::floor(FixedwingModel_P.UniformRandomNumber4_Seed_g[1]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed_as[1] = tseed;
    FixedwingModel_DW.UniformRandomNumber4_NextOutp_l[1] =
      (FixedwingModel_P.UniformRandomNumber4_Maximum_a[1] -
       FixedwingModel_P.UniformRandomNumber4_Minimum_o[1]) *
      rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_as[1]) +
      FixedwingModel_P.UniformRandomNumber4_Minimum_o[1];

    // InitializeConditions for SecondOrderIntegrator: '<S512>/Integrator, Second-Order Limited' 
    FixedwingModel_X.IntegratorSecondOrderLimited__o[1] =
      FixedwingModel_P.IntegratorSecondOrderLimited__g;

    // InitializeConditions for UniformRandomNumber: '<S152>/Uniform Random Number4' 
    tmp = std::floor(FixedwingModel_P.UniformRandomNumber4_Seed_g[2]);
    if (rtIsNaN(tmp) || rtIsInf(tmp)) {
      tmp = 0.0;
    } else {
      tmp = std::fmod(tmp, 4.294967296E+9);
    }

    tseed = tmp < 0.0 ? static_cast<uint32_T>(-static_cast<int32_T>(static_cast<
      uint32_T>(-tmp))) : static_cast<uint32_T>(tmp);
    i = static_cast<int32_T>(tseed >> 16U);
    t = static_cast<int32_T>(tseed & 32768U);
    tseed = ((((tseed - (static_cast<uint32_T>(i) << 16U)) + t) << 16U) + t) + i;
    if (tseed < 1U) {
      tseed = 1144108930U;
    } else if (tseed > 2147483646U) {
      tseed = 2147483646U;
    }

    FixedwingModel_DW.RandSeed_as[2] = tseed;
    FixedwingModel_DW.UniformRandomNumber4_NextOutp_l[2] =
      (FixedwingModel_P.UniformRandomNumber4_Maximum_a[2] -
       FixedwingModel_P.UniformRandomNumber4_Minimum_o[2]) *
      rt_urand_Upu32_Yd_f_pw_snf(&FixedwingModel_DW.RandSeed_as[2]) +
      FixedwingModel_P.UniformRandomNumber4_Minimum_o[2];

    // InitializeConditions for SecondOrderIntegrator: '<S512>/Integrator, Second-Order Limited' 
    FixedwingModel_X.IntegratorSecondOrderLimited__o[2] =
      FixedwingModel_P.IntegratorSecondOrderLimited__g;
    FixedwingModel_X.IntegratorSecondOrderLimited__o[3] =
      FixedwingModel_P.IntegratorSecondOrderLimited__o;
    FixedwingModel_X.IntegratorSecondOrderLimited__o[4] =
      FixedwingModel_P.IntegratorSecondOrderLimited__o;
    FixedwingModel_X.IntegratorSecondOrderLimited__o[5] =
      FixedwingModel_P.IntegratorSecondOrderLimited__o;

    // SystemInitialize for Merge: '<S369>/Merge'
    FixedwingModel_B.Merge = FixedwingModel_P.Merge_InitialOutput_c;

    // SystemInitialize for Merge: '<S525>/Merge'
    FixedwingModel_B.Merge_c = FixedwingModel_P.Merge_InitialOutput_f;

    // SystemInitialize for Enabled SubSystem: '<S528>/Hugw(s)'
    // InitializeConditions for Integrator: '<S541>/ug_p'
    FixedwingModel_X.ug_p_CSTATE[0] = FixedwingModel_P.ug_p_IC;

    // SystemInitialize for Product: '<S541>/w1' incorporates:
    //   Outport: '<S541>/ugw'

    FixedwingModel_B.w1_f[0] = FixedwingModel_P.ugw_Y0;

    // End of SystemInitialize for SubSystem: '<S528>/Hugw(s)'

    // SystemInitialize for Enabled SubSystem: '<S528>/Hvgw(s)'
    // InitializeConditions for Integrator: '<S542>/vg_p1'
    FixedwingModel_X.vg_p1_CSTATE[0] = FixedwingModel_P.vg_p1_IC;

    // InitializeConditions for Integrator: '<S542>/vgw_p2'
    FixedwingModel_X.vgw_p2_CSTATE[0] = FixedwingModel_P.vgw_p2_IC;

    // SystemInitialize for Product: '<S542>/w 1' incorporates:
    //   Outport: '<S542>/vgw'

    FixedwingModel_B.w1[0] = FixedwingModel_P.vgw_Y0;

    // End of SystemInitialize for SubSystem: '<S528>/Hvgw(s)'

    // SystemInitialize for Enabled SubSystem: '<S528>/Hwgw(s)'
    // InitializeConditions for Integrator: '<S543>/wg_p1'
    FixedwingModel_X.wg_p1_CSTATE[0] = FixedwingModel_P.wg_p1_IC;

    // InitializeConditions for Integrator: '<S543>/wg_p2'
    FixedwingModel_X.wg_p2_CSTATE[0] = FixedwingModel_P.wg_p2_IC;

    // SystemInitialize for Product: '<S543>/Lwg//V 1' incorporates:
    //   Outport: '<S543>/wgw'

    FixedwingModel_B.LwgV1[0] = FixedwingModel_P.wgw_Y0;

    // End of SystemInitialize for SubSystem: '<S528>/Hwgw(s)'

    // SystemInitialize for Enabled SubSystem: '<S528>/Hugw(s)'
    // InitializeConditions for Integrator: '<S541>/ug_p'
    FixedwingModel_X.ug_p_CSTATE[1] = FixedwingModel_P.ug_p_IC;

    // SystemInitialize for Product: '<S541>/w1' incorporates:
    //   Outport: '<S541>/ugw'

    FixedwingModel_B.w1_f[1] = FixedwingModel_P.ugw_Y0;

    // End of SystemInitialize for SubSystem: '<S528>/Hugw(s)'

    // SystemInitialize for Enabled SubSystem: '<S528>/Hvgw(s)'
    // InitializeConditions for Integrator: '<S542>/vg_p1'
    FixedwingModel_X.vg_p1_CSTATE[1] = FixedwingModel_P.vg_p1_IC;

    // InitializeConditions for Integrator: '<S542>/vgw_p2'
    FixedwingModel_X.vgw_p2_CSTATE[1] = FixedwingModel_P.vgw_p2_IC;

    // SystemInitialize for Product: '<S542>/w 1' incorporates:
    //   Outport: '<S542>/vgw'

    FixedwingModel_B.w1[1] = FixedwingModel_P.vgw_Y0;

    // End of SystemInitialize for SubSystem: '<S528>/Hvgw(s)'

    // SystemInitialize for Enabled SubSystem: '<S528>/Hwgw(s)'
    // InitializeConditions for Integrator: '<S543>/wg_p1'
    FixedwingModel_X.wg_p1_CSTATE[1] = FixedwingModel_P.wg_p1_IC;

    // InitializeConditions for Integrator: '<S543>/wg_p2'
    FixedwingModel_X.wg_p2_CSTATE[1] = FixedwingModel_P.wg_p2_IC;

    // SystemInitialize for Product: '<S543>/Lwg//V 1' incorporates:
    //   Outport: '<S543>/wgw'

    FixedwingModel_B.LwgV1[1] = FixedwingModel_P.wgw_Y0;

    // End of SystemInitialize for SubSystem: '<S528>/Hwgw(s)'

    // SystemInitialize for IfAction SubSystem: '<S410>/Negative Trace'
    FixedwingMod_NegativeTrace_Init(&FixedwingModel_DW.NegativeTrace_a);

    // End of SystemInitialize for SubSystem: '<S410>/Negative Trace'

    // SystemInitialize for Merge: '<S410>/Merge'
    FixedwingModel_B.Merge_l[0] = FixedwingModel_P.Merge_InitialOutput_fj[0];
    FixedwingModel_B.Merge_l[1] = FixedwingModel_P.Merge_InitialOutput_fj[1];
    FixedwingModel_B.Merge_l[2] = FixedwingModel_P.Merge_InitialOutput_fj[2];
    FixedwingModel_B.Merge_l[3] = FixedwingModel_P.Merge_InitialOutput_fj[3];

    // SystemInitialize for IfAction SubSystem: '<S409>/Negative Trace'
    FixedwingMod_NegativeTrace_Init(&FixedwingModel_DW.NegativeTrace_j);

    // End of SystemInitialize for SubSystem: '<S409>/Negative Trace'

    // SystemInitialize for Merge: '<S409>/Merge'
    FixedwingModel_B.Merge_lc[0] = FixedwingModel_P.Merge_InitialOutput_p[0];
    FixedwingModel_B.Merge_lc[1] = FixedwingModel_P.Merge_InitialOutput_p[1];
    FixedwingModel_B.Merge_lc[2] = FixedwingModel_P.Merge_InitialOutput_p[2];
    FixedwingModel_B.Merge_lc[3] = FixedwingModel_P.Merge_InitialOutput_p[3];

    // SystemInitialize for MATLAB Function: '<Root>/CollisionDetection'
    std::memcpy(&FixedwingModel_DW.state_k[0], &tmp_0[0], 625U * sizeof(uint32_T));
    FixedwingModel_DW.method_o = 7U;
    FixedwingModel_DW.state_n = 1144108930U;
    FixedwingModel_DW.state_an[0] = 362436069U;
    FixedwingModel_DW.state_an[1] = 521288629U;

    // SystemInitialize for MATLAB Function: '<S344>/Ground Model'
    // '<S2>:1:7' isCol=int8(0);
    // '<S2>:1:13' fOut=[0;0;0;0;0;0];
    // '<S2>:1:19' mv0=[0;0;0];
    // '<S2>:1:25' tColi=0;
    // '<S5>:1:6' lastZ=0;
    // '<S412>:1:11' takeoffFlag=int8(0);
    // '<S412>:1:16' landFlag=int8(1);
    FixedwingModel_DW.landFlag = 1;

    // SystemInitialize for Enabled SubSystem: '<S273>/Convert from geodetic to  spherical coordinates ' 
    // SystemInitialize for Iterator SubSystem: '<S283>/For Iterator Subsystem'
    // InitializeConditions for UnitDelay: '<S330>/Unit Delay1'
    // '<S229>:1:6' hFault=false;
    // '<S229>:1:9' fParam=zeros(20,1);
    // '<S230>:1:6' hFault=false;
    // '<S230>:1:9' fParam=zeros(20,1);
    FixedwingModel_DW.UnitDelay1_DSTATE[0] =
      FixedwingModel_P.UnitDelay1_InitialCondition_e;
    FixedwingModel_DW.UnitDelay1_DSTATE[1] =
      FixedwingModel_P.UnitDelay1_InitialCondition_e;

    // End of SystemInitialize for SubSystem: '<S283>/For Iterator Subsystem'

    // SystemInitialize for SignalConversion generated from: '<S283>/sp[13]' incorporates:
    //   Outport: '<S283>/sp[13]'

    std::memcpy(&FixedwingModel_B.OutportBufferForsp13[0],
                &FixedwingModel_P.sp13_Y0[0], 13U * sizeof(real_T));

    // SystemInitialize for SignalConversion generated from: '<S283>/cp[13]' incorporates:
    //   Outport: '<S283>/cp[13]'

    std::memcpy(&FixedwingModel_B.OutportBufferForcp13[0],
                &FixedwingModel_P.cp13_Y0[0], 13U * sizeof(real_T));

    // End of SystemInitialize for SubSystem: '<S273>/Convert from geodetic to  spherical coordinates ' 

    // SystemInitialize for Enabled SubSystem: '<S273>/Convert from geodetic to  spherical coordinates' 
    // SystemInitialize for Sqrt: '<S282>/sqrt' incorporates:
    //   Outport: '<S282>/r'

    FixedwingModel_B.sqrt_d = FixedwingModel_P.r_Y0;

    // SystemInitialize for Product: '<S323>/Product4' incorporates:
    //   Outport: '<S282>/ct'

    FixedwingModel_B.Product4_a = FixedwingModel_P.ct_Y0;

    // SystemInitialize for Sqrt: '<S329>/sqrt' incorporates:
    //   Outport: '<S282>/st'

    FixedwingModel_B.sqrt_j = FixedwingModel_P.st_Y0;

    // SystemInitialize for Product: '<S328>/Product12' incorporates:
    //   Outport: '<S282>/sa'

    FixedwingModel_B.Product12 = FixedwingModel_P.sa_Y0;

    // SystemInitialize for Product: '<S322>/Product11' incorporates:
    //   Outport: '<S282>/ca'

    FixedwingModel_B.Product11 = FixedwingModel_P.ca_Y0;

    // End of SystemInitialize for SubSystem: '<S273>/Convert from geodetic to  spherical coordinates' 

    // SystemInitialize for Iterator SubSystem: '<S273>/Compute magnetic vector in spherical coordinates' 
    // SystemInitialize for Iterator SubSystem: '<S281>/For Iterator Subsystem'
    // SystemInitialize for Enabled SubSystem: '<S289>/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations' 
    // SystemInitialize for Merge: '<S291>/Merge1'
    FixedwingModel_B.Merge1_o = FixedwingModel_P.Merge1_InitialOutput;

    // SystemInitialize for Merge: '<S291>/Merge'
    FixedwingModel_B.Merge_h = FixedwingModel_P.Merge_InitialOutput;

    // End of SystemInitialize for SubSystem: '<S289>/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations' 

    // SystemInitialize for Enabled SubSystem: '<S289>/Time adjust the gauss coefficients' 
    // InitializeConditions for UnitDelay: '<S292>/Unit Delay'
    std::memcpy(&FixedwingModel_DW.UnitDelay_DSTATE_i[0],
                &FixedwingModel_P.UnitDelay_InitialCondition_d[0], 169U * sizeof
                (real_T));

    // InitializeConditions for UnitDelay: '<S319>/Unit Delay'
    std::memcpy(&FixedwingModel_DW.UnitDelay_DSTATE_k[0],
                &FixedwingModel_P.UnitDelay_InitialCondition_l[0], 169U * sizeof
                (real_T));

    // SystemInitialize for Sum: '<S292>/Sum2' incorporates:
    //   Outport: '<S292>/tc[13][13]'

    std::memcpy(&FixedwingModel_B.Sum2_gf[0], &FixedwingModel_P.tc1313_Y0[0],
                169U * sizeof(real_T));

    // End of SystemInitialize for SubSystem: '<S289>/Time adjust the gauss coefficients' 

    // SystemInitialize for Enabled SubSystem: '<S289>/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations' 
    // InitializeConditions for UnitDelay: '<S291>/Unit Delay'
    std::memcpy(&FixedwingModel_DW.UnitDelay_DSTATE_h[0],
                &FixedwingModel_P.UnitDelay_InitialCondition[0], 169U * sizeof
                (real_T));

    // InitializeConditions for UnitDelay: '<S291>/Unit Delay1'
    std::memcpy(&FixedwingModel_DW.UnitDelay1_DSTATE_e[0],
                &FixedwingModel_P.UnitDelay1_InitialCondition_g[0], 169U *
                sizeof(real_T));

    // SystemInitialize for Assignment: '<S291>/Assignment' incorporates:
    //   Outport: '<S291>/dp[13][13]'

    std::memcpy(&FixedwingModel_B.Assignment_p[0], &FixedwingModel_P.dp1313_Y0[0],
                169U * sizeof(real_T));

    // SystemInitialize for Assignment: '<S291>/Assignment_snorm' incorporates:
    //   Outport: '<S291>/snorm[169]'

    std::memcpy(&FixedwingModel_B.Assignment_snorm[0],
                &FixedwingModel_P.snorm169_Y0[0], 169U * sizeof(real_T));

    // End of SystemInitialize for SubSystem: '<S289>/Compute unnormalized associated  legendre polynomials and  derivatives via recursion relations' 

    // SystemInitialize for Enabled SubSystem: '<S290>/Special case - North//South Geographic Pole' 
    // InitializeConditions for UnitDelay: '<S293>/Unit Delay1'
    std::memcpy(&FixedwingModel_DW.UnitDelay1_DSTATE_h[0],
                &FixedwingModel_P.UnitDelay1_InitialCondition[0], 13U * sizeof
                (real_T));

    // SystemInitialize for IfAction SubSystem: '<S293>/If Action Subsystem1'
    // SystemInitialize for Assignment: '<S297>/Assignment2' incorporates:
    //   Outport: '<S297>/pp[13]'

    std::memcpy(&FixedwingModel_B.Assignment2_c[0], &FixedwingModel_P.pp13_Y0[0],
                13U * sizeof(real_T));

    // End of SystemInitialize for SubSystem: '<S293>/If Action Subsystem1'

    // SystemInitialize for IfAction SubSystem: '<S293>/If Action Subsystem2'
    // SystemInitialize for Assignment: '<S298>/Assignment2' incorporates:
    //   Outport: '<S298>/pp[13]'

    std::memcpy(&FixedwingModel_B.Assignment2_g[0], &FixedwingModel_P.pp13_Y0_j
                [0], 13U * sizeof(real_T));

    // End of SystemInitialize for SubSystem: '<S293>/If Action Subsystem2'

    // SystemInitialize for Product: '<S293>/Product2' incorporates:
    //   Outport: '<S293>/bpp'

    FixedwingModel_B.Product2_h = FixedwingModel_P.bpp_Y0;

    // End of SystemInitialize for SubSystem: '<S290>/Special case - North//South Geographic Pole' 

    // SystemInitialize for Sum: '<S290>/Sum1' incorporates:
    //   Outport: '<S289>/bt'

    FixedwingModel_B.Sum1_m = FixedwingModel_P.bt_Y0;

    // SystemInitialize for Sum: '<S290>/Sum2' incorporates:
    //   Outport: '<S289>/bp'

    FixedwingModel_B.Sum2_h = FixedwingModel_P.bp_Y0;

    // SystemInitialize for Sum: '<S290>/Sum3' incorporates:
    //   Outport: '<S289>/br'

    FixedwingModel_B.Sum3 = FixedwingModel_P.br_Y0;

    // SystemInitialize for Sum: '<S290>/Sum5' incorporates:
    //   Outport: '<S289>/bpp'

    FixedwingModel_B.Sum5 = FixedwingModel_P.bpp_Y0_g;

    // End of SystemInitialize for SubSystem: '<S281>/For Iterator Subsystem'

    // SystemInitialize for Sum: '<S281>/Sum1' incorporates:
    //   Outport: '<S281>/bt,bp,br,bpp'

    FixedwingModel_B.Sum1_k[0] = FixedwingModel_P.btbpbrbpp_Y0[0];
    FixedwingModel_B.Sum1_k[1] = FixedwingModel_P.btbpbrbpp_Y0[1];
    FixedwingModel_B.Sum1_k[2] = FixedwingModel_P.btbpbrbpp_Y0[2];
    FixedwingModel_B.Sum1_k[3] = FixedwingModel_P.btbpbrbpp_Y0[3];

    // End of SystemInitialize for SubSystem: '<S273>/Compute magnetic vector in spherical coordinates' 

    // SystemInitialize for Enabled SubSystem: '<S109>/Hugw(z)'
    // '<S231>:1:6' hFault=false;
    // '<S231>:1:9' fParam=zeros(20,1);
    // '<S61>:1:6' hFault=false;
    // '<S61>:1:9' fParam=zeros(20,1);
    // '<S57>:1:6' hFault=false;
    // '<S57>:1:9' fParam=zeros(20,1);
    // '<S58>:1:6' hFault=false;
    // '<S58>:1:9' fParam=zeros(20,1);
    // '<S59>:1:6' hFault=false;
    // '<S59>:1:9' fParam=zeros(20,1);
    // '<S60>:1:6' hFault=false;
    // '<S60>:1:9' fParam=zeros(20,1);
    FixedwingModel_Hugwz_Init(&FixedwingModel_B.Hugwz_l,
      &FixedwingModel_DW.Hugwz_l, &FixedwingModel_P.Hugwz_l);

    // End of SystemInitialize for SubSystem: '<S109>/Hugw(z)'

    // SystemInitialize for Enabled SubSystem: '<S109>/Hvgw(z)'
    FixedwingModel_Hvgwz_Init(&FixedwingModel_B.Hvgwz_o,
      &FixedwingModel_DW.Hvgwz_o, &FixedwingModel_P.Hvgwz_o);

    // End of SystemInitialize for SubSystem: '<S109>/Hvgw(z)'

    // SystemInitialize for Enabled SubSystem: '<S109>/Hwgw(z)'
    FixedwingModel_Hwgwz_Init(&FixedwingModel_B.Hwgwz_j,
      &FixedwingModel_DW.Hwgwz_j, &FixedwingModel_P.Hwgwz_j);

    // End of SystemInitialize for SubSystem: '<S109>/Hwgw(z)'

    // SystemInitialize for MATLAB Function: '<S28>/MATLAB Function'
    std::memcpy(&FixedwingModel_DW.state_a[0], &tmp_0[0], 625U * sizeof(uint32_T));
    FixedwingModel_DW.method = 7U;
    FixedwingModel_DW.state = 1144108930U;
    FixedwingModel_DW.state_b[0] = 362436069U;
    FixedwingModel_DW.state_b[1] = 521288629U;

    // '<S62>:1:12' t0=0;
    // '<S62>:1:17' isInGust=0;
    // '<S62>:1:22' t1=2;
    FixedwingModel_DW.t1 = 2.0;

    // '<S62>:1:27' a=0.5;
    FixedwingModel_DW.a = 0.5;

    // '<S62>:1:32' ang=pi/2;
    FixedwingModel_DW.ang = 1.5707963267948966;

    // SystemInitialize for Enabled SubSystem: '<S70>/Hugw(z)'
    FixedwingModel_Hugwz_Init(&FixedwingModel_B.Hugwz, &FixedwingModel_DW.Hugwz,
      &FixedwingModel_P.Hugwz);

    // End of SystemInitialize for SubSystem: '<S70>/Hugw(z)'

    // SystemInitialize for Enabled SubSystem: '<S70>/Hvgw(z)'
    FixedwingModel_Hvgwz_Init(&FixedwingModel_B.Hvgwz, &FixedwingModel_DW.Hvgwz,
      &FixedwingModel_P.Hvgwz);

    // End of SystemInitialize for SubSystem: '<S70>/Hvgw(z)'

    // SystemInitialize for Enabled SubSystem: '<S70>/Hwgw(z)'
    FixedwingModel_Hwgwz_Init(&FixedwingModel_B.Hwgwz, &FixedwingModel_DW.Hwgwz,
      &FixedwingModel_P.Hwgwz);

    // End of SystemInitialize for SubSystem: '<S70>/Hwgw(z)'

    // SystemInitialize for IfAction SubSystem: '<S151>/Negative Trace'
    // '<S232>:1:6' hFault=false;
    // '<S232>:1:9' fParam=zeros(20,1);
    FixedwingMod_NegativeTrace_Init(&FixedwingModel_DW.NegativeTrace);

    // End of SystemInitialize for SubSystem: '<S151>/Negative Trace'

    // SystemInitialize for Merge: '<S151>/Merge'
    FixedwingModel_B.Merge_m[0] = FixedwingModel_P.Merge_InitialOutput_h[0];
    FixedwingModel_B.Merge_m[1] = FixedwingModel_P.Merge_InitialOutput_h[1];
    FixedwingModel_B.Merge_m[2] = FixedwingModel_P.Merge_InitialOutput_h[2];
    FixedwingModel_B.Merge_m[3] = FixedwingModel_P.Merge_InitialOutput_h[3];

    // SystemInitialize for Enabled SubSystem: '<S17>/Distance into gust (x)'
    // InitializeConditions for Integrator: '<S20>/Distance into Gust (x) (Limited to gust length d)' 
    FixedwingModel_X.DistanceintoGustxLimitedtogus_i =
      FixedwingModel_P.DistanceintoGustxLimitedtogustl;

    // SystemInitialize for Integrator: '<S20>/Distance into Gust (x) (Limited to gust length d)' incorporates:
    //   Outport: '<S20>/x'

    FixedwingModel_B.DistanceintoGustxLimitedtogustl = FixedwingModel_P.x_Y0;

    // End of SystemInitialize for SubSystem: '<S17>/Distance into gust (x)'

    // SystemInitialize for Enabled SubSystem: '<S17>/Distance into gust (y)'
    Fixedwin_Distanceintogusty_Init(&FixedwingModel_B.Distanceintogusty,
      &FixedwingModel_P.Distanceintogusty, &FixedwingModel_X.Distanceintogusty);

    // End of SystemInitialize for SubSystem: '<S17>/Distance into gust (y)'

    // SystemInitialize for Enabled SubSystem: '<S17>/Distance into gust (z)'
    Fixedwin_Distanceintogusty_Init(&FixedwingModel_B.Distanceintogustz,
      &FixedwingModel_P.Distanceintogustz, &FixedwingModel_X.Distanceintogustz);

    // End of SystemInitialize for SubSystem: '<S17>/Distance into gust (z)'

    // SystemInitialize for Enabled SubSystem: '<S69>/Hpgw'
    FixedwingModel_Hpgw_Init(&FixedwingModel_B.Hpgw, &FixedwingModel_DW.Hpgw,
      &FixedwingModel_P.Hpgw);

    // End of SystemInitialize for SubSystem: '<S69>/Hpgw'

    // SystemInitialize for Enabled SubSystem: '<S69>/Hqgw'
    FixedwingModel_Hqgw_Init(&FixedwingModel_B.Hqgw, &FixedwingModel_DW.Hqgw,
      &FixedwingModel_P.Hqgw);

    // End of SystemInitialize for SubSystem: '<S69>/Hqgw'

    // SystemInitialize for Enabled SubSystem: '<S69>/Hrgw'
    FixedwingModel_Hrgw_Init(&FixedwingModel_B.Hrgw, &FixedwingModel_DW.Hrgw,
      &FixedwingModel_P.Hrgw);

    // End of SystemInitialize for SubSystem: '<S69>/Hrgw'

    // SystemInitialize for Enabled SubSystem: '<S108>/Hpgw'
    FixedwingModel_Hpgw_Init(&FixedwingModel_B.Hpgw_h, &FixedwingModel_DW.Hpgw_h,
      &FixedwingModel_P.Hpgw_h);

    // End of SystemInitialize for SubSystem: '<S108>/Hpgw'

    // SystemInitialize for Enabled SubSystem: '<S108>/Hqgw'
    FixedwingModel_Hqgw_Init(&FixedwingModel_B.Hqgw_p, &FixedwingModel_DW.Hqgw_p,
      &FixedwingModel_P.Hqgw_p);

    // End of SystemInitialize for SubSystem: '<S108>/Hqgw'

    // SystemInitialize for Enabled SubSystem: '<S108>/Hrgw'
    FixedwingModel_Hrgw_Init(&FixedwingModel_B.Hrgw_a, &FixedwingModel_DW.Hrgw_a,
      &FixedwingModel_P.Hrgw_a);

    // End of SystemInitialize for SubSystem: '<S108>/Hrgw'

    // SystemInitialize for Enabled SubSystem: '<S527>/Hpgw'
    // InitializeConditions for Integrator: '<S538>/pgw_p'
    FixedwingModel_X.pgw_p_CSTATE[0] = FixedwingModel_P.pgw_p_IC;

    // SystemInitialize for Product: '<S538>/sigma_w' incorporates:
    //   Outport: '<S538>/pgw'

    FixedwingModel_B.sigma_w[0] = FixedwingModel_P.pgw_Y0;

    // End of SystemInitialize for SubSystem: '<S527>/Hpgw'

    // SystemInitialize for Enabled SubSystem: '<S527>/Hqgw'
    // InitializeConditions for Integrator: '<S539>/qgw_p'
    FixedwingModel_X.qgw_p_CSTATE[0] = FixedwingModel_P.qgw_p_IC;

    // SystemInitialize for Product: '<S539>/w' incorporates:
    //   Outport: '<S539>/qgw'

    FixedwingModel_B.w_d0[0] = FixedwingModel_P.qgw_Y0;

    // End of SystemInitialize for SubSystem: '<S527>/Hqgw'

    // SystemInitialize for Enabled SubSystem: '<S527>/Hrgw'
    // InitializeConditions for Integrator: '<S540>/rgw_p'
    FixedwingModel_X.rgw_p_CSTATE[0] = FixedwingModel_P.rgw_p_IC;

    // SystemInitialize for UnaryMinus: '<S540>/Unary Minus' incorporates:
    //   Outport: '<S540>/rgw'

    FixedwingModel_B.UnaryMinus[0] = FixedwingModel_P.rgw_Y0;

    // End of SystemInitialize for SubSystem: '<S527>/Hrgw'

    // SystemInitialize for Enabled SubSystem: '<S527>/Hpgw'
    // InitializeConditions for Integrator: '<S538>/pgw_p'
    FixedwingModel_X.pgw_p_CSTATE[1] = FixedwingModel_P.pgw_p_IC;

    // SystemInitialize for Product: '<S538>/sigma_w' incorporates:
    //   Outport: '<S538>/pgw'

    FixedwingModel_B.sigma_w[1] = FixedwingModel_P.pgw_Y0;

    // End of SystemInitialize for SubSystem: '<S527>/Hpgw'

    // SystemInitialize for Enabled SubSystem: '<S527>/Hqgw'
    // InitializeConditions for Integrator: '<S539>/qgw_p'
    FixedwingModel_X.qgw_p_CSTATE[1] = FixedwingModel_P.qgw_p_IC;

    // SystemInitialize for Product: '<S539>/w' incorporates:
    //   Outport: '<S539>/qgw'

    FixedwingModel_B.w_d0[1] = FixedwingModel_P.qgw_Y0;

    // End of SystemInitialize for SubSystem: '<S527>/Hqgw'

    // SystemInitialize for Enabled SubSystem: '<S527>/Hrgw'
    // InitializeConditions for Integrator: '<S540>/rgw_p'
    FixedwingModel_X.rgw_p_CSTATE[1] = FixedwingModel_P.rgw_p_IC;

    // SystemInitialize for UnaryMinus: '<S540>/Unary Minus' incorporates:
    //   Outport: '<S540>/rgw'

    FixedwingModel_B.UnaryMinus[1] = FixedwingModel_P.rgw_Y0;

    // End of SystemInitialize for SubSystem: '<S527>/Hrgw'

    // InitializeConditions for root-level periodic continuous states
    {
      int_T rootPeriodicContStateIndices[3] = { 8, 9, 10 };

      real_T rootPeriodicContStateRanges[6] = { -3.1415926535897931,
        3.1415926535897931, -3.1415926535897931, 3.1415926535897931,
        -3.1415926535897931, 3.1415926535897931 };

      (void) std::memcpy((void*)FixedwingModel_PeriodicIndX,
                         rootPeriodicContStateIndices,
                         3*sizeof(int_T));
      (void) std::memcpy((void*)FixedwingModel_PeriodicRngX,
                         rootPeriodicContStateRanges,
                         6*sizeof(real_T));
    }
  }
}

// Model terminate function
void MulticopterModelClass::terminate()
{
  // (no terminate code required)
}

// Constructor
MulticopterModelClass::MulticopterModelClass() :
  FixedwingModel_U(),
  FixedwingModel_Y(),
  FixedwingModel_B(),
  FixedwingModel_DW(),
  FixedwingModel_X(),
  FixedwingModel_M()
{
  // Currently there is no constructor body generated.
}

// Destructor
MulticopterModelClass::~MulticopterModelClass()
{
  // Currently there is no destructor body generated.
}

// Real-Time Model get method
RT_MODEL_FixedwingModel_T * MulticopterModelClass::getRTM()
{
  return (&FixedwingModel_M);
}

//
// File trailer for generated code.
//
// [EOF]
//
